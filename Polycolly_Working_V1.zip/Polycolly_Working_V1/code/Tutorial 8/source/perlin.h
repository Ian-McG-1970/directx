#ifndef OLI_PERLIN_H
#define OLI_PERLIN_H

#include <math.h>

// based on : 
// http://freespace.virgin.net/hugo.elias/models/m_perlin.htm
class CPerlin
{
public:
	static const float Linear_Interpolate(const float a, const float b, const float x)
	{
		return a*(1.0f - x) + b * x;
	}

	static const float Cosine_Interpolate(const float a, const float b, const float x)
	{
		const float pi = (float)atan(1.0f) * 4.0f;
		const float ft = x * pi;
		const float f  = (1 - cosf(ft)) * 0.5f;
		return  a*(1.0f - f) + b * f;
	}

	static const float Cubic_Interpolate(const float v0, const float v1, const float v2, const float v3, const float x)
	{
		const float P = (v3 - v2) - (v0 - v1);
		const float Q = (v0 - v1) - P;
		const float R = v2 - v0;
		const float S = v1;
		const float x2 = x*x;
		const float x3 = x2*x;
		return P*x3 + Q*x2 + R*x + S;
	}

	static const float Noise1(const int x, const int y)
	{
		int n = x + y * 57;
		n = (n<<13) ^ n;
		const int d = (n * (n*n * 15731 + 789221) + 1376312589) & 0x7fffffff;
		return 1.0f - (float) d / 1073741824.0f;
	}

	static const float SmoothNoise_1(const float x, const float y)
	{
		const float corners = ( Noise1(x-1, y-1) + Noise1(x+1, y-1) + Noise1(x-1, y+1) + Noise1(x+1, y+1) ) / 16.0f;
		const float sides   = ( Noise1(x-1, y)   + Noise1(x+1, y)   + Noise1(x, y-1)   + Noise1(x, y+1) ) /  8.0f;
		const float center  =  Noise1(x, y) / 4.0f;
		return corners + sides + center;
	}
	
	static const float InterpolatedNoise_1(const float x, const float y)
	{
		const int		integer_Y    = int(y);
		const int		integer_X    = int(x);
		const float	fractional_X = x - integer_X;
		const float	fractional_Y = y - integer_Y;
		const float v1 = SmoothNoise_1(integer_X,     integer_Y);
		const float v2 = SmoothNoise_1(integer_X + 1, integer_Y);
		const float v3 = SmoothNoise_1(integer_X,     integer_Y + 1);
		const float v4 = SmoothNoise_1(integer_X + 1, integer_Y + 1);
		const float i1 = Cosine_Interpolate(v1 , v2 , fractional_X);
		const float i2 = Cosine_Interpolate(v3 , v4 , fractional_X);
		return Cosine_Interpolate(i1 , i2 , fractional_Y);
	}

	static const float PerlinNoise_2D(const float x, const float y, const float persistence=0.25f, const int number_of_octaves=5)
	{
		const float p		= persistence;
		const int   n		= number_of_octaves - 1;
		static const float pi = (float)atanf(1.0f) * 4.0f;
		float total = 0.0f;

		for (int i=0; i<n; ++i)
		{
			const float frequency = (float) pow(2, i);
			const float amplitude = (float) pow(p, i);
			total += InterpolatedNoise_1(x * frequency, y * frequency) * amplitude;
		}
		return total;
	}
};

#endif OLI_PERLIN_H