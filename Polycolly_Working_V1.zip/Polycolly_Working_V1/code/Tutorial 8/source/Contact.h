
#ifdef ASURA_USE_PRAGMA_ONCE
	#pragma once
#endif

#ifndef __CONTACT_H__
#define __CONTACT_H__

#include "Vector.h"

class CContact
{
public:
	enum { eMaxContacts = 2 };

	class CBody* m_pxBodies [2];
	Vector       m_xContacts[eMaxContacts][2];
	Vector		 m_xNormal;
	float		 m_t;
	int			 m_iNumContacts;
	
	CContact();
	
	CContact(const Vector* CA, const Vector* CB, const int iCnum, 
			 const Vector& N, const float t, 
			 CBody* pxBodyA, CBody* pxBodyB);

	void Reset();
		
	void Render(void) const;

	class CBody* GetBody(const int i) { return m_pxBodies[i]; }

	void Solve();
	
private:
	void ResolveCollision();
	void ResolveOverlap  ();

	void ResolveCollision(const Vector& CA, const Vector& CB);
	void ResolveOverlap  (const Vector& CA, const Vector& CB);
	void AddContactPair	 (const Vector& CA, const Vector& CB);
};


class CMaterial
{
public:
	CMaterial(float fCoF = 0.2f, float fCoR = 0.3f, float fCoS = 0.4f, float fSep=0.5f)
	: m_fCoF(fCoF)
	, m_fCoR(fCoR)
	, m_fCoS(fCoS)
	, m_fSep(fSep)
	{}

	void SetSeparation		(const float fSep) { m_fSep = fSep; }
	void SetFriction		(const float fCoF) { m_fCoF = fCoF; }
	void SetStaticFriction	(const float fCoS) { m_fCoS = fCoS; }
	void SetRestitution		(const float fCoR) { m_fCoR = fCoR; }

	const float GetSeparation		() const { return m_fSep; }
	const float GetFriction		() const { return m_fCoF; }
	const float GetStaticFriction	() const { return m_fCoS; }
	const float GetRestitution	() const { return m_fCoR; }

private:
	float m_fCoF, m_fCoR, m_fSep, m_fCoS;
};

// HACK : use a shared material for all objects
extern CMaterial s_xContactMaterial;

#endif//__CONTACT_H__
