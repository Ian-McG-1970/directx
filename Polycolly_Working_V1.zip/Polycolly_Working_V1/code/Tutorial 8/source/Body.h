#ifndef OLI_BODY_H
#define OLI_BODY_H

#include "Vector.h"
#include "Matrix.h"
#include "Polygon.h"

class CBody
{
public:
	CBody();
	CBody(const Vector& xPosition, float fDensity, float width, float height);
	CBody(const Vector& Min, const Vector& Max, float fDensity);
	void Initialise(const Vector& xPosition, const float fDensity, Vector* axVertices, const int iNumVertices);

	void Shutdown();
	
	~CBody();

	void AddForce(const Vector& F);
	
	void AddForce(const Vector& F, const Vector& P);
	
	const bool Collide(CBody& Body, const float dt);
	
	const bool IntersectSegment(const Vector& Start, const Vector& End, const float fDist, Vector& N, float& t) const;

	void Update(const float dt);

	void Render() const;

	void SetOrientation(const float fAngle);
	void SetDensity(const float fDensity);

	const bool IsUnmovable() const { return (m_fMass < 0.0001f); }
	Vector& GetPosition		() { return m_xPosition; }
	Vector& GetLinVelocity	() { return m_xVelocity; }
	float&  GetAngVelocity  () { return m_fAngVelocity; }
	float&  GetMass			() { return m_fMass; }
	float&  GetInvMass		() { return m_fInvMass; }
	float&  GetInertia		() { return m_fInertia; }
	float&  GetInvInertia	() { return m_fInvInertia; }
		
	const Vector& GetPosition	() const { return m_xPosition; }
	const Vector& GetLinVelocity() const { return m_xVelocity; }
	const float GetAngVelocity		() const { return m_fAngVelocity; }
	const float GetMass				() const { return m_fMass; }
	const float GetInvMass			() const { return m_fInvMass; }
	const float GetInvInertia			() const { return m_fInvInertia; }

	void SetCollisionCallback(bool (*fptrHandlePlayerContact)(const Vector& N, float& t, CBody* pxOtherBody));

protected:
	void ProcessCollision(CBody& xBody, const Vector& N, const float t);
	void ProcessOverlap  (CBody& xBody, const Vector& MTD);

	Vector* m_axVertices;
	int     m_iNumVertices;
	
	Vector	m_xVelocity;
	Vector	m_xPosition;

	float	m_fDensity;
	float	m_fMass;
	float   m_fInertia;
	float	m_fInvMass;
	float   m_fInvInertia;

	float m_fOrientation;
	float m_fAngVelocity;
	Matrix m_xOrientation;

	Vector m_xNetForce;
	float  m_fNetTorque;

	bool (*m_fptrHandlePlayerContact)(const Vector& N, float& t, CBody* pxOtherBody);

};

#endif OLI_BODY_H