
#ifdef ASURA_USE_PRAGMA_ONCE
	#pragma once
#endif

#ifndef __MATRIX_H__
#define __MATRIX_H__


#include "Vector.h"

class Matrix
{
public:

	union
	{
		struct
		{
			float e11;
			float e12;
			float e21;
			float e22;
		};

		float e[2][2];
	};

	Matrix(const float _e11, const float _e12, const float _e21, const float _e22)
	: e11(_e11)
	, e12(_e12)
	, e21(_e21)
	, e22(_e22)
	{}
	
	Matrix()
	{}

	Matrix(const float angle)
	{
		const float c = cosf(angle);
		const float s = sinf(angle);

		e11 = c; e12 = s;
		e21 =-s; e22 = c;
	}

	const float  operator()(const int i, const int j) const { return e[i][j]; }
	float& operator()(const int i, const int j)       { return e[i][j]; }

	const Vector& operator[](const int i) const
	{
		return reinterpret_cast<const Vector&>(e[i][0]);
	}
	
	Vector& operator[](const int i)
	{
		return reinterpret_cast<Vector&>(e[i][0]);
	}		

	static Matrix Identity()
	{
		static const Matrix T(1.0f, 0.0f, 0.0f, 1.0f);
		return T;
	}

	static Matrix Zer0()
	{
		static const Matrix T(0.0f, 0.0f, 0.0f, 0.0f);
		return T;
	}


	Matrix Tranpose() const
	{
		Matrix T;
		T.e11 = e11;
		T.e21 = e12;
		T.e12 = e21;
		T.e22 = e22;
		return T;
	}

	Matrix operator * (const Matrix& M) const 
	{
		Matrix T;
		T.e11 = e11 * M.e11 + e12 * M.e21;
		T.e21 = e21 * M.e11 + e22 * M.e21;
		T.e12 = e11 * M.e12 + e12 * M.e22;
		T.e22 = e21 * M.e12 + e22 * M.e22;		
		return T;
	}

	Matrix operator ^ (const Matrix& M) const 
	{
		Matrix T;
		T.e11 = e11 * M.e11 + e12 * M.e12;
		T.e21 = e21 * M.e11 + e22 * M.e12;
		T.e12 = e11 * M.e21 + e12 * M.e22;
		T.e22 = e21 * M.e21 + e22 * M.e22;		
		return T;
	}

	inline Matrix operator * (const float s) const
	{
		Matrix T;
		T.e11 = e11 * s;
		T.e21 = e21 * s;
		T.e12 = e12 * s;
		T.e22 = e22 * s;	
		return T;
	}

};
#endif//__MATRIX_H__