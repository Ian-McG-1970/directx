#include <stdio.h>
#include "fileLoader.h"

const bool cFileLoader::load( const char *path )
{
	unload( );

	FILE *file = NULL;
	fopen_s( &file, path, "rb" ); // load the obj file
	if (file == NULL)
	{
		return false;
	}

	fseek( file, 0, SEEK_END ); // find the file size
	fpos_t size = 0;
	fgetpos( file, &size );
	bytes = (int)size;
	fseek( file, 0, SEEK_SET );

	memory = new char[ bytes + 1 ]; // allocate data for this file

	if ( fread( memory, 1, bytes, file ) != bytes ) // read in the entire file
	{
		delete [] memory;
		memory = NULL;
	}
	
	memory[ bytes ] = '\0'; // add an EOF character

	fclose( file ); // close this file after we are done with it
	return (memory != NULL);
}

const void cFileLoader::unload( void )
{
	if (memory != NULL)
	{
		delete[] memory;
	}
	memory = NULL;
	bytes  = 0;
}

const bool cFileLoader::isOpen( void )
{
	return ( memory != NULL );
}
