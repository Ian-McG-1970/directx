#ifndef MAP
#define MAP

#include "d3d8_screen.h"
#include <vector>

struct sIndex
{
	int v1,v2,v3;
};

struct sVertex
{
	D3DXVECTOR3 pos;
	D3DXVECTOR3 normal;
	D3DXVECTOR3 uv;
	D3DXCOLOR colour;
};

struct cMesh
{
	cMesh(void):
		index(),
		vertex()
	{ }

	~cMesh()
	{
		index.clear();
		vertex.clear();
	}

	std::vector <sIndex > index;
	std::vector <sVertex> vertex;
};

class Map
{
public:
	cMesh mesh;

	const void unload(void);
	const bool Load(char *);
	const void draw(void);

protected:
	const void postLoad(void);
	unsigned int vbo;
	signed int ibo;
};

#endif
