#include <stdio.h>

#include "map.h"

extern FILE *file;

extern bool mesh_loadProc( cMesh &mesh, char *path );

const void Map::unload(void)
{
}

const bool Map::Load(char *path) // load in an obj file from a file
{
	unload();

	if (mesh_loadProc(mesh, path)==false)
	{
		fprintf(file,"error %s\n",path);
		return false;
	}
	fprintf(file,"ok %s\n",path);

	postLoad(); // upload to OpenGL
	return true;
}

const void Map::postLoad(void)
{
	fprintf(file,"postload %i %i\n",mesh.vertex.size(),mesh.index.size());
	if (mesh.vertex.size() == 0 || mesh.index.size() == 0)
	{
		return;
	}

	//	glGenBuffers( 1, &vbo );
	//	glBindBuffer( GL_ARRAY_BUFFER, vbo );
	//	glBufferData(GL_ARRAY_BUFFER, mesh.vertex.sizeBytes( ), &( mesh.vertex[0] ), GL_STATIC_DRAW );

	//	glGenBuffers( 1, &ibo );
	//	glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, ibo );
	//	glBufferData( GL_ELEMENT_ARRAY_BUFFER, mesh.index.sizeBytes(), &( mesh.index[0] ), GL_STATIC_DRAW );
}

const void Map::draw(void)
{
	if(mesh.vertex.size() == 0 || mesh.index.size() == 0)
	{
		return;
	}

	//	glBindBuffer( GL_ARRAY_BUFFER, vbo );
	//	glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, ibo );

	//	glEnableVertexAttribArray( 0 );
	//	glVertexAttribPointer( 0, 3, GL_FLOAT, GL_FALSE, sizeof( sVertex ), (void*)0 );

	//	glEnableVertexAttribArray( 1 );
	//	glVertexAttribPointer( 1, 3, GL_FLOAT, GL_FALSE, sizeof( sVertex ), (void*)12 );

	//	glEnableVertexAttribArray( 2 );
	//  glVertexAttribPointer( 2, 3, GL_FLOAT, GL_FALSE, sizeof( sVertex ), (void*)24 );

	//	glDrawElements( GL_TRIANGLES, mesh.index.sizeBytes(), GL_UNSIGNED_SHORT, 0 );
}
