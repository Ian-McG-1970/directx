#include <math.h>
#include <stdio.h>
#include "engine.h"
#include "d3d8_screen.h"
#include "di_mouse.h"
#include "quake3bsp.h"
#include "map.h"

extern HWND hwnd;
extern Mouse mouse;
extern Screen screen;
extern CQuake3BSP g_bsp;
extern Map map;

extern FILE *file;

const void Engine::RenderLevel()
{
	for(int i=0; i!=map.mesh.index.size(); ++i)
	{
		const int v1=map.mesh.index[i].v1;
		const int v2=map.mesh.index[i].v3;
		const int v3=map.mesh.index[i].v2;
		if (screen.IsTriangleInsideFrustum(map.mesh.vertex[v1].pos,map.mesh.vertex[v2].pos,map.mesh.vertex[v3].pos)==true)
		{
			screen.Triangle(map.mesh.vertex[v1].pos,map.mesh.vertex[v2].pos,map.mesh.vertex[v3].pos,map.mesh.vertex[v1].colour);
		}
	}
}

const void Engine::Setup()
{
	fprintf(file,"engine setup\n");
	Location = D3DXVECTOR3(150.0f, 200.0f, 150.0f); //	if (!g_bsp.LoadBSP("tutorial.bsp"))
	Direction = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	Speed = 0.0f;
}

Engine::~Engine()
{
	fprintf(file,"engine shutdown\n");
}

const void Engine::Move(D3DXVECTOR3 &location, const D3DXVECTOR3 &direction, const float speed)
{
	D3DXMATRIX  matTmp;
	D3DXMatrixRotationYawPitchRoll(&matTmp, direction.y, direction.x, direction.z);      
	D3DXVECTOR4 tmp;
	D3DXVec3Transform(&tmp, &D3DXVECTOR3(0.0f,0.0f,1.0f), &matTmp);
	location = D3DXVECTOR3(tmp.x, tmp.y/*0.0f*/, tmp.z) *speed;
}

const void Engine::Update()
{
	mouse.Update();
	if (mouse.LB!=0 && mouse.RB!=0)
	{
		PostMessage(hwnd, WM_CLOSE, 0, 0);
		return;
	}
	Direction.x -= mouse.Y*0.003f;
	Direction.y += mouse.X*0.003f;
	if (mouse.LB!=0)
	{
		Speed=4.0f;
	}
	else if (mouse.RB!=0)
	{
		Speed=-2.0f;
	}
	else
	{
		Speed=0.0f;
	}

	Move(Movement, Direction, Speed);
	Location+=Movement;

	screen.View_Matrix(Location, Direction);

	screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(BACKGROUND, BACKGROUND, BACKGROUND), 1.0f, 0);
	screen.g_pd3dDevice->SetFVF(D3DFVF_D3D_VERTEX);
	screen.g_pd3dDevice->BeginScene();

	RenderLevel();

	sprintf(screen.string,"xyz %5.1f %5.1f %5.1f\n",Location.x,Location.y,Location.z);
	screen.DrawText(5,5,D3DCOLOR_XRGB(160,160,160));

	screen.g_pd3dDevice->EndScene();
	screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
}

