#pragma once

class cFileLoader
{
public:

	cFileLoader( void ) :
		memory( NULL ),
		bytes ( 0    )
	{
	}

	cFileLoader( const char *path ) :
		memory( NULL ),
		bytes ( 0    )
	{
		load( path );
	}

	~cFileLoader( void )
	{
		unload( );
	}

	const void unload( void       );
	const bool load ( const char *path );
	const bool isOpen( void );

	char *memory;
	int   bytes;
};
