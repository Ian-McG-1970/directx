#pragma once

typedef   signed long long s64;
typedef unsigned long long u64;
typedef   signed int	   s32;
typedef unsigned int       u32;
typedef unsigned short     u16;
typedef unsigned char      byte;

#define NULL 0

const float C_PI  = 3.14159265359f;
const float C_PI2 = 3.14159265359f * 2.0f;

class cParser
{
public:
	enum
	{
		MODE_SKIP_LINES         = 1,
		MODE_SKIP_COMMENTS      = 2,
		MODE_SKIP_WHITESPACE    = 4
	};

	cParser( void *stream, int mode = MODE_SKIP_WHITESPACE )
        : _ptr   ( (byte*) stream )
        , _origin( (byte*) stream )
        , mode( mode )
	{ }

 const void setMode( const int flag )
 {
	 mode = flag;
 }

 const bool atEOF( void )
 {
	 return *_ptr == '\0';
 }

 const void reset( void )
 {
	 _ptr = _origin;
 }

 const bool canMatch ( const char *string );
 const void skipFluff ( void );
 const void skipLine ( void );
 const void skipToNext ( const char ascii );
 const void skipSymbol ( const char *extra="" );
 const void skipString ( const char *extra="/." );
 const void expect ( const char ascii );
 const void expect ( const char *string );
 const int readInt ( const bool skipws=true );
 const float readFloat( const bool skipws=true );

private:
	int mode;
	byte *_origin;
	byte *_ptr;

};