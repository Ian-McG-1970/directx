#include <assert.h>
#include <math.h>
#include <stdio.h>

#include "map.h"
#include "fileLoader.h"
#include "parser.h"
//#include "list.h"
//#include "log.h"

extern FILE *file;

// proc_parseModel
//  proc_parseSurface
//   proc_parseVertex
//   mesh.index.alloc


static void proc_parseVertex( cParser &fileopen, cMesh &mesh )
{
	fileopen.expect( "(" );

	sVertex v;

	v.pos.z = fileopen.readFloat( );
	v.pos.x = fileopen.readFloat( );
	v.pos.y = fileopen.readFloat( );

	v.uv.x = fileopen.readFloat( );
	v.uv.y = fileopen.readFloat( );

	v.normal.x = fileopen.readFloat( );
	v.normal.y = fileopen.readFloat( );
	v.normal.z = fileopen.readFloat( );

	v.colour = ((int)v.pos.x<<16) + ((int)v.pos.y<<8) + ((int)v.pos.z);

	mesh.vertex.push_back(v);

	fileopen.expect( ")" );
}

static void proc_parseSurface( cParser &fileopen, cMesh &mesh )
{
	fileopen.expect( "{" );
	
	fileopen.skipString( ); // material
	const int nVertices = fileopen.readInt( );
	const int nIndices  = fileopen.readInt( );
	
	int tIdx = mesh.vertex.size( );
	
	for ( int i=0; i<nVertices; ++i )
	{
		proc_parseVertex( fileopen, mesh );
	}

	if (nIndices % 3 != 0)
	{
		assert(!"indices not mod3");
	}

	for ( int i=0; i<nIndices; i+=3 )
	{
		sIndex idx;
		idx.v1 = fileopen.readInt( ) + tIdx;
		idx.v2 = fileopen.readInt( ) + tIdx;
		idx.v3 = fileopen.readInt( ) + tIdx;
		mesh.index.push_back(idx);
	}
	fileopen.expect( "}" );
}

static void proc_parseModel( cParser &fileopen, cMesh &mesh )
{
	fileopen.expect( "{" );
	fileopen.skipString( ); // name
	
	const int nSurfaces = fileopen.readInt( );    // surfaces
	
	for ( int i=0; i<nSurfaces; i++ )
	{
		proc_parseSurface( fileopen, mesh );
	}
	
	fileopen.expect( "}" );
}

static void proc_parse( cParser &fileopen, cMesh &mesh ) // here we parse the entire file and load in its attributes
{
	fileopen.reset( );
	fileopen.skipSymbol( ); // proc file name

	while ( fileopen.canMatch( "model" ) )
	{
		proc_parseModel( fileopen, mesh );
	}
}

extern bool mesh_loadProc( cMesh &mesh, char *path )
{
	cFileLoader fileopen( path );
	if (! fileopen.isOpen( ) )
	{
		fprintf(file,"unable to open file" );
		return false;
	}
	
	cParser reader( fileopen.memory, cParser::MODE_SKIP_LINES | cParser::MODE_SKIP_COMMENTS | cParser::MODE_SKIP_WHITESPACE );
	proc_parse( reader, mesh );
    
	return true;
}
