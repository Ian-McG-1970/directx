#include "parser.h"
#include <assert.h>

const bool cParser::canMatch(const char *string)
{
	skipFluff();

	for (byte *x = _ptr; ; )
	{
		if (*string == '\0')
		{
			_ptr = x;
			return true;
		}

		if (*x == '\0')		
		{ 
			break; 
		}
		if (*x != *string)	
		{ 
			break; 
		}

		++x;
		++string;
	}
	return false;
}

const void cParser::skipFluff(void)
{	
	for (int commentLevel = 0; _ptr!='\0'; ++_ptr)
	{
		const char ch = *_ptr;

		if (mode & MODE_SKIP_COMMENTS)
		{
			if ( (ch == '/') && (_ptr[1] == '*') ) // enter a block comment
			{
				++_ptr;
				++commentLevel;
				continue;
			}
			if ( (ch == '*') && (_ptr[1] == '/') ) // exit a block comment
			{
				++_ptr;
				--commentLevel;
				continue;
			}

			if (commentLevel > 0)
			{
				continue;
			}
		}

		if (mode & MODE_SKIP_LINES)
		{
			if (ch == '\n' || ch == '\r')
			{
				continue;
			}
		}

		if (mode & MODE_SKIP_WHITESPACE)
		{
			if (ch == ' ' || ch == '\t')
			{
				continue;
			}
		}
		break;
	}
}

const void cParser::skipLine( void )
{
	for (; _ptr != '\0'; ++_ptr)
	{
		if (*_ptr == '\n')
		{
			++_ptr;
			return;
		}
	}
}

const void cParser::skipString( const char *extra )
{
	skipFluff( );
	expect( "\"" );
	skipSymbol( extra );
	expect( "\"" );
}

const void cParser::skipToNext( const char ascii )
{
	for (; *_ptr != '\0'; ++_ptr )
	{
		if ( *_ptr == ascii )
		{
			++_ptr;
			return;
		}
	}
}

const void cParser::skipSymbol( const char *extra )
{
	skipFluff( );

	for ( bool first=true; ; ++_ptr, first=false )
	{
		const char ch = *_ptr;
		bool valid = false;

		valid |= ( ch >= 'a' && ch <= 'z' );
		valid |= ( ch >= 'A' && ch <= 'Z' );
		valid |= ( ch >= '0' && ch <= '9' )&(!first);
		valid |= ( ch == '_' ); 
        
		for ( int i=0; extra[i]!='\0'; ++i )
		{
			if ( ch == extra[i] )
			{
				valid = true;
				break;
			}
		}
        
		if (!valid)
		{
			break;
		}
	}
}

const void cParser::expect(const char ascii)
{
	if (*_ptr == ascii)
	{
		++_ptr;
	}
	else
	{
		assert(!"unexpected item");
	}
}

const void cParser::expect( const char *_str )
{
	skipFluff( );
	int i=0;
	for ( ;; ++i )
	{
		if (_str[i] == '\0') 
		{ 
			break; 
		}
		if ( _str[i] != _ptr[i] )
		{
			assert(! "match cant be made" );
		}
	}
	_ptr += i;
}

const int cParser::readInt( const bool skipws )
{
	if (skipws)
	{
		skipFluff();
	}
	
	int value = 0;
	for ( ; ; ++_ptr )
	{
		const char c = *_ptr;
		if (c >= '0' && c <= '9')
		{
			value = (value * 10) + (c - '0');
		}
		else
		{
			break;
		}
	}
	return value;
}

const float cParser::readFloat( const bool skipws )
{
	if (skipws)
	{
		skipFluff();
	}

	int  invert = 1;
	if ( *_ptr == '-' ) 
	{ 
		invert=-1; 
		++_ptr; 
	}

	s64  value  = 0;
	u64  scale  = 0;

	for ( ; ; _ptr++ )
	{
		const char c = *_ptr;
		if ( c >= '0' && c <= '9' )
		{
			value  = (value * 10) + (c - '0');
			scale *= 10;
			continue;
		}
		if ( c == '.' && scale == 0 )
		{
			scale = 1;
			continue;
		}
		
		if ( c == 'e' && _ptr[1] == '-' )
		{
			int const exp = _ptr[2] - '0';

			for (int i=0; i<exp; ++i)
			{
				scale = (scale * 10);
			}
			_ptr += 2;
			continue;
		}
		break;
	}

   const double v = ((double)(value)) * invert;
 	 if (scale == 0)
	 {
		 return (float)v;
	 }
	 return (float)(v / ((double)scale));
}
