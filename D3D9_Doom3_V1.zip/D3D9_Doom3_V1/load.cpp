
#include "d3d8_screen.h"
#include "quake3bsp.h"

extern FILE *file;
extern Screen screen;

CQuake3BSP::CQuake3BSP() //	This is our object's constructor to initial all it's data members
{
	// Here we simply initialize our member variables to 0
	m_numOfVerts =	
	m_numOfFaces =	
	m_numOfNodes =
	m_numOfLeafs =
	m_numOfLeafFaces =
	m_numOfPlanes =
	m_numOfTextures = 0;

	// Initialize all the dynamic BSP data pointers to NULL
	m_pVerts = NULL;	
	m_pFaces = NULL;	    
	m_pBrushSides = NULL;
	m_pBrushes = NULL;
	m_pNodes = NULL;
	m_pLeafFaces = NULL;
	D3D_Leafs		= NULL;
	D3D_Planes	= NULL;
	cluster_leafs			= NULL;
	cluster_leaf_list = NULL;
	m_pTextures = NULL;
	memset(&m_clusters,0,sizeof(tBSPVisData));
	m_clusters.pBitsets = NULL;
}

CQuake3BSP::~CQuake3BSP() //	This is our deconstructor that is called when the object is destroyed
{
	if (cluster_leafs)
	{
		delete [] cluster_leafs;
		cluster_leafs = NULL;
	}
	if (cluster_leaf_list)
	{
		delete [] cluster_leaf_list;
		cluster_leaf_list = NULL;
	}
	if (m_pVerts) // If we still have valid memory for our vertices, free them
	{
		delete [] m_pVerts;
		m_pVerts = NULL;
	}
    
	if (m_pFaces) // If we still have valid memory for our faces, free them
	{
		delete [] m_pFaces;
		m_pFaces = NULL;
	}

	if (m_pFaceFrame)
	{
		delete [] m_pFaceFrame;
		m_pFaceFrame = NULL;
	}
     
	if(m_pBrushes)
	{
		delete[] m_pBrushes;
		m_pBrushes = NULL;
  }

	if (m_pBrushSides)
	{
		delete[] m_pBrushSides;
		m_pBrushSides = NULL;
	}
    
	if (m_pLeafBrushes)
	{
		delete[] m_pLeafBrushes;
		m_pLeafBrushes = NULL;
	}
    
	if (m_pNodes) // If we still have valid memory for our nodes, free them
	{
		delete [] m_pNodes;
		m_pNodes = NULL;
	}
    
	if (D3D_Leafs)	// If we still have valid memory for our leafs, free them
	{
		delete [] D3D_Leafs;
		D3D_Leafs = NULL;
	}
    
	if(m_pLeafFaces) // If we still have valid memory for our leaf faces, free them
	{
		delete [] m_pLeafFaces;
		m_pLeafFaces = NULL;
	}
    
	if (D3D_Planes)
	{
		delete [] D3D_Planes;
		D3D_Planes = NULL;
	}

	if (m_clusters.pBitsets) // If we still have valid memory for our clusters, free them
	{
		delete [] m_clusters.pBitsets;
		m_clusters.pBitsets = NULL;
	}
  
	if(m_pTextures)
	{
		delete[] m_pTextures;
		m_pTextures = NULL;
	}

	if (m_vb)
	{
		m_vb->Release();
    m_vb = NULL;
	}    
}
