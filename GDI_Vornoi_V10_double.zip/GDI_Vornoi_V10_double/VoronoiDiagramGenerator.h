
#ifndef VORONOI_DIAGRAM_GENERATOR
#define VORONOI_DIAGRAM_GENERATOR

#include <math.h>
#include <stdlib.h>
#include <string.h>

#define DELETED -2

#define le 0
#define re 1

#define EPSILLON 0.000001 //1.0e-10

struct Freenode	
{
	Freenode *nextfree;
};

struct FreeNodeArrayList
{
	Freenode* memory;
	FreeNodeArrayList* next;
};

struct Freelist	
{
	Freenode	*head;
	int		nodesize;
};

struct PointVDG	
{
	double x,y;
};

struct Point3
{
	double x,y,z;
	int count;
};

struct VertexLink
{
	PointVDG coord;
	PointVDG v[3];
	int count;
};

// structure used both for sites and for vertices 
struct Site	
{
	PointVDG	coord;
	int		sitenbr;
	int		refcnt;
	int		overallRefcnt;
};

struct Edge	
{
	double a,b,c;
	Site 	*ep[2];
	Site	*reg[2];
	int		edgenbr;
};

struct GraphEdge
{
	double x1,y1,x2,y2;
//	long v1,v2; //vertices that this was created from
	GraphEdge* next;
};

struct Halfedge 
{
	Halfedge	*ELleft, *ELright;
	Edge	*ELedge;
	int		ELrefcnt;
	char	ELpm;
	Site	*vertex;
	double	ystar;
	Halfedge *PQnext;
};

class VoronoiDiagramGenerator
{
public:
	VoronoiDiagramGenerator();
	~VoronoiDiagramGenerator();
	const bool generateVoronoi(const double *xValues, const double *yValues, const int numPoints, double minX, double maxX, double minY, double maxY, const double minDist, const bool genVectorInfo=true);
	const void setGenerateDelaunay(const bool genDel); //By default, the delaunay triangulation is NOT generated
	const void setGenerateVoronoi(const bool genVor); //By default, the voronoi diagram IS generated
	const void resetIterator()
	{
		iteratorEdges = allEdges;
	}
	const bool getNext(double& x1, double& y1, double& x2, double& y2)
	{
		if (iteratorEdges == 0)
		{
			return false;
		}
		x1 = iteratorEdges->x1;
		x2 = iteratorEdges->x2;
		y1 = iteratorEdges->y1;
		y2 = iteratorEdges->y2;
		iteratorEdges = iteratorEdges->next;
		return true;
	}
	
	const void resetDelaunayEdgesIterator()
	{
		iteratorDelaunayEdges = delaunayEdges;
	}

	const bool getNextDelaunay(double& x1, double& y1, double& x2, double& y2)
	{
		if(iteratorDelaunayEdges == 0)
		{
			return false;
		}
		x1 = iteratorDelaunayEdges->x1;
		x2 = iteratorDelaunayEdges->x2;
		y1 = iteratorDelaunayEdges->y1;
		y2 = iteratorDelaunayEdges->y2;
		iteratorDelaunayEdges = iteratorDelaunayEdges->next;
		return true;
	}

	const void resetVertexPairIterator()
	{
		currentVertexLink = 0;
	}

	const void resetVerticesIterator()
	{
		currentVertex = 0;
	}

	const bool getNextVertex(double& x, double& y)
	{
		if (finalVertices == 0)
		{
			return false;
		}
		if (currentVertex >= sizeOfFinalVertices) 
		{ 
			return false; 
		}
		x = finalVertices[currentVertex].x;
		y = finalVertices[currentVertex].y;
		currentVertex++;
		return true;
	}
	const void reset();
	const void output_half_edges();
private:
	const void cleanup();
	const void cleanupEdges();
	const char *getfree(Freelist *fl);	
	const int PQempty();
	Halfedge **ELhash;
	Halfedge *HEcreate(Edge *e, const int pm);
	const PointVDG PQ_min();
	Halfedge *PQextractmin();	
	const void freeinit(Freelist *fl, const int size);
	const void makefree(Freenode *curr, Freelist *fl);
	const void geominit();
	const bool voronoi(const bool genVectorInfo);
	const void ref(Site *v);
	const void deref(Site *v);
	const void endpoint(Edge *e, int lr, Site * s);
	const void ELdelete(Halfedge *he);
	Halfedge *ELleftbnd(PointVDG *p);
	Halfedge *ELright(const Halfedge *he);
	const void makevertex(Site *v);
	const void		PQinsert(Halfedge *he, Site * v, const double offset);
	const void		PQdelete(Halfedge *he);
	const bool		ELinitialize();
	const void		ELinsert(Halfedge *lb, Halfedge *newHe);
	Halfedge * ELgethash(const int b);
	Halfedge *ELleft(const Halfedge *he);
	Site *leftreg(const Halfedge *he);
	const bool		PQinitialize();
	const int			PQbucket(Halfedge *he);
	const void		clip_line(const Edge *e);
	const char		*myalloc(const unsigned n);
	const int			right_of(const Halfedge *el, const PointVDG *p);
	Site *rightreg(const Halfedge *he);
	Edge *bisect(Site *s1,	Site *s2);
	const double dist(const Site *s, const Site *t);
	Site *intersect(Halfedge *el1, Halfedge *el2, const PointVDG *p=0);
	const void		out_ep(const Edge *e);
	Site *nextone();
	const void		pushGraphEdge(const double x1, const double y1, const double x2, const double y2);
	const void		pushDelaunayGraphEdge(const double x1, const double y1, const double x2, const double y2);
	const void		openpl();
	const void  		insertVertexAddress(const long vertexNum, Site* address);
	const void		insertVertexLink(const long vertexNum, const long vertexLinkedTo);
	const void		generateVertexLinks();
	bool		genDelaunay;
	bool		genVoronoi;
	Freelist	hfl;
	Halfedge *ELleftend, *ELrightend;
	int 		ELhashsize;
	int			triangulate, sorted, plot, debug;
	double		xmin, xmax, ymin, ymax, deltax, deltay;
	Site	*sites;
	int			nsites;
	int			siteidx;
	int			sqrt_nsites;
	int			nvertices;
	Freelist sfl;
	Site	*bottomsite;
	int			nedges;
	Freelist efl;
	int			PQhashsize;
	Halfedge *PQhash;
	int			PQcount;
	int			PQmin;
	int			ntry, totalsearch;
	double		pxmin, pxmax, pymin, pymax, cradius;
	int			total_alloc;
	double		borderMinX, borderMaxX, borderMinY, borderMaxY;
	FreeNodeArrayList* allMemoryList;
	FreeNodeArrayList* currentMemoryBlock;
	GraphEdge*	allEdges;
	GraphEdge*	iteratorEdges;
	GraphEdge*	delaunayEdges;
	GraphEdge*	iteratorDelaunayEdges;
	Point3*		vertexLinks; //lists all the vectors that each vector is directly connected to	
	long		sizeOfVertexLinks;
	Site**		vertices;
	long		sizeOfVertices ;
	VertexLink* finalVertexLinks;
	long 		sizeOfFinalVertexLinks;
	long		currentVertexLink;
	PointVDG	*finalVertices;	
	long		sizeOfFinalVertices ;	
	long 		currentVertex;
	double		minDistanceBetweenSites;	
//	const void output_half_edges();
};

int scomp(const void *p1,const void *p2);

#endif


