#ifndef MAP
#define MAP

#include <d3dx9.h>
#include "VoronoiDiagramGenerator.h"
#include "game.h"

#define MAX_VERTEX 16383
#define UNUSED -1

struct LINE
{
	unsigned short start;
	unsigned short end;
};

class Map
{
private:
	const void Generate(const int, const int, const int, const int, const long);
	const void Generate_Distributed(const int, const int, const int, const int, const long);
	const int AddPoint(const D3DXVECTOR2);
	const void AddLine(const Vector);
	const void AddNewLine(const Vector);

	D3DXVECTOR2 points[MAX_VERTEX];
	unsigned short Point_Count;
	unsigned short Pnts;
	unsigned short Lines;
	D3DXVECTOR2 Pnt[MAX_VERTEX];
	LINE Line[MAX_VERTEX];
	int SectorPoint[MAX_VERTEX];
	const float Map::Clockwise(const int f, const int s, const int t);
	int LineList[16383];
	bool LineUsed[16383];
	bool LineAllocated[16383];
	const bool Map::Sector();

public:
	const void Reset(const int);
	int SectorPoints;
};

#endif
