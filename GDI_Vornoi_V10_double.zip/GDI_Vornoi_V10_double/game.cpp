#include "game.h"
#include "map.h"
#include "window.h"
#include <stdio.h>
extern Map map;

#define STRICT
#define WIN32_LEAN_AND_MEAN

const static BITMAPINFOHEADER bmih = {sizeof(BITMAPINFOHEADER), MAP_HOR, MAP_VER, 1, 32, BI_RGB, 0, 0, 0, 0, 0};

extern CWindow window;

const void Game::Setup()
{
	Clear();
	map.Reset(1000); //50 = first error - on middle/top left
}

const void Game::Plot(const Vector pos, const long colour)
{
	screen[MAP_VER-1-pos.x][pos.y]=colour;
}

const long Game::Get(const Vector pos)
{
	return screen[MAP_VER - 1 - pos.x][pos.y];
}

const void Game::Clear()
{
	memset(&screen[0][0], 0, MAP_VER*MAP_HOR * sizeof(screen[0][0]));    // clear frame
}

const void Game::Line(const Vector start, const Vector end, const long colour)
{
	const Vector middle = SetVector((start.x + end.x) >> 1, (start.y + end.y) >> 1);
	Plot(middle, colour);
	if (((middle.x == start.x) && (middle.y == start.y)) || ((middle.x == end.x) && (middle.y == end.y))) return;
	Line(start, middle, colour);
	Line(end, middle, colour);
}

const void Game::Update()
{
	const DWORD LoopStartTime = GetTickCount();
	sprintf(string, "SP - %ld", map.SectorPoints);

	SetWindowText(window.GetHandle(),string);
	StretchDIBits(GetDC(window.GetHandle()), 0, 0, MAP_HOR*SCALE, MAP_VER*SCALE, 0, 0, MAP_HOR, MAP_VER, &screen[0][0], (BITMAPINFO*)&bmih, DIB_RGB_COLORS, SRCCOPY);	// Render the bitmap to the DC

	while ((GetTickCount() - LoopStartTime) < MillisecondsFrame); //20 milliseconds=50th second
}

const Vector Game::SetVector(const short x, const short y)
{
	Vector v;
	v.x=x;
	v.y=y;
	return v;
}
