#ifndef GAME
#define GAME

#include <windows.h>

#define STRICT
#define WIN32_LEAN_AND_MEAN

#define MAP_VER 512
#define MAP_HOR 512
#define SCALE 1
#define	FramesSecond 50
#define	MillisecondsFrame 1000/FramesSecond

struct Vector
{
	short x;
	short y;
};

class Game
{
public:
	const void Setup();
	const void Update();
	const void Clear();
	const void Plot(const Vector, const long);
	const void Line(const Vector, const Vector, const long);
	const Vector SetVector(const short, const short);
	const long Get(const Vector);
	const void Fill(const Vector, const long, const long);
private:
	long screen[MAP_VER][MAP_HOR];
	char string[256];
};

#endif
