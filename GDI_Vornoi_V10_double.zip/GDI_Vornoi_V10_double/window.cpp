#include "window.h"
#include <stdio.h>
#include "game.h"
#include "map.h"

#define STRICT
#define WIN32_LEAN_AND_MEAN

FILE *file;

const static SParameters params = {false, MAP_HOR*SCALE, MAP_VER*SCALE, NULL, NULL};

CWindow window;
Map map;
Game game;

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR pCmdLine, int showCmd)
{
	if (FAILED(window.Setup(params, hInst))) return 0;	
	if ((file=fopen("log.txt","w"))==NULL) return 0; fprintf(file, "windows startup\n");
	srand(0);
	game.Setup();
	while (!window.CheckMessage())
	{
		game.Update();
	}
	return 0;
}

/*
if (pbmiDIB->bmiHeader.biHeight > 0)
	{
		pDIB = (pDIBBase + (DIBHeight - 1) * DIBWidth);
		DIBPitch = -DIBWidth;   // bottom-up
	}
	else
	{
		pDIB = pDIBBase;
		DIBPitch = DIBWidth;    // top-down
	}
*/
const HRESULT CWindow::Setup(const SParameters &params, const HINSTANCE hInst)
{
	SParameters WindowParams;
	memcpy(&WindowParams, &params, sizeof(SParameters));
	const HINSTANCE hInstance=hInst;

	WNDCLASS WndClass;     // Register the window class
	WndClass.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
	WndClass.lpfnWndProc = (WNDPROC)WndProc;
	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hInstance = hInstance;
	WndClass.hIcon = LoadIcon(NULL, IDI_WINLOGO);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH); 
	WndClass.lpszMenuName  = WindowParams.pMenu;
	WndClass.lpszClassName = "Window";

	if (!RegisterClass(&WndClass)) return E_FAIL;

	int posX, posY, width, height;   // Setup our window parameters
	DWORD exStyle, style;
/*	if (WindowParams.fullscreen)
	{
		exStyle = WS_EX_TOPMOST; // This lets our window cover the whole screen
		style   = WS_POPUP;      // We don't need caption and system // menu when in fullscreen mode
		posX   = 0;
		posY   = 0;
		width  = GetSystemMetrics(SM_CXSCREEN);
		height = GetSystemMetrics(SM_CYSCREEN);
	}
	else*/
	{
		exStyle = 0;
		style = WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX|WS_DLGFRAME; //style   = WS_OVERLAPPEDWINDOW; // This is a normal window
		RECT rect = {0, 0, WindowParams.width, WindowParams.height};
		AdjustWindowRect(&rect, style, WindowParams.pMenu != 0 ? true : false);
		posX   = CW_USEDEFAULT;
		posY   = CW_USEDEFAULT;
		width  = rect.right - rect.left;
		height = rect.bottom - rect.top;
	}

	hWnd = CreateWindowEx(exStyle, "Window", WindowParams.pTitle, style, posX, posY, width, height, NULL, NULL, hInstance, this);     // Create the render window Set lpParam to point to our application so that the window procedure knows which class to call when handling window messages
	if (hWnd==NULL) return E_FAIL;

	ShowWindow (hWnd, SW_SHOW);
	UpdateWindow (hWnd);

	return S_OK;
}

LRESULT CALLBACK CWindow::WndProc (HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	CWindow *pWindow;
	CREATESTRUCT *pCS;

	switch (msg)
	{
		case WM_CREATE:
			pCS = (CREATESTRUCT *)lParam; 		// Extract the window pointer parameter.
			pWindow = (CWindow *)pCS->lpCreateParams;

			if (pWindow)
			{
				SetWindowLong(hWnd, GWL_USERDATA, (LONG)pWindow);			// Save it in the window handle.
			}
			break;
		
		case WM_KEYDOWN:
			if (GetKeyState(VK_ESCAPE) & 0x80) PostQuitMessage(0);
			if (GetKeyState(VK_CONTROL) & 0x80) game.Setup();

		default:
			pWindow = (CWindow *)GetWindowLong(hWnd, GWL_USERDATA);		// Extract the object from the window handle.
			break;
	}

	if (pWindow)
	{
		return pWindow->MsgProc(hWnd, msg, wParam, lParam);
	}
	else
	{
		return DefWindowProc(hWnd, msg, wParam, lParam);
	}
}

const bool CWindow::CheckMessage ()
{
	MSG msg;

	while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
	{
		if (msg.message==WM_QUIT)
		{
			return true;
		}
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return false;
}

const HWND CWindow::GetHandle()
{
	return hWnd;
}

LRESULT CWindow::MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	switch (msg)
	{
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProc(hWnd, msg, wParam, lParam);	// Let the default window procedure handle any message that we don't care about
}
