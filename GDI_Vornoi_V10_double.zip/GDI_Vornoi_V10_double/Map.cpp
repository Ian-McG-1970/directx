
#include "Map.h"
#include <stdio.h>
#include "game.h"

extern Game game;
extern FILE *file;

const void Map::Generate_Distributed(const int max_points, const int start_x, const int start_y, const int map_width, const long colour)
{
	const float point_distribution=sqrtf(max_points);
	const float point_width=map_width/(point_distribution-1);

	for (float x=0; x<=map_width; x+=point_width)
	{
		for (float y=0; y<=map_width; y+=point_width)
		{
			const D3DXVECTOR2 point = D3DXVECTOR2( (float)((rand() %(int)(point_width*0.75f))+x+start_x), (float)((rand() %(int)(point_width*0.75f))+y+start_y));
			points[Point_Count]=point;
			++Point_Count;
		}
	}
}

const void Map::Generate(const int max_points, const int start_x, const int start_y, const int map_width, const long colour)
{
	const int start_point_count=Point_Count;
	for (int point_count=0; point_count != max_points; )
	{
	  const D3DXVECTOR2 point = D3DXVECTOR2( (float)(rand() %map_width)+start_x, (float)(rand() %map_width)+start_y);
		int c;
		for (c=start_point_count; c!=Point_Count; ++c)
		{
			if (point==points[c])
			{
				break;
			}
		}
		if (c==Point_Count)
		{
			points[Point_Count]=point;
			++Point_Count;
			++point_count;
		}
	}
}

const int Map::AddPoint(const D3DXVECTOR2 point)
{
	for (int p=0; p!=Pnts; ++p)
	{
		if ( ((int)point.x == (int)Pnt[p].x) && ((int)point.y == (int)Pnt[p].y) )
		{
			fprintf(file, "po %ld %f %f\n", p, point.x, point.y);
			return p;
		}
	}

	fprintf(file, "pn %ld %ld %ld\n", Pnts, point.x, point.y);
	Pnt[Pnts].x = point.x;
	Pnt[Pnts].y = point.y;
	++Pnts;
	return Pnts-1;
}

const void Map::AddNewLine(const Vector point)
{
	for (int l = 0; l != Lines; ++l)
	{
		if ((Line[l].start == point.x) && (Line[l].end == point.y))
		{
			return;
		}
		if ((Line[l].start == point.y) && (Line[l].end == point.x))
		{
			return;
		}

	}
	AddLine(point);
}

const void Map::AddLine(const Vector point)
{
	Line[Lines].start = point.x;
	Line[Lines].end = point.y;
//	fprintf(file, "l %ld %ld %ld\n", Lines, Line[Lines].start, Line[Lines].end);
	++Lines;
}

const void Map::Reset(const int max_points)
{
	Point_Count = 0;
	//	Generate(max_points2, 0, 0, sector_size, 0x00ff00);
	Generate_Distributed(max_points, 0, 0, MAP_HOR, 0x00ff00);

	double px[MAX_VERTEX], py[MAX_VERTEX];
	for (int p = 0; p != Point_Count; ++p)
	{
		px[p] = points[p].x;
		py[p] = points[p].y;
	}
	VoronoiDiagramGenerator vdg;
	vdg.generateVoronoi(px, py, Point_Count, 0, MAP_VER, 0, MAP_HOR, 0, true);
	vdg.resetIterator();

	Pnts = Lines = 0;
	double start_x, start_y, end_x, end_y;

	while (vdg.getNext(start_x, start_y,end_x,end_y)==true)
	{
		if ( (start_x == end_x) && (start_y == end_y) )
		{
			continue;
		}
		AddLine(game.SetVector(AddPoint(D3DXVECTOR2(start_x, start_y)), AddPoint(D3DXVECTOR2(end_x, end_y))));
		AddLine(game.SetVector(AddPoint(D3DXVECTOR2(end_x, end_y)), AddPoint(D3DXVECTOR2(start_x, start_y))));
	}

	vdg.output_half_edges();
	for (int l = 0; l != Lines; ++l) { LineUsed[l] = false; LineAllocated[l] = false; };

	for (int l = 0; l != Lines; ++l)
	{
		game.Line(game.SetVector(Pnt[Line[l].start].x, Pnt[Line[l].start].y), game.SetVector(Pnt[Line[l].end].x, Pnt[Line[l].end].y), 0x0f00ff00);
	}

	while (true)
	{
		if (Sector() == true) break;
	}
}

// the problem is that the line is used on the outside before it is allocated to the inside?

const bool Map::Sector()
{
	bool complete = true;
	for (int l = 0; l != Lines; ++l)
	{
		if (LineUsed[l] == false)
		{
			complete = false;
			break;
		}
	}
	if (complete == true)
	{
		return true;
	}

	int LineListCount = 0;
	int first = UNUSED;
	int last = UNUSED;

	while (true)
	{
		int nearest = UNUSED;
		float nearest_direction = 0.0f;

		for (int curr = 0; curr != Lines; ++curr)
		{
			if (LineUsed[curr] == true) continue; // if line is used ignore
			if (LineAllocated[curr] == true) continue; // if line is allocated to a sector ignore

			// get first unused line and then escape top
			if (first == UNUSED) // if first not set
			{
					first = last = nearest = curr; // set first to l
					LineList[LineListCount++] = first;
					LineUsed[first] = true;
					continue; // next loop
			}

			if (Line[curr].start != Line[last].end) continue; 	// if this line.start does not match last line.end then next loop
			
			if (Line[curr].end == Line[last].start) continue; //  if this line.end eq last line.start then next loop

			const float curr_direction = Clockwise(Line[last].start, Line[last].end, Line[curr].end); 
			if (curr_direction >= nearest_direction) 			//    and more clockwise than the rest - <=lt
			{
				nearest = curr; 			//     remember this point
				nearest_direction = curr_direction;
			}
			if (Line[last].end == Line[first].start) break;

			// this line.end matches first line.start - then full loop is found
		}
		if (nearest == UNUSED) break; 			// if no new lines found this pass then exit

		LineList[LineListCount++] = nearest;
		LineUsed[nearest] = true;
		last = nearest;

		if (Line[last].end == Line[first].start) break; 			// this line.end matches first line.start - then full loop is found
 	}

	Vector middle = game.SetVector(0, 0);
	if (Line[last].end == Line[first].start)
	{
		for (int l = 0; l != LineListCount; ++l)
		{
			LineAllocated[LineList[l]] = true;
			middle = game.SetVector(middle.x+((Pnt[Line[LineList[l]].start].x + Pnt[Line[LineList[l]].end].x) / 2), middle.y+((Pnt[Line[LineList[l]].start].y + Pnt[Line[LineList[l]].end].y) / 2));

			game.Line(game.SetVector(Pnt[Line[LineList[l]].start].x, Pnt[Line[LineList[l]].start].y), game.SetVector(Pnt[Line[LineList[l]].end].x, Pnt[Line[LineList[l]].end].y), 0x00ff00ff);
		}
		middle = game.SetVector(middle.x / LineListCount, middle.y / LineListCount);
		game.Plot(game.SetVector(middle.x,middle.y),0x0ffffff);
	}
	return false;
}

const float Map::Clockwise(const int f, const int s, const int t)
{
	const D3DXVECTOR2 fst = D3DXVECTOR2(Pnt[f].x, Pnt[f].y);
	const D3DXVECTOR2 snd = D3DXVECTOR2(Pnt[s].x, Pnt[s].y);
	const D3DXVECTOR2 trd = D3DXVECTOR2(Pnt[t].x, Pnt[t].y);

	const D3DXVECTOR2 v1 = snd - fst;// -snd;
	const D3DXVECTOR2 v2 = snd - trd;// -snd;

	return ((v1.x*v2.y) - (v1.y*v2.x));
}
