
#include "include/SDL.h"
#include <stdio.h>

#include "map.h"
//#include "chull.h"

const int screen_size = 512;

bool draw=true;
SDL_Event event;
bool gameShouldEnd = false; 
SDL_Surface *screen;
unsigned long screen_pitch;
Uint32 *screen_start;

float points[65535];

Map map;

const void setScreen(const int width, const int height, int colorDepth)
{
	if (SDL_Init(SDL_INIT_VIDEO)<0)
	{
		printf("Unable to init SDL: %s\n", SDL_GetError());
		SDL_Quit();
		exit(1);
	}
	atexit(SDL_Quit);
	screen=SDL_SetVideoMode(width,height,colorDepth,SDL_HWSURFACE|SDL_DOUBLEBUF);
	 if (screen==NULL)
	 {
		printf("Unable to set video: %s\n", SDL_GetError());
		SDL_Quit();
		exit(1);
	}
	screen_start=(Uint32 *)screen->pixels;
	screen_pitch=screen->pitch/4l;
}

const void Slock()
{
	if (SDL_MUSTLOCK(screen))
	{
		if (SDL_LockSurface(screen)<0)
		{
			return;
		}
	}
}

const void Sulock()
{
	if (SDL_MUSTLOCK(screen))
	{
		SDL_UnlockSurface(screen);
	}
}

const void Plot(const int x, const int y, const Uint32 color)
{
  Uint32 *bufp = (Uint32 *)screen->pixels + ((y*screen->pitch)/4l) + x;
  *bufp = color;
}

const void Plot3d(const float x, const float y, const float z, const Uint32 colour)
{
	const float screen_size_half=screen_size*0.5f;
	const float pz=z+2.02f;
	const float px= ( (x/pz) * screen_size_half) +screen_size_half;
	const float py= ( (y/pz) * screen_size_half) +screen_size_half;
	Plot(px, py, colour);
//	printf("%f %f %f %ld %ld\n",x,y,z,px,py);
}

const void updateScreen(int u,int v,int width,int height)
{
	SDL_UpdateRect(screen, u, v, width, height);
}

const void clearScreen()
{
	memset(screen->pixels, 0, screen_size*screen_size*4);    // clear frame
}

const void draw_line(const int xs, const int ys, const int xe, const int ye)
{
	const int xm=(xs+xe)>>1;
	const int ym=(ys+ye)>>1;
	if (((xm==xs) && (ym==ys)) || ((xm==xe) && (ym==ye))) return;
	draw_line(xs,ys,xm,ym);
	draw_line(xe,ye,xm,ym);
	Plot(xm, ym, 0x0ffffff);
}

const void userInput()
{
	const Uint8 *keystate = SDL_GetKeyState(NULL);
	if (keystate[SDLK_SPACE]==1)
	{
		draw=true;
	}
	if (keystate[SDLK_ESCAPE]==1)
	{
        SDL_ShowCursor(SDL_ENABLE);
        SDL_WM_GrabInput(SDL_GRAB_OFF);
        gameShouldEnd = true;
    }
}
const void circle(const float x, const float y, const float z, const float radius)
{
	const float inc=D3DX_PI / radius * 0.5f;
	const float circle=D3DX_PI * 4.0f;
	for (float c=0.0f; c<=circle; c+=inc)
	{
		Plot3d(x+(sinf(c)*(radius/100)), y, z+(cosf(c)*(radius/100)), 0x00ffffff);
		Plot3d(x, y+(sinf(c)*(radius/100)), z+(cosf(c)*(radius/100)), 0x00ffffff);
		Plot3d(x+(sinf(c)*(radius/100)), y+(cosf(c)*(radius/100)), z, 0x00ffffff);
	}
}

const void gameLoop()
{
	int done=0;
	while(done==0)
	{
		while (SDL_PollEvent(&event))
		{
			if (event.type==SDL_QUIT || gameShouldEnd)
			{
				done=1;
			}
		}
		if (draw==true)
		{
			clearScreen();
//			map.Reset(1024, screen_size);

			const int p=100;

			for (int pc=0, x=0; x!=p; ++x)
			{
				const int px=(rand() &1023) -512;
				int py=(rand() &1023) -512;
				int pz=(rand() &1023) -512;
				float fx=(float) px/512;
				float fy=(float) py/512;
				float fz=(float) pz/512;

				points[pc++]=fx;
				points[pc++]=fy;
				points[pc++]=fz;
			}

			for (int pc=0, x=0; x!=p; ++x)
			{
				float fx=points[pc++];
				float fy=points[pc++];
				float fz=points[pc++];
//				Plot3d(fx, fy, fz, 0x00ffffff);
			}

//		Chull3D *t = new Chull3D(&points[0], p);
//		t->compute();
		float *vertices; 
		int *faces;
		int vertex_count;
		int face_count;
//		t->get_convex_hull(&vertices, &vertex_count, &faces, &face_count);
//		printf("vc %ld fc %ld\n",vertex_count,face_count);

		for (int p=0, x=0; x!=vertex_count; x++)
		{
			float vx=vertices[p++];
			float vy=vertices[p++];
			float vz=vertices[p++];
			Plot3d(vx, vy, vz, 0x00ff00ff);
//			printf("v %ld %ld %f %f %f\n", x, vertex_count, vx, vy, vz);
		}
		for (int p=0, x=0; x!=face_count; x++)
		{
			int f=faces[p++];
			int s=faces[p++];
			int t=faces[p++];
//			printf("f %ld %ld %ld %ld %ld\n", x, face_count, f, s, t);
		}

//			circle(-0.5f, 0.9f, -0.7f, 10.0f);
/*			Plot3d(-1.0f, -1.0f, -1.0f, 0x00ff00ff);
			Plot3d(1.0f, -1.0f, -1.0f, 0x0000ff00);
			Plot3d(-1.0f, 1.0f, -1.0f, 0x00ffff00);
			Plot3d(1.0f, 1.0f, -1.0f, 0x0000ffff);
			Plot3d(-1.0f, -1.0f, 1.0f, 0x00ff00ff);
			Plot3d(1.0f, -1.0f, 1.0f, 0x0000ff00);
			Plot3d(-1.0f, 1.0f, 1.0f, 0x00ffff00);
			Plot3d(1.0f, 1.0f, 1.0f, 0x0000ffff);*/
			updateScreen(0, 0, screen_size, screen_size);
			draw=false;
		}
		userInput();
	}
}

int main(int argc, char* argv[])
{
   setScreen(screen_size, screen_size, 32);
   SDL_WM_GrabInput(SDL_GRAB_ON);
   SDL_WM_SetCaption("Use Mouse & Arrows To Move, Hit esc to quit", NULL);
   SDL_ShowCursor(SDL_DISABLE);
   gameLoop();
   return (0);
}
