#include <math.h>
#include <stdio.h>
#include "engine.h"
#include "d3d8_screen.h"
#include "di_mouse.h"
#include "Map.h"

extern HWND hwnd;
extern Mouse mouse;
extern Screen screen;
extern FILE *file;
extern Floor mapfloor;

const D3DXVECTOR2 Engine::StartInSector()
{
	D3DXVECTOR2 position;
	for (int sector=INVALID_ROOM; sector==INVALID_ROOM; )
	{
		position=D3DXVECTOR2(rand()&2047, rand()&2047);
		sector=mapfloor.SectorFind(position);
	}
	return position;
}

const D3DXVECTOR2 Engine::GetPosition(const Object &object)
{
	const b2Vec2 position = object.Body->GetPosition();
	return D3DXVECTOR2(position.x, position.y);
}

const void Engine::Draw_Object(const D3DXVECTOR2 &position, Object *object)
{
	DisplayObjects[DisplayObjectCount].Position=position;
	DisplayObjects[DisplayObjectCount].object=object;
	++DisplayObjectCount;			
}

const void Engine::Movement(Object *player)
{
	player->Body->SetLinearVelocity( b2Vec2(Direction.x,Direction.y));
}

const void Engine::Setup()
{
	fprintf(file,"engine setup\n");
	Frame=EnemyCount=RoomCount=0;
	World = new b2World(b2Vec2(0.0f, 0.0f), true);
	screen.g_pd3dDevice->SetTexture(0, screen.Texture_List[1]);
}

const void Engine::CreateObjects()
{
	Frame=0; Add_Object(mapfloor.Map[0].Centre/*StartInSector()*/, D3DCOLOR_XRGB(0, 0, 255), CIRCLE_SHAPE, 15, &D3DXVECTOR2(rand()&2047, rand()&2047), NULL, &Player, Frame); //player
	Frame=0; Add_Object(D3DXVECTOR2(rand()&2047, rand()&2047), D3DCOLOR_XRGB(255, 255, 255), CIRCLE_SHAPE, 3, &D3DXVECTOR2(5,5), NULL, &CursorObject, Frame); //cursor
	Cursor=GetPosition(Player);
	for (int x=0; x!=3; ++x) Add_Object(mapfloor.Map[x].Centre, D3DCOLOR_XRGB(rand(), rand(), rand()), (rand()&1)<<1, (rand()&31)+7, &D3DXVECTOR2( (rand()&31)+3, (rand()&31)+3), NULL, &Enemy[0], EnemyCount);
////	for (int x=0; x!=9; ++x) Add_Object(StartInSector(), D3DCOLOR_XRGB(rand(), rand(), rand()), (rand()&1)<<1, (rand()&31)+7, &D3DXVECTOR2( (rand()&31)+3, (rand()&31)+3), NULL, &Enemy[0], EnemyCount);
}

Engine::~Engine()
{
	fprintf(file,"engine shutdown\n");
	delete World;
}

const void Engine::Input(Object &player, D3DXVECTOR2 &cursor)
{
	mouse.Update();

	const D3DXVECTOR2 position=GetPosition(player);
	cursor.x+=mouse.X;
	const int x=cursor.x-position.x;
	if (x>screen.ScreenSize.x)
	{
		cursor.x=position.x+screen.ScreenSize.x;
	}
	else if (x<-screen.ScreenSize.x)
	{
		cursor.x=position.x-screen.ScreenSize.x;
	}
	cursor.y+=mouse.Y;
	const int y=cursor.y-position.y;
	if (y>screen.ScreenSize.y)
	{
		cursor.y=position.y+screen.ScreenSize.y;
	}
	else if (y<-screen.ScreenSize.y)
	{
		cursor.y=position.y-screen.ScreenSize.y;
	}
	Direction=(cursor-position)*0.1f;//03f;
	if (mouse.LB!=0)
	{
		Movement(&player);
	}

	if (mouse.RB!=0)
	{
		if ((Direction.x!=0) || (Direction.y!=0))
		{
			const int fire_rate=7;
			if (fire_rate==0)
			{
				if (Fire_Button==0)
				{
				}
			}
			else
			{
				if ((Frame & fire_rate)==0)
				{
				}
			}
		}
	}
	Fire_Button=mouse.RB;
}

const void Engine::Draw_Objects()
{
	aabb.lowerBound.Set(Map_Loc.x,Map_Loc.y);
	aabb.upperBound.Set(Map_Loc.x+screen.ScreenSize.x, Map_Loc.y+screen.ScreenSize.y);

	QueryCallback callback;
	World->QueryAABB(&callback, aabb);
}

const void Engine::Add_Object(const D3DXVECTOR2 &position, const D3DCOLOR colour, const unsigned char shape, const float radius, const D3DXVECTOR2 *vertex, void *userdata, Object *object_list, int& object_count)
{
	object_list[object_count].UserData=userdata;
	object_list[object_count].Colour=colour;
 
	b2BodyDef bodydef;
	bodydef.position.Set(position.x, position.y);   // the body's origin position.
	bodydef.angle = 0.0f;      // the body's angle in radians.
	bodydef.linearDamping = bodydef.angularDamping = 0.01f;
	bodydef.allowSleep = bodydef.awake = bodydef.fixedRotation = bodydef.active = true;
	bodydef.bullet = false;
	bodydef.userData = &object_list[object_count];

	b2FixtureDef fixturedef;
	fixturedef.density = 1.0f;
	fixturedef.friction = 0.8f;
	fixturedef.restitution = 0.8f;
		
	b2CircleShape cshape;
	b2PolygonShape pshape;
	object_list[object_count].Shape=shape;

	switch (object_list[object_count].Shape)
	{
		case CIRCLE_SHAPE:
			bodydef.type = b2_dynamicBody;
			object_list[object_count].Radius = cshape.m_radius = radius;
			object_list[object_count].Body = World->CreateBody(&bodydef);
			fixturedef.shape = &cshape;
			object_list[object_count].Body->CreateFixture(&fixturedef);
			break;
		case LINE_SHAPE:
			bodydef.type = b2_staticBody;
			object_list[object_count].Vertex=D3DXVECTOR2(vertex->x, vertex->y);
			pshape.SetAsEdge(b2Vec2(0, 0), b2Vec2(vertex->x, vertex->y));
			object_list[object_count].Body = World->CreateBody(&bodydef);
			fixturedef.shape = &pshape;
			object_list[object_count].Body->CreateFixture(&fixturedef);
			break;
		case BOX_SHAPE:
			bodydef.type = b2_dynamicBody;
			bodydef.fixedRotation = false;
			object_list[object_count].Vertex=D3DXVECTOR2(vertex->x, vertex->y);
			pshape.SetAsBox(vertex->x, vertex->y);
			object_list[object_count].Body = World->CreateBody(&bodydef);
			fixturedef.shape = &pshape;
			object_list[object_count].Body->CreateFixture(&fixturedef);
			break;
		case POLYGON_SHAPE:
			bodydef.type = b2_staticBody;
			object_list[object_count].Body = World->CreateBody(&bodydef);
			Room *room;
			room=(Room *)object_list[object_count].UserData;
			fprintf(file,"add object points %ld\n", room->PointCount);
			fixturedef.shape = &pshape;

			for (int p=0; p!=room->PointCount; ++p)
			{
				if (room->Wall[p]==true)
				{
					pshape.SetAsEdge(b2Vec2(room->Point[p].x, room->Point[p].y), b2Vec2(room->Point[p+1].x, room->Point[p+1].y));
					fixturedef.shape = &pshape;
					object_list[object_count].Body->CreateFixture(&fixturedef);
				}
			}
			break;

		default:
			break;
	}
	++object_count;
}

const void Engine::Remove_Object(const int object_number, Object *object_list, int& object_count)
{
	--object_count;
	memcpy(&object_list[object_number], &object_list[object_count], sizeof(object_list[0]));
}

const void Engine::Update()
{
	World->Step(1.0f/60.0f, 10, 10);
	World->ClearForces();

	screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 0, 0), 1.0f, 0);
	screen.g_pd3dDevice->BeginScene();

	Input(Player, Cursor);
	++Frame;
	Map_Loc=screen.SetScreenPos(GetPosition(Player), Cursor);

	DisplayObjectCount=0;

	Draw_Objects();
	const int sector=mapfloor.SectorFind(GetPosition(Player));

//	DrawRoom(sector);
//	Draw_Object(GetPosition(Player)-Map_Loc, &Player);
////	Draw_Object(Cursor-Map_Loc, &CursorObject);

	screen.Draw_Objects(&DisplayObjects[0], DisplayObjectCount);
screen.DrawBullet(Cursor-Map_Loc, 0x0ffffff);//Player.Colour);

	sprintf(screen.string, "%ld %ld %f %f %f %f",DisplayObjectCount,sector,GetPosition(Player).x,GetPosition(Player).y,Cursor.x, Cursor.y);
	screen.DrawText(3, 3, D3DXCOLOR(0, 127, 127, 127), &screen.string[0]);

	screen.Draw_Primitive_Forced();
	screen.g_pd3dDevice->EndScene();

	screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
}

const bool Engine::OnScreen(const int this_room)
{
	if ( (mapfloor.Map[this_room].Centre.x) < (engine.Map_Loc.x)) return false;
	if ( (mapfloor.Map[this_room].Centre.x) > (engine.Map_Loc.x+screen.ScreenSize.x)) return false;
	if ( (mapfloor.Map[this_room].Centre.y) < (engine.Map_Loc.y)) return false;
	if ( (mapfloor.Map[this_room].Centre.y) > (engine.Map_Loc.y+screen.ScreenSize.y)) return false;
	return true;
/*	for (int x=0; x!=mapfloor.Map[this_room].PointCount; ++x)
	{
		if ( (mapfloor.Map[this_room].Point[x].x>(engine.Map_Loc.x-screen.ScreenSize.x) ) && (mapfloor.Map[this_room].Point[x].x<(engine.Map_Loc.x+screen.ScreenSize.x) )
		|| (mapfloor.Map[this_room].Point[x].y>(engine.Map_Loc.y-screen.ScreenSize.y) ) && (mapfloor.Map[this_room].Point[x].y<(engine.Map_Loc.y+screen.ScreenSize.y) ) )
		{
			return true;
		}
	}
	return false;*/
}

const void Engine::DrawObjectsInRoom(const int this_room)
{
	for (int enemy=0; enemy!=EnemyCount; ++enemy)
	{
		if (mapfloor.SectorFind(GetPosition(Enemy[enemy]))==this_room)
		{
			Draw_Object(GetPosition(Enemy[enemy])-engine.Map_Loc, &Enemy[enemy]);
		}
	}
}

const void Engine::DrawRoom(const int this_room)
{
	if (this_room==INVALID_ROOM) return;

	for (int r=0; r!=mapfloor.Map[this_room].VisibleRoomsCount; ++r)
	{
		const int room=mapfloor.VisibleRoomList[mapfloor.Map[this_room].VisibleRoomsStart+r];
		Draw_Object(GetPosition(engine.Rooms[room])-engine.Map_Loc, &engine.Rooms[room]);
		DrawObjectsInRoom(room);
	}
	return;
}
