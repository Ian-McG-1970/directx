#ifndef MAP
#define MAP

#include "D3D8_Screen.h"

#define MAX_MAP_SIZE 16383
#define MAX_ROOM_SIDES 7 //5
#define MIN_ROOM_SIDES 3
#define MAX_POLYGON_POINTS MAX_ROOM_SIDES*5
#define MAX_ROOM_SIZE 300 //50 //30 //20 //10
#define INVALID_ROOM -1

struct Room
{
	D3DXVECTOR2 Point[MAX_POLYGON_POINTS];
	bool Wall[MAX_POLYGON_POINTS];
	int PointCount;
	D3DXVECTOR2 Centre;
	float Radius;
	int NearestRoom;
	int LinkedRoomsStart;
	int LinkedRoomsCount;
	int VisibleRoomsStart;
	int VisibleRoomsCount;
};

struct RoomLink
{
	int StartRoom;
	int StartRoomWall;
	int EndRoom;
	int EndRoomWall;
};

class Floor
{
private:
	int Rooms;
	const int CalcPolygonPoints(const D3DXVECTOR2 &, const float, D3DXVECTOR2 *, const int);
	const int CalcPolygonRandomPoints(const D3DXVECTOR2 &, const float, D3DXVECTOR2 *);
	const bool LineIntersect(const D3DXVECTOR2 &, const D3DXVECTOR2 &, const D3DXVECTOR2 &, const D3DXVECTOR2 &);
	const void CalcRoomEndPoints(D3DXVECTOR2 *, bool *, const int);
	const bool IntersectNeighbourRoom(const int, const int, int &);
	const float RoomDistance(const int, const int);
	const void LinkRooms(const int);
	const void CreateRooms(const int);
	const void BuildSectors();
	const bool SectorPointTest(const int, const D3DXVECTOR2 &);
	int RoomsLinked;
	RoomLink RoomLinks[65535];
	const void FindVisibleRooms();
	const void SplitConvexPolygons(const int);
	const void AddTriangleRooms(const int start_room, const int end_room, const int start_room_wall, const int end_room_wall, const int rooms_created, const int rooms_linked, const int r);
	const void AddSquareRoom(const int start_room, const int end_room, const int start_room_wall, const int end_room_wall, const int rooms_created, const int rooms_linked, const int r);
	const bool ConcavePolygon(const D3DXVECTOR2& point0, const D3DXVECTOR2& point1, const D3DXVECTOR2& point2, const D3DXVECTOR2& point3);

	int LinkRoomStart[65535];
	int LinkRoomEnd[65535];
	int LinkedRooms;
	const void Floor::AddVisibleRooms(const int, const int);
public:
	int LinkedRoomList[65535];
	int VisibleRoomList[65535];
	Room Map[65535];
	const void Setup(const int);
	~Floor();
	const int SectorFind(const D3DXVECTOR2 &);
};

#endif
