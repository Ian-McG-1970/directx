#include <time.h>

#include "Map.h"
#include "Load.h"
#include "Engine.h"

extern FILE	*file;
extern Engine engine;

Floor::~Floor()
{
}

const int Floor::CalcPolygonPoints(const D3DXVECTOR2 &centre, const float radius, D3DXVECTOR2 *point, const int points)
{
	const float inc=D3DX_PI *2.0f / points;
	static const float circle=D3DX_PI *2.0f;
	int pt=0;
	for (float c=0; c<=circle; c+=inc)
	{
		point[pt]=D3DXVECTOR2(centre.x+(sinf(c)*radius), centre.y+(cosf(c)*radius));
		++pt;
	}
	point[points]=point[0];
	return points;
}

const int Floor::CalcPolygonRandomPoints(const D3DXVECTOR2 &centre, const float radius, D3DXVECTOR2 *point)
{
	return CalcPolygonPoints(centre, radius, point, ((rand()%(MAX_ROOM_SIDES-MIN_ROOM_SIDES))+2)|1);
}

const bool Floor::LineIntersect(const D3DXVECTOR2 &l0, const D3DXVECTOR2 &l1, const D3DXVECTOR2 &l2, const D3DXVECTOR2 &l3)
{	
	const float d=((l1.x-l0.x)*(l3.y-l2.y))-((l1.y-l0.y)*(l3.x-l2.x));
	if (fabs(d)<=0.0001f) 
	{
		return false;
	}	
	const float AB=((l0.y-l2.y)*(l3.x-l2.x)-(l0.x-l2.x)*(l3.y-l2.y))/d;	
	if (AB>0.0f && AB<1.0f)
	{		
		const float CD=((l0.y-l2.y)*(l1.x-l0.x)-(l0.x-l2.x)*(l1.y-l0.y))/d;
		if (CD>0.0f && CD<1.0f)
		{
			return true;
		}
	}
	return false;
}

const void Floor::CalcRoomEndPoints(D3DXVECTOR2 *point, bool *type, const int points)
{
	point[points]=point[0];
	memset(&type[0], true, points);
}

const bool Floor::IntersectNeighbourRoom(const int room, const int nearest_room, int &connecting_wall) 
{
	for (int rp=0; rp!=Map[room].PointCount; ++rp)
	{
		if (Map[room].Wall[rp]==true)
		{
			if (LineIntersect(Map[room].Centre, Map[nearest_room].Centre, Map[room].Point[rp], Map[room].Point[rp+1])==true)
			{
				connecting_wall=rp;
				return true;
			}
		}
	}
	return false;
}

const float Floor::RoomDistance(const int room1, const int room2)
{
	const D3DXVECTOR2 diff=Map[room1].Centre-Map[room2].Centre;
	return sqrtf(fabs(D3DXVec2Dot(&diff,&diff)));
}

const void Floor::SplitConvexPolygons(const int rooms)
{
	fprintf(file,"split convex polygons\n");
	for (int r=0; r!=rooms; ++r)
	{
		fprintf(file,"check convex polygon room %ld %ld\n",r,rooms);
	}
}

const void Floor::AddSquareRoom(const int start_room, const int end_room, const int start_room_wall, const int end_room_wall, const int rooms_created, const int rooms_linked, const int r)
{
		Map[rooms_created].Point[0]=Map[start_room].Point[start_room_wall+1];
		Map[rooms_created].Point[1]=Map[start_room].Point[start_room_wall];
		Map[rooms_created].Point[2]=Map[end_room].Point[end_room_wall+1];
		Map[rooms_created].Point[3]=Map[end_room].Point[end_room_wall];

		Map[rooms_created].PointCount=4;
		CalcRoomEndPoints(&Map[rooms_created].Point[0], &Map[rooms_created].Wall[0], Map[rooms_created].PointCount);

		Map[rooms_created].Wall[0]=Map[rooms_created].Wall[2]=false;
		Map[rooms_created].Centre=(Map[rooms_created].Point[0]+Map[rooms_created].Point[1]+Map[rooms_created].Point[2]+Map[rooms_created].Point[3]) /Map[rooms_created].PointCount;

		const D3DXVECTOR2 diff=Map[rooms_created].Centre-Map[rooms_created].Point[0];
		Map[rooms_created].Radius=sqrtf(fabs(D3DXVec2Dot(&diff,&diff)));

		Map[rooms_created].NearestRoom=end_room;
		Map[start_room].NearestRoom=rooms_created;
	
		RoomLinks[rooms_linked].StartRoom=start_room;
		RoomLinks[rooms_linked].StartRoomWall=start_room_wall;
		RoomLinks[rooms_linked].EndRoom=rooms_created;	
		RoomLinks[rooms_linked].EndRoomWall=2;

		RoomLinks[r].StartRoom=end_room;
		RoomLinks[r].StartRoomWall=end_room_wall;
		RoomLinks[r].EndRoom=rooms_created;
		RoomLinks[r].EndRoomWall=0;
}

const void Floor::AddTriangleRooms(const int start_room, const int end_room, const int start_room_wall, const int end_room_wall, const int rooms_created, const int rooms_linked, const int r)
{		
		const D3DXVECTOR2 dif02=Map[start_room].Point[start_room_wall+1]-Map[end_room].Point[end_room_wall+1];
		const D3DXVECTOR2 dif13=Map[start_room].Point[start_room_wall]-Map[end_room].Point[end_room_wall];
		const float len02=fabs(D3DXVec2Length(&dif02));
		const float len13=fabs(D3DXVec2Length(&dif13));
		if (len02<len13)
		{
			Map[rooms_created].Point[0]=Map[start_room].Point[start_room_wall+1];
			Map[rooms_created].Point[1]=Map[start_room].Point[start_room_wall];
			Map[rooms_created].Point[2]=Map[end_room].Point[end_room_wall+1];

			Map[rooms_created+1].Point[0]=Map[end_room].Point[end_room_wall+1];
			Map[rooms_created+1].Point[1]=Map[end_room].Point[end_room_wall];
			Map[rooms_created+1].Point[2]=Map[start_room].Point[start_room_wall+1];
		}
		else
		{
			Map[rooms_created].Point[1]=Map[end_room].Point[end_room_wall];
			Map[rooms_created].Point[2]=Map[start_room].Point[start_room_wall+1];
			Map[rooms_created].Point[0]=Map[start_room].Point[start_room_wall];

			Map[rooms_created+1].Point[1]=Map[start_room].Point[start_room_wall];
			Map[rooms_created+1].Point[2]=Map[end_room].Point[end_room_wall+1];
			Map[rooms_created+1].Point[0]=Map[end_room].Point[end_room_wall];
		}

		Map[rooms_created].PointCount=3;
		CalcRoomEndPoints(&Map[rooms_created].Point[0], &Map[rooms_created].Wall[0], Map[rooms_created].PointCount);
		Map[rooms_created+1].PointCount=3;
		CalcRoomEndPoints(&Map[rooms_created+1].Point[0], &Map[rooms_created+1].Wall[0], Map[rooms_created+1].PointCount);

		Map[rooms_created].Wall[0]=Map[rooms_created].Wall[2]=false;
		Map[rooms_created].Centre=(Map[rooms_created].Point[0]+Map[rooms_created].Point[1]+Map[rooms_created].Point[2]) /Map[rooms_created].PointCount;
		Map[rooms_created+1].Wall[0]=Map[rooms_created+1].Wall[2]=false;
		Map[rooms_created+1].Centre=(Map[rooms_created+1].Point[0]+Map[rooms_created+1].Point[1]+Map[rooms_created+1].Point[2]) /Map[rooms_created+1].PointCount;

		D3DXVECTOR2 diff=Map[rooms_created].Centre-Map[rooms_created].Point[0];
		Map[rooms_created].Radius=sqrtf(fabs(D3DXVec2Dot(&diff,&diff)));
		diff=Map[rooms_created+1].Centre-Map[rooms_created+1].Point[0];
		Map[rooms_created+1].Radius=sqrtf(fabs(D3DXVec2Dot(&diff,&diff)));

		Map[rooms_created].NearestRoom=end_room;
		Map[rooms_created+1].NearestRoom=rooms_created;
		Map[start_room].NearestRoom=rooms_created+1;

		RoomLinks[rooms_linked].StartRoom=start_room;
		RoomLinks[rooms_linked].StartRoomWall=start_room_wall;
		RoomLinks[rooms_linked].EndRoom=rooms_created;	
		RoomLinks[rooms_linked].EndRoomWall=2;

		RoomLinks[rooms_linked+1].StartRoom=rooms_created;
		RoomLinks[rooms_linked+1].StartRoomWall=2;
		RoomLinks[rooms_linked+1].EndRoom=rooms_created+1;	
		RoomLinks[rooms_linked+1].EndRoomWall=2;

		RoomLinks[r].StartRoom=end_room;
		RoomLinks[r].StartRoomWall=end_room_wall;
		RoomLinks[r].EndRoom=rooms_created+1;
		RoomLinks[r].EndRoomWall=0;
}

const bool Floor::ConcavePolygon(const D3DXVECTOR2& point0, const D3DXVECTOR2& point1, const D3DXVECTOR2& point2, const D3DXVECTOR2& point3)
{
	const D3DXVECTOR2 points[]={point0, point1, point2, point3, point0, point1};
   for (int flag=0, i=0; i<4; ++i)
	 {
      const float z = ((points[i+1].x - points[i].x) * (points[i+2].y - points[i+1].y)) - ((points[i+1].y - points[i].y) * (points[i+2].x - points[i+1].x));
      if (z<0.0f) flag|=1;
      else if (z>0.0f) flag|=2;
      if (flag==3) return true;
	 }
	 return false;
}

const void Floor::CreateRooms(const int rooms)
{
	srand(rooms);
	RoomsLinked=0;
	int rooms_created=0;
	for (; rooms_created!=rooms; )
	{
		Map[rooms_created].Centre=D3DXVECTOR2((rand()%(MAX_MAP_SIZE-(MAX_ROOM_SIZE<<2)))+((MAX_ROOM_SIZE<<1)+5),(rand()%(MAX_MAP_SIZE-(MAX_ROOM_SIZE<<2)))+((MAX_ROOM_SIZE<<1)+5));
		Map[rooms_created].Radius=(rand()%(MAX_ROOM_SIZE>>1))+(MAX_ROOM_SIZE>>1);

		bool collision=false, nearest=false;
		float nearest_distance=99999;
		for (int collision_check=0; collision_check!=rooms_created; ++collision_check)
		{
			const float distance=RoomDistance(rooms_created, collision_check);
			const float radius=Map[rooms_created].Radius+Map[collision_check].Radius;
			if (distance<=(radius*1.3f))
			{
				nearest=true;
				if (distance<=radius)
				{
					collision=true;
					break;
				}
				if (distance<=nearest_distance)
				{
					nearest_distance=distance;
					Map[rooms_created].NearestRoom=collision_check;
				}
			}
		}
		if (collision==true) continue;
		if ( (rooms_created!=0) && (nearest==false) ) continue;

		Map[rooms_created].PointCount=CalcPolygonRandomPoints(Map[rooms_created].Centre, Map[rooms_created].Radius, &Map[rooms_created].Point[0]);
		CalcRoomEndPoints(&Map[rooms_created].Point[0], &Map[rooms_created].Wall[0], Map[rooms_created].PointCount);

		if (rooms_created!=0)
		{
			const int nearest_room=Map[rooms_created].NearestRoom;

			int room_wall_found, nearest_room_wall_found;
			if (IntersectNeighbourRoom(rooms_created, nearest_room, room_wall_found)==false) continue;
			if (IntersectNeighbourRoom(nearest_room, rooms_created, nearest_room_wall_found)==false) continue;

			RoomLinks[RoomsLinked].StartRoom=rooms_created;
			RoomLinks[RoomsLinked].StartRoomWall=room_wall_found;
			RoomLinks[RoomsLinked].EndRoom=nearest_room;
			RoomLinks[RoomsLinked].EndRoomWall=nearest_room_wall_found;
			++RoomsLinked;
	
			Map[rooms_created].Wall[room_wall_found]=Map[nearest_room].Wall[nearest_room_wall_found]=false;
		}
		++rooms_created;
	}

	int rooms_linked=RoomsLinked;
	for (int r=0; r!=RoomsLinked; ++r)
	{
		const int start_room=RoomLinks[r].StartRoom;
		const int end_room=RoomLinks[r].EndRoom;
		const int start_room_wall=RoomLinks[r].StartRoomWall;
		const int end_room_wall=RoomLinks[r].EndRoomWall;

		if (ConcavePolygon(Map[start_room].Point[start_room_wall+1], Map[start_room].Point[start_room_wall], Map[end_room].Point[end_room_wall+1], Map[end_room].Point[end_room_wall])==true)
		{
			AddTriangleRooms(start_room, end_room, start_room_wall, end_room_wall, rooms_created, rooms_linked, r);
			rooms_linked+=2;
			rooms_created+=2;
		}
		else
		{
			AddSquareRoom(start_room, end_room, start_room_wall, end_room_wall, rooms_created, rooms_linked, r);
			++rooms_linked;
			++rooms_created;
		}
	}
	RoomsLinked=rooms_linked;

	SplitConvexPolygons(rooms_created);
	Rooms=rooms_created;
	BuildSectors();
	for (int r=0; r!=Rooms; ++r) 
	{	
		engine.Add_Object(D3DXVECTOR2(0,0), /*D3DCOLOR_XRGB(0,0,255)*/D3DCOLOR_XRGB((rand()&127)+128, (rand()&127)+128, (rand()&127)+128), POLYGON_SHAPE, 0, NULL, &Map[r], &engine.Rooms[0], engine.RoomCount);
	}	

	FindVisibleRooms();
}

const void Floor::Setup(const int rooms)
{
	CreateRooms(rooms);
}

const void Floor::BuildSectors()
{
	int sectorlistpos=0;
	for (int room=0; room!=Rooms; ++room)
	{
		Map[room].LinkedRoomsStart=sectorlistpos;
		Map[room].LinkedRoomsCount=1;
		LinkedRoomList[sectorlistpos]=Map[room].NearestRoom;
		++sectorlistpos;
		fprintf(file,"room %3ld %3ld ",room,Map[room].NearestRoom);
		for (int r=0; r!=Rooms; ++r)
		{
			if ((r!=room) && (Map[r].NearestRoom==room))
			{
				LinkedRoomList[sectorlistpos]=r;
				++sectorlistpos;
				++Map[room].LinkedRoomsCount;		
				fprintf(file,"%3ld ",r);
			}
		}
		fprintf(file,"\n ");
		
//		fprintf(file,"room %3ld ",room);
//		for (int portal=0; portal!=Map[room].SectorCount; ++portal)
//		{
//				fprintf(file,"%3ld ",SectorList[Map[room].SectorListStart+portal]);
//		}
//		fprintf(file,"\n ");

	}
	for (int room=0; room!=RoomsLinked; ++room)
	{
		fprintf(file,"r %3ld rl %3ld sr %3ld srw %3ld er %3ld erw %3ld\n", room, RoomsLinked, RoomLinks[room].StartRoom, RoomLinks[room].StartRoomWall, RoomLinks[room].EndRoom, RoomLinks[room].EndRoomWall);
	}
}

const int Floor::SectorFind(const D3DXVECTOR2 &Point)
{
	for (int sector=0; sector!=Rooms; ++sector)
	{
		if (SectorPointTest(sector, Point)==true)
		{
			return sector;	
		}
	}
	return INVALID_ROOM;
}

const bool Floor::SectorPointTest(const int Sector, const D3DXVECTOR2 &Point)
{
	for (int wall=0; wall!=Map[Sector].PointCount; ++wall)
	{
		const D3DXVECTOR2 diff=Map[Sector].Point[wall+1]-Map[Sector].Point[wall];
		const D3DXVECTOR2 normal=D3DXVECTOR2(-diff.y,diff.x);
		const D3DXVECTOR2 test=Point-Map[Sector].Point[wall];
		if (D3DXVec2Dot(&test, &normal)>=0.0f)
		{
			return false;
		}
	}
	return true;
}

const void Floor::AddVisibleRooms(const int start_room, const int end_room)
{
	for (int room=0; room!=LinkedRooms; ++room)
	{
		if ( (LinkRoomStart[room]==start_room) && (LinkRoomEnd[room]==end_room) ) return;
		if ( (LinkRoomStart[room]==end_room) && (LinkRoomEnd[room]==start_room) ) return;
	}
	LinkRoomStart[LinkedRooms]=start_room;
	LinkRoomEnd[LinkedRooms]=end_room;	
//	fprintf(file,"curr room %ld test room %ld count %ld\n",LinkRoomStart[LinkedRooms],LinkRoomEnd[LinkedRooms],LinkedRooms);
	++LinkedRooms;
}

const void Floor::FindVisibleRooms()
{
	fprintf(file,"fvr\n");
	RayCastCallback callback;
	for (int cr=0; cr!=Rooms; ++cr)
	{
		for (int cw=0; cw!=Map[cr].PointCount; ++cw)
		{
			if (Map[cr].Wall[cw]==false)
			{
				const b2Vec2 cwm(((Map[cr].Point[cw].x+Map[cr].Point[cw+1].x)*0.5f), ((Map[cr].Point[cw].y+Map[cr].Point[cw+1].y)*0.5f));
				for (int tr=cr+1; tr<=Rooms; ++tr)
				{
					for (int tw=0; tw!=Map[tr].PointCount; ++tw)
					{
						if (Map[tr].Wall[tw]==false)	
						{
							const b2Vec2 twm(((Map[tr].Point[tw].x+Map[tr].Point[tw+1].x)*0.5f), ((Map[tr].Point[tw].y+Map[tr].Point[tw+1].y)*0.5f));
							callback.m_fraction=0.0f;
							engine.World->RayCast(&callback, cwm, twm);
//							fprintf(file,"callback cr %3ld cw %2ld tr %3ld tw %2ld cwsx %4.2f cwsy %4.2f twsx %4.2f twsy %4.2f callback.m_fraction %3.4f cx %4.2f cy %4.2f\n",cr, cw, tr, tw, cws.x, cws.y, tws.x, tws.y, callback.m_fraction, Map[cr].Centre.x,Map[cr].Centre.y);
							if (callback.m_fraction==0.0f)
							{
								AddVisibleRooms(cr, tr);
							}
						}
					}
				}
			}
		}
	}
	
	for (int lr=0; lr!=LinkedRooms; ++lr)
	{
		fprintf(file,"count %ld total %ld room %ld visible %ld\n",lr,LinkedRooms,LinkRoomStart[lr],LinkRoomEnd[lr]);
	}

	int visiblelistpos=0;
	for (int room=0; room!=Rooms; ++room)
	{
		Map[room].VisibleRoomsStart=visiblelistpos;
		Map[room].VisibleRoomsCount=1;
		VisibleRoomList[visiblelistpos]=room;
		++visiblelistpos;
		for (int linked_room=0; linked_room!=LinkedRooms; ++linked_room)
		{
			if ( (LinkRoomStart[linked_room]==room) || (LinkRoomEnd[linked_room]==room) ) 
			{
				if (LinkRoomStart[linked_room]==room) 
				{
					VisibleRoomList[visiblelistpos]=LinkRoomEnd[linked_room];
				}
				else
				{
					VisibleRoomList[visiblelistpos]=LinkRoomStart[linked_room];
				}
				++Map[room].VisibleRoomsCount;
				++visiblelistpos;
			}
		}
		fprintf(file,"room %3ld room start %3ld room count %3ld\n",room,Map[room].VisibleRoomsStart,Map[room].VisibleRoomsStart);
	}

}
