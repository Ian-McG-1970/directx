#ifndef ENGINE
#define ENGINE

#include "d3d8_screen.h"

#define MAX_OBJECT 65535

class Engine
{
private:
	Object Player;
	Object CursorObject;
	D3DXVECTOR2 screen_pos;
	D3DXVECTOR2 Cursor;
	b2AABB aabb;
	int Frame;
	const void Movement(Object *);
	const void Draw_Object(const D3DXVECTOR2 &, Object *);
	const void Input(Object &, D3DXVECTOR2 &);
	const void Draw_Objects();
	const void Remove_Object(const int, Object *, int&);
	int Fire_Button;
	const void AI(Object *, int&, int&);
	const D3DXVECTOR2 StartInSector();
	const D3DXVECTOR2 GetPosition(const Object &);
	D3DXVECTOR2 Direction;
	const void Engine::DrawRoom(const int this_room);
	const bool Engine::OnScreen(const int this_room);
	const void Engine::DrawObjectsInRoom(const int this_room);
public:
		b2World *World;
	const void Setup();
	~Engine();
	const void Update();
	const void Add_Object(const D3DXVECTOR2 &, const D3DCOLOR, const unsigned char, const float, const D3DXVECTOR2 *, void*, Object *, int&);
	DisplayObject DisplayObjects[MAX_OBJECT*2];
	int DisplayObjectCount;
	D3DXVECTOR2 Map_Loc;
	Object Enemy[MAX_OBJECT];
	int EnemyCount;
	Object Rooms[MAX_OBJECT];
	int RoomCount;
	const void Engine::CreateObjects();
};

extern Engine engine;

class QueryCallback:public b2QueryCallback
{
	public:
	bool ReportFixture(b2Fixture* fixture)
	{
		const b2Body* body = fixture->GetBody();
		Object* object=(Object*) body->GetUserData();
		const b2Vec2 position = body->GetPosition();
		engine.DisplayObjects[engine.DisplayObjectCount].Position=D3DXVECTOR2(position.x, position.y)-engine.Map_Loc;
		engine.DisplayObjects[engine.DisplayObjectCount].object=object;
		++engine.DisplayObjectCount;			
		return true;
	}
};

class RayCastCallback:public b2RayCastCallback
{
	public:
	RayCastCallback()
	{
		m_fixture = NULL;
	}
	float32 ReportFixture(b2Fixture* fixture, const b2Vec2& point, const b2Vec2& normal, float32 fraction)
	{
		m_fixture = fixture;
		m_point = point;
		m_normal = normal;
		m_fraction = fraction;
		return fraction;
	}
	b2Fixture* m_fixture;
	b2Vec2 m_point;
	b2Vec2 m_normal;
	float32 m_fraction;
}; 

#endif
