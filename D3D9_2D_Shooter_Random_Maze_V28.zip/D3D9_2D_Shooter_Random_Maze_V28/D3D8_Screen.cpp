#include "d3d8_screen.h"
#include <stdio.h>
#include <math.h>
#include "Map.h"
#include "Engine.h"

extern FILE *file;
extern Engine engine;
extern Floor mapfloor;

const bool Screen::Setup(const int width, const int height, const D3DFORMAT format, const int backbuffers, const HWND hwnd)
{
	g_pD3D				=NULL;
	g_pd3dDevice	=NULL;

	fprintf(file,"d3d Direct3DCreate8\n");
	if ((g_pD3D=Direct3DCreate9(D3D_SDK_VERSION))==NULL)
	{
		return false;
	}

	ScreenSize=D3DXVECTOR2(width, height);
	ScreenSizeHalf=ScreenSize*0.5f;

	D3DPRESENT_PARAMETERS d3dpp; 
	ZeroMemory (&d3dpp, sizeof(d3dpp));
	d3dpp.SwapEffect = D3DSWAPEFFECT_FLIP;
	d3dpp.BackBufferFormat = format;
	d3dpp.BackBufferWidth=width;
	d3dpp.BackBufferHeight=height;
	d3dpp.BackBufferCount=backbuffers;
	d3dpp.Windowed = false;
	d3dpp.FullScreen_RefreshRateInHz=D3DPRESENT_RATE_DEFAULT;
	d3dpp.PresentationInterval=D3DPRESENT_INTERVAL_IMMEDIATE; 
	d3dpp.EnableAutoDepthStencil = false;
	fprintf(file,"d3d CreateDevice\n");
	if (FAILED(g_pD3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hwnd, D3DCREATE_SOFTWARE_VERTEXPROCESSING /*| D3DCREATE_PUREDEVICE*/, &d3dpp, &g_pd3dDevice)))
	{
		return false;
	}

	g_pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW); //D3DCULL_NONE); //D3DCULL_CCW);
	g_pd3dDevice->SetRenderState(D3DRS_FOGENABLE, false);    
	g_pd3dDevice->SetRenderState(D3DRS_CLIPPING, true);
	g_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	g_pd3dDevice->SetRenderState(D3DRS_LIGHTING, false);
	g_pd3dDevice->SetRenderState(D3DRS_SHADEMODE, D3DSHADE_FLAT);
	g_pd3dDevice->SetRenderState(D3DRS_LASTPIXEL, true); 

	g_pd3dDevice->SetSamplerState(0, D3DSAMP_MINFILTER, /*D3DTEXF_NONE);*/D3DTEXF_LINEAR); //D3DTEXF_LINEAR D3DTEXF_POINT
	g_pd3dDevice->SetSamplerState(0, D3DSAMP_MAGFILTER, /*D3DTEXF_NONE);*/D3DTEXF_LINEAR);
	g_pd3dDevice->SetSamplerState(0, D3DSAMP_MIPFILTER, /*D3DTEXF_NONE);*/D3DTEXF_LINEAR);

	g_pd3dDevice->SetTextureStageState(0,D3DTSS_ALPHAARG1,D3DTA_TEXTURE);

	for (int x=0; x!=MAX_TEXTURES; ++x)
	{
		Texture_List[x]=NULL;
	}

	for (int x=0; x!=MAX_VERTEX_BUFFER; ++x)
	{
		TL_Vertex_Buffer[x]=NULL;
		if (FAILED(g_pd3dDevice->CreateVertexBuffer(sizeof(TL_VERTEX)*MAX_VERTEX, D3DUSAGE_WRITEONLY, D3DFVF_TL_VERTEX, D3DPOOL_DEFAULT, &TL_Vertex_Buffer[x], NULL)))
		{
			return false;
		}
		TL_Index_Buffer[x]=NULL;
		if (FAILED(g_pd3dDevice->CreateIndexBuffer(sizeof(WORD)*MAX_VERTEX*3, D3DUSAGE_WRITEONLY, D3DFMT_INDEX16, D3DPOOL_DEFAULT, &TL_Index_Buffer[x], NULL)))
		{
			return false;
		}
	}

	g_pd3dDevice->SetFVF(D3DFVF_TL_VERTEX); 
	D3DXCreateFont(g_pd3dDevice, height/60, width/120, FW_BOLD, 0, false, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, TEXT("Arial"), &Font);

	Vertex_Count=Index_Count=Vertex_Buffer_Count=0;

 	return true;
}

Screen::~Screen()
{
	fprintf(file,"d3d screen shutdown\n");

	for (int y=0; y!=MAX_VERTEX_BUFFER; ++y)
	{
		if (TL_Vertex_Buffer[y]!=NULL)
		{
			TL_Vertex_Buffer[y]->Release();
			TL_Vertex_Buffer[y]=NULL;
		}
		if (TL_Index_Buffer[y]!=NULL)
		{
			TL_Index_Buffer[y]->Release();
			TL_Index_Buffer[y]=NULL;
		}
	}

	for (int y=0; y!=MAX_TEXTURES; ++y)
	{
		if (Texture_List[y]!=NULL)
		{
			Texture_List[y]->Release();
			Texture_List[y]=NULL;
		}
	}

	if (g_pd3dDevice)
	{
		g_pd3dDevice->Release();
		g_pd3dDevice=NULL;
	}
	if (g_pD3D)
	{
		g_pD3D->Release();
		g_pD3D=NULL;
	}
}

const D3DXVECTOR2 Screen::SetScreenPos(const D3DXVECTOR2 &position, const D3DXVECTOR2 &cursor)
{
	return ((cursor+position) *0.5f) - ScreenSizeHalf;
}

const void Screen::Draw_Objects(const DisplayObject *object_list, const int object_count)
{
	Lock_Vertex_Buffer();

	for (int x=0; x!=object_count; ++x)
	{
		Room *room;
		switch (object_list[x].object->Shape)
		{
		case CIRCLE_SHAPE:
			DrawCircle(object_list[x].Position, object_list[x].object->Radius, object_list[x].object->Colour);
			break;
		case LINE_SHAPE:
			DrawLine(object_list[x].Position, object_list[x].Position+object_list[x].object->Vertex, object_list[x].object->Colour);
			break;
		case BOX_SHAPE:
			float xcos, xsin, ycos, ysin, angle;
			angle=object_list[x].object->Body->GetAngle();
			xcos=object_list[x].object->Vertex.x*cosf(angle);
			xsin=object_list[x].object->Vertex.x*sinf(angle);
			ycos=object_list[x].object->Vertex.y*cosf(angle);
			ysin=object_list[x].object->Vertex.y*sinf(angle);
			DrawBox( D3DXVECTOR2(object_list[x].Position.x+((-xcos)-(-ysin)), object_list[x].Position.y+((-ycos)+(-xsin))), D3DXVECTOR2(object_list[x].Position.x+((xcos)-(-ysin)), object_list[x].Position.y+((-ycos)+(xsin))), D3DXVECTOR2(object_list[x].Position.x+((-xcos)-(ysin)), object_list[x].Position.y+((ycos)+(-xsin))), D3DXVECTOR2(object_list[x].Position.x+((xcos)-(ysin)), object_list[x].Position.y+((ycos)+(xsin))), object_list[x].object->Colour);
			break;
		case POLYGON_SHAPE:
			room=(Room *)object_list[x].object->UserData;

////			for (int p=0; p!=room->PointCount; ++p) DrawTriangle(object_list[x].Position+room->Point[0], object_list[x].Position+room->Point[p+1],object_list[x].Position+room->Point[p], 0.95f, object_list[x].object->Colour);
			for (int p=0; p!=room->PointCount; ++p)
			{
				if (room->Wall[p]==true)
				{
					DrawLine(object_list[x].Position+room->Point[p], object_list[x].Position+room->Point[p+1], object_list[x].object->Colour);
				}// 				else DrawLine(object_list[x].Position+room->Point[p], object_list[x].Position+room->Point[p+1], D3DCOLOR_XRGB(255, 255, 255));
			}
//sprintf(string, "%ld %ld",mapfloor.SectorFind(room->Centre), x); DrawText(object_list[x].Position.x+room->Centre.x, object_list[x].Position.y+room->Centre.y, D3DXCOLOR(0, 127, 127, 127), &string[0]);

			break;
		default:
			break;
		}
	}
	Draw_Primitive_Forced();
}

const void Screen::Lock_Vertex_Buffer()
{
	TL_Vertex_Buffer[Vertex_Buffer_Count]->Lock(0, 0, (void**)&Vertex_Buffer, D3DLOCK_DISCARD);
	TL_Index_Buffer[Vertex_Buffer_Count]->Lock(0, 0, (void**)&Index_Buffer, D3DLOCK_DISCARD);

	Vertex_Count=Index_Count=0;
}

const void Screen::Draw_Primitive()
{
	TL_Vertex_Buffer[Vertex_Buffer_Count]->Unlock();
	TL_Index_Buffer[Vertex_Buffer_Count]->Unlock();

	g_pd3dDevice->SetStreamSource(0, TL_Vertex_Buffer[Vertex_Buffer_Count], 0, sizeof(TL_VERTEX)); 
	g_pd3dDevice->SetIndices(TL_Index_Buffer[Vertex_Buffer_Count]);
	g_pd3dDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, Vertex_Count, 0, Index_Count/3);

	++Vertex_Buffer_Count;
	if (Vertex_Buffer_Count==MAX_VERTEX_BUFFER)
	{
		Vertex_Buffer_Count=0;
	}
}

const void Screen::Draw_Primitive_Forced()
{
	if (Vertex_Count!=0)
	{
		Draw_Primitive();
		Lock_Vertex_Buffer();
	}
}

const void Screen::DrawLine(const D3DXVECTOR2 &start, const D3DXVECTOR2 &end, const D3DCOLOR colour)
{
	const D3DXVECTOR2 diff=end-start;
	D3DXVECTOR2 normal_vector= D3DXVECTOR2(-diff.y,diff.x);
	const float length=D3DXVec2Length(&normal_vector);
	const float scale=1.0f/length;
	normal_vector*=scale*2.0f;// *3; *2;

	const D3DXVECTOR2 top_left=start-normal_vector;
	const D3DXVECTOR2 top_right=end-normal_vector;

	Vertex_Buffer[Vertex_Count+0].Position=D3DXVECTOR4(top_left.x,top_left.y,0.0f,1.0f);//top_left
	Vertex_Buffer[Vertex_Count+1].Position=D3DXVECTOR4(top_right.x,top_right.y,0.0f,1.0f);// top_right;
	Vertex_Buffer[Vertex_Count+2].Position=D3DXVECTOR4(start.x,start.y,0.0f,1.0f);// top_right;
	Vertex_Buffer[Vertex_Count+3].Position=D3DXVECTOR4(end.x,end.y,0.0f,1.0f);// top_right;

	Vertex_Buffer[Vertex_Count+0].TU=0.999f; Vertex_Buffer[Vertex_Count+0].TV=0.001f;
	Vertex_Buffer[Vertex_Count+1].TU=0.001f; Vertex_Buffer[Vertex_Count+1].TV=0.001f;
	Vertex_Buffer[Vertex_Count+2].TU=0.001f; Vertex_Buffer[Vertex_Count+2].TV=0.999f;
	Vertex_Buffer[Vertex_Count+3].TU=0.999f; Vertex_Buffer[Vertex_Count+3].TV=0.999f;

	Vertex_Buffer[Vertex_Count+2].Colour=colour;

	Index_Buffer[Index_Count+0]=Index_Buffer[Index_Count+3]=Vertex_Count+2;
	Index_Buffer[Index_Count+1]=Vertex_Count+0;
	Index_Buffer[Index_Count+2]=Index_Buffer[Index_Count+4]=Vertex_Count+1;
	Index_Buffer[Index_Count+5]=Vertex_Count+3;
	Vertex_Count+=4;
	Index_Count+=6;

	if (Vertex_Count>=MAX_VERTEX)
	{
		Draw_Primitive();
		Lock_Vertex_Buffer();
	}
//	Draw_Primitive_Forced();
}

const void Screen::DrawTriangle(const D3DXVECTOR2 &start, const D3DXVECTOR2 &middle, const D3DXVECTOR2 &end, const float texture, const D3DCOLOR colour)
{
	Vertex_Buffer[Vertex_Count+0].Position=D3DXVECTOR4(start.x,start.y,0.9f,0.9f);
	Vertex_Buffer[Vertex_Count+1].Position=D3DXVECTOR4(middle.x,middle.y,0.9f,0.9f);
	Vertex_Buffer[Vertex_Count+2].Position=D3DXVECTOR4(end.x,end.y,0.9f,0.9f);

	Vertex_Buffer[Vertex_Count+0].TU=0.95f; Vertex_Buffer[Vertex_Count+0].TV=texture;
	Vertex_Buffer[Vertex_Count+1].TU=0.95f; Vertex_Buffer[Vertex_Count+1].TV=texture;
	Vertex_Buffer[Vertex_Count+2].TU=0.95f; Vertex_Buffer[Vertex_Count+2].TV=texture;

//	Vertex_Buffer[Vertex_Count+0].TU=0.5f; Vertex_Buffer[Vertex_Count+0].TV=0.5f;
//	Vertex_Buffer[Vertex_Count+1].TU=0.5f; Vertex_Buffer[Vertex_Count+1].TV=0.5f;
//	Vertex_Buffer[Vertex_Count+2].TU=0.5f; Vertex_Buffer[Vertex_Count+2].TV=0.5f;


	Vertex_Buffer[Vertex_Count+0].Colour=colour;

	Index_Buffer[Index_Count+0]=Vertex_Count+0;
	Index_Buffer[Index_Count+1]=Vertex_Count+1;
	Index_Buffer[Index_Count+2]=Vertex_Count+2;
	Vertex_Count+=3;
	Index_Count+=3;

	if (Vertex_Count>=MAX_VERTEX)
	{
		Draw_Primitive();
		Lock_Vertex_Buffer();
	}
//	Draw_Primitive_Forced();
}

const void Screen::DrawText(int  x, int y, D3DCOLOR color, char *string)
{
	RECT rect;
	SetRect(&rect, x, y, 0, 0);
	Font->DrawText(NULL, string, -1, &rect, DT_NOCLIP, color);
}

const void Screen::DrawCircle(const D3DXVECTOR2 &centre, const float radius, const D3DCOLOR colour)
{
	static const D3DXVECTOR2 Circle[]={D3DXVECTOR2(0.000000, 1.000000), D3DXVECTOR2(0.500000, 0.866025), D3DXVECTOR2(0.866025, 0.500000), D3DXVECTOR2(1.000000, -0.000000),
		D3DXVECTOR2(0.866025, -0.500000), D3DXVECTOR2(0.500000, -0.866025), D3DXVECTOR2(0.000000, -1.000000), D3DXVECTOR2(-0.500000, -0.866026),
		D3DXVECTOR2(-0.866025, -0.500000), D3DXVECTOR2(-1.000000, -0.000000), D3DXVECTOR2(-0.866026, 0.499999), D3DXVECTOR2(-0.500001, 0.866025)};

	D3DXVECTOR2 point[13];
	for (int x=0; x!=12; ++x) point[x]=centre+(Circle[x]*radius);
	point[12]=point[0];
	for (int x=1; x!=11; ++x) DrawTriangle(point[0], point[x+1], point[x], 0.95f, colour);
	for (int x=0; x!=12; ++x) DrawLine(point[x], point[x+1], colour);
}

const void Screen::DrawAABox(const D3DXVECTOR2 &start, const D3DXVECTOR2 &end, const D3DCOLOR colour)
{
	DrawBox(D3DXVECTOR2(start.x, start.y), D3DXVECTOR2(start.x, end.y), D3DXVECTOR2(end.x, start.y), D3DXVECTOR2(end.x, end.y), colour);
}

const void Screen::DrawBox(const D3DXVECTOR2 &tl, const D3DXVECTOR2 &tr, const D3DXVECTOR2 &bl, const D3DXVECTOR2 &br, const D3DCOLOR colour)
{
	DrawTriangle(tl, br, bl, 0.95f, colour);
	DrawTriangle(tl, tr, br, 0.95f, colour);
	DrawLine(tl, tr, colour);
	DrawLine(tr, br, colour);
	DrawLine(br, bl, colour);
	DrawLine(bl, tl, colour);
}

const void Screen::DrawBullet(const D3DXVECTOR2 &point, const D3DCOLOR colour)
{
	DrawTriangle(point, D3DXVECTOR2(point.x+2, point.y+2), D3DXVECTOR2(point.x, point.y+2), 0.50f, colour);
	DrawTriangle(point, D3DXVECTOR2(point.x+2, point.y), D3DXVECTOR2(point.x+2, point.y+2), 0.50f, colour);
}
