#ifndef MAP
#define MAP

#include <stdio.h>
#include "map_size.h"

typedef struct
{
	int Model;
	D3DXVECTOR3	BoundingSphereCentre;
	float				BoundingSphereRadius;
	D3DXVECTOR3	BoundingBox[MAX_BOUNDING_BOX];
} BEZIER_PATCH;

typedef struct
{
	int x;
	int y;
	float mx;
	float my;
	int lod;
} DrawOrderLocation;

typedef struct
{
	int old_pos;
	int count;
	int new_pos;
	int IB; //first index buffer this point is used in
} RE_INDEX;

#define MAP_MAX_HEIGHT 32767
#define PATCH_SIZE 8192
#define MAP_SIZE PATCH_POINTS * PATCH_COUNT
#define MAP_DETAIL_SIZE PATCH_COUNT * PATCH_SIZE
#define MAP_TILE_SIZE PATCH_SIZE / PATCH_POINTS

class Map
{
private:   
	const void Build_Grid();
	const void BuildDrawOrder(const int);
	const void AddDrawOrder(const int, const int);
public:
	BEZIER_PATCH Patch_Grid[PATCH_COUNT][PATCH_COUNT]; // patches to be drawn
	const void Setup();
	~Map();
	DrawOrderLocation DrawOrder[PATCH_COUNT*PATCH_COUNT];
	int DrawOrderCount;
};

#endif
