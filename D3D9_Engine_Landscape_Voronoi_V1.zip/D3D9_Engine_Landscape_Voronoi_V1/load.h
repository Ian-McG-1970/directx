#ifndef LOAD
#define LOAD

#include <stdio.h>

class Load
{
private:
public:
	const void	Setup();
	~Load();
};

#endif
