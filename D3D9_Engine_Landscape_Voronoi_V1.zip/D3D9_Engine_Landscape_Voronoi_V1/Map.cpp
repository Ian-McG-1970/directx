#include "stdlib.h"
#include "time.h"

#include "d3d8_screen.h"
#include "load.h"
#include "map.h"

extern Screen screen;
extern Load load;
extern FILE *file;

const void Map::Setup()
{
	fprintf(file,"map setup\n");

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(255, 0, 0), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 255, 0), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 0, 255), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 255, 0), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
	Build_Grid();

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 0, 255), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
	BuildDrawOrder(33);
}

Map::~Map()
{
	fprintf(file,"map shutdown\n");
}

const void Map::Build_Grid()
{
	for (int x=0; x<PATCH_COUNT; ++x)
	{
		for (int y=0; y!=PATCH_COUNT; ++y)
		{
			const D3DXVECTOR3 point[]={D3DXVECTOR3(0,0,0), D3DXVECTOR3(0,0,PATCH_SIZE), D3DXVECTOR3(PATCH_SIZE,0,PATCH_SIZE), D3DXVECTOR3(PATCH_SIZE,0,0)};
			const WORD index[]={ 0,1,2, 0,2,3 };
			const int points=sizeof(point)/sizeof(point[0]);
			const int triangles=(sizeof(index)/sizeof(index[0])/3);

			const D3DCOLOR colour=D3DCOLOR_XRGB(rand(),rand(),rand());
			for(int p=0; p!=points; ++p)
			{
				screen.Vertex[p].Location=point[p];
				screen.Vertex[p].Colour=colour;
			}
			memcpy(&screen.Index[0], &index[0], sizeof(screen.Index[0])*triangles*3);

			Patch_Grid[x][y].Model = screen.CreateObject(points, triangles);

			screen.BoundingBox(&point[0], screen.Model[Patch_Grid[x][y].Model].Vertices, &screen.Model[Patch_Grid[x][y].Model].Bounding_Box[0]);
			screen.BoundingSphere(&screen.Model[Patch_Grid[x][y].Model].Bounding_Box[0], MAX_BOUNDING_BOX, screen.Model[Patch_Grid[x][y].Model].Bounding_Sphere_Radius, screen.Model[Patch_Grid[x][y].Model].Bounding_Sphere_Centre);
		}
	}
}

const void Map::AddDrawOrder(const int x, const int y)
{
	for (int c=0; c!=DrawOrderCount; ++c)
	{
		if ((DrawOrder[c].x==x) && (DrawOrder[c].y==y))
		{
			return;
		}
	}
//	++DrawOrderCount;
	DrawOrder[DrawOrderCount].x=x;
	DrawOrder[DrawOrderCount].y=y;
	DrawOrder[DrawOrderCount].mx=x*PATCH_SIZE;
	DrawOrder[DrawOrderCount].my=y*PATCH_SIZE;
	DrawOrder[DrawOrderCount].lod = sqrt(abs(x*x) + abs(y*y));
//	DrawOrder[DrawOrderCount].lod = max(abs(x), abs(y));
//	DrawOrder[DrawOrderCount].lod=min(abs(x),abs(y));

	DrawOrder[DrawOrderCount].lod /= 3;
//	fprintf(file,"ado2 c %i x %i y %i lod %i\n",DrawOrderCount,DrawOrder[DrawOrderCount].x,DrawOrder[DrawOrderCount].y, DrawOrder[DrawOrderCount].lod);
	++DrawOrderCount;
}

const void Map::BuildDrawOrder(const int patch_end)
{
	DrawOrderCount=0;
	AddDrawOrder(0, 0);
	const int distance = (patch_end - 1) >> 1;
	for (int d=0; d!=distance; ++d)
	{
		for (int x=0; x!=d; ++x)
		{
			for (int y=0; y!=d; ++y)
			{
				if((sqrtf((x*x)+(y*y))) > (float)distance)
				{
					continue;
				}
				AddDrawOrder(x, y);
				AddDrawOrder(x, -y);
				AddDrawOrder(-x, y);
				AddDrawOrder(-x, -y);
			}
		}
	}
}
