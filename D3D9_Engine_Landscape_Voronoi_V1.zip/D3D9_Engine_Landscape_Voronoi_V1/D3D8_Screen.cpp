#include "d3d8_screen.h"
#include <d3d9.h>
#include <stdio.h>
#include <math.h>

extern FILE *file;

const bool Screen::Setup(const int width, const int height, const D3DFORMAT format, const float near_clip, const float far_clip, const D3DFORMAT zbuffer, const int backbuffers, const HWND hwnd)
{
	g_pD3D	=NULL;
	g_pd3dDevice=NULL;

	fprintf(file,"d3d Direct3DCreate9\n");
	g_pD3D=Direct3DCreate9(D3D_SDK_VERSION);
	if (g_pD3D==NULL)
	{
		return false;
	}

	D3DPRESENT_PARAMETERS d3dpp; 
	ZeroMemory (&d3dpp, sizeof(d3dpp));
	d3dpp.SwapEffect = D3DSWAPEFFECT_FLIP;
	d3dpp.BackBufferFormat = format;
	d3dpp.BackBufferWidth=width;
	d3dpp.BackBufferHeight=height;
	d3dpp.BackBufferCount=backbuffers;
	d3dpp.Windowed = false;
	d3dpp.FullScreen_RefreshRateInHz=D3DPRESENT_RATE_DEFAULT;
	d3dpp.PresentationInterval=D3DPRESENT_INTERVAL_IMMEDIATE; 
	d3dpp.EnableAutoDepthStencil = true;
	d3dpp.AutoDepthStencilFormat = zbuffer;
	fprintf(file,"d3d CreateDevice\n");
	if (FAILED(g_pD3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hwnd, D3DCREATE_HARDWARE_VERTEXPROCESSING | D3DCREATE_PUREDEVICE, &d3dpp, &g_pd3dDevice)))
	{
		return false;
	}

  D3DXMatrixPerspectiveFovLH(&Matrix_Projection, D3DX_PI/4.0f, 1.0f, near_clip, far_clip);
  g_pd3dDevice->SetTransform(D3DTS_PROJECTION, &Matrix_Projection);

	fprintf(file,"d3d SetRenderState\n");
	g_pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	g_pd3dDevice->SetRenderState(D3DRS_SHADEMODE, D3DSHADE_FLAT); //D3DSHADE_FLAT //D3DSHADE_GOURAUD
	g_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID); //D3DFILL_WIREFRAME //D3DFILL_SOLID
	g_pd3dDevice->SetRenderState(D3DRS_CLIPPING, true);
	g_pd3dDevice->SetRenderState(D3DRS_ZENABLE, true);

	g_pd3dDevice->SetRenderState(D3DRS_LIGHTING, false);

	g_pd3dDevice->SetRenderState(D3DRS_FOGENABLE, true/*false true*/);
	g_pd3dDevice->SetRenderState(D3DRS_RANGEFOGENABLE, true/*false true*/);
	g_pd3dDevice->SetRenderState(D3DRS_FOGCOLOR, BACKGROUND); 
	g_pd3dDevice->SetRenderState(D3DRS_FOGVERTEXMODE,D3DFOG_LINEAR); //D3DFOG_EXP D3DFOG_EXP2 D3DFOG_LINEAR
	g_pd3dDevice->SetRenderState(D3DRS_FOGSTART, *(DWORD *)(&near_clip));
	g_pd3dDevice->SetRenderState(D3DRS_FOGEND,   *(DWORD *)(&far_clip));

	for (int x=0; x!=MAX_MODELS; ++x)
	{
		Model[x].VB=NULL;
		Model[x].IB=NULL;
	}

	g_pd3dDevice->SetFVF(D3DFVF_IM_VERTEX);
	D3DXCreateFont(g_pd3dDevice, height/40, width/80, FW_BOLD, 0, false, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, TEXT("Arial"), &Font);

	Objects=0;

 	return true;
}

const void Screen::View_Matrix(const D3DXVECTOR3 &location, const D3DXVECTOR3 &direction)
{
	D3DXMATRIX matTmp;
	D3DXMatrixRotationYawPitchRoll(&matTmp, direction.y, direction.x, direction.z); // View direction
	D3DXVECTOR4 tmp;
	D3DXVec3Transform(&tmp, &D3DXVECTOR3(0.0f,0.0f,1.0f), &matTmp);
	const D3DXVECTOR3 viewDir = (D3DXVECTOR3)tmp + location;
	
	D3DXVec3Transform(&tmp, &D3DXVECTOR3(0.0f,1.0f,0.0f), &matTmp); // View up orientation
	const D3DXVECTOR3 viewUp = (D3DXVECTOR3)tmp;

	D3DXMatrixLookAtLH(&Matrix_View, &location, &viewDir, &viewUp);
  g_pd3dDevice->SetTransform(D3DTS_VIEW, &Matrix_View);
	ExtractFrustumPlanes();
}

Screen::~Screen()
{
	fprintf(file,"d3d screen shutdown\n");

	for (int x=0; x!=MAX_MODELS; ++x)
	{
		if (Model[x].VB!=NULL)
		{
			Model[x].VB->Release();
			Model[x].VB=NULL;
		}
		if (Model[x].IB!=NULL)
		{
			Model[x].IB->Release();
			Model[x].IB = NULL;
		}
	}
	if (g_pd3dDevice)
	{
		g_pd3dDevice->Release();
		g_pd3dDevice=NULL;
	}
	if (g_pD3D)
	{
		g_pD3D->Release();
		g_pD3D=NULL;
	}
}

const void Screen::ExtractFrustumPlanes(void)
{
	D3DXMATRIX ViewProj;
	D3DXMatrixMultiply(&ViewProj, &Matrix_View, &Matrix_Projection);

	Frustum[0].a = -(ViewProj._14 + ViewProj._11); // Left clipping plane
	Frustum[0].b = -(ViewProj._24 + ViewProj._21);
	Frustum[0].c = -(ViewProj._34 + ViewProj._31);
	Frustum[0].d = -(ViewProj._44 + ViewProj._41);
	D3DXPlaneNormalize(&Frustum[0], &Frustum[0]);

	Frustum[1].a = -(ViewProj._14 - ViewProj._11); // Right clipping plane
	Frustum[1].b = -(ViewProj._24 - ViewProj._21);
	Frustum[1].c = -(ViewProj._34 - ViewProj._31);
	Frustum[1].d = -(ViewProj._44 - ViewProj._41);
	D3DXPlaneNormalize(&Frustum[1], &Frustum[1]);

	Frustum[2].a = -(ViewProj._14 - ViewProj._12); // Top clipping plane
	Frustum[2].b = -(ViewProj._24 - ViewProj._22);
	Frustum[2].c = -(ViewProj._34 - ViewProj._32);
	Frustum[2].d = -(ViewProj._44 - ViewProj._42);
	D3DXPlaneNormalize(&Frustum[2], &Frustum[2]);

	Frustum[3].a = -(ViewProj._14 + ViewProj._12); // Bottom clipping plane
	Frustum[3].b = -(ViewProj._24 + ViewProj._22);
	Frustum[3].c = -(ViewProj._34 + ViewProj._32);
	Frustum[3].d = -(ViewProj._44 + ViewProj._42);
	D3DXPlaneNormalize(&Frustum[3], &Frustum[3]);

	Frustum[4].a = -(ViewProj._13); // Near clipping plane
	Frustum[4].b = -(ViewProj._23);
	Frustum[4].c = -(ViewProj._33);
	Frustum[4].d = -(ViewProj._43);
	D3DXPlaneNormalize(&Frustum[4], &Frustum[4]);

	Frustum[5].a = -(ViewProj._14 - ViewProj._13); // Far clipping plane
	Frustum[5].b = -(ViewProj._24 - ViewProj._23);
	Frustum[5].c = -(ViewProj._34 - ViewProj._33);
	Frustum[5].d = -(ViewProj._44 - ViewProj._43);
	D3DXPlaneNormalize(&Frustum[5], &Frustum[5]);
}

const bool Screen::IsPointInsideFrustum(const D3DXVECTOR3 *location)
{
	for (int i=0; i!=MAX_PLANES; ++i)
	{
		if (D3DXPlaneDotCoord(&Frustum[i], location)>=0.0f)
		{
			return false;
		}
	}
	return true;
}

const bool Screen::IsBoundingBoxInsideFrustum(const D3DXVECTOR3 *location)
{
	for (int x=0; x!=MAX_PLANES; ++x)
	{
		int y;
		for (y=0; y!=MAX_BOUNDING_BOX; ++y)
		{
			if (D3DXPlaneDotCoord(&Frustum[x], &location[y])<=0.0f)
			{
				break;
			}
		}
		if (y==MAX_BOUNDING_BOX)
		{
			return false;
		}
	}
	return true;
}

const bool Screen::IsBoundingBoxInsideFrustum2(const D3DXVECTOR3 *location, const D3DXVECTOR3 *bounding_box)
{
	for (int x=0; x!=MAX_PLANES; ++x)
	{
		int y;
		for (y=0; y!=MAX_BOUNDING_BOX; ++y)
		{
			const D3DXVECTOR3 position=D3DXVECTOR3(location->x+bounding_box[y].x, location->y+bounding_box[y].y, location->z+bounding_box[y].z); 
			if (D3DXPlaneDotCoord(&Frustum[x], &position)<=0.0f)
			{
				break;
			}
		}
		if (y==MAX_BOUNDING_BOX)
		{
			return false;
		}
	}
	return true;
}

const bool Screen::IsSphereInsideFrustum(const D3DXVECTOR3 *location, const float Bounding_Sphere)
{
	for (int i=0; i!=MAX_PLANES; ++i)
	{
		if (D3DXPlaneDotCoord(&Frustum[i], location)>=Bounding_Sphere)
		{
			return false;
		}
	}
	return true;
}

const void Screen::DrawMap3(const D3DXVECTOR3 *location, const int model)
{
	D3DXMatrixIdentity(&Matrix_Translation);
	D3DXMatrixTranslation(&Matrix_Translation, location->x, location->y, location->z);
	g_pd3dDevice->SetTransform(D3DTS_WORLD, &Matrix_Translation);

	if (model!=Current_Model)
	{
		g_pd3dDevice->SetIndices(Model[model].IB);
		Current_Model = model;
	}

	g_pd3dDevice->SetStreamSource(0, Model[model].VB, 0, sizeof(IM_VERTEX));
	g_pd3dDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, Model[model].Vertices, 0, Model[model].Triangles);
}

const int Screen::CreateObject(const int vertices, const int triangles)
{
	Model[Objects].Vertices=vertices;
	Model[Objects].VB=NULL;
	g_pd3dDevice->CreateVertexBuffer(sizeof(IM_VERTEX)*Model[Objects].Vertices, D3DUSAGE_WRITEONLY, D3DFVF_IM_VERTEX, D3DPOOL_MANAGED/*DEFAULT*/, &Model[Objects].VB, NULL);
	IM_VERTEX* pVertices;
	Model[Objects].VB->Lock(0, sizeof(IM_VERTEX)*Model[Objects].Vertices, (void**)&pVertices, 0);
	memcpy(&pVertices[0], &Vertex[0], sizeof(Vertex[0])*Model[Objects].Vertices);
	Model[Objects].VB->Unlock();

	Model[Objects].Triangles=triangles;
	Model[Objects].IB=NULL;
	g_pd3dDevice->CreateIndexBuffer(sizeof(WORD)*Model[Objects].Triangles*3, D3DUSAGE_WRITEONLY,D3DFMT_INDEX16,D3DPOOL_MANAGED/*DEFAULT*/,&Model[Objects].IB,NULL);
	WORD *pIndices;
	Model[Objects].IB->Lock(0,sizeof(WORD)*Model[Objects].Triangles*3,(void**)&pIndices,0);
	memcpy(&pIndices[0],&Index[0],sizeof(Index[0])*Model[Objects].Triangles*3);
	Model[Objects].IB->Unlock();

	++Objects;
	return Objects-1;
}

const void Screen::DrawText(const int  x, const int y, D3DCOLOR color)
{
	RECT rect;
	SetRect(&rect, x, y, 0, 0);
	Font->DrawText(NULL, string, -1, &rect, DT_NOCLIP, color);
}

const int Screen::IsSphereInsideFrustum2(const D3DXVECTOR3 *location, const float Bounding_Sphere)
{
	int result = ALL_ON;
	for (int i=0; i!=MAX_PLANES; ++i)
	{
		float dot = D3DXPlaneDotCoord(&Frustum[i], location);
		if (dot >Bounding_Sphere)
		{
			return ALL_OFF;
		}
		if (dot <Bounding_Sphere)
		{
			result = INTERSECTING;
		}
	}
	return result;
}

const void Screen::BoundingBox(const D3DXVECTOR3* Point, const int Points, D3DXVECTOR3* BoundingBox)
{
	D3DXVECTOR3 min=Point[0], max=Point[0];
	for (int p=0; p!=Points; ++p)
	{
		min.x = min(min.x, Point[p].x);
		min.y = min(min.y, Point[p].y);
		min.z = min(min.z, Point[p].z);
		max.x = max(max.x, Point[p].x);
		max.y = max(max.y, Point[p].y);
		max.z = max(max.z, Point[p].z);
	}
	BoundingBox[0] = D3DXVECTOR3(min.x, min.y, min.z);
	BoundingBox[1] = D3DXVECTOR3(min.x, min.y, max.z);
	BoundingBox[2] = D3DXVECTOR3(min.x, max.y, min.z);
	BoundingBox[3] = D3DXVECTOR3(min.x, max.y, max.z);
	BoundingBox[4] = D3DXVECTOR3(max.x, min.y, min.z);
	BoundingBox[5] = D3DXVECTOR3(max.x, min.y, max.z);
	BoundingBox[6] = D3DXVECTOR3(max.x, max.y, min.z);
	BoundingBox[7] = D3DXVECTOR3(max.x, max.y, max.z);
}

const void Screen::BoundingSphere(const D3DXVECTOR3* Point, const int Points, float &Radius, D3DXVECTOR3 &Centre)
{
	Centre = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	Radius = (Point[0].x * Point[0].x) + (Point[0].y * Point[0].y) + (Point[0].z * Point[0].z);

	for (int p=0; p!=Points; ++p)
	{
		const float radius = (Point[p].x * Point[p].x) + (Point[p].y * Point[p].y) + (Point[p].z * Point[p].z);
		Radius = max(Radius, radius);
	}
	Radius = sqrtf(Radius);
}
