#ifndef MAP_SZ
#define MAP_SZ

#define PATCH_COUNT 128 //64 patches across/down
//#define PATCH_POINTS 64 //32 //64 //8 map is GRID_SIZE*GRID_SIZE patches

#endif
