
#include <math.h>
#include <stdio.h>
#include "engine.h"
#include "di_mouse.h"
#include "Map.h"

extern Map map;
extern Mouse mouse;
extern Screen screen;
extern FILE *file;

const void Engine::Draw_Object(const D3DXVECTOR2 &position, const D3DXVECTOR2 &size, const D3DCOLOR colour)
{
	DisplayObjects[DisplayObjectCount].Position=position;
	DisplayObjects[DisplayObjectCount].Size=size;
	DisplayObjects[DisplayObjectCount].Colour=colour;
	++DisplayObjectCount;	
}

const bool Engine::Collision(const D3DXVECTOR2 &object1, const D3DXVECTOR2 &size1, const D3DXVECTOR2 &object2, const D3DXVECTOR2 &size2)
{
	if ((object1.x > object2.x+size2.x) || (object1.x+size1.x < object2.x) || (object1.y > object2.y+size2.y) || (object1.y+size1.y < object2.y))
	{
		return false;
	}
	return true;
}

const bool Engine::Remove(Object &object, const int damage)
{
	object.Energy+=damage;
	if (object.Energy<0)
	{
		return true;
	}
	return false;
}

const void Engine::CheckCollisions(Object *object1, int& objects1, const int objectdamage1, Object *object2, int& objects2, const int objectdamage2, const void (Engine::*func)(Object &))
{
	for (int obj1=objects1-1; obj1>=0; --obj1)
	{
		for (int obj2=objects2-1; obj2>=0; --obj2)
		{
			if (Collision(object1[obj1].Position, object1[obj1].Size, object2[obj2].Position, object2[obj2].Size) == true)
			{
				(this->*func)(object2[obj2]);
				if (Remove(object2[obj2], objectdamage2)==true)
				{
					Remove_Object(obj2, object2, objects2);
				}
				(this->*func)(object1[obj1]);
				if (Remove(object1[obj1], objectdamage1)==true)
				{
					Remove_Object(obj1, object1, objects1);
					break;
				}
			}
		}
	}
}

const void Engine::Collide(Object &object)
{
	object.Position -= object.Direction;
}

const void Engine::NoCollide(Object &object)
{
}

const void Engine::Setup()
{
	fprintf(file,"engine setup\n");

	CollidePtr = &Engine::Collide;
	NoCollidePtr = &Engine::NoCollide;

	PlayerCount = EnemyCount = EnemyBulletCount = PlayerBulletCount = WallCount = 0;
	Add_Object(D3DXVECTOR2(rand() &511, rand() &511), D3DXVECTOR2(0, 0), D3DCOLOR_XRGB(255, 255, 255), 9999, D3DXVECTOR2(PLAYER_SIZE, PLAYER_SIZE), &Player[0], PlayerCount);

	Add_Object(D3DXVECTOR2(-256,-256), D3DXVECTOR2(0,0), NULL, 1, D3DXVECTOR2(256, 256+screen.Size.y+256), &Wall[0], WallCount);
	Add_Object(D3DXVECTOR2(-256,-256), D3DXVECTOR2(0,0), NULL, 1, D3DXVECTOR2(256+screen.Size.x+256, 256), &Wall[0], WallCount);
	Add_Object(D3DXVECTOR2(-256, screen.Size.y), D3DXVECTOR2(0, 0), NULL, 1, D3DXVECTOR2(256 + screen.Size.x + 256, 256), &Wall[0], WallCount);
	Add_Object(D3DXVECTOR2(screen.Size.x, -256), D3DXVECTOR2(0, 0), NULL, 1, D3DXVECTOR2(256, 256 + screen.Size.y + 256), &Wall[0], WallCount);

	for (int x=0; x!=64; ++x) Add_Object(D3DXVECTOR2(rand() &511, rand() &511), D3DXVECTOR2(((rand() &31)-15)*0.001f, ((rand() &31)-15)*0.001f), D3DCOLOR_XRGB(rand(), rand(), rand()), 1, D3DXVECTOR2(ENEMY_SIZE, ENEMY_SIZE), &Enemy[0], EnemyCount);

	Tst.Colour=D3DCOLOR_XRGB(255,255,255);
	Tst.Direction=D3DXVECTOR2(1,0);
	Tst.Position=D3DXVECTOR2(5,50);
	Tst.Size=D3DXVECTOR2(50,50);

	test_right=true;
}

Engine::~Engine()
{
	fprintf(file,"engine shutdown\n");
}

const float Engine::InertiaMovement(const float Dir, const float Min, const float Max, const float Speed, const float Velocity)
{
	if ((Dir < 0.0f) && (Velocity > -Max)) 	// less than (<)
	{
		return Velocity-Speed;
	}
	if ((Dir > 0.0f) && (Velocity < Max))
	{
		return Velocity+Speed;
	}
	if ( (Velocity < 0.0f) && (Velocity < -Min) )
	{
		return Velocity+Speed;
	}
	if ((Velocity > 0.0f) && (Velocity > Min) )
	{
		return Velocity-Speed;
	}
	return 0.0f;
}

const void Engine::InertiaMove(Object &player, const D3DXVECTOR2 &direction, const float min, const float max, const float speed)
{
	player.Direction=D3DXVECTOR2(InertiaMovement(direction.x, min, max, speed, player.Direction.x), InertiaMovement(direction.y, min, max, speed, player.Direction.y));
	player.Position+=player.Direction;
}

const void Engine::Input(Object &player)
{
	mouse.Update();
	InertiaMove(player, mouse.Direction, 0.005f, 0.5f, 0.001f);

	if (mouse.FIRE==true)
	{
		Add_Object(D3DXVECTOR2(player.Position.x + PLAYER_BULLET_POS, player.Position.y + PLAYER_BULLET_POS), D3DXVECTOR2(0,-1), D3DCOLOR_XRGB(rand(), rand(), rand()), 1, D3DXVECTOR2(BULLET_SIZE, BULLET_SIZE), &PlayerBullet[0], PlayerBulletCount);
	}
}

const bool Engine::On_Screen(const Object &object)
{
	if ( (object.Position.x>=screen.Size.x) || (object.Position.x+object.Size.x<=0) || (object.Position.y>= screen.Size.y) || (object.Position.y+object.Size.y<=0) )
	{
		return false;
	}
	return true;
}

const void Engine::Draw_Objects(const Object *object_list, const int object_count)
{
	for (int object=0; object!=object_count; ++object)
	{
		if (On_Screen(object_list[object])==true)
		{
			Draw_Object(object_list[object].Position, object_list[object].Size, object_list[object].Colour);
		}
	}	
}

const void Engine::Add_Object(const D3DXVECTOR2 &position, const D3DXVECTOR2 &direction, const D3DCOLOR colour, const int energy, const D3DXVECTOR2 &size, Object *object_list, int& object_count)
{
	if (object_count != MAX_OBJECT)
	{
		object_list[object_count].Position = position;
		object_list[object_count].Direction = direction;
		object_list[object_count].Colour = colour;
		object_list[object_count].Size = size;
		object_list[object_count].Energy = energy;
		object_list[object_count].Size = size;
		++object_count;
	}
}

const void Engine::Move_Objects(Object *object_list, int& object_count)
{
	for (int object=object_count-1; object>=0; object--)
	{
		object_list[object].Position+=object_list[object].Direction;
	}
}

const void Engine::Remove_Object(const int object_number, Object *object_list, int& object_count)
{
	--object_count;
	memcpy(&object_list[object_number], &object_list[object_count], sizeof(object_list[0]));
}

const void Engine::AI(Object *object_list, int& object_count, int& ai_count)
{
	++ai_count;
	if (ai_count>=object_count)
	{
		ai_count=0;
	}
	Add_Object(D3DXVECTOR2(object_list[ai_count].Position.x+ENEMY_BULLET_POS, object_list[ai_count].Position.y+ENEMY_BULLET_POS), D3DXVECTOR2(((rand() & 1023) - 512)*0.001f, ((rand() & 1023) - 512)*0.001f), D3DCOLOR_XRGB(rand(), rand(), rand()), 1, D3DXVECTOR2(BULLET_SIZE, BULLET_SIZE), &EnemyBullet[0], EnemyBulletCount);
}

const void Engine::Move_Enemy(const float start, const float end, float &position, bool &direction)
{
	if (direction==true)
	{
		position+=0.1f;
		if (position > end)
		{
			direction=false;
		}
	}
	else
	{
		position-=0.1f;
		if (position < start)
		{
			direction=true;
		}
	}
}

const void Engine::Update()
{
	screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 0, 0), 1.0f, 0);
	screen.g_pd3dDevice->BeginScene();

	Input(Player[0]);
	AI(&Enemy[0], EnemyCount, AICount);

	for (int r=0; r!=map.Room.size(); ++r)
	{
		for (int e=0; e!=map.Room[r].Enemy.size(); ++e)
		{
			if(map.Room[r].Enemy[e].xplane==HR)
				Move_Enemy(map.Room[r].Enemy[e].start.x,map.Room[r].Enemy[e].end.x,map.Room[r].Enemy[e].position.x,map.Room[r].Enemy[e].direction);
			else
				Move_Enemy(map.Room[r].Enemy[e].start.y,map.Room[r].Enemy[e].end.y,map.Room[r].Enemy[e].position.y,map.Room[r].Enemy[e].direction);
		}
	}

	Move_Objects(&Enemy[0], EnemyCount);
	Move_Objects(&EnemyBullet[0], EnemyBulletCount);
	Move_Objects(&PlayerBullet[0], PlayerBulletCount);

	CheckCollisions(&Player[0], PlayerCount, -1, &EnemyBullet[0], EnemyBulletCount, -1, NoCollidePtr); // player / enemy bullet
	CheckCollisions(&Enemy[0], EnemyCount, -1, &PlayerBullet[0], PlayerBulletCount, -1, NoCollidePtr); // player bullet / enemy
	CheckCollisions(&Player[0], PlayerCount, -1, &Enemy[0], EnemyCount, -1, NoCollidePtr); // player / enemy

	CheckCollisions(&Wall[0], WallCount, 0, &EnemyBullet[0], EnemyBulletCount, -1, CollidePtr);
	CheckCollisions(&Wall[0], WallCount, 0, &PlayerBullet[0], PlayerBulletCount, -1, CollidePtr);
	CheckCollisions(&Wall[0], WallCount, 0, &Enemy[0], EnemyCount, 0, CollidePtr);
	CheckCollisions(&Wall[0], WallCount, 0, &Player[0], PlayerCount, 0, CollidePtr);

	++Frame;
	DisplayObjectCount=0;

	Draw_Objects(&EnemyBullet[0], EnemyBulletCount);
	Draw_Objects(&PlayerBullet[0], PlayerBulletCount);
	Draw_Objects(&Enemy[0], EnemyCount);
	Draw_Objects(&Player[0],PlayerCount);
	Draw_Objects(&Tst, 1);

	screen.Draw_Objects(&DisplayObjects[0],DisplayObjectCount);
	screen.Draw_Room(Player[0].Position,0);

	sprintf(screen.string, "%f %f %i %f %f %f %f %i %i %i %i\n",Player[0].Position.x, Player[0].Position.y, DisplayObjectCount, mouse.Direction.x, mouse.Direction.y, Player[0].Direction.x, Player[0].Direction.y, EnemyBulletCount, PlayerBulletCount, WallCount, Player[0].Energy);
	screen.DrawText(3, 3, D3DXCOLOR(0, 127, 127, 127), &screen.string[0]);

	screen.g_pd3dDevice->EndScene();
	screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);

//	Move_Enemy(Tst.Position.x,Tst.Direction.x,test_right,1.0f/1.1f, 0.001f);
}
