#ifndef MAP
#define MAP

#include "D3D8_Screen.h"
#include "engine.h"

#include <vector>

#define TYP 0
#define SX 2
#define SY 8
#define EX 14
#define EY 20
#define DMG 26
#define HV 26
#define COL 27
#define LEN 27
#define CLD 30

#define MAP_SIZE 16

#define NO 0
#define YS 1
#define MS 64
#define M_S 8.0f
#define HR 0
#define VR 1

#define WALL 0
#define SPARE 1
#define TREASURE 2
#define ENMY 3

#define AND1 1
#define AND3 3
#define AND7 7
#define AND15 15
#define AND31 31
#define AND63 63

#define BLK(typ,sx,sy,ex,ey,dmg,cld,col) ((unsigned long)( ((unsigned long)(typ &AND3)<<TYP) | ((unsigned long)(sx &AND63)<<SX) | ((unsigned long)(sy &AND63)<<SY) | ((unsigned long)(ex &AND63)<<EX) | ((unsigned long)(ey &AND63)<<EY) | ((unsigned long)(dmg &AND1)<<DMG) | ((unsigned long)(col &AND7)<<COL) | ((unsigned long)(cld &AND1)<<CLD)))
#define EMY(typ,sx,sy,ex,ey,hv,len) ((unsigned long)( ((unsigned long)(typ &AND3)<<TYP) | ((unsigned long)(sx &AND63)<<SX) | ((unsigned long)(sy &AND63)<<SY) | ((unsigned long)(ex &AND63)<<EX) | ((unsigned long)(ey &AND63)<<EY) | ((unsigned long)(hv &AND1)<<HV) | ((unsigned long)(len &AND31)<<LEN)))

const D3DXCOLOR Colour[]={ 
	D3DCOLOR_XRGB(192,192,192),
	D3DCOLOR_XRGB(0,0,127),
	D3DCOLOR_XRGB(0,127,0),
	D3DCOLOR_XRGB(0,127,127),
	D3DCOLOR_XRGB(127,0,0),
	D3DCOLOR_XRGB(127,0,127),
	D3DCOLOR_XRGB(127,127,0),
	D3DCOLOR_XRGB(127,127,127),
	D3DCOLOR_XRGB(127,127,255),
	D3DCOLOR_XRGB(127,255,127),
	D3DCOLOR_XRGB(127,255,255),
	D3DCOLOR_XRGB(255,127,127),
	D3DCOLOR_XRGB(255,127,255),
	D3DCOLOR_XRGB(255,255,127),
	D3DCOLOR_XRGB(255,255,255),
	D3DCOLOR_XRGB(64,64,64),

};

typedef struct
{
	D3DXVECTOR2 position;
	D3DXVECTOR2 size;
	bool collide;
	bool damage;
	D3DXCOLOR colour;
} BLOCK;

typedef struct
{
	D3DXVECTOR2 start;
	D3DXVECTOR2 end;
	D3DXVECTOR2 position;
	D3DXVECTOR2 size;
	bool xplane;
	bool direction;
	D3DXCOLOR colour;
} ENEMY;

typedef struct
{
	std::vector<BLOCK> Block;
	std::vector<ENEMY> Enemy;
	BYTE Collision[MS][MS];
} MESH;

typedef struct
{
	WORD X;
	WORD Y;
	WORD Room;
} ROOM;

class Map
{
private:
//	std::vector<MESH> Room;
	WORD Level[MAP_SIZE][MAP_SIZE];
	const BLOCK Block(const unsigned long);
	const ENEMY Enemy(const unsigned long);
	const void BuildCollision(const BLOCK &block);
	BYTE Collision[MS][MS];
public:
	std::vector<MESH> Room;
	const void BuildRoom(const std::vector<unsigned long> &,const int);
	const void Start(D3DXVECTOR2&);
	const bool Setup();
	~Map();
	const MESH RoomMesh(const int);
};

const std::vector<unsigned long> r000={
	BLK(WALL,0,0,1,63,YS,YS,2),
	BLK(WALL,0,0,63,1,YS,YS,3),
	BLK(WALL,0,63,63,1,YS,YS,4),
	BLK(WALL,63,0,1,63,YS,YS,5),
	BLK(WALL,1,7,36,2,YS,YS,6),
	BLK(WALL,48,7,15,2,YS,YS,7),
	BLK(WALL,41,12,5,1,YS,YS,8),
	BLK(WALL,42,16,5,1,YS,YS,8),
	BLK(WALL,43,20,5,1,YS,YS,8),
	BLK(WALL,44,24,5,1,YS,YS,8),
	BLK(WALL,45,28,5,1,YS,YS,8),
	BLK(WALL,46,32,5,1,YS,YS,8),
	BLK(WALL,47,36,5,1,YS,YS,8),
	BLK(WALL,48,40,5,1,YS,YS,8),
	BLK(WALL,49,44,5,1,YS,YS,8),
	BLK(WALL,50,48,5,1,YS,YS,8),
	BLK(WALL,51,52,5,1,YS,YS,8),

	BLK(WALL,18,13,18,2,YS,YS,9),
	BLK(WALL,53,12,6,2,YS,YS,9),

	BLK(WALL,10,38,14,2,YS,YS,10),
	BLK(WALL,34,39,9,2,YS,YS,10),
	BLK(WALL,26,43,4,2,YS,YS,10),

	BLK(WALL,1,59,62,4,YS,YS,11),
	BLK(WALL,1,58,55,1,YS,YS,12),
	BLK(WALL,1,49,2,9,YS,YS,13),
	BLK(WALL,1,44,5,5,YS,YS,14),

	BLK(WALL,14,48,20,3,YS,YS,15),
	BLK(WALL,14,51,5,2,YS,YS,1),
	BLK(WALL,10,53,16,5,YS,YS,2),

	BLK(WALL,40,55,4,1,YS,YS,3),
	BLK(WALL,40,56,7,1,YS,YS,4),
	BLK(WALL,40,57,11,1,YS,YS,5),



	EMY(ENMY,0,0,1,1,HR,31),
	EMY(ENMY,0,0,1,1,VR,31),

	EMY(ENMY,2,5,2,2,HR,16)

};

/*
1/8/37/1
48/8/15/1
*/

#endif
