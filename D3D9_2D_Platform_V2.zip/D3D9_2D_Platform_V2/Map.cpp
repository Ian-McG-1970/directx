#include <time.h>

#include "Map.h"
#include "Load.h"

extern FILE	*file;
extern Screen	screen;
extern Load load;

Map::~Map()
{
	fprintf(file, "Map shutdown\n");
}

const bool Map::Setup()
{
	fprintf(file, "Map reset\n");
	return true;
}

const void Map::Start(D3DXVECTOR2 &start)
{
	start.x=rand()&255;
	start.y=rand()&255;
}

const BLOCK Map::Block(const unsigned long Block)
{
	BLOCK block;
	block.position=D3DXVECTOR2(((Block >>SX) &AND63), ((Block >>SY) &AND63))*M_S;
	block.size=D3DXVECTOR2(((Block >>EX) &AND63), ((Block >>EY) &AND63))*M_S;

	block.colour=Colour[(Block >>COL) &AND7];
	block.collide=(Block >>CLD) &AND1;
	block.damage=(Block >>DMG) &AND1;
	return block;
}

const ENEMY Map::Enemy(const unsigned long Enemy)
{
	ENEMY enemy;
	enemy.position=D3DXVECTOR2(((Enemy >>SX) &AND63),((Enemy >>SY) &AND63))*M_S;
	enemy.size=D3DXVECTOR2(((Enemy >>EX) &AND63),((Enemy >>EY) &AND63))*M_S;
	enemy.start=enemy.position;

	const float length=((Enemy >>LEN) &AND31)*(M_S*2.0f);
	enemy.xplane=((Enemy >>HV) &AND1);

	enemy.end = (enemy.xplane==HR) ? D3DXVECTOR2(enemy.start.x+length,enemy.start.y) : D3DXVECTOR2(enemy.start.x,enemy.start.y+length);

	const int colour=((Enemy)+(Enemy>>4)+(Enemy>>8)+(Enemy>>12))%15;
	enemy.colour=Colour[colour];

	enemy.direction=true;
	return enemy;
}

const void Map::BuildRoom(const std::vector<unsigned long> &mesh, const int room_number)
{
	MESH room;
	room.Block.clear();
	room.Enemy.clear();
	BuildCollision(Block(BLK(WALL,NO,NO,0,0,MS,MS,0)));

	for (int r=0; r!=mesh.size(); ++r)
	{
		if (((mesh[r] &AND3)<<TYP)==WALL)
		{
			const BLOCK block=Block(mesh[r]);
			room.Block.push_back(block);
			BuildCollision(block);
		}
		else if (((mesh[r] &AND3)<<TYP)==ENMY)
		{
			const ENEMY enemy=Enemy(mesh[r]);
			room.Enemy.push_back(enemy);
		}
	}
	memcpy(&room.Collision[0][0], &Collision[0][0], sizeof(Collision[0][0])*MS*MS);
	Room.push_back(room);
}

const void Map::BuildCollision(const BLOCK &block)
{
	const int sx=block.position.x /M_S;
	const int sy=block.position.y /M_S;
	const int ex=(block.position.x+block.size.x) /M_S;
	const int ey=(block.position.y+block.size.y) /M_S;

	for (int x=sx; x!=ex; ++x)
	{
		for (int y=sy; y!=ey; ++y)
		{
			Collision[x][y]=block.collide;
		}
	}
}

const MESH Map::RoomMesh(const int room)
{
	return Room[room];
}
