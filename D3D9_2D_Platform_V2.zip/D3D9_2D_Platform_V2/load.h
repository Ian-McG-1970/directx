#ifndef LOAD
#define LOAD

#include <stdio.h>

class Load
{
public:
	const void	Setup();
	~Load();
};

#endif
