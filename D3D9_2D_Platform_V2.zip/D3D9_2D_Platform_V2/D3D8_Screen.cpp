#include "d3d8_screen.h"
#include <stdio.h>
#include <math.h>
#include "Map.h"
#include "Engine.h"

extern FILE *file;
extern Map map;
extern Engine engine;

const bool Screen::Setup(const int width, const int height, const D3DFORMAT format, const int backbuffers, const HWND hwnd)
{
	g_pD3D				=NULL;
	g_pd3dDevice	=NULL;

	fprintf(file,"d3d Direct3DCreate8\n");
	if ((g_pD3D=Direct3DCreate9(D3D_SDK_VERSION))==NULL)
	{
		return false;
	}

	D3DPRESENT_PARAMETERS d3dpp; 
	ZeroMemory (&d3dpp, sizeof(d3dpp));
	d3dpp.SwapEffect = D3DSWAPEFFECT_FLIP;
	d3dpp.BackBufferFormat = format;
	d3dpp.BackBufferWidth=width;
	d3dpp.BackBufferHeight=height;
	d3dpp.BackBufferCount=backbuffers;
	d3dpp.Windowed = false;
	d3dpp.FullScreen_RefreshRateInHz=D3DPRESENT_RATE_DEFAULT;
	d3dpp.PresentationInterval=D3DPRESENT_INTERVAL_IMMEDIATE; 
	d3dpp.EnableAutoDepthStencil = false;
	fprintf(file,"d3d CreateDevice\n");
	if (FAILED(g_pD3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hwnd, D3DCREATE_SOFTWARE_VERTEXPROCESSING, &d3dpp, &g_pd3dDevice)))
	{
		return false;
	}

	g_pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	g_pd3dDevice->SetRenderState(D3DRS_FOGENABLE, false);    
	g_pd3dDevice->SetRenderState(D3DRS_CLIPPING, true);
	g_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	g_pd3dDevice->SetRenderState(D3DRS_LIGHTING, false);
	g_pd3dDevice->SetRenderState(D3DRS_SHADEMODE, D3DSHADE_FLAT);
	g_pd3dDevice->SetRenderState(D3DRS_LASTPIXEL, true); 

	for (unsigned long x=0; x!=MAX_VERTEX_BUFFER; ++x)
	{
		TL_Vertex_Buffer[x]=NULL;
		if (FAILED(g_pd3dDevice->CreateVertexBuffer(sizeof(TL_VERTEX)*MAX_VERTEX, D3DUSAGE_WRITEONLY, D3DFVF_TL_VERTEX, D3DPOOL_DEFAULT, &TL_Vertex_Buffer[x], NULL)))
		{
			return false;
		}
	}

	g_pd3dDevice->SetFVF(D3DFVF_TL_VERTEX); 
	D3DXCreateFont(g_pd3dDevice, height/60, width/120, FW_BOLD, 0, false, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, TEXT("Arial"), &Font);

	Size = D3DXVECTOR2(width, height);
	Vertex_Count=0;
	Triangle_Count=0;
	Vertex_Buffer_Count=0;

 	return true;
}

Screen::~Screen()
{
	fprintf(file,"d3d screen shutdown\n");
	unsigned long y;

	for (y=0; y!=MAX_VERTEX_BUFFER; ++y)
	{
		if (TL_Vertex_Buffer[y]!=NULL)
		{
			TL_Vertex_Buffer[y]->Release();
			TL_Vertex_Buffer[y]=NULL;
		}
	}

	if (g_pd3dDevice)
	{
		g_pd3dDevice->Release();
		g_pd3dDevice=NULL;
	}
	if (g_pD3D)
	{
		g_pD3D->Release();
		g_pD3D=NULL;
	}
}

const void Screen::Draw_Objects(const DisplayObject *object_list, const int object_count)
{
	Lock_Vertex_Buffer();
	for (int x=0; x!=object_count; ++x)
	{
		Draw_Sprite(object_list[x].Position, object_list[x].Size, object_list[x].Colour);
	}
	Draw_Primitive_Forced();
}

const void Screen::Lock_Vertex_Buffer()
{
	TL_Vertex_Buffer[Vertex_Buffer_Count]->Lock(0, 0, (void**)&Vertex_Buffer, D3DLOCK_DISCARD);
	Vertex_Count=Triangle_Count=0;
}

const void Screen::Draw_Primitive()
{
	TL_Vertex_Buffer[Vertex_Buffer_Count]->Unlock();
	g_pd3dDevice->SetStreamSource(0, TL_Vertex_Buffer[Vertex_Buffer_Count], 0, sizeof(TL_VERTEX)); 
	g_pd3dDevice->DrawPrimitive(D3DPT_TRIANGLELIST, 0, Triangle_Count);

	++Vertex_Buffer_Count;
	if (Vertex_Buffer_Count==MAX_VERTEX_BUFFER)
	{
		Vertex_Buffer_Count=0;
	}
}

const void Screen::Draw_Primitive_Forced()
{
	if (Vertex_Count!=0)
	{
		Draw_Primitive();
//		Lock_Vertex_Buffer();
	}
}

const void Screen::Draw_Sprite(const D3DXVECTOR2 &position,const D3DXVECTOR2 &size, const D3DCOLOR colour)
{
	Vertex_Buffer[Vertex_Count+0].Position.w = Vertex_Buffer[Vertex_Count+1].Position.w = Vertex_Buffer[Vertex_Count+2].Position.w = Vertex_Buffer[Vertex_Count+3].Position.w = Vertex_Buffer[Vertex_Count+4].Position.w = Vertex_Buffer[Vertex_Count+5].Position.w = 1.0f;;

	Vertex_Buffer[Vertex_Count+0].Position.x = Vertex_Buffer[Vertex_Count+1].Position.x = Vertex_Buffer[Vertex_Count+3].Position.x = position.x;
	Vertex_Buffer[Vertex_Count+0].Position.y = Vertex_Buffer[Vertex_Count+2].Position.y = Vertex_Buffer[Vertex_Count+4].Position.y = position.y;
	Vertex_Buffer[Vertex_Count+2].Position.x = Vertex_Buffer[Vertex_Count+4].Position.x = Vertex_Buffer[Vertex_Count+5].Position.x = position.x+(size.x-0.5f);
	Vertex_Buffer[Vertex_Count+1].Position.y = Vertex_Buffer[Vertex_Count+3].Position.y = Vertex_Buffer[Vertex_Count+5].Position.y = position.y+(size.y-0.5f);

	Vertex_Buffer[Vertex_Count+0].Colour = Vertex_Buffer[Vertex_Count+3].Colour = colour;

	Vertex_Count+=6;
	Triangle_Count+=2;

	if (Vertex_Count>=MAX_VERTEX)
	{
		Draw_Primitive();
		Lock_Vertex_Buffer();
	}
}

const void Screen::DrawText(const int x, const int y, const D3DCOLOR color, const char *String)
{
	RECT rect;
	SetRect(&rect, x, y, 0, 0);
	Font->DrawText(NULL, String, -1, &rect, DT_NOCLIP, color);
}

/*
	screen.g_pd3dDevice->SetIndices(screen.Model[map.Patch_Grid[0][0].Model].Index_Buffer);

	screen.Model[object].Vertex_Buffer->Unlock();
	WORD *pIndices;
	screen.Model[object].Index_Buffer->Lock(0, sizeof(WORD)*screen.Model[object].Triangles*3, (void**) &pIndices, 0);
	for (unsigned long y=0, z=0; y!=screen.Model[object].Triangles; ++y, z+=3)
	{
		fscanf(fileopen, "%s", rec);
		pIndices[z] =atol(rec);
		fscanf(fileopen, "%s", rec);
		pIndices[z+1] =atol(rec);
		fscanf(fileopen, "%s", rec);
		pIndices[z+2] =atol(rec);
	}
	screen.Model[object].Index_Buffer->Unlock();
	screen.Model[object].Texture=texture;

g_pd3dDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, Model[model].Vertices, 0, 0, Model[model].Triangles);
*/

const void Screen::Draw_Room(const D3DXVECTOR2 &position, const int room_number)
{
	const MESH room=map.RoomMesh(room_number);
	Lock_Vertex_Buffer();
	for(int r=0; r!=room.Block.size(); ++r)
	{
		Draw_Sprite(position+room.Block[r].position, room.Block[r].size, room.Block[r].colour);
	}

	for (int e=0; e!=room.Enemy.size(); ++e)
	{
		Draw_Sprite(position+room.Enemy[e].position,room.Enemy[e].size,room.Enemy[e].colour);
	}

	Draw_Primitive_Forced();
}
