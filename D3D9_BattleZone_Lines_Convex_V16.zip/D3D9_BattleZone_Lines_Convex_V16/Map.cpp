#include "d3d8_screen.h"
#include "load.h"
#include "map.h"

extern Screen screen;
extern Load load;
extern Map map;
extern FILE *file;

D3DXVECTOR3 mid;

void Map::Setup()
{
	fprintf(file,"map setup\n");

	BuildTrack();
}

Map::~Map()
{
	fprintf(file,"map shutdown\n");
}

void Map::BuildTrack()
{
	TrackSections=TRACK_PATCH_COUNT;
	for (int x=1; x!=TrackSections; ++x)
	{
		Track[x].Model=99+(rand()%9);
		Track[x].Location= D3DXVECTOR3( (((int)rand()&127)-63), (((int)rand()&127)-63), (((int)rand()&127)-63));
		Track[x].Direction=D3DXVECTOR3(rand(),rand(),rand());
		fprintf(file, "bt %i %i\n", x, Track[x].Model);
	}
}
