#ifndef MAP
#define MAP

#define TRACK_PATCH_COUNT 256
extern int XYZCompare(const void *, const void *);

const int Max_Vertices = 65535;
const int Max_Triangles = 65535;
const float EPSILON = 0.000001f;
const int NOT_USED = -1;

struct ITRIANGLE
{
  int p1, p2, p3;
};

struct IEDGE
{
  int p1, p2;
};

typedef struct
{
	unsigned long Model;
	D3DXVECTOR3 Location;
	D3DXVECTOR3 Direction;
} TRACK_PATCH;

class Map
{
private:
	const bool CircumCircle(const float, const float, const float, const float, const float, const float, const float, const float, float &, float &, float &);
	const void Triangulate();
	const void Generate(const int, const int, const int, const int);
	const void Edge_Distance(const int, const int);
	const void Height();
	const void Colourise();
	bool complete[Max_Triangles]; // Allocate memory for the completeness list, flag for each triangle
	IEDGE edges[Max_Triangles]; // Allocate memory for the edge list
	int Colour[Max_Triangles];
	D3DXVECTOR2 points[Max_Vertices];
	float Distance[Max_Vertices];
	ITRIANGLE triangles[Max_Triangles*3]; 
	int Point_Count;
	int Triangle_Count;
	int Map_Size;
	int Grid_Size;
	int Patches;
	int Max_Height;
	const void Map::outputtriangle(unsigned long Point_Count);
public:
		const void Reset(const int, const int, const int, const int);
	void Setup();
	~Map();
	TRACK_PATCH Track[TRACK_PATCH_COUNT];
	void BuildTrack();
	unsigned long TrackSections;
};

#endif
