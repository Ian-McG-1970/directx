#ifndef ENGINE
#define ENGINE

#include "d3d8_screen.h"

class Engine
{
private:
	float	Speed;
	D3DXVECTOR3 Location;
	D3DXVECTOR3 Direction;
	D3DXVECTOR3 BoundingBox;
	void Move(D3DXVECTOR3 &, const D3DXVECTOR3 &, const float);
	void Input(D3DXVECTOR3 &, float &, const float);
	void DrawTrack();
public:
	void Setup();
	~Engine();
	void Update();
};

#endif

