#include "engine.h"
#include "d3d8_screen.h"
#include "di_mouse.h"
#include "map.h"

extern HWND hwnd;
extern Mouse mouse;
extern Map map;
extern Screen screen;

extern FILE *file;

unsigned long count;

void Engine::Setup()
{
	fprintf(file,"engine setup\n");

	Location=D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	Direction=D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	Speed=0.0f;
}

Engine::~Engine()
{
	fprintf(file,"engine shutdown\n");
}

void Engine::Move(D3DXVECTOR3 &location, const D3DXVECTOR3 &direction, const float speed)
{
	D3DXMATRIX  matTmp;
	D3DXMatrixRotationYawPitchRoll(&matTmp, direction.y, direction.x, direction.z);      
	D3DXVECTOR4 tmp;
	const D3DXVECTOR3 viewDir(0.0f, 0.0f, 1.0f);
	D3DXVec3Transform(&tmp, &viewDir, &matTmp);

	location.x += (tmp.x*speed);
	location.y += (tmp.y*speed);
	location.z += (tmp.z*speed);
}

void Engine::Input(D3DXVECTOR3 &direction, float &speed, const float dampen)
{
	mouse.Update();
	if (mouse.LB!=0 && mouse.RB!=0)
	{
		PostMessage(hwnd, WM_CLOSE, 0, 0);
		return;
	}
	if (mouse.LB==0 && mouse.RB==0)
	{
		direction.x -= mouse.Y*dampen;
		direction.y += mouse.X*dampen;
	}
	if (mouse.RB!=0)
	{
		direction.z -= mouse.X*dampen;
	}
	if (mouse.LB!=0)
	{
		speed -= mouse.Y*dampen;
	}
	speed*=0.9999f;
}

void Engine::DrawTrack()
{
	for (unsigned long ts=0; ts!=map.TrackSections; ++ts)
	{
		const unsigned long model=map.Track[ts].Model;
		const D3DXVECTOR3 location=map.Track[ts].Location;

//		map.Track[ts].Direction.x+=0.0001; map.Track[ts].Direction.y+=0.0002; map.Track[ts].Direction.z+=0.0003;

//	fprintf(file,"bsr %ld %f\n",model, screen.Model[model].Bounding_Sphere_Radius);

		if (screen.IsSphereInsideFrustum(location, screen.Model[model].Bounding_Sphere_Centre, screen.Model[model].Bounding_Sphere_Radius)==true)
//		if (screen.IsPointInsideFrustum(&location)==true)
//		if (screen.BoundingBoxInFrustum(&screen.Model[model].Bounding_Box[0], location)==true)
		{
			screen.DrawObject(&location, &map.Track[ts].Direction, model);
			++count;
		}
	}
}

void Engine::Update()
{
	count=0;
	screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, BACKGROUND, 1.0f, 0);

	Input(Direction, Speed, 0.0003f);
	Move(Location, Direction, Speed);
	screen.View_Matrix(&Location, &Direction);

	screen.g_pd3dDevice->BeginScene();
	DrawTrack();

	sprintf(screen.string, "px %5f py %5f pz %5f cnt %ld\n", Location.x, Location.y, Location.z, count);
	screen.DrawText(5, 5, D3DXCOLOR(0, 127, 127, 127));

	screen.g_pd3dDevice->EndScene();
	screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
}




