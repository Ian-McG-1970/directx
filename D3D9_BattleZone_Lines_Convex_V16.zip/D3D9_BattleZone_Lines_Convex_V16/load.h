#ifndef LOAD
#define LOAD

#include <stdio.h>
#include "d3d8_screen.h"

class Load
{
	FILE	*fileopen;
	D3DFORMAT Format;
public:
	const void	Setup(const D3DFORMAT);
	~Load();
	unsigned long Line_List[65536];
	const void Texture2(const int, const D3DCOLOR *);
	const int Generate_Model_Skeleton2(const unsigned long faces, unsigned long& vertices);
	const void Point_Line(const D3DXVECTOR3&, const D3DXVECTOR3&, const D3DXVECTOR3&, D3DXVECTOR3&, D3DXVECTOR3&);
	const bool LineLineIntersect(const D3DXVECTOR3&, const D3DXVECTOR3&, const D3DXVECTOR3&, const D3DXVECTOR3&, D3DXVECTOR3&);
	const void Model_Skeleton2(const float *, const int, const int);
	const int Generate_Lines(const int);
	const void AddLine(const int, const int, int &);
	const D3DXVECTOR3 Middle(const int*, const int, const int, const int, const int);
	const float FacesViewer(const D3DXVECTOR3 &, const D3DXVECTOR3 &, const D3DXVECTOR3 &, const D3DXVECTOR3 &);
};

#endif
