#define NAME "PORTAL"
#define TITLE "PORTAL"

#define WIN32_LEAN_AND_MEAN
#define WIN32_EXTRA_LEAN

#define D3D_OVERLOADS
#define STRICT

#include <windows.h>

#include "d3d8_screen.h"
#include "di_mouse.h"
#include "load.h"
#include "engine.h"
#include "map.h"

Mouse		mouse;
Screen	screen;
Load		load;
Engine	engine;
Map map;

HWND	hwnd;
FILE	*file;

void ReleaseObjects()
{
	fprintf(file, "windows shutdown\n");
}

long FAR PASCAL WindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
    case	WM_DESTROY:
			ReleaseObjects();
			PostQuitMessage(0);
			break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	WNDCLASS wc;
	wc.style = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc = WindowProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = LoadIcon(hInstance, IDI_APPLICATION);
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = NULL;
	wc.lpszMenuName = NAME;
	wc.lpszClassName = NAME;
	RegisterClass(&wc);

	if (!(hwnd = CreateWindowEx(WS_EX_TOPMOST, NAME, TITLE, WS_POPUP, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), NULL, NULL, hInstance, NULL))) return false;

	ShowWindow(hwnd, nCmdShow);
	UpdateWindow(hwnd);

	if ((file = fopen("log.txt", "w")) == NULL) return false;
	fprintf(file, "windows startup\n");

	if (!mouse.Setup(hInstance, hwnd)) return false;

	if (!screen.Setup(GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), D3DFMT_X8R8G8B8, 1.0f, 1024.0f, D3DFMT_D24X8, 2, hwnd)) return false;

	load.Setup(D3DFMT_X8R8G8B8);

	const D3DCOLOR r[] = { D3DCOLOR_XRGB(15, 0, 0), D3DCOLOR_XRGB(255, 16, 16), D3DCOLOR_XRGB(255, 48, 48), D3DCOLOR_XRGB(255, 80, 80), D3DCOLOR_XRGB(255, 112, 112), D3DCOLOR_XRGB(255, 144, 144), D3DCOLOR_XRGB(255, 176, 176), D3DCOLOR_XRGB(255, 255, 255) };
	const D3DCOLOR g[] = { D3DCOLOR_XRGB(0, 15, 0), D3DCOLOR_XRGB(16, 255, 16), D3DCOLOR_XRGB(48, 255, 48), D3DCOLOR_XRGB(80, 255, 80), D3DCOLOR_XRGB(112, 255, 112), D3DCOLOR_XRGB(144, 255, 144), D3DCOLOR_XRGB(176, 255, 176), D3DCOLOR_XRGB(255, 255, 255) };
	const D3DCOLOR b[] = { D3DCOLOR_XRGB(0, 0, 15), D3DCOLOR_XRGB(16, 16, 255), D3DCOLOR_XRGB(48, 48, 255), D3DCOLOR_XRGB(80, 80, 255), D3DCOLOR_XRGB(112, 112, 255), D3DCOLOR_XRGB(144, 144, 255), D3DCOLOR_XRGB(176, 176, 255), D3DCOLOR_XRGB(255, 255, 255) };
	const D3DCOLOR gr[] = { D3DCOLOR_XRGB(15, 15, 15), D3DCOLOR_XRGB(16, 16, 16), D3DCOLOR_XRGB(48, 48, 48), D3DCOLOR_XRGB(80, 80, 80), D3DCOLOR_XRGB(112, 112, 112), D3DCOLOR_XRGB(144, 144, 144), D3DCOLOR_XRGB(176, 176, 176), D3DCOLOR_XRGB(255, 255, 255) };
	load.Texture2(1, &gr[0]);
	load.Texture2(2, &r[0]);
	load.Texture2(3, &g[0]);
	load.Texture2(4, &b[0]);

	const float shape01[] = { 8, -1.000, -1.000, -1.000, -1.000, -1.000, +1.000, -1.000, +1.000, -1.000, -1.000, +1.000, +1.000, +1.000, -1.000, -1.000, +1.000, -1.000, +1.000, +1.000, +1.000, -1.000, +1.000, +1.000, +1.000, 6, 4, 0, 1, 3, 2, 4, 5, 4, 6, 7, 4, 0, 2, 6, 4, 4, 3, 1, 5, 7, 4, 1, 0, 4, 5, 4, 2, 3, 7, 6 };
	const float shape02[] = { 4, -0.500, -0.350, 0.000, +0.500, -0.350, 0.000, 0.000, +0.350, -0.500, 0.000, +0.350, +0.500, 4, 3, 0, 2, 1, 3, 0, 1, 3, 3, 3, 2, 0, 3, 2, 3, 1 };
	const float shape03[] = { 6, 
		-10.0, +10.0, +10.0,
		+10.0, +10.0, +10.0,
+10.0, +10.0, +00.0,
-02.9, +10.0, +02.9,
+00.0, +10.0, -10.0,
-10.0, +10.0, -10.0,

		2, 6, 0, 1, 2, 3, 4, 5, 6, 0, 5, 4, 3, 2, 1 };
	load.Model_Skeleton2(shape01, 1, 99);
	load.Model_Skeleton2(shape01, 2, 101);
	load.Model_Skeleton2(shape01, 3, 103);
	load.Model_Skeleton2(shape01, 4, 105);
	load.Model_Skeleton2(shape02, 1, 100);
	load.Model_Skeleton2(shape02, 2, 102);
	load.Model_Skeleton2(shape02, 3, 104);
	load.Model_Skeleton2(shape02, 4, 106);
	load.Model_Skeleton2(shape03, 1, 107);

	map.Setup();
	engine.Setup();

	MSG msg;
	while (msg.message!=WM_QUIT)
	{
		if (PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
		{
			if (!GetMessage(&msg, NULL, 0, 0))
			{
				return msg.wParam;
			}
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
		{
			engine.Update();
		}
	}
}

