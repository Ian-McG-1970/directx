#include "load.h"
#include "d3d8_screen.h"
#include "map.h"

extern FILE *file;
extern Screen screen;
extern Map map;

// todo look into d3dxoptimizefaces and d3dxoptimizevertices

void Load::Setup()
{
	fprintf(file, "Load setup\n");
}

Load::~Load()
{
	fprintf(file, "Load shutdown\n");
}

long Load::Model(const char *name)
{
	if ((fileopen=fopen(name, "r"))==NULL) return false;

	char rec[256];
	fscanf(fileopen, "%s", rec);
	const unsigned long vertices=atol(rec);
	fscanf(fileopen, "%s", rec);
	const unsigned long triangles=atol(rec);
	fscanf(fileopen, "%s", rec);
	const unsigned long lines=atol(rec);

	for (unsigned long x=0; x!=vertices; ++x)
	{
		fscanf(fileopen, "%s", rec);
		screen.Vertex[x].Location.x=atof(rec);
		fscanf(fileopen, "%s", rec);
		screen.Vertex[x].Location.y=atof(rec);
		fscanf(fileopen, "%s", rec);
		screen.Vertex[x].Location.z=atof(rec);

		fscanf(fileopen, "%s", rec);
		const unsigned long red=atol(rec);
		fscanf(fileopen, "%s", rec);
		const unsigned long green=atol(rec);
		fscanf(fileopen, "%s", rec);
		const unsigned long blue=atol(rec);
		screen.Vertex[x].Colour=D3DCOLOR_XRGB(red, green, blue);
	}

	for (unsigned long y=0, z=0; y!=triangles; ++y, z+=3)
	{
		fscanf(fileopen, "%s", rec);
		screen.Index[z] =atol(rec);
		fscanf(fileopen, "%s", rec);
		screen.Index[z+1] =atol(rec);
		fscanf(fileopen, "%s", rec);
		screen.Index[z+2] =atol(rec);
	}

	for (unsigned long y=0, z=0; y!=lines; ++y, z+=2)
	{
		fscanf(fileopen, "%s", rec);
		screen.Index_Line[z] =atol(rec);
		fscanf(fileopen, "%s", rec);
		screen.Index_Line[z+1] =atol(rec);
	}

	fclose(fileopen);
	return screen.CreateObject(vertices, triangles, lines);
}
