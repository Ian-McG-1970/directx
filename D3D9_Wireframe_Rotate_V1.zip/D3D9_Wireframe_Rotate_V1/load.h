#ifndef LOAD
#define LOAD

#include <stdio.h>

class Load
{
	FILE	*fileopen;
public:
	void	Setup();
	~Load();
	long Model(const char *);
};

#endif
