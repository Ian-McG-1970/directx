#include "d3d8_screen.h"
#include "load.h"
#include "map.h"

extern Screen screen;
extern Load load;
extern FILE *file;

D3DXVECTOR3 mid;

void Map::Setup()
{
	fprintf(file,"map setup\n");

	BuildTrack();
}

Map::~Map()
{
	fprintf(file,"map shutdown\n");
}

void Map::BuildTrack()
{
	TrackPoints=4;
	TrackSections=(TrackPoints-1)>>1;

	TrackList[0][1]=D3DXVECTOR3(15,10,5);
	TrackList[1][1]=D3DXVECTOR3(5,10,5);

	TrackList[2][1]=D3DXVECTOR3(10,10,25);
	TrackList[3][1]=D3DXVECTOR3(10,10,35);

	TrackList[4][1]=D3DXVECTOR3(5,10,45);
	TrackList[5][1]=D3DXVECTOR3(15,10,55);

	TrackList[6][1]=D3DXVECTOR3(25,10,50);
	TrackList[7][1]=D3DXVECTOR3(35,10,50);

	TrackList[0][2]=D3DXVECTOR3(25,10,15);
	TrackList[1][2]=D3DXVECTOR3(15,10,25);

	TrackList[2][2]=D3DXVECTOR3(20,10,25);
	TrackList[3][2]=D3DXVECTOR3(20,10,35);

	TrackList[4][2]=D3DXVECTOR3(15,10,35);
	TrackList[5][2]=D3DXVECTOR3(25,10,45);

	TrackList[6][2]=D3DXVECTOR3(25,10,40);
	TrackList[7][2]=D3DXVECTOR3(35,10,40);

/*		D3DXVECTOR3(-110.0f,10.0f, -50.0f),
		D3DXVECTOR3(90.0f, 10.0f, -140.0f),
		D3DXVECTOR3(150.0f, 10.0f, 20.0f),
		D3DXVECTOR3(140.0f, 10.0f, 110.0f),
		D3DXVECTOR3(0.0f, 10.0f, 70.0f),
		D3DXVECTOR3(-150.0f, 10.0f, 10.0f),
		D3DXVECTOR3(-110.0f, 10.0f, -50.0f),
		D3DXVECTOR3(-107.0f, 10.0f, -47.0f),
		D3DXVECTOR3(89.0f, 10.0f, -134.0f),
		D3DXVECTOR3(147.0f, 10.0f, 20.0f),
		D3DXVECTOR3(138.0f, 10.0f, 107.0f),
		D3DXVECTOR3(01.0f, 10.0f, 68.0f),
		D3DXVECTOR3(-144.0f, 10.0f, 10.0f),
		D3DXVECTOR3(-107.0f, 10.0f, -47.0f) */
//	};


	for (unsigned long tl=0; tl!=TrackPoints; ++tl)
	{
//		TrackList[tl][0]=loaded_track[tl];
//		TrackList[tl][1]=loaded_track[tl+TrackPoints*2];

		fprintf(file,"tl0 %ld lx0 %f lz0 %f\n", tl, TrackList[tl][0].x, TrackList[tl][0].z);
		fprintf(file,"tl1 %ld lx1 %f lz1 %f\n", tl, TrackList[tl][1].x, TrackList[tl][1].z);
	}

	for (unsigned long tp=0, ts=0; ts!=TrackSections; ++ts, tp+=2)
	{

	fprintf(file,"tp %ld ts %ld Tracksections %ld\n", tp, ts, TrackSections);

		PointList[0][0]=TrackList[tp][0];
		PointList[1][0]=TrackList[tp+1][0];
		PointList[2][0]=TrackList[tp+2][0];
		PointList[3][0]=TrackList[tp+3][0];
		PointList[0][1]=TrackList[tp][1];
		PointList[1][1]=TrackList[tp+1][1];
		PointList[2][1]=TrackList[tp+2][1];
		PointList[3][1]=TrackList[tp+3][1];

		PointList[0][0]=(PointList[0][0]+PointList[1][0])/2.0f;
		PointList[0][1]=(PointList[0][1]+PointList[1][1])/2.0f;

		PointList[3][0]=(PointList[2][0]+PointList[3][0])/2.0f;
		PointList[3][1]=(PointList[2][1]+PointList[3][1])/2.0f;

		BuildTrackCurve(15);
		CentreTrack(15);
		BuildTrackSection(15, ts);
	}
}

void Map::CentreTrack(const unsigned long point_count)
{
	D3DXVECTOR3 total=D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	for (unsigned long i=0; i!=point_count; ++i)
	{
		total+=BezierList[i][0];
		total+=BezierList[i][1];
	}
	total.y=0;
	const D3DXVECTOR3 middle=total/point_count;
	for (unsigned long i=0; i!=point_count; ++i)
	{
		BezierList[i][0]-=middle;
		BezierList[i][1]-=middle;
	}
	mid=middle;
}

void Map::BuildTrackCurve(const unsigned long point_count)
{
//	const D3DXVECTOR3 dist=PointList[0][2]-PointList[0][0];
//	const unsigned long detail=sqrtf((dist.x*dist.x) + (dist.y*dist.y) + (dist.z*dist.z));

//	fprintf(file,"lx1 %5.2f ly1 %5.2f lz1 %5.2f lx2 %5.2f ly2 %5.2f lz2 %5.2f lx3 %5.2f ly3 %5.2f lz3 %5.2f\n", PointList[0][0].x, PointList[0][0].y, PointList[0][0].z, PointList[1][0].x, PointList[1][0].y, PointList[1][0].z, PointList[2][0].x, PointList[2][0].y, PointList[2][0].z);
	fprintf(file,"lx1 %5.2f lz1 %5.2f\nlx2 %5.2f lz2 %5.2f\nlx3 %5.2f lz3 %5.2f\nlx4 %5.2f lz4 %5.2f\n", PointList[0][0].x, PointList[0][0].z, PointList[1][0].x, PointList[1][0].z, PointList[2][0].x, PointList[2][0].z, PointList[3][0].x, PointList[3][0].z);
	fprintf(file,"lx1 %5.2f lz1 %5.2f\nlx2 %5.2f lz2 %5.2f\nlx3 %5.2f lz3 %5.2f\nlx4 %5.2f lz4 %5.2f\n", PointList[0][1].x, PointList[0][1].z, PointList[1][1].x, PointList[1][1].z, PointList[2][1].x, PointList[2][1].z, PointList[3][1].x, PointList[3][1].z);

	for (unsigned long i=0; i!=point_count; ++i)
	{
		const float t = (float)i/(point_count-1);
		const float it = 1.0f-t;
		const float t2 = t*t;
		const float it2 = it*it;
//		BezierList[i][0] = (PointList[0][0] * it2) + (2.0f * PointList[1][0] * it * t) + (PointList[2][0] * t2);
//		BezierList[i][1] = (PointList[0][1] * it2) + (2.0f * PointList[1][1] * it * t) + (PointList[2][1] * t2);

		const float mum13 = it*it*it;
		const float mu3 = t*t*t;
		BezierList[i][0] = (mum13*PointList[0][0]) + (3.0f*t*it*it*PointList[1][0]) + (3.0f*t*t*it*PointList[2][0]) + (mu3*PointList[3][0]);
		BezierList[i][1] = (mum13*PointList[0][1]) + (3.0f*t*it*it*PointList[1][1]) + (3.0f*t*t*it*PointList[2][1]) + (mu3*PointList[3][1]);
	}

for (unsigned long i=0; i!=point_count; ++i) fprintf(file,"0 i %ld blx %5.2f blz %5.2f\n", i, BezierList[i][0].x, BezierList[i][0].z);
for (unsigned long i=0; i!=point_count; ++i) fprintf(file,"1 i %ld blx %5.2f blz %5.2f\n", i, BezierList[i][1].x, BezierList[i][1].z);

}

void Map::BuildTrackSection(const unsigned long point_count, const unsigned long track_pos)
{
	fprintf(file,"build track section %ld\n",track_pos);
//	Track[track_pos].Location=D3DXVECTOR3(0.0f, 0.0f, 0.0f);//BezierList[0][0];
	Track[track_pos].Location=mid;//BezierList[0][0];

	unsigned long vertex=point_count*4, index=0;

	for (unsigned long v=0; v!=point_count; ++v)
	{
		screen.Vertex[v].Location=BezierList[v][0];
//		screen.Vertex[v].Colour=D3DCOLOR_XRGB(rand(), rand(), rand());

		screen.Vertex[v+point_count].Location=BezierList[v][1];
//		screen.Vertex[v+point_count].Colour=D3DCOLOR_XRGB(rand(), rand(), rand());

		screen.Vertex[v+(point_count*2)].Location=BezierList[v][0];
		screen.Vertex[v+(point_count*2)].Location.y=0.0f;
//		screen.Vertex[v+(point_count*2)].Colour=D3DCOLOR_XRGB(rand(), rand(), rand());

		screen.Vertex[v+(point_count*3)].Location=BezierList[v][1];
		screen.Vertex[v+(point_count*3)].Location.y=0.0f;
//		screen.Vertex[v+(point_count*3)].Colour=D3DCOLOR_XRGB(rand(), rand(), rand());
	}

	for (unsigned long i=0; i!=point_count-1; ++i)
	{
		screen.Index[index+0]=i+0;
		screen.Index[index+1]=i+point_count;
		screen.Index[index+2]=i+point_count+1;
		screen.Index[index+3]=i+0;
		screen.Index[index+4]=i+point_count+1;
		screen.Index[index+5]=i+1;

		screen.Index[index+6]=i+(point_count*2);
		screen.Index[index+7]=i+0;
		screen.Index[index+8]=i+1;
		screen.Index[index+9]=i+(point_count*2);
		screen.Index[index+10]=i+1;
		screen.Index[index+11]=i+(point_count*2)+1;

		screen.Index[index+12]=i+(point_count*3);
		screen.Index[index+13]=i+(point_count*3)+1;
		screen.Index[index+14]=i+point_count+1;
		screen.Index[index+15]=i+(point_count*3);
		screen.Index[index+16]=i+point_count+1;
		screen.Index[index+17]=i+point_count;

		index+=18;
	}
	int lines=2;
	Track[track_pos].Model=screen.CreateObject(vertex, index/3, lines);
}
