#include "d3d8_screen.h"
#include <d3d9.h>
#include <stdio.h>

extern FILE *file;

bool Screen::Setup(const unsigned long width, const unsigned long height, const D3DFORMAT format, const float near_clip, const float far_clip, const D3DFORMAT zbuffer, const unsigned long backbuffers, const HWND hwnd)
{
	g_pD3D	=NULL;
	g_pd3dDevice=NULL;

	fprintf(file,"d3d Direct3DCreate9\n");
	if ((g_pD3D=Direct3DCreate9(D3D_SDK_VERSION))==NULL) return false;

	D3DPRESENT_PARAMETERS d3dpp; 
	ZeroMemory (&d3dpp, sizeof(d3dpp));
	d3dpp.SwapEffect = D3DSWAPEFFECT_FLIP;
	d3dpp.BackBufferFormat = format;
	d3dpp.BackBufferWidth=width;
	d3dpp.BackBufferHeight=height;
	d3dpp.BackBufferCount=backbuffers;
	d3dpp.Windowed = false;
	d3dpp.FullScreen_RefreshRateInHz=D3DPRESENT_RATE_DEFAULT;
	d3dpp.PresentationInterval=D3DPRESENT_INTERVAL_IMMEDIATE; 
	d3dpp.EnableAutoDepthStencil = true;
	d3dpp.AutoDepthStencilFormat = zbuffer;
	fprintf(file,"d3d CreateDevice\n");
	if (FAILED(g_pD3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hwnd, D3DCREATE_HARDWARE_VERTEXPROCESSING | D3DCREATE_PUREDEVICE, &d3dpp, &g_pd3dDevice))) return false;

  D3DXMatrixPerspectiveFovLH(&Matrix_Projection, D3DX_PI/4.0f, 1.0f, near_clip, far_clip); // For the projection matrix, we set up a perspective transform (which transforms geometry from 3D view space to 2D viewport space, with a perspective divide making objects smaller in the distance). To build a perspective transform, we need the field of view (1/4 pi is common), the aspect ratio, and the near and far clipping planes (which define at what distances geometry should be no longer be rendered).
  g_pd3dDevice->SetTransform(D3DTS_PROJECTION, &Matrix_Projection);

	fprintf(file,"d3d SetRenderState\n");

	g_pd3dDevice->SetRenderState(D3DRS_LASTPIXEL, false); 
	g_pd3dDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, false);
	g_pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	g_pd3dDevice->SetRenderState(D3DRS_SHADEMODE, D3DSHADE_FLAT); //D3DSHADE_FLAT //D3DSHADE_GOURAUD
	g_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID); //D3DFILL_WIREFRAME //D3DFILL_SOLID
	g_pd3dDevice->SetRenderState(D3DRS_CLIPPING, true);
	g_pd3dDevice->SetRenderState(D3DRS_LIGHTING, false);
	g_pd3dDevice->SetRenderState(D3DRS_ZENABLE, true);

	g_pd3dDevice->SetRenderState(D3DRS_DEPTHBIAS, 1);
	g_pd3dDevice->SetRenderState(D3DRS_SLOPESCALEDEPTHBIAS, 1);

//	g_pd3dDevice->SetRenderState(D3DRS_TEXTUREFACTOR, D3DCOLOR_XRGB(0, 255, 0));
//	g_pd3dDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);
//	g_pd3dDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TFACTOR);

	for (unsigned long x=0; x!=MAX_MODELS; ++x)
	{
		Model[x].Vertex_Buffer=NULL;
		Model[x].Index_Triangle_Buffer=NULL;
	}

	g_pd3dDevice->SetFVF(D3DFVF_IM_VERTEX);
	D3DXCreateFont(g_pd3dDevice, height/40, width/80, FW_BOLD, 0, false, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, TEXT("Arial"), &Font);

 	return true;
}

void Screen::View_Matrix(const D3DXVECTOR3 *location, const D3DXVECTOR3 *direction)
{
	D3DXMATRIX  matTmp;
	D3DXVECTOR3 viewDir(0.0f, 0.0f, 1.0f);
	D3DXVECTOR3 viewUp(0.0f, 1.0f, 0.0f);
	D3DXVECTOR4 tmp;
	
	D3DXMatrixRotationYawPitchRoll(&matTmp, direction->y, direction->x, direction->z); // View direction
	D3DXVec3Transform(&tmp, &viewDir, &matTmp);
	viewDir.x = tmp.x + location->x;
	viewDir.y = tmp.y + location->y;
	viewDir.z = tmp.z + location->z;
	
	D3DXVec3Transform(&tmp, &viewUp, &matTmp); // View up orientation
	viewUp.x = tmp.x;
	viewUp.y = tmp.y;
	viewUp.z = tmp.z;

	D3DXMatrixLookAtLH(&Matrix_View, location, &viewDir, &viewUp);
  g_pd3dDevice->SetTransform(D3DTS_VIEW, &Matrix_View);
	ExtractFrustumPlanes();
}

Screen::~Screen()
{
	fprintf(file,"d3d screen shutdown\n");

	for (unsigned long x=0; x!=MAX_MODELS; ++x)
	{
		if (Model[x].Vertex_Buffer!=NULL)
		{
			Model[x].Vertex_Buffer->Release();
			Model[x].Vertex_Buffer=NULL;
		}
		if (Model[x].Index_Triangle_Buffer!=NULL)
		{
			Model[x].Index_Triangle_Buffer->Release();
			Model[x].Index_Triangle_Buffer=NULL;
		}
		if (Model[x].Index_Line_Buffer!=NULL)
		{
			Model[x].Index_Line_Buffer->Release();
			Model[x].Index_Line_Buffer=NULL;
		}
	}

	if (g_pd3dDevice)
	{
		g_pd3dDevice->Release();
		g_pd3dDevice=NULL;
	}
	if (g_pD3D)
	{
		g_pD3D->Release();
		g_pD3D=NULL;
	}
}

void Screen::ExtractFrustumPlanes(void)
{
	D3DXMATRIX ViewProj;
	D3DXMatrixMultiply(&ViewProj, &Matrix_View, &Matrix_Projection);

	Frustum[0].a = -(ViewProj._14 + ViewProj._11); // Left clipping plane
	Frustum[0].b = -(ViewProj._24 + ViewProj._21);
	Frustum[0].c = -(ViewProj._34 + ViewProj._31);
	Frustum[0].d = -(ViewProj._44 + ViewProj._41);
	D3DXPlaneNormalize(&Frustum[0], &Frustum[0]);

	Frustum[1].a = -(ViewProj._14 - ViewProj._11); // Right clipping plane
	Frustum[1].b = -(ViewProj._24 - ViewProj._21);
	Frustum[1].c = -(ViewProj._34 - ViewProj._31);
	Frustum[1].d = -(ViewProj._44 - ViewProj._41);
	D3DXPlaneNormalize(&Frustum[1], &Frustum[1]);

	Frustum[2].a = -(ViewProj._14 - ViewProj._12); // Top clipping plane
	Frustum[2].b = -(ViewProj._24 - ViewProj._22);
	Frustum[2].c = -(ViewProj._34 - ViewProj._32);
	Frustum[2].d = -(ViewProj._44 - ViewProj._42);
	D3DXPlaneNormalize(&Frustum[2], &Frustum[2]);

	Frustum[3].a = -(ViewProj._14 + ViewProj._12); // Bottom clipping plane
	Frustum[3].b = -(ViewProj._24 + ViewProj._22);
	Frustum[3].c = -(ViewProj._34 + ViewProj._32);
	Frustum[3].d = -(ViewProj._44 + ViewProj._42);
	D3DXPlaneNormalize(&Frustum[3], &Frustum[3]);

	Frustum[4].a = -(ViewProj._13); // Near clipping plane
	Frustum[4].b = -(ViewProj._23);
	Frustum[4].c = -(ViewProj._33);
	Frustum[4].d = -(ViewProj._43);
	D3DXPlaneNormalize(&Frustum[4], &Frustum[4]);

	Frustum[5].a = -(ViewProj._14 - ViewProj._13); // Far clipping plane
	Frustum[5].b = -(ViewProj._24 - ViewProj._23);
	Frustum[5].c = -(ViewProj._34 - ViewProj._33);
	Frustum[5].d = -(ViewProj._44 - ViewProj._43);
	D3DXPlaneNormalize(&Frustum[5], &Frustum[5]);
}

bool Screen::IsPointInsideFrustum(const D3DXVECTOR3 *location)
{
	for (unsigned long i=0; i!=MAX_PLANES; ++i)
	{
		if (D3DXPlaneDotCoord(&Frustum[i], location)>=0.0f)
		{
			return false;
		}
	}
	return true;
}

bool Screen::IsSphereInsideFrustum(const D3DXVECTOR3 *location, const float Bounding_Sphere)
{
	for (unsigned long i=0; i!=MAX_PLANES; ++i)
	{
		if (D3DXPlaneDotCoord(&Frustum[i], location)>=Bounding_Sphere)
		{
			return false;
		}
	}
	return true;
}

bool Screen::BoundingBoxInFrustum(const D3DXVECTOR3 *bounding_box, const D3DXVECTOR3 &location)
{
	for (unsigned long x=0; x!=MAX_PLANES; ++x)
	{
		unsigned long y;
		for (y=0; y!=MAX_BOUNDING_BOX; ++y)
		{
			const D3DXVECTOR3 boundingboxpoint=bounding_box[y]+location;
			if (D3DXPlaneDotCoord(&Frustum[x], &boundingboxpoint)<=0.0f)
			{
				break;
			}
		}
		if (y==MAX_BOUNDING_BOX)
		{
			return false;
		}
	}
	return true;
}

bool Screen::BoundingBoxStaticInFrustum(const D3DXVECTOR3 *bounding_box)
{
	for (unsigned long x=0; x!=MAX_PLANES; ++x)
	{
		unsigned long y;
		for (y=0; y!=MAX_BOUNDING_BOX; ++y)
		{
			if (D3DXPlaneDotCoord(&Frustum[x], &bounding_box[y])<=0.0f)
			{
				break;
			}
		}
		if (y==MAX_BOUNDING_BOX)
		{
			return false;
		}
	}
	return true;
}

bool Screen::IsBoundingBoxInsideFrustum(const D3DXVECTOR3 *location)
{
	for (unsigned long x=0; x!=MAX_PLANES; ++x)
	{
		unsigned long y;
		for (y=0; y!=MAX_BOUNDING_BOX; ++y)
		{
			if (D3DXPlaneDotCoord(&Frustum[x], &location[y])<=0.0f)
			{
				break;
			}
		}
		if (y==MAX_BOUNDING_BOX)
		{
			return false;
		}
	}
	return true;
}

void Screen::DrawObject(const D3DXVECTOR3 *location, const D3DXVECTOR3 *direction, const unsigned long model)
{
	D3DXMatrixIdentity(&Matrix_Translation);
	D3DXMatrixTranslation(&Matrix_Translation, location->x, location->y, location->z);
	D3DXMatrixRotationYawPitchRoll(&Matrix_Rotation, direction->y, direction->x, direction->z);
	D3DXMatrixMultiply(&Matrix_World, &Matrix_Rotation, &Matrix_Translation);
	g_pd3dDevice->SetTransform(D3DTS_WORLD, &Matrix_World);

	g_pd3dDevice->SetStreamSource(0, Model[model].Vertex_Buffer,0, sizeof(IM_VERTEX));

	g_pd3dDevice->SetIndices(Model[model].Index_Line_Buffer);
	g_pd3dDevice->DrawIndexedPrimitive(D3DPT_LINELIST, 0, 0, Model[model].Vertices, 0, Model[model].Lines);
	g_pd3dDevice->SetIndices(Model[model].Index_Triangle_Buffer);
	g_pd3dDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, Model[model].Vertices, 0, Model[model].Triangles);
}

unsigned long Screen::CreateObject(const unsigned long vertices, const unsigned long triangles, const unsigned long lines)
{
	const unsigned long object=Objects;
	++Objects;
	fprintf(file,"co1 o %ld v %ld t %ld\n", object, vertices, triangles);

	Model[object].Vertices=vertices;
	Model[object].Triangles=triangles;
	Model[object].Lines=lines;
	Model[object].Vertex_Buffer=NULL;
	Model[object].Index_Triangle_Buffer=NULL;
	Model[object].Index_Line_Buffer=NULL;

	LPD3DXMESH mesh;
	D3DXCreateMeshFVF(Model[object].Triangles, Model[object].Vertices, D3DXMESH_MANAGED, D3DFVF_IM_VERTEX, g_pd3dDevice, &mesh);

	IM_VERTEX* mesh_vertices;
	mesh->LockVertexBuffer(D3DLOCK_DISCARD, (void**) &mesh_vertices);
	memcpy(&mesh_vertices[0], &Vertex[0], sizeof(Vertex[0])*Model[object].Vertices);
	g_pd3dDevice->CreateVertexBuffer(sizeof(IM_VERTEX)*Model[object].Vertices, D3DUSAGE_WRITEONLY, D3DFVF_IM_VERTEX, D3DPOOL_DEFAULT, &Model[object].Vertex_Buffer, NULL);
  IM_VERTEX* pVertices;
	Model[object].Vertex_Buffer->Lock(0, sizeof(IM_VERTEX)*Model[object].Vertices, (void**) &pVertices, 0);
	memcpy(&pVertices[0], &mesh_vertices[0], sizeof(mesh_vertices[0])*Model[object].Vertices);

	WORD *mesh_indices;
	mesh->LockIndexBuffer(D3DLOCK_DISCARD, (void**) &mesh_indices);
	memcpy(&mesh_indices[0], &Index[0], sizeof(Index[0])*Model[object].Triangles*3);
	g_pd3dDevice->CreateIndexBuffer(sizeof(WORD)*Model[object].Triangles*3, D3DUSAGE_WRITEONLY, D3DFMT_INDEX16, D3DPOOL_DEFAULT, &Model[object].Index_Triangle_Buffer, NULL);
	WORD *pIndices;
	Model[object].Index_Triangle_Buffer->Lock(0, sizeof(WORD)*Model[object].Triangles*3, (void**) &pIndices, 0);
	memcpy(&pIndices[0], &mesh_indices[0], sizeof(mesh_indices[0])*Model[object].Triangles*3);
	Model[object].Index_Triangle_Buffer->Unlock();
	mesh->UnlockIndexBuffer();

	D3DXVECTOR3 min, max;
	D3DXComputeBoundingBox(&mesh_vertices[0].Location, Model[object].Vertices, sizeof(mesh_vertices[0]), &min, &max);
	D3DXComputeBoundingSphere(&mesh_vertices[0].Location, Model[object].Vertices, sizeof(IM_VERTEX), &Model[object].Bounding_Sphere_Centre, &Model[object].Bounding_Sphere_Radius);

	Model[object].Vertex_Buffer->Unlock();
	mesh->UnlockVertexBuffer();
	mesh->Release();
	mesh=NULL;

	g_pd3dDevice->CreateIndexBuffer(sizeof(WORD)*Model[object].Lines*2, D3DUSAGE_WRITEONLY, D3DFMT_INDEX16, D3DPOOL_DEFAULT, &Model[object].Index_Line_Buffer, NULL);
	Model[object].Index_Line_Buffer->Lock(0, sizeof(WORD)*Model[object].Lines*3, (void**) &pIndices, 0);
	memcpy(&pIndices[0], &Index_Line[0], sizeof(Index_Line[0])*Model[object].Lines*2);
	Model[object].Index_Line_Buffer->Unlock();

	Model[object].Bounding_Box[0]=D3DXVECTOR3(min.x, min.y, min.z);
	Model[object].Bounding_Box[1]=D3DXVECTOR3(min.x, min.y, max.z);
	Model[object].Bounding_Box[2]=D3DXVECTOR3(min.x, max.y, min.z);
	Model[object].Bounding_Box[3]=D3DXVECTOR3(min.x, max.y, max.z);
	Model[object].Bounding_Box[4]=D3DXVECTOR3(max.x, min.y, min.z);
	Model[object].Bounding_Box[5]=D3DXVECTOR3(max.x, min.y, max.z);
	Model[object].Bounding_Box[6]=D3DXVECTOR3(max.x, max.y, min.z);
	Model[object].Bounding_Box[7]=D3DXVECTOR3(max.x, max.y, max.z);

	fprintf(file,"co2 o %ld v %ld t %ld\n", object, Model[object].Vertices, Model[object].Triangles);
	return object;
}

void Screen::DrawText(const unsigned long  x, const unsigned long y, const D3DCOLOR color)
{
	RECT rect;
	SetRect(&rect, x, y, 0, 0);
	Font->DrawText(NULL, string, -1, &rect, DT_NOCLIP, color);
}

void Screen::DrawBoundingBox(const unsigned long model)
{
return;
	static const WORD index[]={0,1,1,3,3,2,2,0,4,5,5,7,7,6,6,4,0,4,1,5,3,7,2,6};
	g_pd3dDevice->DrawIndexedPrimitiveUP(D3DPT_LINELIST, 0, 8, 12, (void*) index, D3DFMT_INDEX16, (void*) Model[model].Bounding_Box[0], sizeof(D3DXVECTOR3));     

}
