#ifndef MAP
#define MAP

#define TRACK_PATCH_COUNT 256

typedef struct
{
	unsigned long Model;
	D3DXVECTOR3 Location;
	D3DXVECTOR3 Direction;
} TRACK_PATCH;

class Map
{
private:
	D3DXVECTOR3 TrackList[256][2];
	D3DXVECTOR3 PointList[4][2];
	D3DXVECTOR3 BezierList[256][2];
	void BuildTrackCurve(const unsigned long);
	void CentreTrack(const unsigned long);
	void BuildTrackSection(const unsigned long, const unsigned long);
	unsigned long TrackPoints;
public:
	void Setup();
	~Map();
	TRACK_PATCH Track[TRACK_PATCH_COUNT];
	void BuildTrack();
	unsigned long TrackSections;
};

#endif
