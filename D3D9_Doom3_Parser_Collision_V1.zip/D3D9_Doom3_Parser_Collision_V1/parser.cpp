#include "parser.h"
#include "log.h"
#include "d3d8_screen.h"
#include <algorithm>

extern LogFile logfile;
extern FILE *file;
extern Screen screen;

const D3DXVECTOR3 Parser::FlipPoint(const D3DXVECTOR3 &point)
{
	return D3DXVECTOR3(point.x,point.z,point.y);
}

const std::vector<char> Parser::Load(const char * filename)
{
	std::vector<char> output;
	fprintf(file,"load %s\n",filename);

	FILE *fileopen = fopen(filename, "rb");

	fseek(fileopen, 0, SEEK_END); // find the file size
	fpos_t size = 0;
	fgetpos(fileopen, &size);
	const int bytes = (int)size;
	fprintf(file,"%s size %i\n",filename,bytes);

	fseek(fileopen, 0, SEEK_SET);

	output.resize(bytes+1); // allocate data for this file
	fread(&output[0], 1, bytes, fileopen); // read in the entire file
	output[bytes] = '\0'; // add an EOF character

	fprintf(file,"load close %s\n",filename);
	fclose(fileopen); // close this file after we are done with it
	return output;//(file_contents != NULL);
}

const void Parser::Output(const char *filename, const std::vector<char> stream)
{
	fprintf(file,"output %s %i\n",filename, stream.size());

	FILE *fileoutput = fopen(filename, "w");

	for (int o=0; o!=stream.size(); ++o)
	{
		fprintf(fileoutput,"%c",stream[o]);

		if ((o&127)==0)
		{
			fprintf(fileoutput,"\n");
		}
	}
	fprintf(fileoutput,"\n");
	fclose(fileoutput);
}

const void Parser::RemoveComments(std::vector<char> &stream,const char replace)
{
	bool inside_comment=false;
	for (int i=0; i!=stream.size(); ++i)
	{
		if (inside_comment==false)
		{
			if ((stream[i] == '/') && (stream[i+1] == '*'))
			{
				inside_comment=true;
			}
		}
		if (inside_comment==true)
		{
			if ((stream[i] == '*') && (stream[i+1] == '/'))
			{
				stream[i+1]=replace;
				inside_comment=false;
			}
			stream[i]=replace;
		}
	}
}

const std::string Parser::String(const std::vector<char> &input, const int start, const int end)
{
	std::string text;
	for (int s=start+1; s!=end; ++s)
	{
		text.push_back(input[s]);
	}
	text.push_back('\0');
	return text;
}

const void Parser::Parse(const char * file_name)
{
	char filename[256];
	char extension[8];
	strcpy(filename,file_name);
	strcpy(extension, ".proc");
	strncat(filename,extension,255);

	screen.g_pd3dDevice->Clear(0,NULL,D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,D3DCOLOR_XRGB(255,255,255),1.0f,0); screen.g_pd3dDevice->Present(NULL,NULL,NULL,NULL);

	std::vector<char> proc_contents=Load(filename);

	screen.g_pd3dDevice->Clear(0,NULL,D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,D3DCOLOR_XRGB(127,127,127),1.0f,0); screen.g_pd3dDevice->Present(NULL,NULL,NULL,NULL);

	std::replace(proc_contents.begin(), proc_contents.end(), '\n', ' ');
	screen.g_pd3dDevice->Clear(0,NULL,D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,D3DCOLOR_XRGB(255,63,63),1.0f,0); screen.g_pd3dDevice->Present(NULL,NULL,NULL,NULL);
	std::replace(proc_contents.begin(), proc_contents.end(), '\0', ' ');
	screen.g_pd3dDevice->Clear(0,NULL,D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,D3DCOLOR_XRGB(63,255,63),1.0f,0); screen.g_pd3dDevice->Present(NULL,NULL,NULL,NULL);

	RemoveComments(proc_contents, '^');
	screen.g_pd3dDevice->Clear(0,NULL,D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,D3DCOLOR_XRGB(63,63,255),1.0f,0); screen.g_pd3dDevice->Present(NULL,NULL,NULL,NULL);
	proc_contents.erase(std::remove(begin(proc_contents), end(proc_contents), '^'), end(proc_contents));
	Output("test3.txt", proc_contents);

	screen.g_pd3dDevice->Clear(0,NULL,D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,D3DCOLOR_XRGB(255,0,0),1.0f,0); screen.g_pd3dDevice->Present(NULL,NULL,NULL,NULL);


	ParseAreas(proc_contents);
	screen.g_pd3dDevice->Clear(0,NULL,D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,D3DCOLOR_XRGB(0,255,0),1.0f,0); screen.g_pd3dDevice->Present(NULL,NULL,NULL,NULL);
	ParsePortals(proc_contents);
	screen.g_pd3dDevice->Clear(0,NULL,D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,D3DCOLOR_XRGB(0,0,255),1.0f,0); screen.g_pd3dDevice->Present(NULL,NULL,NULL,NULL);
	ParseBSP(proc_contents);
	screen.g_pd3dDevice->Clear(0,NULL,D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,D3DCOLOR_XRGB(255,255,0),1.0f,0); screen.g_pd3dDevice->Present(NULL,NULL,NULL,NULL);

	sprintf(logfile.file_output,"parse end %i %i\n",models.size(),nodes.size()); logfile.Write();

	strcpy(filename,file_name);
	strcpy(extension,".cm");
	strncat(filename,extension,255);

	screen.g_pd3dDevice->Clear(0,NULL,D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,D3DCOLOR_XRGB(255,255,255),1.0f,0); screen.g_pd3dDevice->Present(NULL,NULL,NULL,NULL);
	std::vector<char> cm_contents=Load(filename);
	
	std::replace(cm_contents.begin(),cm_contents.end(),'\n',' ');
	screen.g_pd3dDevice->Clear(0,NULL,D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,D3DCOLOR_XRGB(255,63,63),1.0f,0); screen.g_pd3dDevice->Present(NULL,NULL,NULL,NULL);
	std::replace(cm_contents.begin(),cm_contents.end(),'\0',' ');
	screen.g_pd3dDevice->Clear(0,NULL,D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,D3DCOLOR_XRGB(63,255,63),1.0f,0); screen.g_pd3dDevice->Present(NULL,NULL,NULL,NULL);

	RemoveComments(cm_contents,'^');
	screen.g_pd3dDevice->Clear(0,NULL,D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,D3DCOLOR_XRGB(63,63,255),1.0f,0); screen.g_pd3dDevice->Present(NULL,NULL,NULL,NULL);
	cm_contents.erase(std::remove(begin(cm_contents),end(cm_contents),'^'),end(cm_contents));
	Output("test4.txt",cm_contents);

	fprintf(file,"models %i %i\n",models.size(),nodes.size());
}

const std::string Parser::NumberString(std::string &stream)
{
//	if (stream[0]!=' ')
//	{
//		stream = ' ' + stream;
//	}

	int first_non_space=0;
	for(; first_non_space!=stream.length(); ++first_non_space) // find first non space
	{
		if (stream[first_non_space]!=' ')
		{
			break;
		}
	}

	int middle_space=first_non_space;
	for(; middle_space!=stream.length(); ++middle_space) // find middle space
	{
		if (stream[middle_space]==' ')
		{
			break;
		}
	}

	std::string string;
	string.clear();
	for (int f=1; f!=middle_space; ++f) // create string from start to middle space
	{
		string.push_back(stream[f]);
		stream[f]=' ';
	}
	string.push_back('\0');
	return string;
}

const void Parser::ParseAreas(const std::vector<char> &stream)
{
	int last_model=0;
	last_model=Find(stream,"interAreaPortals",last_model)-16; // word model - minimum size of vertex?

	for (int position=0; position<last_model; )
	{
		MESH mesh;
		mesh.index.clear();
		mesh.vertex.clear();

		Find(stream,"model", position); // word model
		Find(stream,"{",position); // {
		const int quote1=Find(stream,"\"",position); // "
		const int quote2=Find(stream,"\"",position); // "

		const int curlybracketfirstface=Find(stream,"{",position); // {

		const std::string face_string=String(stream, quote2, curlybracketfirstface);
		const int face_count=atoi(face_string.c_str());

		--position; // to refind first face bracket

		for (int f=0; f!=face_count; ++f)
		{ 
			Find(stream,"{",position); // {
			Find(stream,"\"",position); // "
			const int quote4=Find(stream,"\"",position); // "
			const int bracketfirstvertex=Find(stream,"(",position); // (
			std::string vertex_index_string=String(stream,quote4,bracketfirstvertex);

			const std::string vertex_string=NumberString(vertex_index_string);
			const std::string index_string=NumberString(vertex_index_string);
			const int vertex_count=atoi(vertex_string.c_str());
			const int index_count=atoi(index_string.c_str());

			--position; // to refind first vertex bracket

			int vbracketclose;
			for (int v=0; v!=vertex_count; ++v)
			{
				const int vbracketopen=Find(stream,"(",position); // (
				vbracketclose=Find(stream,")",position); // )
				std::string point_string=String(stream,vbracketopen,vbracketclose);

				const std::string x_str=NumberString(point_string);
				const std::string y_str=NumberString(point_string);
				const std::string z_str=NumberString(point_string);

				const D3DXVECTOR3 vertex=FlipPoint(D3DXVECTOR3(atof(x_str.c_str()), atof(y_str.c_str()), atof(z_str.c_str())));
				mesh.vertex.push_back(vertex);
			}

			const int fcurlybracketclose=Find(stream,"}",position); // }
			std::string indexes_string=String(stream, vbracketclose, fcurlybracketclose);

			const int vertex_offset=mesh.vertex.size()-vertex_count;
			for (int i=0; i!=index_count; ++i)
			{
				const std::string index_str=NumberString(indexes_string);
				const WORD index=atoi(index_str.c_str())+vertex_offset;

				mesh.index.push_back(index);
			}
		}

		if (mesh.vertex.size()!=0)
		{
			std::string area_string=String(stream,quote1,quote2);
			if (Find1(area_string,"_area")==true)
			{
				area_string.erase(std::remove(begin(area_string),end(area_string),'_'),end(area_string));
				area_string.erase(std::remove(begin(area_string),end(area_string),'a'),end(area_string));
				area_string.erase(std::remove(begin(area_string),end(area_string),'r'),end(area_string));
				area_string.erase(std::remove(begin(area_string),end(area_string),'e'),end(area_string));
				area_string.erase(std::remove(begin(area_string), end(area_string),'a'), end(area_string));
				mesh.area=atoi(area_string.c_str());
				models.push_back(mesh);
			}
		}

		Find(stream,"}",position); // {
	}
}

const void Parser::ParseBSP(std::vector<char> &stream)
{
	sprintf(logfile.file_output,"parsebsps start\n"); logfile.Write();

	int position=0;
	position=Find(stream,"interAreaPortals",position);
	position=Find(stream,"nodes",position); // word nodes

	const int open_curly_bracket=Find(stream,"{",position);
	int temp=position;
//	sprintf(logfile.file_output,"ocb %i %i\n",temp,position); logfile.Write();

	const int close_curly_bracket=Find(stream,"}",temp); // find next curly bracket
	stream[close_curly_bracket]='('; // change } to a }
//	position=temp; //
//	sprintf(logfile.file_output,"ocb %i %i\n",temp,position); logfile.Write();

	const int open_bracket=Find(stream,"(",position);

	std::string nodes_string=String(stream,open_curly_bracket,open_bracket);
	const int planes=atoi(nodes_string.c_str());
	--position;

	sprintf(logfile.file_output,"planes %i\n",planes); logfile.Write();

	nodes.clear();
	for(int node=0; node!=planes; ++node)
	{
		const int node_bracket_open=Find(stream,"(",position);
		const int node_bracket_close=Find(stream,")",position);


		std::string node_plane_string=String(stream,node_bracket_open,node_bracket_close);
		const std::string a_str=NumberString(node_plane_string);
		const std::string b_str=NumberString(node_plane_string);
		const std::string c_str=NumberString(node_plane_string);
		const std::string d_str=NumberString(node_plane_string);

		const D3DXVECTOR3 plane_point=FlipPoint(D3DXVECTOR3(atof(a_str.c_str()),atof(b_str.c_str()),atof(c_str.c_str())));

		const int node_bracket_open_next=Find(stream,"(",position);
		--position;

		std::string node_child_string=String(stream,node_bracket_close,node_bracket_open_next);
		const std::string p_str=NumberString(node_child_string);
		const std::string n_str=NumberString(node_child_string);

		NODE n;
		n.plane = D3DXPLANE(plane_point.x,plane_point.y,plane_point.z,atof(d_str.c_str()));
		n.children[0]=atoi(p_str.c_str());
		n.children[1]=atoi(n_str.c_str());
		nodes.push_back(n);

	}
	sprintf(logfile.file_output,"parsebsps end\n"); logfile.Write();
}

const void Parser::ParsePortals(const std::vector<char> &stream)
{
	sprintf(logfile.file_output,"parseportals start\n"); logfile.Write();

	int position=0;
	position=Find(stream,"interAreaPortals",position);

	const int open_curly_bracket=Find(stream,"{",position);
	const int open_bracket=Find(stream,"(",position);
	--position;

	std::string area_portal_string=String(stream,open_curly_bracket,open_bracket);
	const std::string area_str=NumberString(area_portal_string);
	const std::string portals_str=NumberString(area_portal_string);

	const int area_cnt=atoi(area_str.c_str());
	const int portal_cnt=atoi(portals_str.c_str());

	sprintf(logfile.file_output,"iap %i\n",portal_cnt); logfile.Write();

	position=open_curly_bracket+area_str.length()+portals_str.length();
	position--;

	for (int p=0; p!=portal_cnt; ++p)
	{
		PORTAL portal;
		const int start_portal = position;
		const int first_open_bracket=Find(stream,"(",position);
		--position;

		std::string points_parea_narea_string=String(stream,start_portal,first_open_bracket);
		points_parea_narea_string = ' ' + points_parea_narea_string;
		const std::string portal_points_str=NumberString(points_parea_narea_string);
		const std::string pos_portal_str=NumberString(points_parea_narea_string);
		const std::string neg_portal_str=NumberString(points_parea_narea_string);

		const int portal_points=atoi(portal_points_str.c_str());
	
		portal.from_area=atoi(pos_portal_str.c_str());
		portal.to_area=atoi(neg_portal_str.c_str());

//		sprintf(logfile.file_output,"iap %i\n",portal_cnt); logfile.Write();

		sprintf(logfile.file_output,"portal %i %i %i\n",p,portal_cnt,portal_points); logfile.Write();

		for (int pp=0; pp!=portal_points; ++pp)
		{
			const int open_bracket=Find(stream,"(",position);
			const int close_bracket=Find(stream,")",position);

			std::string point_string=String(stream,open_bracket,close_bracket);
			const std::string x_str=NumberString(point_string);
			const std::string y_str=NumberString(point_string);
			const std::string z_str=NumberString(point_string);

			const D3DXVECTOR3 portal_point=FlipPoint(D3DXVECTOR3(atof(x_str.c_str()),atof(y_str.c_str()),atof(z_str.c_str())));
			portal.point.push_back(portal_point);
		}
		portals.push_back(portal);
	}
	sprintf(logfile.file_output,"parseportals end\n"); logfile.Write();
}

const int Parser::Find(const std::vector<char> &stream, const std::string find, int &position)
{
	for (; position!=stream.size(); ++position)
	{
		bool found = true;
		for (int f=0; f!=find.size(); ++f)
		{
			if (stream[position+f]!=find[f])
			{
				found=false;
				break;
			}
		}
		if (found==true)
		{
			position+=find.size();
			return position-find.size();
		}
	}
	return NULL;
}

const bool Parser::Find1(const std::string &stream, const std::string &find)
{
	const std::size_t found = stream.find(find);
	return (found!=std::string::npos);
}
