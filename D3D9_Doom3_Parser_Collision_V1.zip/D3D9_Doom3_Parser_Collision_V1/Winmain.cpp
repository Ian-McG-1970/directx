#define NAME "PORTAL"
#define TITLE "PORTAL"

#define WIN32_LEAN_AND_MEAN
#define WIN32_EXTRA_LEAN

#define D3D_OVERLOADS
#define STRICT

#include <windows.h>

#include "d3d8_screen.h"
#include "di_mouse.h"
#include "load.h"
#include "engine.h"
#include "map.h"
#include "parser.h"
#include "portal.h"
#include "log.h"

Mouse		mouse;
Screen	screen;
Load		load;
Engine	engine;
Map map;
Parser parser;
Portal portal;
LogFile logfile;

HWND	hwnd;
FILE	*file;

void ReleaseObjects()
{
	fprintf(file, "windows shutdown\n");
}

long FAR PASCAL WindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
    case	WM_DESTROY:
			ReleaseObjects();
			PostQuitMessage(0);
			break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
  WNDCLASS wc;
  wc.style = CS_HREDRAW | CS_VREDRAW;
  wc.lpfnWndProc = WindowProc;
  wc.cbClsExtra = 0;
  wc.cbWndExtra = 0;
  wc.hInstance = hInstance;
  wc.hIcon = LoadIcon(hInstance, IDI_APPLICATION);
  wc.hCursor = LoadCursor(NULL, IDC_ARROW);
  wc.hbrBackground = NULL;
  wc.lpszMenuName = NAME;
  wc.lpszClassName = NAME;
  RegisterClass(&wc);
    
  if (!(hwnd = CreateWindowEx(WS_EX_TOPMOST, NAME, TITLE, WS_POPUP, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), NULL, NULL, hInstance, NULL))) return false;

  ShowWindow(hwnd, nCmdShow);
	UpdateWindow(hwnd);

	logfile.Open("testlog.txt");
	if ((file=fopen("log.txt","w"))==NULL) return false;
	fprintf(file, "windows startup\n");
	if (!mouse.Setup(hInstance, hwnd)) return false;

	if (!screen.Setup(GetSystemMetrics(SM_CXSCREEN),GetSystemMetrics(SM_CYSCREEN), D3DFMT_X8R8G8B8, 1.0f, 32767.0f, D3DFMT_D24X8, 2, hwnd)) return false;

	parser.Parse("d3ctf4");

	load.Setup();
	map.Setup();

	engine.Setup();
	map.BuildObjects();

	MSG msg;
	while (msg.message!=WM_QUIT)
	{
		if (PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
		{
			if (!GetMessage(&msg, NULL, 0, 0))
			{
				return msg.wParam;
			}
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
		{
			engine.Update();
		}
	}
}
