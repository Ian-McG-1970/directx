#ifndef PARSER
#define PARSER

#include <d3dx9.h>
#include <vector>

typedef struct
{
	int area;
	std::vector<D3DXVECTOR3> vertex;
	std::vector<WORD> index;
} MESH;

typedef struct
{
	D3DXPLANE plane;
	int children[2]; // 0=solid
} NODE;

typedef struct
{
	int from_area;
	int to_area;
	std::vector<D3DXVECTOR3> point;
} PORTAL;

class Parser
{
public:
	const void Parse(const char *);
	std::vector<MESH> models;
	std::vector<NODE> nodes;
	std::vector<PORTAL> portals;
private:
	const std::vector<char> Load(const char *);
	const void Output(const char *,const std::vector<char>);
	const void RemoveComments(std::vector<char> &,const char);
	const int Find(const std::vector<char> &, const std::string, int &);
	const void ParseAreas(const std::vector<char> &);
	const void ParsePortals(const std::vector<char> &);
	const void ParseBSP(std::vector<char> &);
	const std::string String(const std::vector<char> &, const int, const int);
	const std::string NumberString(std::string &);
	const bool Find1(const std::string &, const std::string &);
	const D3DXVECTOR3 FlipPoint(const D3DXVECTOR3&);
};

#endif
