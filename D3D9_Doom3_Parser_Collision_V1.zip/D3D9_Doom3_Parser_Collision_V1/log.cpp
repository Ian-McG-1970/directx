#include "log.h"

const void LogFile::Open(const char * name)
{
	strcpy(file_name, name);
	FILE *file=fopen(file_name,"w");
	fclose(file);
}

const void LogFile::Write()
{
	FILE *file=fopen(file_name,"a");
	fprintf(file,file_output);
	fflush(file);
	fclose(file);
}
