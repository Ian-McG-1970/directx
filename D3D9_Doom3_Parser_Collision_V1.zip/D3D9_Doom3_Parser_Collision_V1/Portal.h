#ifndef P_ORTAL
#define P_ORTAL

#include <stdio.h>
#include "d3d8_screen.h"

#define MAX_SECTORS 1024
#define MAX_SECTOR_PORTALS 512
#define MAX_PORTAL_POINTS 65535

typedef struct
{
	int Model; // object to be drawn
	int Sector_Portal_Count; // number of portals in sector
	int Sector_Portal_Start_Pos; // pointer to first portal in sector
} SECTOR;

typedef struct
{
	int Sector_From; // sector number of where portal is looking from
	int Sector_To; // sector number of where portal is looking into
	int Portal_Point_Start_Pos; // pointer to first portal point
	int Portal_Point_Count; // number of points in this portal
} SECTOR_PORTAL;

#define SECTOR_WALL -1
#define PORTAL_POINTS_OUTSIDE_FRUSTUM -1
#define PORTAL_POINTS_INSIDE_FRUSTUM 0

class Portal
{
private:
	D3DXVECTOR3 Portal_Clipped[MAX_SECTOR_PORTALS][MAX_SECTOR_PORTALS]; //portal to be drawn

	const void Create_Frustum_From_Portal(D3DXVECTOR3*, D3DXPLANE*, const int);
	const long Test_Portal_Against_Frustum(const D3DXVECTOR3 *, const D3DXPLANE *, const int, const int);
	D3DXVECTOR3 * Clip_Portal_To_Frustum(D3DXVECTOR3 *, const D3DXPLANE *, int &, const int, const int);
	D3DXVECTOR3 * Clip_Portal_To_Frustum_Plane(D3DXVECTOR3 *, const D3DXPLANE *, const int, int &);
	const void Set_Clip_Planes(const D3DXPLANE*, const int);

public:
	SECTOR Sector[MAX_SECTORS];
	D3DXVECTOR3 Portal_Point[MAX_PORTAL_POINTS];
	SECTOR_PORTAL Sector_Portal[MAX_SECTOR_PORTALS];
	const void Reset_Frustum(const int);
	const void Draw_Sector(const int, const int, const D3DXVECTOR3 *, D3DXPLANE *, int);
	D3DXPLANE Portal_Frustum[MAX_SECTOR_PORTALS];
	int Curr_Sector;
	const void Setup();
	~Portal();
};

#endif


