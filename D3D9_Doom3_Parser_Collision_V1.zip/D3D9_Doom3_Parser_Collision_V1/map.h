#ifndef MAP
#define MAP

#include "parser.h"
#include <vector>

#define TRACK_PATCH_COUNT 1024

typedef struct
{
	int Model;
	D3DXVECTOR3 Location;
	D3DXVECTOR3 Direction;
} TRACK_PATCH;

typedef struct
{
	int from_area;
	int to_area;
	std::vector<D3DXVECTOR3> point;
} MAP_PORTAL;

typedef struct
{
	std::vector<MAP_PORTAL> Portal;
} PORTALS;

class Map
{
private:
	std::vector<D3DXVECTOR3> Point;
	std::vector<WORD> Triangle;
	const void BuildObject(const std::vector<D3DXVECTOR3> &,const std::vector<WORD> &,const int);
	const void BuildPortals();
public:
	std::vector<PORTALS> Portals;
	void Setup();
	~Map();
	ACTOR Track[TRACK_PATCH_COUNT];
	void BuildTrack();
	unsigned long TrackSections;
	const void BuildObjects();
	const int FindArea(const D3DXVECTOR3 &);

};

#endif
