#ifndef ENGINE
#define ENGINE

#include "d3d8_screen.h"
#include <vector>

class Engine
{
private:
	float	Speed;
	D3DXVECTOR3 Direction;
	D3DXVECTOR3 BoundingBox;
	const D3DXVECTOR3 Move(const D3DXVECTOR3 &, const D3DXVECTOR3 &, const float);
	const void Input(D3DXVECTOR3 &, float &, const float);
	const void DrawTrack();
	const void DrawPortals();
public:
	int count,portals,clipped,inside,drawn,test,front;
	D3DXVECTOR3 Location;
	const void Setup();
	~Engine();
	const void Update();
};

#endif

