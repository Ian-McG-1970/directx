#include "stdlib.h"
#include "d3d8_screen.h"
#include "portal.h"
#include "engine.h"
#include "log.h"

extern Screen screen;
extern Engine engine;
extern LogFile logfile;

const void Portal::Setup()
{
	sprintf(logfile.file_output,"portal setup\n"); logfile.Write();
}

Portal::~Portal()
{
	sprintf(logfile.file_output,"portal shutdown\n"); logfile.Write();
}

D3DXVECTOR3 * Portal::Clip_Portal_To_Frustum_Plane(D3DXVECTOR3 *portal, const D3DXPLANE *frustum, const int frustum_count, int &portal_count)
{
	int clipped_portal_count=0;
	portal[portal_count]=portal[0];	// copy first to last
	for (int p=0; p!=portal_count; ++p)
	{
		const float curr_dot=D3DXPlaneDotCoord(frustum, &portal[p]);
		const float next_dot=D3DXPlaneDotCoord(frustum, &portal[p+1]);

		if (curr_dot<0.0f) // if curr point inside
		{
			Portal_Clipped[frustum_count][clipped_portal_count]=portal[p]; // add it to the output list
			++clipped_portal_count;

			if (next_dot>=0.0f) // if the other isnt
			{
				const float scale=next_dot/(curr_dot-next_dot);
				const D3DXVECTOR3 diff=portal[p+1]-portal[p];
				Portal_Clipped[frustum_count][clipped_portal_count]=portal[p+1] + (diff * scale); // clip the point at the frustum
				++clipped_portal_count;
			}
		}
		else if (next_dot<0.0f) // else if the other is
		{
			const float scale=curr_dot/(next_dot-curr_dot);
			const D3DXVECTOR3 diff=portal[p]-portal[p+1];
			Portal_Clipped[frustum_count][clipped_portal_count]=portal[p] + (diff * scale); // clip the point at the frustum
			++clipped_portal_count;
		}
	}
	portal_count=clipped_portal_count; // set new portal point count
	return &Portal_Clipped[frustum_count][0]; // return portal clipped against this frustum
}

D3DXVECTOR3 * Portal::Clip_Portal_To_Frustum(D3DXVECTOR3 *portal, const D3DXPLANE *frustum, int &portal_count, const int frustum_count, const int clip_codes)
{
	D3DXVECTOR3 *clipped_portal=portal;
	for (int f=0,clip_code=1; f!=frustum_count; ++f)
	{
		const int outside_clip_code=clip_codes&clip_code;
		if (outside_clip_code!=0) // if some portal points are outside this frustum
		{
			clipped_portal=Clip_Portal_To_Frustum_Plane(clipped_portal, &frustum[f], f, portal_count); // clip the portal to this frustum, return the list of clipped points and set the new point count
		}
		clip_code+=clip_code;
	}
	return clipped_portal; // return the last clipped portal
}

const void Portal::Set_Clip_Planes(const D3DXPLANE* frustum, const int portal_count)
{
	DWORD clipplanes=0;
	for (int x=0; x!=portal_count; ++x)
	{
		const D3DXPLANE clipplane=-frustum[x];
		screen.g_pd3dDevice->SetClipPlane(x, (float *) &clipplane);
		clipplanes=(clipplanes<<1)+1;
	}
	screen.g_pd3dDevice->SetRenderState(D3DRS_CLIPPLANEENABLE, clipplanes);
}

const void Portal::Reset_Frustum(const int portal_count) // set original frustum from screen portal
{
	memcpy(&Portal_Frustum[0], &screen.Frustum[0], sizeof(Portal_Frustum[0])*portal_count);
	Set_Clip_Planes(&Portal_Frustum[0], portal_count);
}

const void Portal::Create_Frustum_From_Portal(D3DXVECTOR3* portal, D3DXPLANE* frustum, const int portal_count)
{
	portal[portal_count]=portal[0]; // copy first portal point to last

	for (int x=0; x!=portal_count; ++x)
	{
		D3DXPlaneFromPoints(&frustum[x], &engine.Location, &portal[x], &portal[x+1]);
	}
	Set_Clip_Planes(frustum, portal_count);
}

const long Portal::Test_Portal_Against_Frustum(const D3DXVECTOR3 *portal, const D3DXPLANE *frustum, const int portal_count, const int frustum_count)
{
	int outside_clip_code=PORTAL_POINTS_INSIDE_FRUSTUM;
	for (int f=0, clip_code=1; f!=frustum_count; ++f)
	{
		int outside_count=0;
		for (int p=0; p!=portal_count; ++p)
		{
			if (D3DXPlaneDotCoord(&frustum[f], &portal[p]) >=0.0f) // if point is outside frustum
			{
				++outside_count; // 
			}
		}
		if (outside_count==portal_count) // if all points are outside of this frustum
		{
			return PORTAL_POINTS_OUTSIDE_FRUSTUM; // return outside
		}
		if (outside_count!=0) // if some points are outside of this frustum
		{
			outside_clip_code+=clip_code; // mark frustum to be clipped against
		}
		clip_code+=clip_code;
	}
	return outside_clip_code; // return frustums to be clipped against
}

const void Portal::Draw_Sector(const int to_sector, const int from_sector, const D3DXVECTOR3 *location, D3DXPLANE *frustum, const int frustum_count)
{
//	sprintf(logfile.file_output,"dss %i\n",from_sector); logfile.Write();

	screen.DrawObject(&D3DXVECTOR3(0,0,0),&D3DXVECTOR3(0,0,0),Sector[to_sector].Model,0);

	for (int p=0, sp=Sector[to_sector].Sector_Portal_Start_Pos; p!=Sector[to_sector].Sector_Portal_Count; ++p, ++sp)
	{
		if (Sector_Portal[sp].Sector_To!=from_sector)
		{
			const int portal_start=Sector_Portal[sp].Portal_Point_Start_Pos;
			int portal_count=Sector_Portal[sp].Portal_Point_Count;

			D3DXVECTOR3 *portal=&Portal_Point[portal_start];
			long portal_clip_code=Test_Portal_Against_Frustum(portal, frustum, portal_count, frustum_count); // test each portal point against each frustum
			if (portal_clip_code!=PORTAL_POINTS_OUTSIDE_FRUSTUM) // not all are outside
			{
				if (portal_clip_code!=PORTAL_POINTS_INSIDE_FRUSTUM) // some are outside
				{
					portal=Clip_Portal_To_Frustum(portal, frustum, portal_count, frustum_count, portal_clip_code); // clip all portals to frustums based on clip codes
				}
				if (portal_count>=3)
				{
					Create_Frustum_From_Portal(portal, &frustum[frustum_count], portal_count); // create a unique frustum and return it and the frustum count
					Draw_Sector(Sector_Portal[sp].Sector_To, to_sector, location, &frustum[frustum_count], portal_count); // draw sector through portal
				}
			}
		}
	}
//	sprintf(logfile.file_output,"dse %i\n",from_sector); logfile.Write();
}
 