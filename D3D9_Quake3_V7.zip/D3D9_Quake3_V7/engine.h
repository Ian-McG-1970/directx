#ifndef ENGINE
#define ENGINE

#include "d3d8_screen.h"

class Engine
{
private:
	float	Speed;
	float	VSpeed;
	D3DXVECTOR3 Direction;
	D3DXVECTOR3 Location;
	D3DXVECTOR3 Movement;
	D3DXVECTOR3 Extent;

	const void Move(D3DXVECTOR3 &, const D3DXVECTOR3 &, const float);
public:

	const void Setup();
	~Engine();
	const void Update();
};

#endif

