#ifndef _QUAKE3BSP_H
#define _QUAKE3BSP_H

#include <string>

#define VERT_FVF D3DFVF_XYZ | D3DFVF_DIFFUSE

#define FACE_POLYGON	1 // This is the number that is associated with a face that is of type "polygon"
#define Q3_FRONT 0
#define Q3_BACK 1
#define DIST_EPSILON 1.0f/32.0f
#define GRAVITY_INCH -1.0f
#define STEP_UP D3DXVECTOR3(0.0f, 16.0f, 0.0f);
#define DELTA_DOWN -1.0f

#define	CONTENTS_SOLID			1
#define	CONTENTS_PLAYERCLIP	0x10000

struct tVector3i // This is our integer vector structure
{
	int x, y, z;				// The x y and z position of our integer vector
};

struct tBSPHeader // This is our BSP header structure
{
    char strID[4];				// This should always be 'IBSP'
    int version;				// This should be 0x2e for Quake 3 files
}; 

struct tBSPLump // This is our BSP lump structure
{
	int offset;					// The offset into the file for the start of this lump
	int length;					// The length in bytes for this lump
};

struct tBSPVertex // This is our BSP vertex structure
{
    D3DXVECTOR3 vPosition;			// (x, y, z) position. 
		DWORD		face_colour;
};

struct tBSPLoadVertex
{
    D3DXVECTOR3 vPosition;			// (x, y, z) position. 
    D3DXVECTOR2 vTextureCoord;		// (u, v) texture coordinate
    D3DXVECTOR2 vLightmapCoord;	// (u, v) lightmap coordinate
    D3DXVECTOR3 vNormal;
    byte color[4];				// RGBA color for the vertex 
};

struct tBSPbrush
{
	long firstside;
	long numsides;
	long contents;
};

struct tBSPbrushside
{
	long planenum;
	long content;			
};

struct tBSPFace // This is our BSP face structure
{
    int textureID;				// The index into the texture array 
    int effect;					// The index for the effects (or -1 = n/a) 
    int type;					// 1=polygon, 2=patch, 3=mesh, 4=billboard 
    int startVertIndex;			// The starting index into this face's first vertex 
    int numOfVerts;				// The number of vertices for this face 
    int meshVertIndex;			// The index into the first meshvertex 
    int numMeshVerts;			// The number of mesh vertices 
    int lightmapID;				// The texture index for the lightmap 
    int lMapCorner[2];			// The face's lightmap corner in the image 
    int lMapSize[2];			// The size of the lightmap section 
    D3DXVECTOR3 lMapPos;			// The 3D origin of lightmap. 
    D3DXVECTOR3 lMapVecs[2];		// The 3D space for s and t unit vectors. 
    D3DXVECTOR3 vNormal;			// The face normal. 
    int size[2];				// The bezier patch dimensions. 
};

struct tBSPNode // This stores a node in the BSP tree
{
    int plane;					// The index into the planes array 
    int children[2];	// The child index for the front node and the back node
    tVector3i min;				// The bounding box min position. 
    tVector3i max;				// The bounding box max position. 
}; 

struct tBSPLeaf // This stores a leaf (end node) in the BSP tree
{
    int cluster;				// The visibility cluster 
    int area;					// The area portal 
    tVector3i min;				// The bounding box min position 
    tVector3i max;				// The bounding box max position 
    int leafface;				// The first index into the face array 
    int numOfLeafFaces;			// The number of faces for this leaf 
    int leafBrush;				// The first index for into the brushes 
    int numOfLeafBrushes;		// The number of brushes for this leaf 
}; 

struct D3D_BSPLeaf
{
	int cluster;				// The visibility cluster 
	int area;					// The area portal 
	int leafface;				// The first index into the face array 
	int numOfLeafFaces;			// The number of faces for this leaf 
	int leafBrush;				// The first index for into the brushes 
	int numOfLeafBrushes;		// The number of brushes for this leaf 
	D3DXVECTOR3	bounding_box[8];
}; 

struct cluster_leaf
{
	int start;	// start of this clusters leafs
	int count;	// number of leafs to draw
};

struct tBSPPlane // This stores a splitter plane in the BSP tree
{
	D3DXVECTOR3 vNormal;			// Plane normal. 
	float d;					// The plane distance from origin 
};

struct tBSPVisData // This stores the cluster data for the PVS's
{
	int numOfClusters;			// The number of clusters
	int bytesPerCluster;		// The amount of bytes (8 bits) in the cluster's bitset
	byte *pBitsets;				// The array of bytes that holds the cluster bitsets				
};

struct BSPTexture
{
	char			name[64];		//Texture name.
	int				flags;			//Surface flags.
	int				contents;		//Content flags.
};

enum eLumps // This is our lumps enumeration
{
    kEntities = 0,				// Stores player/object positions, etc...
    kTextures,					// Stores texture information
    kPlanes,				    // Stores the splitting planes
    kNodes,						// Stores the BSP nodes
    kLeafs,						// Stores the leafs of the nodes
    kLeafFaces,					// Stores the leaf's indices into the faces
    kLeafBrushes,				// Stores the leaf's indices into the brushes
    kModels,					// Stores the info of world models
    kBrushes,					// Stores the brushes info (for collision)
    kBrushSides,				// Stores the brush surfaces info
    kVertices,					// Stores the level vertices
    kMeshVerts,					// Stores the model vertices offsets
    kShaders,					// Stores the shader files (blending, anims..)
    kFaces,						// Stores the faces for the level
    kLightmaps,					// Stores the lightmaps for the level
    kLightVolumes,				// Stores extra world lighting information
    kVisData,					// Stores PVS and cluster info (visibility)
    kMaxLumps					// A constant to store the number of lumps
};

struct Q3Move
{	
	float	fraction;
	D3DXVECTOR3	start;
	D3DXVECTOR3	end;
	D3DXVECTOR3	size;	// Size of the bounding box / 2
	D3DXVECTOR3	mins;	// Bounding box	
	D3DXVECTOR3	maxs;
	D3DXVECTOR3	normal;	// Normal at collision point
	bool	allSolid;
};

class CQuake3BSP
{

private:
	const int IsClusterVisible(const int &current, const int &test);
	const Q3Move checkMove(const D3DXVECTOR3& start,const D3DXVECTOR3& end,const D3DXVECTOR3& extent);
	const void checkMoveLeaf(const int leaf);
	const void checkMoveNode(const float sf,const float ef,const D3DXVECTOR3& sp,const D3DXVECTOR3& ep,const int node);
	const D3DXVECTOR3 FlipPoint(const D3DXVECTOR3&);
	const tVector3i FlipPoint(const tVector3i &);
	const int LoadLump(FILE *fp, const int count, const int offset, void *dest, const int stride);
	const void RenderFace2(const int faceIndex); // This renders a single face to the screen

	D3DXVECTOR3 Point[65535];

	tBSPNode    *m_pNodes;
	D3DXPLANE	*D3D_Planes;
	int         *m_pLeafFaces;
	tBSPVisData  m_clusters;		

	int m_numOfVerts;			// The number of verts in the model
	int m_numOfFaces;			// The number of faces in the model

	int m_numOfNodes;
	int m_numOfLeafs;
	int m_numOfLeafFaces;
	int m_numOfPlanes;

	int m_numOfLeafBrushes;

	int m_numOfBrushes;
  int m_numOfBrushSides;

	tBSPVertex  *m_pVerts;		// The object's vertices
	tBSPFace    *m_pFaces;		// The faces information of the object
	unsigned long *m_pFaceFrame; // last frame this face was rendered in

	int *m_pLeafBrushes;

	tBSPbrush   *m_pBrushes;
	tBSPbrushside *m_pBrushSides;

	cluster_leaf	*cluster_leafs;			// pointers into cluster leaf list for each cluster
	D3D_BSPLeaf		**cluster_leaf_list;	// list of leafs to be drawn from each cluster

	unsigned long Frame; // current frame

	int m_numOfTextures;
	BSPTexture *m_pTextures;
	Q3Move moveMove;

public:

	CQuake3BSP(); // Our constructor
	~CQuake3BSP(); // Our deconstructor. This destroys the level data
	const bool LoadBSP(const char *strFileName); // This loads a .bsp file by it's file name (Returns true if successful)
	const void RenderLevel(const int iLeaf); // This renders the level to the screen, currently the camera pos isn't being used
	const int FindLeaf(const D3DXVECTOR3 &vPos);
	const void update(const float dTime, D3DXVECTOR3 &position, const D3DXVECTOR3 &reqMove, const D3DXVECTOR3 &extents, float &vSpeed);
	const float OnGround(const D3DXVECTOR3 &,const D3DXVECTOR3 &);

	D3D_BSPLeaf	*D3D_Leafs;
	LPDIRECT3DVERTEXBUFFER9 m_vb;};

#endif
