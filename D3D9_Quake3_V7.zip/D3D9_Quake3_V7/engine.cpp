#include <math.h>
#include <stdio.h>
#include "engine.h"
#include "d3d8_screen.h"
#include "di_mouse.h"
#include "quake3bsp.h"

extern HWND hwnd;
extern Mouse mouse;
extern Screen screen;
extern CQuake3BSP g_bsp;

extern FILE *file;

const void Engine::Setup()
{
	fprintf(file,"engine setup\n");

//	Location = D3DXVECTOR3(40.0f, 200.0f, -130.0f); //	if (!g_bsp.LoadBSP("q3dm11.bsp"))
//	Location = D3DXVECTOR3(200.0f, 180.0f, 100.0f); //	if (!g_bsp.LoadBSP("tutorial.bsp"))
	Location = D3DXVECTOR3(150.0f, 200.0f, 150.0f); //	if (!g_bsp.LoadBSP("tutorial.bsp"))
	Direction = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	Extent = D3DXVECTOR3(20.0f, 60.0f, 20.0f);

	Speed = 0.0f;
	VSpeed = 0.0f;
}

Engine::~Engine()
{
	fprintf(file,"engine shutdown\n");
}

const void Engine::Move(D3DXVECTOR3 &location, const D3DXVECTOR3 &direction, const float speed)
{
	D3DXMATRIX  matTmp;
	D3DXMatrixRotationYawPitchRoll(&matTmp, direction.y, direction.x, direction.z);      
	D3DXVECTOR4 tmp;
	D3DXVec3Transform(&tmp, &D3DXVECTOR3(0.0f,0.0f,1.0f), &matTmp);
	location = D3DXVECTOR3(tmp.x, 0.0f, tmp.z) *speed;
}

const void Engine::Update()
{
	mouse.Update();
	if (mouse.LB!=0 && mouse.RB!=0)
	{
		PostMessage(hwnd, WM_CLOSE, 0, 0);
		return;
	}
	Direction.x -= mouse.Y*0.003f;
	Direction.y += mouse.X*0.003f;
	if (mouse.LB!=0)
	{
		Speed=4.0f;
	}
	else if (mouse.RB!=0)
	{
		VSpeed=4.0f;
	}
	else
	{
		Speed=0.0f;
	}

	Move(Movement, Direction, Speed);

	g_bsp.update(1.0f, Location, Movement, Extent,	VSpeed);

	const int Leaf = g_bsp.FindLeaf(Location);
	const int Cluster = g_bsp.D3D_Leafs[Leaf].cluster;

	screen.View_Matrix(Location, Direction);

	screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(BACKGROUND, BACKGROUND, BACKGROUND), 1.0f, 0);
	screen.g_pd3dDevice->SetFVF(D3DFVF_D3D_VERTEX);
	screen.g_pd3dDevice->BeginScene();

	g_bsp.RenderLevel(Cluster);

	sprintf(screen.string,"xyz %5.1f %5.1f %5.1f lc %i %i %F\n",Location.x,Location.y,Location.z,Leaf,Cluster,g_bsp.OnGround(Location,Extent));
	screen.DrawText(5,5,D3DCOLOR_XRGB(160,160,160));

	screen.g_pd3dDevice->EndScene();
	screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
}

