
#include "d3d8_screen.h"
#include "quake3bsp.h"

extern FILE *file;
extern Screen screen;

#define	CONTENTS_PLAYERCLIP	0x10000

CQuake3BSP::CQuake3BSP() //	This is our object's constructor to initial all it's data members
{
	// Here we simply initialize our member variables to 0
	m_numOfVerts =	
	m_numOfFaces =	
	m_numOfNodes =
	m_numOfLeafs =
	m_numOfLeafFaces =
	m_numOfPlanes =
	m_numOfTextures = 0;

	// Initialize all the dynamic BSP data pointers to NULL
	m_pVerts = NULL;	
	m_pFaces = NULL;	    
	m_pBrushSides = NULL;
	m_pBrushes = NULL;
	m_pNodes = NULL;
	m_pLeafFaces = NULL;
	D3D_Leafs		= NULL;
	D3D_Planes	= NULL;
	cluster_leafs			= NULL;
	cluster_leaf_list = NULL;
	m_pTextures = NULL;
	memset(&m_clusters,0,sizeof(tBSPVisData));
	m_clusters.pBitsets = NULL;
}

const D3DXVECTOR3 CQuake3BSP::FlipPoint(const D3DXVECTOR3 &point) // Swap the y and z values, and negate the new z so Y is up.
{
	return D3DXVECTOR3(point.x, point.z, point.y); 
}

const tVector3i CQuake3BSP::FlipPoint(const tVector3i &point) // Swap the y and z values, and negate the new z so Y is up.
{
	const D3DXVECTOR3 flipped_point=FlipPoint( D3DXVECTOR3(point.x, point.y, point.z));
	tVector3i flip_point;
	flip_point.x=flipped_point.x;
	flip_point.y=flipped_point.y;
	flip_point.z=flipped_point.z;
	return flip_point;
}

const int CQuake3BSP::LoadLump(FILE *fp, const int count, const int offset, void *dest, const int stride) // This loads in a lump of data
{
	fseek(fp, offset, SEEK_SET);
	fread(dest, stride, count, fp);
	return count;
}

const bool CQuake3BSP::LoadBSP(const char *strFileName) // This loads in all of the .bsp data for the level
{
	fprintf(file, "loadbsp\n");

	FILE *fp;
	if ((fp = fopen(strFileName, "rb"))==NULL) // Check if the .bsp file could be opened
	{
		fprintf(file, "bsp not found\n");
		return false;
	}
 
	tBSPHeader header = {0}; // Initialize the header and lump structures
	tBSPLump lumps[kMaxLumps] = {0};
 	fread(&header, 1, sizeof(tBSPHeader), fp); // Read in the header and lump data
	fread(&lumps, kMaxLumps, sizeof(tBSPLump), fp);
    
	// Now we know all the information about our file.  We can then allocate the needed memory for our member variables.
    
	m_pLeafBrushes = new int[lumps[kLeafBrushes].length / sizeof(int)];
	m_numOfLeafBrushes = LoadLump(fp, lumps[kLeafBrushes].length / sizeof(int), lumps[kLeafBrushes].offset, &m_pLeafBrushes[0], sizeof(m_pLeafBrushes[0]));

	m_pBrushes = new tBSPbrush[lumps[kBrushes].length / sizeof(tBSPbrush)];
	m_numOfBrushes = LoadLump(fp, lumps[kBrushes].length / sizeof(tBSPbrush), lumps[kBrushes].offset, &m_pBrushes[0], sizeof(m_pBrushes[0]));

	m_pBrushSides = new tBSPbrushside[lumps[kBrushSides].length / sizeof(tBSPbrushside)];
	m_numOfBrushSides = LoadLump(fp, lumps[kBrushSides].length / sizeof(tBSPbrushside), lumps[kBrushSides].offset, &m_pBrushSides[0], sizeof(m_pBrushSides[0]));

	m_pFaces = new tBSPFace [lumps[kFaces].length / sizeof(tBSPFace)];
	m_numOfFaces = LoadLump(fp, lumps[kFaces].length / sizeof(tBSPFace), lumps[kFaces].offset, &m_pFaces[0], sizeof(m_pFaces[0]));

	tBSPLoadVertex *load_vertex = new tBSPLoadVertex[lumps[kVertices].length / sizeof(tBSPLoadVertex)];
	m_numOfVerts = LoadLump(fp, lumps[kVertices].length / sizeof(tBSPLoadVertex), lumps[kVertices].offset, &load_vertex[0], sizeof(load_vertex[0]));

	m_pVerts = new tBSPVertex[lumps[kVertices].length / sizeof(tBSPLoadVertex)];
	for (int i=0; i<m_numOfVerts; ++i) // Go through all of the vertices that need to be read and swap axises
	{
		m_pVerts[i].vPosition = FlipPoint(load_vertex[i].vPosition);
	}
	delete[] load_vertex;

	// In this function we read from a bunch of new lumps.  These include the BSP nodes, the leafs, the leaf faces, BSP splitter planes and visibility data (clusters).

	m_pNodes = new tBSPNode[lumps[kNodes].length / sizeof(tBSPNode)];
	m_numOfNodes = LoadLump(fp, lumps[kNodes].length / sizeof(tBSPNode), lumps[kNodes].offset, &m_pNodes[0], sizeof(m_pNodes[0]));

	tBSPLeaf *m_pLeafs = new tBSPLeaf[lumps[kLeafs].length / sizeof(tBSPLeaf)];
	m_numOfLeafs = LoadLump(fp, lumps[kLeafs].length / sizeof(tBSPLeaf), lumps[kLeafs].offset, &m_pLeafs[0], sizeof(m_pLeafs[0]));

	D3D_Leafs = new D3D_BSPLeaf[m_numOfLeafs];

	for (int i=0; i<m_numOfLeafs; ++i) // Now we need to go through and convert all the leaf bounding boxes to the normal OpenGL Y up axis.
	{
		m_pLeafs[i].min=FlipPoint(m_pLeafs[i].min);
		m_pLeafs[i].max=FlipPoint(m_pLeafs[i].max);

		D3D_Leafs[i].area = m_pLeafs[i].area;
		D3D_Leafs[i].cluster = m_pLeafs[i].cluster;
		D3D_Leafs[i].leafBrush = m_pLeafs[i].leafBrush;
		D3D_Leafs[i].leafface = m_pLeafs[i].leafface;
		D3D_Leafs[i].numOfLeafBrushes = m_pLeafs[i].numOfLeafBrushes;
		D3D_Leafs[i].numOfLeafFaces = m_pLeafs[i].numOfLeafFaces;

		D3D_Leafs[i].bounding_box[0] = D3DXVECTOR3(m_pLeafs[i].min.x, m_pLeafs[i].min.y, m_pLeafs[i].min.z);
		D3D_Leafs[i].bounding_box[1] = D3DXVECTOR3(m_pLeafs[i].max.x, m_pLeafs[i].min.y, m_pLeafs[i].min.z);
		D3D_Leafs[i].bounding_box[2] = D3DXVECTOR3(m_pLeafs[i].min.x, m_pLeafs[i].max.y, m_pLeafs[i].min.z);
		D3D_Leafs[i].bounding_box[3] = D3DXVECTOR3(m_pLeafs[i].max.x, m_pLeafs[i].max.y, m_pLeafs[i].min.z);
		D3D_Leafs[i].bounding_box[4] = D3DXVECTOR3(m_pLeafs[i].min.x, m_pLeafs[i].min.y, m_pLeafs[i].max.z);
		D3D_Leafs[i].bounding_box[5] = D3DXVECTOR3(m_pLeafs[i].max.x, m_pLeafs[i].min.y, m_pLeafs[i].max.z);
		D3D_Leafs[i].bounding_box[6] = D3DXVECTOR3(m_pLeafs[i].min.x, m_pLeafs[i].max.y, m_pLeafs[i].max.z);
		D3D_Leafs[i].bounding_box[7] = D3DXVECTOR3(m_pLeafs[i].max.x, m_pLeafs[i].max.y, m_pLeafs[i].max.z);
	}
	delete [] m_pLeafs;

	m_pLeafFaces = new int[lumps[kLeafFaces].length / sizeof(int)];
	m_numOfLeafFaces = LoadLump(fp, lumps[kLeafFaces].length / sizeof(int), lumps[kLeafFaces].offset, &m_pLeafFaces[0], sizeof(m_pLeafFaces[0]));

	tBSPPlane *m_pPlanes = new tBSPPlane[lumps[kPlanes].length / sizeof(tBSPPlane)];
	m_numOfPlanes = LoadLump(fp, lumps[kPlanes].length / sizeof(tBSPPlane), lumps[kPlanes].offset, &m_pPlanes[0], sizeof(m_pPlanes[0]));

	D3D_Planes = new D3DXPLANE[m_numOfPlanes];

	for (int i=0; i<m_numOfPlanes; ++i) // Go through every plane and convert it's normal to the Y-axis being up
	{
		m_pPlanes[i].vNormal=FlipPoint(m_pPlanes[i].vNormal);
		D3D_Planes[i] = D3DXPLANE(m_pPlanes[i].vNormal.x,m_pPlanes[i].vNormal.y,m_pPlanes[i].vNormal.z,-m_pPlanes[i].d);
	}
	delete[] m_pPlanes;

	m_pTextures = new BSPTexture[lumps[kTextures].length/sizeof(BSPTexture)];
	m_numOfTextures = LoadLump(fp,lumps[kTextures].length/sizeof(BSPTexture),lumps[kTextures].offset,&m_pTextures[0],sizeof(m_pTextures[0]));

	if (lumps[kVisData].length) // Check if there is any visibility information first
	{
		fseek(fp,lumps[kVisData].offset,SEEK_SET); // Seek to the position in the file that holds the visibility lump
		fread(&(m_clusters.numOfClusters), 1, sizeof(int), fp); // Read in the number of vectors and each vector's size
		fread(&(m_clusters.bytesPerCluster), 1, sizeof(int), fp);

		const int size = m_clusters.numOfClusters * m_clusters.bytesPerCluster; // Allocate the memory for the cluster bitsets
		m_clusters.pBitsets = new byte[size];

		fread(m_clusters.pBitsets, 1, sizeof(byte) * size, fp); // Read in the all the visibility bitsets for each cluster

		cluster_leafs			= new cluster_leaf[m_clusters.numOfClusters];
		cluster_leaf_list = new D3D_BSPLeaf *[m_clusters.numOfClusters*m_numOfLeafs];

		for (int from_cluster=0; from_cluster!=m_clusters.numOfClusters; ++from_cluster)
		{
			cluster_leafs[from_cluster].start=m_numOfLeafs*from_cluster; // start position from this cluster
			cluster_leafs[from_cluster].count=0; // reset clusters to draw

			for (int to_leaf=0; to_leaf!=m_numOfLeafs; ++to_leaf)
			{
				if (D3D_Leafs[to_leaf].numOfLeafFaces!=0) // faces to draw
				{
					const int to_cluster = D3D_Leafs[to_leaf].cluster;
					if ((IsClusterVisible(from_cluster, to_cluster)) || (from_cluster==to_cluster)) // cluster is in view
					{
						cluster_leaf_list[(cluster_leafs[from_cluster].start+cluster_leafs[from_cluster].count)]=&D3D_Leafs[to_leaf]; // add leaf to cluster draw list
						++cluster_leafs[from_cluster].count; // increment cluster draw list
					}
				}
			}
		}
	}

	fclose(fp); // Close the file

	m_pFaceFrame = new unsigned long[m_numOfFaces];

	return true; // Return a success
}

const int CQuake3BSP::FindLeaf(const D3DXVECTOR3 &vPos) // This returns the leaf our camera is in
{
	// This function takes in our camera position, then goes and walks through the BSP nodes, starting at the root node, finding the leaf node
	// that our camera resides in.  This is done by checking to see if the camera is in front or back of each node's splitting plane. If the
	// camera is in front of the camera, then we want to check the node in front of the node just tested.  If the camera is behind the current
	// node, we check that nodes back node.  Eventually, this will find where the camera is according to the BSP tree. Once a node index (i) is
	// found to be a negative number, that tells us that that index is a leaf node, not another BSP node.  We can either calculate the leaf node
	// index from -(i + 1) or ~1.  This is because the starting leaf index is 0, and you can't have a negative 0. It's important for us to know
	// which leaf our camera is in so that we know which cluster we are in. That way we can test if other clusters are seen from our cluster.

	int i=0;
	while (i>=0) // Continue looping until we find a negative index
	{
		const tBSPNode&  node = m_pNodes[i]; // Get the current node, then find the slitter plane from that node's plane index.
		const D3DXPLANE& D3Dplane = D3D_Planes[node.plane];

		const float distance = D3DXPlaneDotCoord(&D3Dplane, &vPos);
		if (distance>=0) // If the camera is in front of the plane
		{
			i = node.children[0]; // Assign the current node to the node in front of itself
		}
		else // Else if the camera is behind the plane
		{
			i = node.children[1]; // Assign the current node to the node behind itself
		}
	}
	return ~i; // Return the leaf index (same thing as saying:  return -(i + 1)).
}

const int CQuake3BSP::IsClusterVisible(const int &current, const int &test) // This tells us if the "current" cluster can see the "test" cluster
{
	// This function is used to test the "current" cluster against the "test" cluster.  If the "test" cluster is seen from the "current" cluster,
	// we can then draw it's associated faces, assuming they aren't frustum culled of course.  Each cluster has their own bitset containing a bit
	// for each other cluster.  For instance, if there is 10 clusters in the whole level (a tiny level), then each cluster would have a bitset of
	// 10 bits that store a 1 (visible) or a 0 (not visible) for each other cluster.  Bitsets are used because it's faster and saves memory,
	// instead of creating a huge array of booleans.  It seems that people tend to call the bitsets "vectors", so keep that in mind too.

	// Use binary math to get the 8 bit visibility set for the current cluster Now that we have our vector (bitset), do some bit shifting to find if
	// the "test" cluster is visible from the "current" cluster, according to the bitset.

	return ((m_clusters.pBitsets[(current*m_clusters.bytesPerCluster) + (test >>3)]) & (1 << ((test) & 7))); // Return the result (either 1 (visible) or 0 (not visible)) //	return ((m_clusters.pBitsets[(current) + (test >>3)]) & (1 << ((test) & 7))); // Faster version of the above
}

const void CQuake3BSP::RenderFace2(const int faceIndex) //	This renders a face, determined by the passed in index
{
	const int startVertIndex = m_pFaces[faceIndex].startVertIndex;
	const int numOfVerts = m_pFaces[faceIndex].numOfVerts;
	const int endverts = startVertIndex + numOfVerts;

	for (int x=startVertIndex, i=0; x!=endverts; ++x, ++i)
	{
		Point[i]=m_pVerts[x].vPosition;
	}
	screen.Polygon(&Point[0], numOfVerts,D3DCOLOR_XRGB(m_pFaces[faceIndex].startVertIndex,m_pFaces[faceIndex].meshVertIndex,m_pFaces[faceIndex].lightmapID));
}

const void CQuake3BSP::RenderLevel(const int cluster) //	Goes through all of the faces and draws them if the type is FACE_POLYGON
{
	++Frame;
	
	const int start = cluster_leafs[cluster].start;
	const int count = cluster_leafs[cluster].count;
	for (int x=0; x!=count; ++x)
	{
		const D3D_BSPLeaf *pLeaf = cluster_leaf_list[start+x]; // Get the current leaf that is to be tested for visibility from our camera's leaf
		if (!screen.IsBoxInsideFrustum(&pLeaf->bounding_box[0]))
		{
			continue;
		}

		int faceCount = pLeaf->numOfLeafFaces; // Get the number of faces that this leaf is in charge of.

		while (faceCount--) // Loop through and render all of the faces in this leaf
		{
			const int faceIndex = m_pLeafFaces[pLeaf->leafface + faceCount]; // Grab the current face index from our leaf faces array

			if (m_pFaces[faceIndex].type!=FACE_POLYGON) // Before drawing this face, make sure it's a normal polygon
			{
				continue;
			}

			if (m_pFaceFrame[faceIndex]!=Frame) // Since many faces are duplicated in other leafs, we need to make sure this face already hasn't been drawn.
			{
				RenderFace2(faceIndex);
				m_pFaceFrame[faceIndex]=Frame;
			}
		}			
	}
}

CQuake3BSP::~CQuake3BSP() //	This is our deconstructor that is called when the object is destroyed
{
	if (cluster_leafs)
	{
		delete [] cluster_leafs;
		cluster_leafs = NULL;
	}
	if (cluster_leaf_list)
	{
		delete [] cluster_leaf_list;
		cluster_leaf_list = NULL;
	}
	if (m_pVerts) // If we still have valid memory for our vertices, free them
	{
		delete [] m_pVerts;
		m_pVerts = NULL;
	}
    
	if (m_pFaces) // If we still have valid memory for our faces, free them
	{
		delete [] m_pFaces;
		m_pFaces = NULL;
	}

	if (m_pFaceFrame)
	{
		delete [] m_pFaceFrame;
		m_pFaceFrame = NULL;
	}
     
	if(m_pBrushes)
	{
		delete[] m_pBrushes;
		m_pBrushes = NULL;
  }

	if (m_pBrushSides)
	{
		delete[] m_pBrushSides;
		m_pBrushSides = NULL;
	}
    
	if (m_pLeafBrushes)
	{
		delete[] m_pLeafBrushes;
		m_pLeafBrushes = NULL;
	}
    
	if (m_pNodes) // If we still have valid memory for our nodes, free them
	{
		delete [] m_pNodes;
		m_pNodes = NULL;
	}
    
	if (D3D_Leafs)	// If we still have valid memory for our leafs, free them
	{
		delete [] D3D_Leafs;
		D3D_Leafs = NULL;
	}
    
	if(m_pLeafFaces) // If we still have valid memory for our leaf faces, free them
	{
		delete [] m_pLeafFaces;
		m_pLeafFaces = NULL;
	}
    
	if (D3D_Planes)
	{
		delete [] D3D_Planes;
		D3D_Planes = NULL;
	}

	if (m_clusters.pBitsets) // If we still have valid memory for our clusters, free them
	{
		delete [] m_clusters.pBitsets;
		m_clusters.pBitsets = NULL;
	}
  
	if(m_pTextures)
	{
		delete[] m_pTextures;
		m_pTextures = NULL;
	}

	if (m_vb)
	{
		m_vb->Release();
    m_vb = NULL;
	}    
}

// ------------------------------------------------------------//  Movement clipping// ------------------------------------------------------------

const Q3Move CQuake3BSP::checkMove(const D3DXVECTOR3& start, const D3DXVECTOR3& end, const D3DXVECTOR3& extent)
{	
	moveMove.size = extent*0.5f;
	moveMove.start = start;
	moveMove.end = end;			// If nothing is hit, full movement by default	
	moveMove.fraction = 1.0f;
	moveMove.allSolid = false;
	checkMoveNode(0.0f, 1.0f, start, end, 0.0f);		// Calculate final coordinates
	if(moveMove.fraction < 1.0f)
	{
		moveMove.end = start + moveMove.fraction*(end - start);
	}
	return moveMove;
}

const void CQuake3BSP::checkMoveNode(const float sf, const float ef, const D3DXVECTOR3& sp, const D3DXVECTOR3& ep, const int node)
{
	if (moveMove.fraction < sf) // If the path was blocked by a nearer obstacle, don't bother checking
	{
		return;
	}
	if (node < 0) // We found a leaf, check the whole path against its brushes
	{
		checkMoveLeaf(-(node + 1));
		return;
	}

	const D3DXPLANE& D3Dplane = D3D_Planes[m_pNodes[node].plane];
	const float t1 = D3DXPlaneDotCoord(&D3Dplane, &sp);
	const float t2 = D3DXPlaneDotCoord(&D3Dplane, &ep);
	const float offset = fabs(moveMove.size.x*D3Dplane.a) + fabs(moveMove.size.y*D3Dplane.b) + fabs(moveMove.size.z*D3Dplane.c);

	if ((t1 >= offset) && (t2 >= offset)) // The whole volume is in front of the plane
	{
		checkMoveNode(sf, ef, sp, ep, m_pNodes[node].children[Q3_FRONT]);
		return;
	}

	if ((t1 < -offset) && (t2 < -offset)) // The whole volume is in the back of the plane
	{
		checkMoveNode(sf, ef, sp, ep, m_pNodes[node].children[Q3_BACK]);
		return;
	}

	// Else, the box is split. Check the two halves.
	int side;
	float frac, frac2;

	if (t1 < t2)
	{
		side  = Q3_BACK;
		const float idist = 1.0f / (t1 - t2);
		frac  = (t1 - offset - DIST_EPSILON) * idist;
		frac2 = (t1 + offset + DIST_EPSILON) * idist;
	}
	else if (t1 > t2)
	{
		side  = Q3_FRONT;
		const float idist = 1.0f / (t1 - t2);
		frac  = (t1 + offset + DIST_EPSILON) * idist;
		frac2 = (t1 - offset - DIST_EPSILON) * idist;
	}
	else
	{
		side  = Q3_FRONT;
		frac  = 1.0f;
		frac2 = 0.0f;
	}

	if (frac < 0.0f)
	{
		frac = 0.0f;
	}
	else if (frac > 1.0f)
	{
		frac = 1.0f;
	}
	float midf = sf + (ef - sf)*frac; // Move from start to the plane	
	D3DXVECTOR3 midp = sp + frac*(ep - sp);
	checkMoveNode(sf, midf, sp, midp, m_pNodes[node].children[side]);

	midf = sf + (ef - sf)*frac2; // Move from the plane to the end
	midp = sp + frac2*(ep - sp);
	checkMoveNode(midf, ef, midp, ep, m_pNodes[node].children[1-side]);
}

const void CQuake3BSP::checkMoveLeaf (const int leaf)
{
	const int bb = D3D_Leafs[leaf].leafBrush;
	int bc = D3D_Leafs[leaf].numOfLeafBrushes;
	while (bc--)
	{
		const int bi = m_pLeafBrushes[bb+bc];
		const tBSPbrush& brush = m_pBrushes[bi];
		if (brush.numsides == 0)
		{
			continue;
		}

		const int collision=m_pTextures[brush.contents].contents; //		const int collision=brush.contents;

//		bool test_brush=false;
//		if (((collision & CONTENTS_SOLID)) && ((collision & CONTENTS_PLAYERCLIP))) { test_brush=true; }
//		if (((collision & CONTENTS_SOLID)==1) || ((collision & CONTENTS_PLAYERCLIP)==1)) { test_brush=true; }
//		if (test_brush==false) continue;

		if (((collision & CONTENTS_SOLID)!=1) && ((collision & CONTENTS_PLAYERCLIP)!=1)) continue;

		const int sb = brush.firstside;
		int sc = brush.numsides;
		float enterf = -1.0f;
		float exitf = 1.0f;
		bool startOut = false;
		bool endOut = false;
		bool fullOut = false;
		D3DXVECTOR3 hitNormal;
		while (sc--)
		{
			const int pi = m_pBrushSides[sb+sc].planenum; // if (!(m_pBrushSides[sb+sc].content >=0)) continue;
			const D3DXPLANE& planeD3D = D3D_Planes[pi];

			D3DXVECTOR3 ofs = -moveMove.size; // Calculate distances, taking the bounding box dimensions into account
			if (planeD3D.a < 0.0f)
			{
				ofs.x = -ofs.x;
			}
			if (planeD3D.b < 0.0f)
			{
				ofs.y = -ofs.y;
			}
			if (planeD3D.c < 0.0f)
			{
				ofs.z = -ofs.z;
			}
			const D3DXVECTOR3 plane_normal = D3DXVECTOR3(planeD3D.a, planeD3D.b, planeD3D.c);
			const float dist = D3DXVec3Dot(&ofs, &plane_normal) + planeD3D.d;
			const float d1 = D3DXVec3Dot(&moveMove.start, &plane_normal) + dist;
			const float d2 = D3DXVec3Dot(&moveMove.end, &plane_normal) + dist;
			if (d1 >= -DIST_EPSILON)
			{
				startOut = true;
			}
			if (d2 >= -DIST_EPSILON)
			{
				endOut = true;
			}

			if ((d1 > 0.0f) && (d2 >= d1)) // Both in front of face : outside this brush
			{
				fullOut = true;
				break;
			}

			if ((d1 <= 0.0f) && (d2 <= 0.0f)) // Both behind the face : will get clipped by another plane
			{
				continue;
			}

			if (d1 > d2) // Entering the brush
			{
				const float f = (d1 - DIST_EPSILON) / (d1 - d2);
				if (f > enterf)
				{
					enterf = f;
					hitNormal = plane_normal;
				}
			}
			else
			{
				const float f = (d1 + DIST_EPSILON) / (d1 - d2);
				if (f < exitf)
				{
					exitf = f;
				}
			}
		}
		if (!fullOut)
		{
			if (!startOut && !endOut)
			{
				moveMove.fraction = 0.0f;
				moveMove.allSolid = true;
				moveMove.normal = hitNormal;
				return;
			}
			if (enterf < exitf)
			{
				if (enterf > -1.0f && enterf < moveMove.fraction)
				{
					if (enterf < 0.0f)
					{
						enterf = 0.0f;
					}
					moveMove.fraction = enterf;
					moveMove.normal = hitNormal;
				}
			}
		}

		if (moveMove.fraction == 0.0f) // Already fully blocked
		{
			return;
		}
	}
}

// And a little example on how to use it :

// We get the desired direction externally (from the animation or the AI). We try the following ://
// if could move in the desired direction, at least partially
// 		move;
// else
//		try stepping up
//		if could step up
//			move down to exactly the step's height
//		else
//			slide along the plane which blocked the movement

const float CQuake3BSP::OnGround(const D3DXVECTOR3 &location, const D3DXVECTOR3 &extents)
{
	const Q3Move move = checkMove(location, D3DXVECTOR3(location.x,location.y+DELTA_DOWN,location.z), extents);
	return move.fraction;
}

const void CQuake3BSP::update(const float dTime, D3DXVECTOR3 &position, const D3DXVECTOR3 &reqMove, const D3DXVECTOR3 &extents, float &vSpeed)
{
	D3DXVECTOR3 startPoint, endPoint;
	Q3Move move;
	bool stepDown = false;
	const bool jumping = (vSpeed > 0.0f);
	if (D3DXVec3Length(&reqMove))
	{
		endPoint = position + reqMove;
		move = checkMove(position, endPoint, extents);
		if (move.fraction == 0.0f) // Try stepping up
		{
			startPoint = position + STEP_UP;
			endPoint = startPoint + reqMove;
			move = checkMove(startPoint, endPoint, extents);
			if (move.fraction) // Move down. We need to go up exactly the step height.
			{
				startPoint = move.end;
				endPoint = startPoint - STEP_UP;
				move = checkMove(startPoint, endPoint, extents);
			}
			else // Try sliding along the hit plane
			{
				D3DXVec3Normalize(&move.normal,&move.normal);
				const D3DXVECTOR3 remain = reqMove*(1-move.fraction); // Remaining to move
				const D3DXVECTOR3 slide = remain - move.normal*D3DXVec3Dot(&move.normal,&remain); 
				startPoint = position;
				endPoint = startPoint + slide;
				move = checkMove(startPoint, endPoint, extents);
			}
		}
		position = move.end;
	}

	move = checkMove(position,D3DXVECTOR3(position.x, position.y+DELTA_DOWN, position.z), extents);
	if (move.fraction >= DIST_EPSILON)
	{
		if ((vSpeed == 0.0f) && (!jumping)) // Might be stepping down
		{
			startPoint = position;
			endPoint = startPoint - STEP_UP;
			move = checkMove(startPoint, endPoint, extents);
			if (move.fraction < 1.0f) // Hit the step
			{
				position = move.end;
				stepDown = true;
			}
		}
		if (!stepDown)
		{
			vSpeed += GRAVITY_INCH*dTime;
		}
	}
	if (vSpeed)
	{
		endPoint = position + D3DXVECTOR3(0, vSpeed*dTime, 0);
		move = checkMove(position, endPoint, extents);
		position = move.end;
		if (move.fraction < DIST_EPSILON)
		{
			if (jumping)
			{
				vSpeed = DIST_EPSILON;
			}
			else
			{
				vSpeed = 0.0f;
			}
		}
	}
}
