#include "d3d8_screen.h"
#include <d3d9.h>
#include <stdio.h>
#include <math.h>
#include "Engine.h"

extern FILE *file;
extern Engine engine;

const bool Screen::Setup(const int width, const int height, const D3DFORMAT format, const float near_clip, const float far_clip, const D3DFORMAT zbuffer, const int backbuffers, const HWND hwnd)
{
	g_pD3D				=NULL;
	g_pd3dDevice	=NULL;

	fprintf(file,"d3d Direct3DCreate9\n");
	g_pD3D=Direct3DCreate9(D3D_SDK_VERSION);
	if (g_pD3D==NULL)
	{
		return false;
	}

	D3DPRESENT_PARAMETERS d3dpp; 
	ZeroMemory (&d3dpp, sizeof(d3dpp));
	d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
	d3dpp.BackBufferFormat = format;
	d3dpp.BackBufferWidth=width;
	d3dpp.BackBufferHeight=height;
	d3dpp.BackBufferCount=backbuffers;
	d3dpp.Windowed = false;
	d3dpp.FullScreen_RefreshRateInHz=D3DPRESENT_RATE_DEFAULT;
//	d3dpp.FullScreen_PresentationInterval=D3DPRESENT_INTERVAL_ONE;
	d3dpp.EnableAutoDepthStencil = TRUE;
	d3dpp.AutoDepthStencilFormat = zbuffer;
	fprintf(file,"d3d CreateDevice\n");
	if (FAILED(g_pD3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hwnd, D3DCREATE_HARDWARE_VERTEXPROCESSING | D3DCREATE_PUREDEVICE, &d3dpp, &g_pd3dDevice)))
	{
		return false;
	}
	Format = format;

	fprintf(file,"d3d SetRenderState\n");
	g_pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	g_pd3dDevice->SetRenderState(D3DRS_CLIPPING, true);
	g_pd3dDevice->SetRenderState(D3DRS_FILLMODE,D3DFILL_SOLID); //	D3DFILL_WIREFRAME); D3DFILL_SOLID
	g_pd3dDevice->SetRenderState(D3DRS_LIGHTING, false);
	g_pd3dDevice->SetRenderState(D3DRS_SHADEMODE, D3DSHADE_FLAT); //	D3DSHADE_GOURAUD);
	g_pd3dDevice->SetRenderState(D3DRS_LASTPIXEL, true); 
//	g_pd3dDevice->SetRenderState(D3DRS_ZBIAS, 0);

  // For the projection matrix, we set up a perspective transform (which transforms geometry from 3D view space to 2D viewport space, with a perspective divide making objects smaller in the distance). To build a perspective transform, we need the field of view (1/4 pi is common), the aspect ratio, and the near and far clipping planes (which define at what distances geometry should be no longer be rendered).
  D3DXMatrixPerspectiveFovLH(&Matrix_Projection, D3DX_PI/4.0f, 1.0f, near_clip, far_clip);
  g_pd3dDevice->SetTransform(D3DTS_PROJECTION, &Matrix_Projection);

//	Font = new CD3DFont(_T("Terminal"), 6, D3DFONT_BOLD);
//	Font->InitDeviceObjects(g_pd3dDevice);
//	Font->RestoreDeviceObjects();

	for (int x=0;x!=MAX_VERTEX_BUFFER; ++x)
	{
		TL_Vertex_Buffer[x]=NULL;
		if (FAILED(g_pd3dDevice->CreateVertexBuffer(sizeof(D3D_VERTEX)*MAX_VERTEX, D3DUSAGE_WRITEONLY, D3DFVF_D3D_VERTEX, D3DPOOL_DEFAULT, &TL_Vertex_Buffer[x], NULL)))
		{
			return false;
		}
	}

	D3DXCreateFont(g_pd3dDevice,height/40,width/80,FW_BOLD,0,false,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH | FF_DONTCARE,TEXT("Arial"),&Font);

 	return true;
}

const void Screen::View_Matrix(const D3DXVECTOR3 &location, const D3DXVECTOR3 &direction)
{
	D3DXMATRIX matTmp;	
	D3DXMatrixRotationYawPitchRoll(&matTmp, direction.y, direction.x, direction.z); // View direction
	D3DXVECTOR4 tmp;
	D3DXVec3Transform(&tmp,&D3DXVECTOR3(0.0f,0.0f,1.0f), &matTmp);
	const D3DXVECTOR3 viewDir = (D3DXVECTOR3)tmp + location;
	
	D3DXVec3Transform(&tmp, &D3DXVECTOR3(0.0f,1.0f,0.0f), &matTmp); // Tmp is View up orientation
	D3DXMatrixLookAtLH(&Matrix_View, &location, &viewDir, &(D3DXVECTOR3)tmp);
  g_pd3dDevice->SetTransform(D3DTS_VIEW, &Matrix_View);
	ExtractFrustumPlanes();
}

Screen::~Screen()
{
	fprintf(file,"d3d screen shutdown\n");

//	if (Font)
//	{
//		Font->DeleteDeviceObjects();
//		delete (Font);
//		Font=NULL;
//	}
	for (int x=0;x!=MAX_VERTEX_BUFFER; ++x)
	{
		D3D_RELEASE(TL_Vertex_Buffer[x]);
	}
	D3D_RELEASE(g_pd3dDevice);
	D3D_RELEASE(g_pD3D);
}

const void Screen::ExtractFrustumPlanes(void)
{
	D3DXMATRIX ViewProj;
	D3DXMatrixMultiply(&ViewProj, &Matrix_View, &Matrix_Projection);

	Frustum[0].a = -(ViewProj._14 + ViewProj._11); // Left clipping plane
	Frustum[0].b = -(ViewProj._24 + ViewProj._21);
	Frustum[0].c = -(ViewProj._34 + ViewProj._31);
	Frustum[0].d = -(ViewProj._44 + ViewProj._41);
	D3DXPlaneNormalize(&Frustum[0], &Frustum[0]);

	Frustum[1].a = -(ViewProj._14 - ViewProj._11); // Right clipping plane
	Frustum[1].b = -(ViewProj._24 - ViewProj._21);
	Frustum[1].c = -(ViewProj._34 - ViewProj._31);
	Frustum[1].d = -(ViewProj._44 - ViewProj._41);
	D3DXPlaneNormalize(&Frustum[1], &Frustum[1]);

	Frustum[2].a = -(ViewProj._14 - ViewProj._12); // Top clipping plane
	Frustum[2].b = -(ViewProj._24 - ViewProj._22);
	Frustum[2].c = -(ViewProj._34 - ViewProj._32);
	Frustum[2].d = -(ViewProj._44 - ViewProj._42);
	D3DXPlaneNormalize(&Frustum[2], &Frustum[2]);

	Frustum[3].a = -(ViewProj._14 + ViewProj._12); // Bottom clipping plane
	Frustum[3].b = -(ViewProj._24 + ViewProj._22);
	Frustum[3].c = -(ViewProj._34 + ViewProj._32);
	Frustum[3].d = -(ViewProj._44 + ViewProj._42);
	D3DXPlaneNormalize(&Frustum[3], &Frustum[3]);

	Frustum[4].a = -(ViewProj._13); // Near clipping plane
	Frustum[4].b = -(ViewProj._23);
	Frustum[4].c = -(ViewProj._33);
	Frustum[4].d = -(ViewProj._43);
	D3DXPlaneNormalize(&Frustum[4], &Frustum[4]);

	Frustum[5].a = -(ViewProj._14 - ViewProj._13); // Far clipping plane
	Frustum[5].b = -(ViewProj._24 - ViewProj._23);
	Frustum[5].c = -(ViewProj._34 - ViewProj._33);
	Frustum[5].d = -(ViewProj._44 - ViewProj._43);
	D3DXPlaneNormalize(&Frustum[5], &Frustum[5]);
}

const bool Screen::IsPointInsideFrustum(const D3DXVECTOR3 &location)
{
	for (int i=0; i!=MAX_PLANES; ++i)
	{
		if (D3DXPlaneDotCoord(&Frustum[i], &location) >=0.0f)
		{
			return false;
		}
	}
	return true;
}


const bool Screen::IsSphereInsideFrustum(const D3DXVECTOR3 &location, const float Bounding_Sphere)
{
	for (int i=0; i!=MAX_PLANES; ++i)
	{
		if (D3DXPlaneDotCoord(&Frustum[i], &location)>=Bounding_Sphere)
		{
			return false;
		}
	}
	return true;
}


const bool Screen::IsBoxInsideFrustum(const D3DXVECTOR3 *bounding_box)
{
	for (int i=0; i!=MAX_PLANES; ++i) // Go through all of the corners of the box and check then again each plane in the frustum. If all of them are behind one of the planes, then it most like is not in the frustum.
	{
		if ((D3DXPlaneDotCoord(&Frustum[i], &bounding_box[0]) >=0.0f)
		 && (D3DXPlaneDotCoord(&Frustum[i], &bounding_box[1]) >=0.0f)
     && (D3DXPlaneDotCoord(&Frustum[i], &bounding_box[2]) >=0.0f)
     && (D3DXPlaneDotCoord(&Frustum[i], &bounding_box[3]) >=0.0f)
     && (D3DXPlaneDotCoord(&Frustum[i], &bounding_box[4]) >=0.0f)
     && (D3DXPlaneDotCoord(&Frustum[i], &bounding_box[5]) >=0.0f)
     && (D3DXPlaneDotCoord(&Frustum[i], &bounding_box[6]) >=0.0f)
     && (D3DXPlaneDotCoord(&Frustum[i], &bounding_box[7]) >=0.0f))
		{
			return false; // If we get here, it isn't in the frustum
		}
	}
	return true; // Return a true for the box being inside of the frustum
}

const void Screen::Polygon(const D3DXVECTOR3 *point,const int points,const D3DXCOLOR colour)
{
	PolygonPoint[0].Colour=colour;
	for(int p=0; p!=points; ++p)
	{
		PolygonPoint[p].Location=point[p];
		PolygonPoint[p].Colour=colour;
	}
	g_pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLEFAN,points-2,&PolygonPoint[0],sizeof(D3D_VERTEX));
}

const void Screen::DrawText(const int x,const int y, const D3DCOLOR color)
{
	RECT rect;
	SetRect(&rect,x,y,0,0);
	Font->DrawText(NULL,string,-1,&rect,DT_NOCLIP,color);
}

/*
void Screen::Draw_Triangle(const const D3DXVECTOR3 *p0, const const D3DXVECTOR3 *p1, const const D3DXVECTOR3 *p2, const D3DCOLOR colour)
{
	Vertex_Buffer[Vertex_Count+0].Position.w = Vertex_Buffer[Vertex_Count+1].Position.w = Vertex_Buffer[Vertex_Count+2].Position.w = Vertex_Buffer[Vertex_Count+3].Position.w = Vertex_Buffer[Vertex_Count+4].Position.w = Vertex_Buffer[Vertex_Count+5].Position.w = 
	Vertex_Buffer[Vertex_Count+0].Position.z = Vertex_Buffer[Vertex_Count+1].Position.z = Vertex_Buffer[Vertex_Count+2].Position.z = Vertex_Buffer[Vertex_Count+3].Position.z = Vertex_Buffer[Vertex_Count+4].Position.z = Vertex_Buffer[Vertex_Count+5].Position.z = 1.0f;

	Vertex_Buffer[Vertex_Count+0].Position.x = Vertex_Buffer[Vertex_Count+1].Position.x = Vertex_Buffer[Vertex_Count+3].Position.x = start_x;
	Vertex_Buffer[Vertex_Count+0].Position.y = Vertex_Buffer[Vertex_Count+2].Position.y = Vertex_Buffer[Vertex_Count+4].Position.y = start_y;
	Vertex_Buffer[Vertex_Count+2].Position.x = Vertex_Buffer[Vertex_Count+4].Position.x = Vertex_Buffer[Vertex_Count+5].Position.x = end_x;
	Vertex_Buffer[Vertex_Count+1].Position.y = Vertex_Buffer[Vertex_Count+3].Position.y = Vertex_Buffer[Vertex_Count+5].Position.y = end_y;

	Vertex_Buffer[Vertex_Count+0].TU = Vertex_Buffer[Vertex_Count+1].TU = Vertex_Buffer[Vertex_Count+3].TU = MT_Location[tile].Start_X;
	Vertex_Buffer[Vertex_Count+0].TV = Vertex_Buffer[Vertex_Count+2].TV = Vertex_Buffer[Vertex_Count+4].TV = MT_Location[tile].Start_Y;
	Vertex_Buffer[Vertex_Count+2].TU = Vertex_Buffer[Vertex_Count+4].TU = Vertex_Buffer[Vertex_Count+5].TU = MT_Location[tile].End_X;
	Vertex_Buffer[Vertex_Count+1].TV = Vertex_Buffer[Vertex_Count+3].TV = Vertex_Buffer[Vertex_Count+5].TV = MT_Location[tile].End_Y;

	Vertex_Buffer[Vertex_Count+0].Colour = Vertex_Buffer[Vertex_Count+3].Colour = colour;

	Vertex_Count+=6;
	Triangle_Count+=2;

	if (Vertex_Count==MAX_VERTEX)
	{
		Draw_Primitive();
		Lock_Vertex_Buffer();
	}
}
*/
