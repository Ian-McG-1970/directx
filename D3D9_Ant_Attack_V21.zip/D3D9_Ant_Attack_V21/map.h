#ifndef MAP
#define MAP

#include <stdio.h>
#include "d3d8_screen.h"

enum
{
	MAP_SIZE = 256,
	MAP_PATCH_SIZE = 16,
	MAP_PATCH_COUNT = MAP_SIZE / MAP_PATCH_SIZE,

	TOP_COLOUR = 224,
	BOTTOM_COLOUR = 96,
	LEFT_COLOUR = 160,
	RIGHT_COLOUR = 128,
	FRONT_COLOUR = 192,
	BACK_COLOUR = 104,
	FLOOR_COLOUR = 144,

	FRONT_SIDE = 0,
	BACK_SIDE = 1,
	LEFT_SIDE = 2,
	RIGHT_SIDE = 3,
	TOP_SIDE = 4,
	BOTTOM_SIDE = 5,
	SIDE_NOT_USED = 6,

	MAX_SIDES = 6,

	SCALE = 4,
	DRAW_ORDER_SIZE = 15,
	POSITIONS_PER_BYTE = 4,
};

const unsigned char BIT_SET[] =   { 0b000000011, 0b000001100, 0b000110000, 0b011000000};
const unsigned char BIT_RESET[] = { 0b011111100, 0b011110011, 0b011001111, 0b000111111 };
const unsigned char BIT_SHIFT[] = { 0, 2, 4, 6};

typedef struct
{
	unsigned long Model;
	D3DXVECTOR3 Location;
} MAP_PATCH;

typedef struct
{
	unsigned long x;
	unsigned long y;
	unsigned long z;
} DrawOrderLocation;

class Map
{
private:
	unsigned char GRID_BLOCK[MAP_PATCH_SIZE][MAP_PATCH_SIZE][MAP_PATCH_SIZE];
	unsigned char GRID_BLOCK_SIDES_USED[MAP_PATCH_SIZE][MAP_PATCH_SIZE][MAP_PATCH_SIZE][6]; // which sides of the grid block are used?
	const void BuildRandomMap(const float tolerance);
	const void BuildPatches();
	const unsigned long BuildPatch(const unsigned long, const unsigned long, const unsigned long); 
	const unsigned char AddBlock(const unsigned long, const unsigned long, const unsigned long);
	const void AddTriangles(const unsigned long, const unsigned long, const unsigned long, const unsigned long, unsigned long &);
	const void SetVertex(const unsigned long, const unsigned long, const unsigned long, const unsigned char, unsigned long &);
	const void AddVertices(const unsigned long, const unsigned long, const unsigned long, unsigned long &);
	const void BuildDrawOrder(const unsigned long);
	const void AddDrawOrder(const unsigned long, const unsigned long, const unsigned long);
	const void OptimiseGrid(unsigned long &, unsigned long &);
	const void RemoveTriangles(const unsigned long);
	const void RemoveHiddenBlocks();
public:
	const void Setup();
	~Map();
	MAP_PATCH Patch[MAP_PATCH_COUNT][MAP_PATCH_COUNT][MAP_PATCH_COUNT];
	unsigned char AMAP[(MAP_SIZE*MAP_SIZE*MAP_SIZE)/ POSITIONS_PER_BYTE];
	const unsigned char ReturnBlock(const D3DXVECTOR3 &);
	DrawOrderLocation DrawOrder[(DRAW_ORDER_SIZE+3)*(DRAW_ORDER_SIZE+3)*(DRAW_ORDER_SIZE+3)];
	unsigned long DrawOrderCount;
	const unsigned char GetBlock(const int, const int, const int);
	const void SetBlock(const int, const int, const int, const unsigned char);
};

#endif
