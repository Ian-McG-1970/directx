#ifndef PERLIN_H
#define PERLIN_H

#define STRICT				// Enable strict type checking
#define WIN32_LEAN_AND_MEAN // Don't include stuff that are rarely used
#include <windows.h>
#include <d3dx9.h>

#define MAP_SIZE 256
#define MASK MAP_SIZE-1

class CPerlin
{
private:
	float RotationMatrix[9]; // Rotation matrix
	const float Noise1(const float x);
	const float Noise2(const float x,const  float y);
	const float Noise3(const D3DXVECTOR3);
	int Permutation[MAP_SIZE]; // Permutation table
	D3DXVECTOR3 Gradient[MAP_SIZE]; // Gradient

public:
	CPerlin();
	const void Initialize(const UINT nSeed);
	const float GetPerlinPoint(const float ix, const float iy, const float z);
	const void InitRotationMatrix(const float *pAxis, const float r);
};

#endif