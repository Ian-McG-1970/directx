#ifndef ENGINE
#define ENGINE

#include "d3d8_screen.h"

class Engine
{
private:
	float	Speed;
	D3DXVECTOR3 Location;
	D3DXVECTOR3 Direction;
	D3DXVECTOR3 BoundingBox;
	const void DrawMap(const D3DXVECTOR3 &);
	const void Move(D3DXVECTOR3 &, const D3DXVECTOR3 &, const float);
	const void Move2(D3DXVECTOR3 &, const D3DXVECTOR3 &, const float, const D3DXVECTOR3 &);
	const void Input(D3DXVECTOR3 &, float &, const float);
	const void StartPos(D3DXVECTOR3 &location);
public:
	const void Setup();
	~Engine();
	const void Update();
};

#endif

