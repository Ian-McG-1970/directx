#include "load.h"
#include "d3d8_screen.h"
#include "map.h"

extern FILE *file;
extern Screen screen;
extern Map map;

// todo look into d3dxoptimizefaces and d3dxoptimizevertices

void Load::Setup()
{
	fprintf(file, "Load setup\n");
}

Load::~Load()
{
	fprintf(file, "Load shutdown\n");
}

unsigned long Load::Model(const char *name, const unsigned long texture)
{
	fprintf(file,"load model %s texture %ld\n", name, texture);
	if ((fileopen=fopen(name, "r"))==NULL)
	{
		fprintf(file,"not found\n");
		return 0;
	}

	char rec[256];
	fscanf(fileopen, "%s", rec);
	const unsigned long vertices=atol(rec);
	fscanf(fileopen, "%s", rec);
	const unsigned long triangles=atol(rec);

	fprintf(file,"verts %ld tris %ld\n", vertices, triangles);

	fscanf(fileopen, "%s", rec);

	for (unsigned long b=0; b!=8; ++b)
	{
		fscanf(fileopen, "%s", rec);
		fscanf(fileopen, "%s", rec);
		fscanf(fileopen, "%s", rec);
	}
	
	for (unsigned long x=0; x!=vertices; ++x)
	{
		fscanf(fileopen, "%s", rec);
		screen.Vertex[x].Location.x=atof(rec);
		fscanf(fileopen, "%s", rec);
		screen.Vertex[x].Location.y=atof(rec);
		fscanf(fileopen, "%s", rec);
		screen.Vertex[x].Location.z=atof(rec);

		fscanf(fileopen, "%s", rec);
//		float TU= /* screen.Vertex[x].TU*/ =atof(rec);
		fscanf(fileopen, "%s", rec);
//		float TU= /* screen.Vertex[x].TV*/ =atof(rec);
		screen.Vertex[x].Colour=D3DCOLOR_XRGB(rand(),rand(),rand());
	}

	for (unsigned long y=0, z=0; y!=triangles; ++y, z+=3)
	{
		fscanf(fileopen, "%s", rec);
		screen.Index[z] =atol(rec);
		fscanf(fileopen, "%s", rec);
		screen.Index[z+1] =atol(rec);
		fscanf(fileopen, "%s", rec);
		screen.Index[z+2] =atol(rec);
	}
	fclose(fileopen);

	return screen.CreateObject(vertices, triangles, texture);
}

bool Load::Texture(const char *name, const unsigned long number)
{
	fprintf(file,"load texture %s number %ld\n", name, number);

	D3DXIMAGE_INFO texture_format;
	D3DXCreateTextureFromFileEx(screen.g_pd3dDevice, name, D3DX_DEFAULT, D3DX_DEFAULT, D3DX_DEFAULT, 0,	D3DFMT_UNKNOWN,	D3DPOOL_MANAGED, D3DX_FILTER_NONE, D3DX_FILTER_NONE, 0x0ff000000, &texture_format, NULL, &screen.Texture[number]);
	if (screen.Texture[number]==NULL)
	{
		fprintf(file, "not found\n");
		return false;
	}
	fprintf(file, "width %ld height %ld depth %ld format %ld mipmap %ld\n",	texture_format.Width,	texture_format.Height, texture_format.Depth, texture_format.MipLevels, texture_format.Format,	texture_format.MipLevels);

	return true;
}
