#include "stdlib.h"
#include "d3d8_screen.h"
#include "load.h"
#include "map.h"
#include "perlin.h"

extern Screen screen;
extern Load load;
extern FILE *file;

const void Map::Setup()
{
	fprintf(file,"map setup\n");

	memset(&AMAP[0],0,(sizeof(AMAP[0])*MAP_SIZE*MAP_SIZE*MAP_SIZE)/POSITIONS_PER_BYTE);
	BuildRandomMap(0.999f);
	RemoveHiddenBlocks();
	BuildPatches();
	BuildDrawOrder(DRAW_ORDER_SIZE);

	unsigned long triangles=0, vertices=0;
	for (unsigned long x=0; x!=MAP_PATCH_COUNT; ++x)
	{
		for (unsigned long y=0; y!=MAP_PATCH_COUNT; ++y)
		{
			for (unsigned long z=0; z!=MAP_PATCH_COUNT; ++z)
			{
				triangles+=screen.Model[Patch[x][y][z].Model].Triangles;
				vertices+=screen.Model[Patch[x][y][z].Model].Vertices;
			}
		}
	}
	fprintf(file,"map - triangles %ld vertices %ld\n", triangles, vertices);

}

Map::~Map()
{
	fprintf(file,"map shutdown\n");
}

const unsigned char Map::AddBlock(const unsigned long x, const unsigned long z, const unsigned long y)
{
//	srand(x+y+z);
	if ((rand()&7)!=1)
	{
		return 0;
	}
	if (y==0)
	{
		return 1;
	}
	if (GetBlock(x,z,y-1)!=0)
	{
		return 1;
	}
	if ((x!=0) && (GetBlock(x-1,z,y)!=0))
	{
		return 1;
	}
	if ((x!=(MAP_SIZE-1)) && (GetBlock(x+1,z,y)!=0))
	{
		return 1;
	}
	if ((z!=0) && (GetBlock(x,z-1,y)!=0))
	{
		return 1;
	}
	if ((z!=(MAP_SIZE-1)) && (GetBlock(x,z+1,y)!=0))
	{
		return 1;
	}
	return 0;
}

const void Map::BuildRandomMap(const float tolerance)
{
	CPerlin *pPerlin = new CPerlin(); 	// Initialize perlin noise
	pPerlin->Initialize(0);

	const float Axis[3] = {10.16f, 20.67f, 30.43f}; 	// Initialize rotation matrix with random values This will make sure our bitmap will not be  parallel to the planes of the noise function
	pPerlin->InitRotationMatrix(Axis, 0.0f);//0.34521f);

	for (unsigned long x=0; x!=MAP_SIZE; ++x)
	{
		screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(rand(), rand(), rand()), 1.0f, 0);
		screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);

		for (unsigned long y=0; y!=MAP_SIZE; ++y)
		{
			for (unsigned long z=0; z!=MAP_SIZE; ++z)
			{
					if (pPerlin->GetPerlinPoint(x, y, (float)z/16.0f) >tolerance)
					{
						SetBlock(x,y,z,1);
					}
					else
					{
						SetBlock(x,y,z,0);
					}
			}
		}
	}
	delete pPerlin;
}

const void Map::RemoveHiddenBlocks()
{

	for (unsigned long x=1; x!=MAP_SIZE-1; ++x)
	{
		for (unsigned long y=1; y!=MAP_SIZE-1; ++y)
		{
			for (unsigned long z=1; z!=MAP_SIZE-1; ++z)
			{
				if ( (GetBlock(x,y,z)!=0)
				&& (GetBlock(x-1,y,z)!=0)
				&& (GetBlock(x+1,y,z)!=0)
				&& (GetBlock(x,y-1,z)!=0)
				&& (GetBlock(x,y+1,z)!=0)
				&& (GetBlock(x,y,z-1)!=0)
				&& (GetBlock(x,y,z+1)!=0) )
				{
					SetBlock(x,y,z,2);
				}
			}
		}
	}

//	unsigned long cnt1=0, cnt2=0;
	for (unsigned long x=1; x!=MAP_SIZE-1; ++x)
	{
		for (unsigned long y=1; y!=MAP_SIZE-1; ++y)
		{
			for (unsigned long z=1; z!=MAP_SIZE-1; ++z)
			{
				if (GetBlock(x,y,z)==2)
				{
//					++cnt2;
					SetBlock(x,y,z,0);
				}
//				++cnt1;
			}
		}
	}
//	fprintf(file, "rst_xyz %ld %ld\n", cnt1, cnt2);
}


const void Map::BuildPatches()
{
	for (unsigned long x=0, xp=0; x!=MAP_SIZE; ++xp, x+=MAP_PATCH_SIZE)
	{
		screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(rand(), rand(), rand()), 1.0f, 0);
		screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);

		for (unsigned long y=0, yp=0; y!=MAP_SIZE; ++yp, y+=MAP_PATCH_SIZE)
		{
			for (unsigned long z=0, zp=0; z!=MAP_SIZE; ++zp, z+=MAP_PATCH_SIZE)
			{
				Patch[xp][yp][zp].Location.x=x*SCALE;
				Patch[xp][yp][zp].Location.y=y*SCALE;
				Patch[xp][yp][zp].Location.z=z*SCALE;
				Patch[xp][yp][zp].Model=BuildPatch(x, y, z);
			}
		}
	}
}

const void Map::AddTriangles(const unsigned long v1, const unsigned long v2, const unsigned long v3, const unsigned long v4, unsigned long &index)
{
	screen.Index[index+0]=v1;
	screen.Index[index+1]=v2;
	screen.Index[index+2]=v3;
	screen.Index[index+3]=v1;
	screen.Index[index+4]=v3;
	screen.Index[index+5]=v4;
	index+=6;
}

const void Map::SetVertex(const unsigned long x, const unsigned long y, const unsigned long z, const unsigned char colour, unsigned long &vertex)
{
	screen.Vertex[vertex].Location.x=x*SCALE;
	screen.Vertex[vertex].Location.y=y*SCALE;
	screen.Vertex[vertex].Location.z=z*SCALE;
	screen.Vertex[vertex].Colour=D3DCOLOR_XRGB(colour,colour,colour);
	++vertex;
}

const void Map::AddVertices(const unsigned long x, const unsigned long y, const unsigned long z, unsigned long &vertex)
{
	SetVertex(x+0, y+0, z+0, LEFT_COLOUR, vertex);
	SetVertex(x+0, y+0, z+1, BACK_COLOUR, vertex);
	SetVertex(x+0, y+1, z+0, TOP_COLOUR, vertex);
	SetVertex(x+0, y+1, z+1, LEFT_COLOUR, vertex);
	SetVertex(x+1, y+0, z+0, FRONT_COLOUR, vertex);
	SetVertex(x+1, y+0, z+1, LEFT_COLOUR, vertex);
	SetVertex(x+1, y+1, z+0, RIGHT_COLOUR, vertex);
	SetVertex(x+1, y+1, z+1, BACK_COLOUR, vertex);
	SetVertex(x+1, y+0, z+1, BOTTOM_COLOUR, vertex);
}

// todo - need to copy 18*18*18 instead of 16*16*16, and start loops from 1 to 17 instead of 0 to 16

const unsigned long Map::BuildPatch(const unsigned long x, const unsigned long y, const unsigned long z) 
{
//	screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(rand(), rand(), rand()), 1.0f, 0);
//	screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);

//	fprintf(file,"bp x %ld z %ld\n", x, z);
	memset(&GRID_BLOCK_SIDES_USED[0][0][0][0], SIDE_NOT_USED, sizeof(GRID_BLOCK_SIDES_USED[0][0][0][0])*MAP_PATCH_SIZE*MAP_PATCH_SIZE*MAP_PATCH_SIZE*MAX_SIDES); //set all sides to not used

	for (unsigned long xmap=x, xgrid=0; xgrid!=MAP_PATCH_SIZE; ++xgrid, ++xmap) //copy points from full map to 16x16x16 block
	{
		for (unsigned long ymap=y, ygrid=0; ygrid!=MAP_PATCH_SIZE; ++ygrid, ++ymap)
		{
			for (unsigned long zmap=z, zgrid=0; zgrid!=MAP_PATCH_SIZE; ++zgrid, ++zmap)
			{
				GRID_BLOCK[xgrid][zgrid][ygrid]=GetBlock(xmap,zmap,ymap);
			}
		}
	}

	unsigned long vertex_count=0, index_count=0;
	for (unsigned long xface=0; xface!=MAP_PATCH_SIZE; ++xface)
	{
		for (unsigned long zface=0; zface!=MAP_PATCH_SIZE; ++zface)
		{
			for (unsigned long yface=0; yface!=MAP_PATCH_SIZE; ++yface)
			{
				if (GRID_BLOCK[xface][zface][yface]!=0) // if point is not empty
				{
					if ((zface==0) ||  (GRID_BLOCK[xface][zface-1][yface]==0)) //zface-1 - front
					{
						GRID_BLOCK_SIDES_USED[xface][zface][yface][FRONT_SIDE]=index_count;
						AddTriangles(vertex_count+4, vertex_count+0, vertex_count+2, vertex_count+6, index_count);
					}
					if ((zface==MAP_PATCH_SIZE-1) || (GRID_BLOCK[xface][zface+1][yface]==0)) //zface+1 back
					{
						GRID_BLOCK_SIDES_USED[xface][zface][yface][BACK_SIDE]=index_count;
						AddTriangles(vertex_count+1, vertex_count+5, vertex_count+7, vertex_count+3, index_count);
					}
					if ((xface==0) || (GRID_BLOCK[xface-1][zface][yface]==0)) //xface-1 left
					{
						GRID_BLOCK_SIDES_USED[xface][zface][yface][RIGHT_SIDE]=index_count;
						AddTriangles(vertex_count+0, vertex_count+1, vertex_count+3, vertex_count+2, index_count);
					}
					if ((xface==MAP_PATCH_SIZE-1) || (GRID_BLOCK[xface+1][zface][yface]==0)) //xface+1 right
					{
						GRID_BLOCK_SIDES_USED[xface][zface][yface][LEFT_SIDE]=index_count;
						AddTriangles(vertex_count+5, vertex_count+4, vertex_count+6, vertex_count+7, index_count);
					}
					if ((yface==0) || (GRID_BLOCK[xface][zface][yface-1]==0)) //yface-1 up
					{
						GRID_BLOCK_SIDES_USED[xface][zface][yface][BOTTOM_SIDE]=index_count;
						AddTriangles(vertex_count+8, vertex_count+1, vertex_count+0, vertex_count+4, index_count);
					}
					if ((yface==MAP_PATCH_SIZE-1) || (GRID_BLOCK[xface][zface][yface+1]==0)) //yface+1 down
					{
						GRID_BLOCK_SIDES_USED[xface][zface][yface][TOP_SIDE]=index_count;
						AddTriangles(vertex_count+2, vertex_count+3, vertex_count+7, vertex_count+6, index_count);
					}
					AddVertices(xface, yface, zface, vertex_count);
				}
			}
		}
	}

	fprintf(file,"og before vc %ld ic %ld\n",vertex_count,index_count);
//	OptimiseGrid(vertex_count, index_count);
	fprintf(file,"og after vc %ld ic %ld\n",vertex_count,index_count);

//	SetVertex(0, 0, 0, FLOOR_COLOUR, vertex_count);
//	SetVertex(0, 0, MAP_PATCH_SIZE, FLOOR_COLOUR, vertex_count);
//	SetVertex(MAP_PATCH_SIZE, 0, MAP_PATCH_SIZE, FLOOR_COLOUR, vertex_count);
//	SetVertex(MAP_PATCH_SIZE, 0, 0, FLOOR_COLOUR, vertex_count);
//	AddTriangles(vertex_count-4, vertex_count-3, vertex_count-2, vertex_count-1, index_count);

	return screen.CreateObject(vertex_count, index_count/3, 1);
}

const void Map::RemoveTriangles(const unsigned long index_remove)
{
	memset(&screen.Index[index_remove], 0, sizeof(screen.Index[0])*MAX_SIDES);
//	for (unsigned long x=0; x!=6; ++x) screen.Index[index_remove+x]=0;
}

const void Map::OptimiseGrid(unsigned long &vertex, unsigned long &index)
{

	for (unsigned long xface=0; xface!=MAP_PATCH_SIZE; ++xface)
	{
		for (unsigned long zface=0; zface!=MAP_PATCH_SIZE; ++zface)
		{
			for (unsigned long side=0; side!=MAX_SIDES-2; ++side)
			{
				for (unsigned long yface=1; yface!=MAP_PATCH_SIZE; ++yface)
				{
					if ((GRID_BLOCK_SIDES_USED[xface][zface][yface-1][side]!=SIDE_NOT_USED) && (GRID_BLOCK_SIDES_USED[xface][zface][yface][side]!=SIDE_NOT_USED))
					{
						const unsigned long index_top=GRID_BLOCK_SIDES_USED[xface][zface][yface-1][side];
						const unsigned long index_bottom=GRID_BLOCK_SIDES_USED[xface][zface][yface][side];
						const unsigned long top_left=screen.Index[index_top];
						const unsigned long top_right=screen.Index[index_top+1];
						const unsigned long bottom_left=screen.Index[index_bottom+4];
						const unsigned long bottom_right=screen.Index[index_bottom+5];
						RemoveTriangles(index_top);
						RemoveTriangles(index_bottom);
						GRID_BLOCK_SIDES_USED[xface][zface][yface-1][side]=GRID_BLOCK_SIDES_USED[xface][zface][yface][side]=index;
						AddTriangles(top_left, top_right, bottom_left, bottom_right, index);
					}
				}
			}
		}
	}

	for (unsigned long xface=1; xface!=MAP_PATCH_SIZE; ++xface)
	{
		for (unsigned long zface=0; zface!=MAP_PATCH_SIZE; ++zface)
		{
			for (unsigned long yface=0; yface!=MAP_PATCH_SIZE; ++yface)
			{
				if ((GRID_BLOCK_SIDES_USED[xface-1][zface][yface][FRONT_SIDE]!=SIDE_NOT_USED) && (GRID_BLOCK_SIDES_USED[xface][zface][yface][FRONT_SIDE]!=SIDE_NOT_USED))
				{
					const unsigned long index_left=GRID_BLOCK_SIDES_USED[xface-1][zface][yface][FRONT_SIDE];
					const unsigned long index_right=GRID_BLOCK_SIDES_USED[xface][zface][yface][FRONT_SIDE];
					const unsigned long top_left=screen.Index[index_right+0];
					const unsigned long top_right=screen.Index[index_left+1];
					const unsigned long bottom_right=screen.Index[index_left+4];
					const unsigned long bottom_left=screen.Index[index_right+5];
					if ((top_left!=0) || (top_right!=0) || (bottom_left!=0) || (bottom_right!=0))
					{
						if ((screen.Vertex[top_left].Location.y==screen.Vertex[top_right].Location.y) && (screen.Vertex[bottom_left].Location.y==screen.Vertex[bottom_right].Location.y))
						{
							RemoveTriangles(index_left);
							RemoveTriangles(index_right);
							GRID_BLOCK_SIDES_USED[xface-1][zface][yface][FRONT_SIDE]=GRID_BLOCK_SIDES_USED[xface][zface][yface][FRONT_SIDE]=index;
							AddTriangles(top_left, top_right, bottom_right,bottom_left, index);
						}
					}
				}
			}
		}
	}

	for (unsigned long xface=1; xface!=MAP_PATCH_SIZE; ++xface)
	{
		for (unsigned long zface=0; zface!=MAP_PATCH_SIZE; ++zface)
		{
			for (unsigned long yface=0; yface!=MAP_PATCH_SIZE; ++yface)
			{
				if ((GRID_BLOCK_SIDES_USED[xface-1][zface][yface][BACK_SIDE]!=SIDE_NOT_USED) && (GRID_BLOCK_SIDES_USED[xface][zface][yface][BACK_SIDE]!=SIDE_NOT_USED))
				{
					const unsigned long index_right=GRID_BLOCK_SIDES_USED[xface-1][zface][yface][BACK_SIDE];
					const unsigned long index_left=GRID_BLOCK_SIDES_USED[xface][zface][yface][BACK_SIDE];
					const unsigned long top_left=screen.Index[index_right+0];
					const unsigned long top_right=screen.Index[index_left+1];
					const unsigned long bottom_right=screen.Index[index_left+4];
					const unsigned long bottom_left=screen.Index[index_right+5];
					if ((top_left!=0) || (top_right!=0) || (bottom_left!=0) || (bottom_right!=0))
					{
						if ((screen.Vertex[top_left].Location.y==screen.Vertex[top_right].Location.y) && (screen.Vertex[bottom_left].Location.y==screen.Vertex[bottom_right].Location.y))
						{
							RemoveTriangles(index_left);
							RemoveTriangles(index_right);
							GRID_BLOCK_SIDES_USED[xface-1][zface][yface][BACK_SIDE]=	GRID_BLOCK_SIDES_USED[xface][zface][yface][BACK_SIDE]=index;
							AddTriangles(top_left, top_right, bottom_right,bottom_left, index);
						}
					}
				}
			}
		}
	}

	for (unsigned long xface=0; xface!=MAP_PATCH_SIZE; ++xface)
	{
		for (unsigned long zface=1; zface!=MAP_PATCH_SIZE; ++zface)
		{
			for (unsigned long yface=0; yface!=MAP_PATCH_SIZE; ++yface)
			{
				if ((GRID_BLOCK_SIDES_USED[xface][zface-1][yface][LEFT_SIDE]!=SIDE_NOT_USED) && (GRID_BLOCK_SIDES_USED[xface][zface][yface][LEFT_SIDE]!=SIDE_NOT_USED))
				{
					const unsigned long index_front=GRID_BLOCK_SIDES_USED[xface][zface-1][yface][LEFT_SIDE];
					const unsigned long index_back=GRID_BLOCK_SIDES_USED[xface][zface][yface][LEFT_SIDE];
					const unsigned long top_left=screen.Index[index_back+0];
					const unsigned long top_right=screen.Index[index_front+1];
					const unsigned long bottom_right=screen.Index[index_front+4];
					const unsigned long bottom_left=screen.Index[index_back+5];
					if ((top_left!=0) || (top_right!=0) || (bottom_left!=0) || (bottom_right!=0))
					{
						if ((screen.Vertex[top_left].Location.y==screen.Vertex[top_right].Location.y) && (screen.Vertex[bottom_left].Location.y==screen.Vertex[bottom_right].Location.y))
						{
							RemoveTriangles(index_front);
							RemoveTriangles(index_back);
							GRID_BLOCK_SIDES_USED[xface][zface-1][yface][LEFT_SIDE]=GRID_BLOCK_SIDES_USED[xface][zface][yface][LEFT_SIDE]=index;
							AddTriangles(top_left, top_right, bottom_right,bottom_left, index);
						}
					}
				}
			}
		}
	}

	for (unsigned long xface=0; xface!=MAP_PATCH_SIZE; ++xface)
	{
		for (unsigned long zface=1; zface!=MAP_PATCH_SIZE; ++zface)
		{
			for (unsigned long yface=0; yface!=MAP_PATCH_SIZE; ++yface)
			{
				if ((GRID_BLOCK_SIDES_USED[xface][zface-1][yface][RIGHT_SIDE]!=SIDE_NOT_USED) && (GRID_BLOCK_SIDES_USED[xface][zface][yface][RIGHT_SIDE]!=SIDE_NOT_USED))
				{
					const unsigned long index_front=GRID_BLOCK_SIDES_USED[xface][zface-1][yface][RIGHT_SIDE];
					const unsigned long index_back=GRID_BLOCK_SIDES_USED[xface][zface][yface][RIGHT_SIDE];
					const unsigned long top_left=screen.Index[index_front+0];
					const unsigned long top_right=screen.Index[index_back+1];
					const unsigned long bottom_right=screen.Index[index_back+4];
					const unsigned long bottom_left=screen.Index[index_front+5];
					if ((top_left!=0) || (top_right!=0) || (bottom_left!=0) || (bottom_right!=0))
					{
						if ((screen.Vertex[top_left].Location.y==screen.Vertex[top_right].Location.y) && (screen.Vertex[bottom_left].Location.y==screen.Vertex[bottom_right].Location.y))
						{
							RemoveTriangles(index_front);
							RemoveTriangles(index_back);
							GRID_BLOCK_SIDES_USED[xface][zface-1][yface][RIGHT_SIDE]=GRID_BLOCK_SIDES_USED[xface][zface][yface][RIGHT_SIDE]=index;
							AddTriangles(top_left, top_right, bottom_right,bottom_left, index);
						}
					}
				}
			}
		}
	}

	for (unsigned long xface=1; xface!=MAP_PATCH_SIZE; ++xface)
	{
		for (unsigned long zface=0; zface!=MAP_PATCH_SIZE; ++zface)
		{
			for (unsigned long yface=0; yface!=MAP_PATCH_SIZE; ++yface)
			{
				if ((GRID_BLOCK_SIDES_USED[xface-1][zface][yface][TOP_SIDE]!=SIDE_NOT_USED) && (GRID_BLOCK_SIDES_USED[xface][zface][yface][TOP_SIDE]!=SIDE_NOT_USED))
				{
					const unsigned long index_front=GRID_BLOCK_SIDES_USED[xface-1][zface][yface][TOP_SIDE];
					const unsigned long index_back=GRID_BLOCK_SIDES_USED[xface][zface][yface][TOP_SIDE];
					const unsigned long top_left=screen.Index[index_front+0];
					const unsigned long top_right=screen.Index[index_front+1];
					const unsigned long bottom_left=screen.Index[index_back+5];
					const unsigned long bottom_right=screen.Index[index_back+4];
					if ((top_left!=0) || (top_right!=0) || (bottom_left!=0) || (bottom_right!=0))
					{
						RemoveTriangles(index_front);
						RemoveTriangles(index_back);
						GRID_BLOCK_SIDES_USED[xface-1][zface][yface][TOP_SIDE]=GRID_BLOCK_SIDES_USED[xface][zface][yface][TOP_SIDE]=index;
						AddTriangles(top_left, top_right, bottom_right, bottom_left, index);
					}
				}
			}
		}
	}

	for (unsigned long xface=0; xface!=MAP_PATCH_SIZE; ++xface)
	{
		for (unsigned long zface=0; zface!=MAP_PATCH_SIZE-1; ++zface)
		{
			for (unsigned long yface=0; yface!=MAP_PATCH_SIZE; ++yface)
			{
				if ((GRID_BLOCK_SIDES_USED[xface][zface+1][yface][TOP_SIDE]!=SIDE_NOT_USED) && (GRID_BLOCK_SIDES_USED[xface][zface][yface][TOP_SIDE]!=SIDE_NOT_USED))
				{
					const unsigned long index_front=GRID_BLOCK_SIDES_USED[xface][zface][yface][TOP_SIDE];
					const unsigned long index_back=GRID_BLOCK_SIDES_USED[xface][zface+1][yface][TOP_SIDE];
					const unsigned long top_left=screen.Index[index_front+0];
					const unsigned long top_right=screen.Index[index_front+5];
					const unsigned long bottom_left=screen.Index[index_back+1];
					const unsigned long bottom_right=screen.Index[index_back+4];
					if ((top_left!=0) || (top_right!=0) || (bottom_left!=0) || (bottom_right!=0))
					{
						if ((screen.Vertex[top_left].Location.x==screen.Vertex[bottom_left].Location.x) && (screen.Vertex[top_right].Location.x==screen.Vertex[bottom_right].Location.x))
						{
							RemoveTriangles(index_front);
							RemoveTriangles(index_back);
							GRID_BLOCK_SIDES_USED[xface][zface+1][yface][TOP_SIDE]=GRID_BLOCK_SIDES_USED[xface][zface][yface][TOP_SIDE]=index;
							AddTriangles(top_left, bottom_left, bottom_right ,top_right, index);
						}
					}
				}
			}
		}
	}

	for (unsigned long xface=1; xface!=MAP_PATCH_SIZE; ++xface)
	{
		for (unsigned long zface=0; zface!=MAP_PATCH_SIZE; ++zface)
		{
			for (unsigned long yface=0; yface!=MAP_PATCH_SIZE; ++yface)
			{
				if ((GRID_BLOCK_SIDES_USED[xface-1][zface][yface][BOTTOM_SIDE]!=SIDE_NOT_USED) && (GRID_BLOCK_SIDES_USED[xface][zface][yface][BOTTOM_SIDE]!=SIDE_NOT_USED))
				{
					const unsigned long index_front=GRID_BLOCK_SIDES_USED[xface][zface][yface][BOTTOM_SIDE];
					const unsigned long index_back=GRID_BLOCK_SIDES_USED[xface-1][zface][yface][BOTTOM_SIDE];
					const unsigned long top_left=screen.Index[index_front+0];
					const unsigned long top_right=screen.Index[index_front+5];
					const unsigned long bottom_left=screen.Index[index_back+1];
					const unsigned long bottom_right=screen.Index[index_back+4];
					if ((top_left!=0) || (top_right!=0) || (bottom_left!=0) || (bottom_right!=0))
					{
						RemoveTriangles(index_front);
						RemoveTriangles(index_back);
						GRID_BLOCK_SIDES_USED[xface-1][zface][yface][BOTTOM_SIDE]=	GRID_BLOCK_SIDES_USED[xface][zface][yface][BOTTOM_SIDE]=index;
						AddTriangles(top_left, bottom_left, bottom_right, top_right, index);
					}
				}
			}
		}
	}

	for (unsigned long xface=0; xface!=MAP_PATCH_SIZE; ++xface)
	{
		for (unsigned long zface=0; zface!=MAP_PATCH_SIZE-1; ++zface)
		{
			for (unsigned long yface=1; yface!=MAP_PATCH_SIZE; ++yface)
			{
				if ((GRID_BLOCK_SIDES_USED[xface][zface][yface][BOTTOM_SIDE]!=SIDE_NOT_USED) && (GRID_BLOCK_SIDES_USED[xface][zface+1][yface][BOTTOM_SIDE]!=SIDE_NOT_USED))
				{
					const unsigned long index_back=GRID_BLOCK_SIDES_USED[xface][zface][yface][BOTTOM_SIDE];
					const unsigned long index_front=GRID_BLOCK_SIDES_USED[xface][zface+1][yface][BOTTOM_SIDE];
					const unsigned long top_left=screen.Index[index_front+0];
					const unsigned long top_right=screen.Index[index_front+1];
					const unsigned long bottom_left=screen.Index[index_back+5];
					const unsigned long bottom_right=screen.Index[index_back+4];
					if ((top_left!=0) || (top_right!=0) || (bottom_left!=0) || (bottom_right!=0))
					{
						if ((screen.Vertex[top_left].Location.y==screen.Vertex[bottom_left].Location.y) && (screen.Vertex[top_right].Location.y==screen.Vertex[bottom_right].Location.y))
						{
							RemoveTriangles(index_front);
							RemoveTriangles(index_back);
							GRID_BLOCK_SIDES_USED[xface][zface][yface][BOTTOM_SIDE]=GRID_BLOCK_SIDES_USED[xface][zface+1][yface][BOTTOM_SIDE]=index;
							AddTriangles(top_left, top_right, bottom_right, bottom_left, index);
						}
					}
				}
			}
		}
	}

	unsigned long y=0;
	for (unsigned long x=0; x!=index; x+=3)
	{
		if ((screen.Index[x]!=0) || (screen.Index[x+1]!=0) || (screen.Index[x+2]!=0))
		{	
//			screen.Index[y+0]=screen.Index[x+0];
//			screen.Index[y+1]=screen.Index[x+1];
//			screen.Index[y+2]=screen.Index[x+2];
			memcpy(&screen.Index[y], &screen.Index[x], sizeof(screen.Index[0])*3);
			y+=3;
		}
	}
	index=y;
	
}

const unsigned char Map::ReturnBlock(const D3DXVECTOR3 &location)
{
	if ((location.y>=0.0f) && (location.y<=((MAP_SIZE*SCALE)-1)) && (location.x>=0) && (location.z>=0) 	&& (location.x<=((MAP_SIZE*SCALE)-1)) && (location.z<=((MAP_SIZE*SCALE)-1)) )
	{
		const unsigned long x=location.x/SCALE;
		const unsigned long y=location.y/SCALE;
		const unsigned long z=location.z/SCALE;
		return GetBlock(x,z,y);
	}
	return 1;
}

const void Map::AddDrawOrder(const unsigned long x, const unsigned long y, const unsigned long z)
{
	for (unsigned long c=0; c!=DrawOrderCount; ++c)
	{
		if ((DrawOrder[c].x==x) && (DrawOrder[c].y==y) && (DrawOrder[c].z==z))
	 {
			return;
		}
	}
	++DrawOrderCount;
	DrawOrder[DrawOrderCount].x=x;
	DrawOrder[DrawOrderCount].y=y;
	DrawOrder[DrawOrderCount].z=z;
	fprintf(file,"ado c %ld x %ld y %ld z %ld\n",DrawOrderCount,DrawOrder[DrawOrderCount].x,DrawOrder[DrawOrderCount].y,DrawOrder[DrawOrderCount].z);
}

const void Map::BuildDrawOrder(const unsigned long patch_end)
{
	DrawOrderCount=0;
	const unsigned long distance=(patch_end-1)>>1;
	AddDrawOrder(0, 0, 0);
	for (unsigned long d=0; d!=distance; ++d)
	{
		for (int x=-d; x!=d; ++x)
		{
			for (int y=-d; y!=d; ++y)
			{
				for (int z=-d; z!=d; ++z)
				{
					AddDrawOrder(x, y, z);
				}
			}
		}
	}
}

const unsigned char Map::GetBlock(const int x, const int y, const int z)
{
	const unsigned long byte_pos = ((x*MAP_SIZE*MAP_SIZE) + (y*MAP_SIZE) + z) >>2;
	const unsigned long bit_pos = z & 3;
	const unsigned char bit = AMAP[byte_pos] & BIT_SET[bit_pos];
	return bit >> BIT_SHIFT[bit_pos];
}

const void Map::SetBlock(const int x, const int y, const int z, const unsigned char value)
{
	const unsigned long byte_pos = ((x*MAP_SIZE*MAP_SIZE) + (y*MAP_SIZE) + z) >>2;
	const unsigned long bit_pos = z & 3;
	AMAP[byte_pos] = AMAP[byte_pos] & BIT_RESET[bit_pos];
	AMAP[byte_pos] = AMAP[byte_pos] | (value << BIT_SHIFT[bit_pos]);
}
