// TODO:
//
// By doubling the length of the arrays and duplicating the first half onto the 
// second half there is no need for the bitwise and when computing the 
// permuation.
//
// Is it possible to make a generalized noise function that takes a number for 
// the dimension and a vector with equal amount of values for the coordinate?
// I propose that a one dimensional gradient array can be used. The permutation
// array can be used to pseudo randomly pick n gradients from this array and 
// combine into a gradient vector.

#include "perlin.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

extern FILE	*file;

CPerlin::CPerlin()
{
}

const void CPerlin::Initialize(const UINT nSeed)
{
	srand(nSeed);

	for (int i=0; i!=MAP_SIZE; ++i) // Initialize the permutation table
	{
		Permutation[i] = i;
	}

	for (int i=0; i!=MAP_SIZE; ++i)
	{
		const int j = rand() & MASK;

		const int nSwap = Permutation[i];
		Permutation[i]  = Permutation[j];
		Permutation[j]  = nSwap;
	}

	for (int i=0; i!=MAP_SIZE; ++i) 	// Generate the gradient lookup tables
	{
		// Ken Perlin proposes that the gradients are taken from the unit circle/sphere for 2D/3D, but there are no noticable difference between that and what I'm doing here. For the sake of generality I will not do that.
		Gradient[i].x = float(rand())/(RAND_MAX/2) - 1.0f; 
		Gradient[i].y = float(rand())/(RAND_MAX/2) - 1.0f;
		Gradient[i].z = float(rand())/(RAND_MAX/2) - 1.0f;
	}
}

const float CPerlin::Noise1(const float x)
{
	int qx0 = (int)floorf(x); // Compute what gradients to use
	int qx1 = qx0 + 1;
	const float tx0 = x - (float)qx0;
	const float tx1 = tx0 - 1;

	qx0 = qx0 & MASK; 	// Make sure we don't come outside the lookup table
	qx1 = qx1 & MASK;

	const float v0 = Gradient[qx0].x*tx0; 	// Compute the dotproduct between the vectors and the gradients
	const float v1 = Gradient[qx1].x*tx1;

	const float wx = (3 - 2*tx0)*tx0*tx0; 	// Modulate with the weight function
	const float v = v0 - wx*(v0 - v1);

	return v;
}

const float CPerlin::Noise2(const float x, const float y)
{
	int qx0 = (int)floorf(x); 	// Compute what gradients to use
	int qx1 = qx0 + 1;
	const float tx0 = x - (float)qx0;
	const float tx1 = tx0 - 1;
	int qy0 = (int)floorf(y);
	int qy1 = qy0 + 1;
	const float ty0 = y - (float)qy0;
	const float ty1 = ty0 - 1;

	qx0 = qx0 & MASK; 	// Make sure we don't come outside the lookup table
	qx1 = qx1 & MASK;
	qy0 = qy0 & MASK;
	qy1 = qy1 & MASK;

	const int q00 = Permutation[(qy0 + Permutation[qx0]) & MASK]; 	// Permutate values to get pseudo randomly chosen gradients
	const int q01 = Permutation[(qy0 + Permutation[qx1]) & MASK]; 
	const int q10 = Permutation[(qy1 + Permutation[qx0]) & MASK];
	const int q11 = Permutation[(qy1 + Permutation[qx1]) & MASK];

	const float v00 = Gradient[q00].x*tx0 + Gradient[q00].y*ty0;	// Compute the dotproduct between the vectors and the gradients
	const float v01 = Gradient[q01].x*tx1 + Gradient[q01].y*ty0;
	const float v10 = Gradient[q10].x*tx0 + Gradient[q10].y*ty1;
	const float v11 = Gradient[q11].x*tx1 + Gradient[q11].y*ty1;

	const float wx = (3 - 2*tx0)*tx0*tx0; 	// Modulate with the weight function
	const float v0 = v00 - wx*(v00 - v01);
	const float v1 = v10 - wx*(v10 - v11);
	const float wy = (3 - 2*ty0)*ty0*ty0;
	const float v = v0 - wy*(v0 - v1);

	return v;
}

const float CPerlin::Noise3(const D3DXVECTOR3 n)
{
//	fprintf(file, "n3 %f %f %f\n",x,y,z);

	int qx0 = (int) floorf(n.x); 	// Compute what gradients to use
	int qy0 = (int) floorf(n.y);
	int qz0 = (int) floorf(n.z);

	const D3DXVECTOR3 t0=D3DXVECTOR3( n.x - (float) qx0,  n.y - (float) qy0,  n.z - (float) qz0);
	const D3DXVECTOR3 t1=D3DXVECTOR3( t0.x-1, t0.y-1, t0.z-1);

	const int qx1 = qx0 + 1 & MASK;
	const int qy1 = qy0 + 1 & MASK;
	const int qz1 = qz0 + 1 & MASK;

	qx0 = qx0 & MASK;	// Make sure we don't come outside the lookup table
	qy0 = qy0 & MASK;
	qz0 = qz0 & MASK;

	const int q000 = Permutation[(qz0 + Permutation[(qy0 + Permutation[qx0]) & MASK]) & MASK]; 	// Permutate values to get pseudo randomly chosen gradients
	const int q001 = Permutation[(qz0 + Permutation[(qy0 + Permutation[qx1]) & MASK]) & MASK];
	const int q010 = Permutation[(qz0 + Permutation[(qy1 + Permutation[qx0]) & MASK]) & MASK];
	const int q011 = Permutation[(qz0 + Permutation[(qy1 + Permutation[qx1]) & MASK]) & MASK];
	const int q100 = Permutation[(qz1 + Permutation[(qy0 + Permutation[qx0]) & MASK]) & MASK];
	const int q101 = Permutation[(qz1 + Permutation[(qy0 + Permutation[qx1]) & MASK]) & MASK];
	const int q110 = Permutation[(qz1 + Permutation[(qy1 + Permutation[qx0]) & MASK]) & MASK];
	const int q111 = Permutation[(qz1 + Permutation[(qy1 + Permutation[qx1]) & MASK]) & MASK];

	const float v000 = Gradient[q000].x*t0.x + Gradient[q000].y*t0.y + Gradient[q000].z*t0.z; 	// Compute the dotproduct between the vectors and the gradients
	const float v001 = Gradient[q001].x*t1.x + Gradient[q001].y*t0.y + Gradient[q001].z*t0.z;  
	const float v010 = Gradient[q010].x*t0.x + Gradient[q010].y*t1.y + Gradient[q010].z*t0.z;
	const float v011 = Gradient[q011].x*t1.x + Gradient[q011].y*t1.y + Gradient[q011].z*t0.z;
	const float v100 = Gradient[q100].x*t0.x + Gradient[q100].y*t0.y + Gradient[q100].z*t1.z;
	const float v101 = Gradient[q101].x*t1.x + Gradient[q101].y*t0.y + Gradient[q101].z*t1.z;  
	const float v110 = Gradient[q110].x*t0.x + Gradient[q110].y*t1.y + Gradient[q110].z*t1.z;
	const float v111 = Gradient[q111].x*t1.x + Gradient[q111].y*t1.y + Gradient[q111].z*t1.z;

	const D3DXVECTOR3 w = D3DXVECTOR3 ((3.0f - 2.0f*t0.x)*t0.x*t0.x, (3.0f - 2.0f*t0.y)*t0.y*t0.y, (3.0f - 2.0f*t0.z)*t0.z*t0.z); // Modulate with the weight function

	const float v00 = v000 - w.x*(v000 - v001);
	const float v01 = v010 - w.x*(v010 - v011);
	const float v10 = v100 - w.x*(v100 - v101);
	const float v11 = v110 - w.x*(v110 - v111);

	const float v0 = v00 - w.y*(v00 - v01);
	const float v1 = v10 - w.y*(v10 - v11);

	const float v = v0 - w.z*(v0 - v1);

	return v;
}

const float CPerlin::GetPerlinPoint(const float ix, const float iy, const float z)
{
//	fprintf(file, "gpp %f %f %f\n",ix,iy,z);

	const float y = iy/16.0f; 		// Compute the starting position from the y and z coordinate
	D3DXVECTOR3 p = D3DXVECTOR3( y*RotationMatrix[1] + z*RotationMatrix[2], y*RotationMatrix[4] + z*RotationMatrix[5], y*RotationMatrix[7] + z*RotationMatrix[8] );

	const float x = 1/16.0f; 		// This represents movements along the x axis
	const D3DXVECTOR3 d = D3DXVECTOR3 ( x*RotationMatrix[0], x*RotationMatrix[3], x*RotationMatrix[6] );

	p += d*ix;

	return (Noise3(p) + 1);
}

const void CPerlin::InitRotationMatrix(const float *pAxis, const float r)
{
  const float m = sqrtf(pAxis[0]*pAxis[0] + pAxis[1]*pAxis[1] + pAxis[2]*pAxis[2]);   // The axis vector must be of unit length
  const float x = pAxis[0] /m;
  const float y = pAxis[1] /m;
  const float z = pAxis[2] /m;
  const float c = cosf(r);   // Compute the rotation matrix  
  const float s = sinf(r);

  RotationMatrix[0] = (x * x) * (1.0f - c) + c;
  RotationMatrix[1] = (y * x) * (1.0f - c) + (z * s);
  RotationMatrix[2] = (z * x) * (1.0f - c) - (y * s);

  RotationMatrix[3] = (x * y) * (1.0f - c) - (z * s);
  RotationMatrix[4] = (y * y) * (1.0f - c) + c;
  RotationMatrix[5] = (z * y) * (1.0f - c) + (x * s);

  RotationMatrix[6] = (x * z) * (1.0f - c) + (y * s);
  RotationMatrix[7] = (y * z) * (1.0f - c) - (x * s);
  RotationMatrix[8] = (z * z) * (1.0f - c) + c;
} 
