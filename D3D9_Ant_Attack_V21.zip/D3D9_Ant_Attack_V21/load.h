#ifndef LOAD
#define LOAD

#include <stdio.h>

class Load
{
	FILE	*fileopen;
public:
	void	Setup();
	~Load();
	unsigned long Model(const char *, const unsigned long);
	bool Texture(const char *, const unsigned long);
};

#endif
