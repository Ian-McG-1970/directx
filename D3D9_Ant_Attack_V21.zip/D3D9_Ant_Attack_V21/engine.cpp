#include <math.h>
#include <stdio.h>
#include "engine.h"
#include "d3d8_screen.h"
#include "di_mouse.h"
#include "map.h"

extern HWND hwnd;
extern Mouse mouse;
extern Map map;
extern Screen screen;

extern FILE *file;

unsigned long objects_drawn, triangles_drawn, vertices_drawn;

const void Engine::StartPos(D3DXVECTOR3 &location)
{
//	do
	{
		location.x=rand() &(MAP_SIZE-1);
		location.y=rand() &(MAP_SIZE-1);
		location.z=rand() &(MAP_SIZE-1);
	} //while (map.ReturnBlock(location)!=0);
}

const void Engine::Setup()
{
	fprintf(file,"engine setup\n");

	StartPos(Location);
	Direction=D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	BoundingBox=D3DXVECTOR3(1.1f, 1.1f, 1.1f);
	Speed=0.0f;
}

Engine::~Engine()
{
	fprintf(file,"engine shutdown\n");
}

const void Engine::Move2(D3DXVECTOR3 &location, const D3DXVECTOR3 &direction, const float speed, const D3DXVECTOR3 &bounding_box)
{
	D3DXMATRIX  matTmp;
	const D3DXVECTOR3 viewDir(0.0f, 0.0f, 1.0f);
	D3DXVECTOR4 tmp;
	D3DXMatrixRotationYawPitchRoll(&matTmp, direction.y, direction.x, direction.z);      
	D3DXVec3Transform(&tmp, &viewDir, &matTmp);

	D3DXVECTOR3 test1, test2, test3, test4;

	const float speed_x=tmp.x*speed;
	const float location_x=location.x+speed_x;
	if (speed_x<0)
	{
		test1=D3DXVECTOR3(location_x-bounding_box.x, location.y-bounding_box.y, location.z-bounding_box.z);
		test2=D3DXVECTOR3(location_x-bounding_box.x, location.y+bounding_box.y, location.z-bounding_box.z);
		test3=D3DXVECTOR3(location_x-bounding_box.x, location.y-bounding_box.y, location.z+bounding_box.z);
		test4=D3DXVECTOR3(location_x-bounding_box.x, location.y+bounding_box.y, location.z+bounding_box.z);
//		if ((map.ReturnBlock(test1)==0) && (map.ReturnBlock(test2)==0) && (map.ReturnBlock(test3)==0) && (map.ReturnBlock(test4)==0))
		{
			location.x=location_x;
		}
	}
	else if (speed_x>0)
	{
		test1=D3DXVECTOR3(location_x+bounding_box.x, location.y-bounding_box.y, location.z-bounding_box.z);
		test2=D3DXVECTOR3(location_x+bounding_box.x, location.y+bounding_box.y, location.z-bounding_box.z);
		test3=D3DXVECTOR3(location_x+bounding_box.x, location.y-bounding_box.y, location.z+bounding_box.z);
		test4=D3DXVECTOR3(location_x+bounding_box.x, location.y+bounding_box.y, location.z+bounding_box.z);
//		if ((map.ReturnBlock(test1)==0) && (map.ReturnBlock(test2)==0) && (map.ReturnBlock(test3)==0) && (map.ReturnBlock(test4)==0))
		{
			location.x=location_x;
		}
	}

	const float speed_y=tmp.y*speed;
	const float location_y=location.y+speed_y;
	if (speed_y<0)
	{
		test1=D3DXVECTOR3(location.x-bounding_box.x, location_y-bounding_box.y, location.z-bounding_box.z);
		test2=D3DXVECTOR3(location.x+bounding_box.x, location_y-bounding_box.y, location.z-bounding_box.z);
		test3=D3DXVECTOR3(location.x+bounding_box.x, location_y-bounding_box.y, location.z+bounding_box.z);
		test4=D3DXVECTOR3(location.x-bounding_box.x, location_y-bounding_box.y, location.z+bounding_box.z);
//		if ((map.ReturnBlock(test1)==0) && (map.ReturnBlock(test2)==0) && (map.ReturnBlock(test3)==0) && (map.ReturnBlock(test4)==0))
		{
			location.y=location_y;
		}
	}
	else if (speed_y>0)
	{
		test1=D3DXVECTOR3(location.x-bounding_box.x, location_y+bounding_box.y, location.z-bounding_box.z);
		test2=D3DXVECTOR3(location.x+bounding_box.x, location_y+bounding_box.y, location.z-bounding_box.z);
		test3=D3DXVECTOR3(location.x+bounding_box.x, location_y+bounding_box.y, location.z+bounding_box.z);
		test4=D3DXVECTOR3(location.x-bounding_box.x, location_y+bounding_box.y, location.z+bounding_box.z);
//		if ((map.ReturnBlock(test1)==0) && (map.ReturnBlock(test2)==0) && (map.ReturnBlock(test3)==0) && (map.ReturnBlock(test4)==0))
		{
			location.y=location_y;
		}
	}

	const float speed_z=tmp.z*speed;
	const float location_z=location.z+speed_z;
	if (speed_z<0)
	{
		test1=D3DXVECTOR3(location.x-bounding_box.x, location.y-bounding_box.y, location_z-bounding_box.z);
		test2=D3DXVECTOR3(location.x+bounding_box.x, location.y-bounding_box.y, location_z-bounding_box.z);
		test3=D3DXVECTOR3(location.x+bounding_box.x, location.y+bounding_box.y, location_z-bounding_box.z);
		test4=D3DXVECTOR3(location.x-bounding_box.x, location.y+bounding_box.y, location_z-bounding_box.z);
//		if ((map.ReturnBlock(test1)==0) && (map.ReturnBlock(test2)==0) && (map.ReturnBlock(test3)==0) && (map.ReturnBlock(test4)==0))
		{
			location.z=location_z;
		}
	}
	else if (speed_z>0)
	{
		test1=D3DXVECTOR3(location.x-bounding_box.x, location.y-bounding_box.y, location_z+bounding_box.z);
		test2=D3DXVECTOR3(location.x+bounding_box.x, location.y-bounding_box.y, location_z+bounding_box.z);
		test3=D3DXVECTOR3(location.x+bounding_box.x, location.y+bounding_box.y, location_z+bounding_box.z);
		test4=D3DXVECTOR3(location.x-bounding_box.x, location.y+bounding_box.y, location_z+bounding_box.z);
//		if ((map.ReturnBlock(test1)==0) && (map.ReturnBlock(test2)==0) && (map.ReturnBlock(test3)==0) && (map.ReturnBlock(test4)==0))
		{
			location.z=location_z;
		}
	}
}

const void Engine::Move(D3DXVECTOR3 &location, const D3DXVECTOR3 &direction, const float speed)
{
	D3DXMATRIX  matTmp;
	D3DXMatrixRotationYawPitchRoll(&matTmp, direction.y, direction.x, direction.z);      
	D3DXVECTOR4 tmp;
	const D3DXVECTOR3 viewDir(0.0f, 0.0f, 1.0f);
	D3DXVec3Transform(&tmp, &viewDir, &matTmp);

	const float location_x = location.x + (tmp.x*speed);
	const float location_y = location.y + (tmp.y*speed);
	const float location_z = location.z + (tmp.z*speed);
	if (map.GetBlock(location_x,location.z,location.y)==0) location.x=location_x;
	if (map.GetBlock(location.x,location_z,location.y)==0) location.z=location_z;
	if (map.GetBlock(location.x,location.z,location_y)==0) location.y=location_y;
}

const void Engine::DrawMap(const D3DXVECTOR3 &location)
{
	const long lx=(location.x/(MAP_PATCH_SIZE*SCALE));
	const long ly=(location.y/(MAP_PATCH_SIZE*SCALE));
	const long lz=(location.z/(MAP_PATCH_SIZE*SCALE));

	for (unsigned long d=0; d!=map.DrawOrderCount; ++d)
	{
		const long px=lx+map.DrawOrder[d].x;
		const long py=ly+map.DrawOrder[d].y;
		const long pz=lz+map.DrawOrder[d].z;
		if ((px>=0) && (px<MAP_PATCH_COUNT) && (py>=0) && (py<MAP_PATCH_COUNT) && (pz>=0) && (pz<MAP_PATCH_COUNT))
		{
			const unsigned long model=map.Patch[px][py][pz].Model;
			if (screen.BoundingBoxInFrustum(&screen.Model[model].Bounding_Box[0], map.Patch[px][py][pz].Location)==true)
			{
				screen.DrawStaticObject(map.Patch[px][py][pz].Location, model);
				++objects_drawn;
				triangles_drawn+=screen.Model[model].Triangles;
				vertices_drawn+=screen.Model[model].Vertices;
			}
		}
	}
}

const void Engine::Input(D3DXVECTOR3 &direction, float &speed, const float dampen)
{
	mouse.Update();
	if (mouse.LB!=0 && mouse.RB!=0)
	{
		PostMessage(hwnd, WM_CLOSE, 0, 0);
		return;
	}
	if (mouse.LB==0 && mouse.RB==0)
	{
		direction.x -= mouse.Y*dampen;
		direction.y += mouse.X*dampen;
	}
	if (mouse.RB!=0)
	{
		direction.z -= mouse.X*dampen;
	}
	if (mouse.LB!=0)
	{
		speed -= mouse.Y*dampen;
	}
	speed*=0.9999f;
}

const void Engine::Update()
{
	objects_drawn=triangles_drawn=vertices_drawn=0;
	screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, BACKGROUND, 1.0f, 0);

	Input(Direction, Speed, 0.0003f);
	Move2(Location, Direction, Speed, BoundingBox);
	screen.View_Matrix(&Location, &Direction);

	screen.g_pd3dDevice->BeginScene();
	DrawMap(Location);

	sprintf(screen.string, "px %5.2f py %5.2f pz %5.2f od %6ld td %6ld vd %6ld m %1ld\n", Location.x, Location.y, Location.z, objects_drawn, triangles_drawn, vertices_drawn, map.ReturnBlock(Location));
	screen.DrawText(5, 5, D3DXCOLOR(0, 127, 127, 127));

	screen.g_pd3dDevice->EndScene();
	screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
}
