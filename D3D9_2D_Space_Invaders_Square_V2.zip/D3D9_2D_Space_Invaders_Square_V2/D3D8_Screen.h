#include <d3d9.h>
#include <d3dx9.h>

#ifndef D3D_SCREEN
#define D3D_SCREEN

enum
{
	MAX_VERTEX=1024*6,
	MAX_VERTEX_BUFFER=8,
};

#define SCREEN_FORMAT D3DFMT_A8R8G8B8

typedef struct
{
	D3DXVECTOR4 Position;
	D3DCOLOR Colour;
} TL_VERTEX;
#define D3DFVF_TL_VERTEX (D3DFVF_XYZRHW | D3DFVF_DIFFUSE)
    
typedef struct
{
	D3DXVECTOR2 Position;
	D3DXVECTOR2 Size;
	D3DCOLOR Colour;
} DisplayObject;
             
class Screen
{
private:
	const void Draw_Sprite(const D3DXVECTOR2 &, const D3DXVECTOR2 &, const D3DCOLOR);
	const void Draw_Primitive();
	const void Draw_Primitive_Forced();
	const void Lock_Vertex_Buffer();
	LPDIRECT3D9	g_pD3D;
	LPDIRECT3DVERTEXBUFFER9 TL_Vertex_Buffer[MAX_VERTEX_BUFFER];
	LPD3DXFONT Font;
	int Vertex_Count;
	int Triangle_Count;
	int Vertex_Buffer_Count;
	TL_VERTEX* Vertex_Buffer;
public:
	const bool Setup(const int, const int, const D3DFORMAT, const int, const HWND);
	~Screen();
	const void Draw_Objects(const DisplayObject *, const int);
	const void DrawText(const int, const int, const D3DCOLOR, const char *);
	char string[255];
	LPDIRECT3DDEVICE9	g_pd3dDevice;
	D3DXVECTOR2 Size;
};


#endif