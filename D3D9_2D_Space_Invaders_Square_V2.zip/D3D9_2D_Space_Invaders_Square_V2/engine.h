#ifndef ENGINE
#define ENGINE

#include "d3d8_screen.h"

typedef struct
{
	D3DXVECTOR2 Position;
	D3DXVECTOR2 Direction;
	D3DXVECTOR2 Size;
	D3DCOLOR Colour;
	int Energy;
} Object;

#define PLAYER_SPRITE 0
#define BULLET_SPRITE 1
#define PLAYER_SIZE 16
#define ENEMY_SIZE 8
#define BULLET_SIZE 4
#define PLAYER_BULLET_POS PLAYER_SIZE/2
#define ENEMY_BULLET_POS ENEMY_SIZE/2

#define MAX_OBJECT 1024

class Engine
{
private:
	Object Player[2];
	int PlayerCount;
	Object Enemy[MAX_OBJECT];
	int EnemyCount;
	Object EnemyBullet[MAX_OBJECT];
	int EnemyBulletCount;
	Object PlayerBullet[MAX_OBJECT];
	int PlayerBulletCount;
	Object Wall[MAX_OBJECT];
	int WallCount;
	int AICount;
	int Frame;
	DisplayObject DisplayObjects[MAX_OBJECT*4];
	int DisplayObjectCount;
	const bool Collision(const D3DXVECTOR2 &, const D3DXVECTOR2 &, const D3DXVECTOR2 &, const D3DXVECTOR2 &);
	const bool On_Screen(const Object &);
	const void Draw_Object(const D3DXVECTOR2 &, const D3DXVECTOR2 &, const D3DCOLOR);
	const void Input(Object &, const float);
	const void Draw_Objects(const Object *, const int);
	const void Add_Object(const D3DXVECTOR2 &, const D3DXVECTOR2 &, const D3DCOLOR, const int, const D3DXVECTOR2 &, Object *, int&);
	const void Remove_Object(const int, Object *, int&);
	const void Move_Objects(Object *, int&, const float);
	const void AI(Object *, int&, int&);
	const void InertiaMove(Object &, const D3DXVECTOR2 &, const float, const float, const float, const float);
	const float InertiaMovement(const float, const float, const float, const float, const float);
	const bool Remove(Object &, const int);

	const void (Engine::*CollidePtr) (Object &);
	const void (Engine::*NoCollidePtr) (Object &);
	const void Collide(Object &);
	const void NoCollide(Object &);

	const void CheckCollisions(Object *, int&, const int, Object *, int&, const int, const void (Engine::*)(Object &));

public:
	const void Setup();
	~Engine();
	const void Update();
};

#endif
