#include "stdlib.h"
#include "time.h"

#include "d3d8_screen.h"
#include "load.h"
#include "map.h"

extern Screen screen;
extern Load load;
extern FILE *file;

const void Map::Setup()
{
	fprintf(file,"map setup\n");

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(255, 0, 0), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
	Generate();

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 255, 0), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
	FractalSetup(rand());

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(255, 0, 0), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
	ReSize();

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 255, 0), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
BuildDrawOrder(((((MAP_DIST+ (PATCH_SIZE*2 / 1024)) / (PATCH_SIZE / 1024)) +1) *2)+1);

time_t c_time;
time(&c_time);
fprintf(file, "builddraworder %s\n", ctime(&c_time));

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 0, 255), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
	Build();

time(&c_time);
fprintf(file, "build %s\n", ctime(&c_time));

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 0, 255), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
	ReBuild();
	Scale();

time(&c_time);
fprintf(file, "rebuild %s\n", ctime(&c_time));

}

Map::~Map()
{
	fprintf(file,"map shutdown\n");
}

const void Map::FractalSetup(const int seed)
{
	srand(seed);
	for (int inc=MAP_SIZE>>1, loop=2; inc!=1; inc=inc>>1, loop+=loop)
	{
		for (int x=0, xs=0; x!=loop; ++x, xs+=inc)
		{
			for (int y=0, ys=0; y!=loop; ++y, ys+=inc)
			{
				Fractal(xs,ys,xs+inc,ys+inc);
			}
		}
	}
}

const void Map::Fractal(const int sx, const int sy, const int ex, const int ey)
{
	const int mx=(sx+ex)>>1;
	const int my=(sy+ey)>>1;

	const int sxp=sx &(MAP_SIZE-1);
	const int syp=sy &(MAP_SIZE-1);
	const int mxp=mx &(MAP_SIZE-1);
	const int myp=my &(MAP_SIZE-1);
	const int exp=ex &(MAP_SIZE-1);
	const int eyp=ey &(MAP_SIZE-1);

	const float top_left=Detail[sxp][syp];
	const float top_right=Detail[sxp][eyp];
	const float bottom_left=Detail[exp][syp];
	const float bottom_right=Detail[exp][eyp];

	const float top_max=max(top_left, top_right);
	const float bottom_max=max(bottom_left, bottom_right);
	const float left_max=max(top_left, bottom_right);
	const float right_max=max(top_right, bottom_right);

	float middle_max=max(top_max, bottom_max);
	middle_max=max(bottom_max, middle_max);
	middle_max=max(left_max, middle_max);
	middle_max=max(right_max, middle_max);

	const float middle=(top_left+top_right+bottom_right+bottom_left)*0.25f;
	const float top=(top_left+top_right)*0.5f;
	const float bottom=(bottom_left+bottom_right)*0.5f;
	const float left=(top_left+bottom_left)*0.5f;
	const float right=(top_right+bottom_right)*0.5f;

	const int middle_diff=labs(middle_max-middle);
	const int top_diff=labs(top_max-top);
	const int bottom_diff=labs(bottom_max-bottom);
	const int left_diff=labs(left_max-left);
	const int right_diff=labs(right_max-right);

	Detail[mxp][myp]=middle +(rand() %(middle_diff+1)) -(middle_diff>>1);
	Detail[sxp][myp]=top +(rand() %(top_diff+1)) -(top_diff>>1);
	Detail[exp][myp]=bottom +(rand() %(bottom_diff+1)) -(bottom_diff>>1);
	Detail[mxp][syp]=left +(rand() %(left_diff+1)) -(left_diff>>1);
	Detail[mxp][eyp]=right +(rand() %(right_diff+1)) -(right_diff>>1);
}

const void Map::Generate()
{
	for (int x=0; x!=MAP_SIZE; ++x)
	{
		for (int y=0; y!=MAP_SIZE; ++y)
		{
			Detail[x][y]=rand() &255;
		}
	}
}

const float Map::Height2(const D3DXVECTOR3 &location)
{
	const int map_tile_x = location.x / PATCH_SIZE;
	const int map_tile_z = location.z / PATCH_SIZE;
	return Detail[map_tile_x][map_tile_z];
}

const void Map::AddDrawOrder(const int x, const int y)
{
	for (int c=0; c!=DrawOrderCount; ++c)
	{
		if ((DrawOrder[c].x==x) && (DrawOrder[c].y==y))
	 {
			return;
		}
	}
	++DrawOrderCount;
	DrawOrder[DrawOrderCount].x=x;
	DrawOrder[DrawOrderCount].y=y;
	DrawOrder[DrawOrderCount].mx=x*PATCH_SIZE;
	DrawOrder[DrawOrderCount].my=y*PATCH_SIZE;
	DrawOrder[DrawOrderCount].lod = sqrt(abs(x*x) + abs(y*y));
	DrawOrder[DrawOrderCount].lod /= 3;
	if (DrawOrder[DrawOrderCount].lod == PATCH_LOD) { fprintf(file, "bdo error\n"); DrawOrder[DrawOrderCount].lod = PATCH_LOD - 1; }
	fprintf(file, "bdo %i %i %i %i\n", DrawOrderCount, DrawOrder[DrawOrderCount].x, DrawOrder[DrawOrderCount].y, DrawOrder[DrawOrderCount].lod);
}

const void Map::BuildDrawOrder(const int patch_end)
{
	fprintf(file, "bdo %i\n", patch_end);
	DrawOrderCount=0;
	const int distance=(patch_end-1)>>1;
	AddDrawOrder(0, 0);
	for (int d=0; d!=distance; ++d)
	{
		for (int x=0; x!=d; ++x)
		{
			for (int y=0; y!=d; ++y)
			{
				if ((sqrtf( (x*x)+(y*y) )) > (float)distance) continue;
				AddDrawOrder(x, y);
				AddDrawOrder(x, -y);
				AddDrawOrder(-x, y);
				AddDrawOrder(-x, -y);
			}
		}
	}
}

const int Map::Bitmap(const float ttl, const float tl, const float tll, const float ttr, const float tr, const float trr, const float bbl, const float bl, const float bll, const float bbr, const float br, const float brr)
{
	for (int a=0; a!=bm; ++a)
	{
		if ( (diff_array[a].TopTopLeft == ttl) && (diff_array[a].TopLeft == tl) && (diff_array[a].TopLeftLeft == tll)
			&& (diff_array[a].TopTopRight == ttr) && (diff_array[a].TopRight == tr) && (diff_array[a].TopRightRight == trr)
			&& (diff_array[a].BottomBottomLeft == bbl) && (diff_array[a].BottomLeft == bl) && (diff_array[a].BottomLeftLeft == bll)
			&& (diff_array[a].BottomBottomRight == bbr) && (diff_array[a].BottomRight == br) && (diff_array[a].BottomRightRight == brr) )
		{
			return a;
		}
	}
	diff_array[bm].TopTopLeft = ttl;
	diff_array[bm].TopLeft = tl;
	diff_array[bm].TopLeftLeft = tll;
	diff_array[bm].TopTopRight = ttr;
	diff_array[bm].TopRight = tr;
	diff_array[bm].TopRightRight = trr;
	diff_array[bm].BottomBottomRight = bbr;
	diff_array[bm].BottomRight = br;
	diff_array[bm].BottomRightRight = brr;
	diff_array[bm].BottomBottomLeft = bbl;
	diff_array[bm].BottomLeft = bl;
	diff_array[bm].BottomLeftLeft = bll;
//	fprintf(file, "bm %i %i %i %i %i %i %i %i %i %i %i %i %i\n", bm, diff_array[bm].TopTopLeft, diff_array[bm].TopLeft, diff_array[bm].TopLeftLeft, diff_array[bm].TopTopRight, diff_array[bm].TopRight, diff_array[bm].TopRightRight, diff_array[bm].BottomBottomRight, diff_array[bm].BottomRight, diff_array[bm].BottomRightRight, diff_array[bm].BottomBottomLeft, diff_array[bm].BottomLeft, diff_array[bm].BottomLeftLeft);
	++bm;
	return bm - 1;
}

const void Map::Build()
{
	bm = 0;
	for (int x = 0; x != MAP_SIZE; ++x)
	{
		const int px = (x - 1)  &(MAP_SIZE - 1);
		const int nx = (x + 1)  &(MAP_SIZE - 1);
		const int nnx = (nx + 1)  &(MAP_SIZE - 1);
		for (int y = 0; y != MAP_SIZE; ++y)
		{
			const int py = (y - 1)  &(MAP_SIZE - 1);
			const int ny = (y + 1)  &(MAP_SIZE - 1);
			const int nny = (ny + 1)  &(MAP_SIZE - 1);

			const float ttl = Detail[x][py]; //[px][y];
			const float tl = Detail[x][y]; //[x][y;
			const float tll = Detail[px][y]; //[x][py];

			const float bbl = Detail[x][nny]; //[nnx][y];
			const float bl = Detail[x][ny]; //[nx][y];
			const float bll= Detail[px][ny]; //[nx][py];

			const float ttr = Detail[nx][py]; //[px][ny];
			const float tr = Detail[nx][y]; //[x][ny];
			const float trr = Detail[nnx][y]; //[x][nny];

			const float bbr = Detail[nx][nny]; //[nnx][ny];
			const float br= Detail[nx][ny]; //[nx][ny];
			const float brr = Detail[nnx][ny]; //[nx][nny];

			const float tltl= tl - tl;
			const float tltr= tr - tl;
			const float tlbr= br - tl;
			const float tlbl= bl - tl;

			const float ttltl = ttl - tl;
			const float tlltl = tll - tl;

			const float ttrtr = ttr - tl;
			const float trrtr = trr - tl;

			const float bblbl = bbl - tl;
			const float bllbl = bll - tl;

			const float bbrbr = bbr - tl;
			const float brrbr = brr - tl;

			type[x][y] = Bitmap(ttltl, tltl, tlltl, ttrtr, tltr, trrtr, bblbl, tlbl, bllbl, bbrbr, tlbr, brrbr);
//fprintf(file,"type x %i y %i t %i\n",x,y,type[x][y]);
		}
	}
}

const void Map::ReBuild()
{
	for (int a=0; a!=bm; ++a)
	{
		const CORNER corner = diff_array[a];
		BuildPatch2(corner.TopTopLeft *MAP_SCALE, corner.TopTopRight *MAP_SCALE, corner.TopLeftLeft *MAP_SCALE, corner.TopLeft *MAP_SCALE, corner.TopRight *MAP_SCALE, corner.TopRightRight *MAP_SCALE, corner.BottomLeftLeft *MAP_SCALE, corner.BottomLeft *MAP_SCALE, corner.BottomRight *MAP_SCALE, corner.BottomRightRight *MAP_SCALE, corner.BottomBottomLeft *MAP_SCALE, corner.BottomBottomRight *MAP_SCALE);

		memcpy(&screen.Vertex[0], &load.Vertex[0][0], sizeof(screen.Vertex[0])*load.Vertex_Count[0]);
		Build_Patch(0);
		memcpy(&screen.Index[0], &load.Index[0][0], sizeof(screen.Index[0])*load.Index_Count[0] * 3);
		Patch[0][a].Model = screen.CreateObject_Normal_Optimise(load.Vertex_Count[0], load.Index_Count[0]);

		Build_Patch(1);
		memcpy(&screen.Index[0], &load.Index[1][0], sizeof(screen.Index[0])*load.Index_Count[1] * 3);
		Patch[1][a].Model = screen.CreateObject_Normal_Optimise(load.Vertex_Count[1], load.Index_Count[1]);

		Build_Patch(2);
		memcpy(&screen.Index[0], &load.Index[2][0], sizeof(screen.Index[0])*load.Index_Count[2] * 3);
		Patch[2][a].Model = screen.CreateObject_Normal_Optimise(load.Vertex_Count[2], load.Index_Count[2]);

		Build_Patch(3);
		memcpy(&screen.Index[0], &load.Index[3][0], sizeof(screen.Index[0])*load.Index_Count[3] * 3);
		Patch[3][a].Model = screen.CreateObject_Normal_Optimise(load.Vertex_Count[3], load.Index_Count[3]);

		Build_Patch(4);
		memcpy(&screen.Index[0], &load.Index[4][0], sizeof(screen.Index[0])*load.Index_Count[4] * 3);
		Patch[4][a].Model = screen.CreateObject_Normal_Optimise(load.Vertex_Count[4], load.Index_Count[4]);
	}
	fprintf(file, "bm %i\n", bm);

	for (int x=0; x!=MAP_SIZE; ++x)
	{
		for (int y=0; y!=MAP_SIZE; ++y)
		{
			Patch_Grid[x][y][0].Model = Patch[0][type[x][y]].Model;
			Patch_Grid[x][y][1].Model = Patch[1][type[x][y]].Model;
			Patch_Grid[x][y][2].Model = Patch[2][type[x][y]].Model;
			Patch_Grid[x][y][3].Model = Patch[3][type[x][y]].Model;
			Patch_Grid[x][y][4].Model = Patch[4][type[x][y]].Model;
		}
	}
}

const void Map::ReSize()
{
	float lowest=Detail[0][0], highest=Detail[0][0];
	for (int x=0; x!=MAP_SIZE; ++x)
	{
		for (int y=0; y!=MAP_SIZE; ++y)
		{
			lowest = min(lowest, Detail[x][y]);
			highest = max(highest, Detail[x][y]);
		}
	}
	highest -= lowest;
	for (int x=0; x!=MAP_SIZE; ++x)
	{
		for (int y=0; y!=MAP_SIZE; ++y)
		{
			Detail[x][y] -= lowest;
		}
	}
	const float ratio = MAP_HIGHEST / (highest);
	for (int x=0; x!=MAP_SIZE; ++x)
	{
		for (int y=0; y!=MAP_SIZE; ++y)
		{
			Detail[x][y] *= ratio;
			Detail[x][y] = (int)Detail[x][y];
		}
	}
}

const void Map::Scale()
{
	for (int x = 0; x != MAP_SIZE; ++x)
	{
		for (int y = 0; y != MAP_SIZE; ++y)
		{
			Detail[x][y] *= MAP_SCALE;
		}
	}
}

const void Map::BuildPatch2(const float p0, const float p1, const float p2, const float p3, const float p4, const float p5, const float p6, const float p7, const float p8, const float p9, const float p10, const float p11)
{
	FractalLineSetup2(0, POINTS_IN_PATCH, p2, p3, p4, p5, &patch1[0][0]);
	FractalLineSetup2(0, POINTS_IN_PATCH, p6, p7, p8, p9, &patch1[POINTS_IN_PATCH - 1][0]);
	float output2[POINTS_IN_PATCH];
	FractalLineSetup2(0, POINTS_IN_PATCH, p0, p3, p7, p10, &output2[0]);
	PatchSwap(0, &output2[0]);
	FractalLineSetup2(0, POINTS_IN_PATCH, p1, p4, p8, p11, &output2[0]);
	PatchSwap(POINTS_IN_PATCH - 1, &output2[0]);

	for (int x = 1; x != POINTS_IN_PATCH - 1; ++x)
	{
		const float x_ratio = (patch1[x][POINTS_IN_PATCH - 1] - patch1[x][0]) / (float)(POINTS_IN_PATCH - 1);
		for (int y = 1; y != POINTS_IN_PATCH - 1; ++y)
		{
			const float y_ratio = (patch1[POINTS_IN_PATCH - 1][y] - patch1[0][y]) / (float)(POINTS_IN_PATCH - 1);
			patch1[x][y] = ((patch1[x][0] + (x_ratio*y)) + (patch1[0][y] + (y_ratio*x))) * 0.5f;
		}
	}

	for (int i=1, number = LinearCongruentialGeneratorSeed(BuildEdge(p2, p3, p4, p5), 128); i!=64; ++i) output2[i] = number = LinearCongruentialGenerator(number, 17, 44, 128);
	for (int y=1; y!= POINTS_IN_PATCH-1; ++y) patch1[0][y] = (patch1[0][y] + output2[y])/**0.5f*/;

	for (int i=1, number = LinearCongruentialGeneratorSeed(BuildEdge(p6, p7, p8, p9), 128); i != 64; ++i) output2[i] = number = LinearCongruentialGenerator(number, 17, 44, 128);
	for (int y=1; y!=POINTS_IN_PATCH-1; ++y) patch1[POINTS_IN_PATCH - 1][y] = (patch1[POINTS_IN_PATCH - 1][y] + output2[y]) /**0.5f*/;

	for (int i = 1, number = LinearCongruentialGeneratorSeed(BuildEdge(p0, p3, p7, p10), 128); i != 64; ++i) output2[i] = number = LinearCongruentialGenerator(number, 17, 44, 128);
	for (int y = 1; y != POINTS_IN_PATCH - 1; ++y) patch1[y][0] = (patch1[y][0] + output2[y])/**0.5f*/;

	for (int i = 1, number = LinearCongruentialGeneratorSeed(BuildEdge(p1, p4, p8, p11), 128); i != 64; ++i) output2[i] = number = LinearCongruentialGenerator(number, 17, 44, 128);
	for (int y = 1; y != POINTS_IN_PATCH - 1; ++y) patch1[y][POINTS_IN_PATCH - 1] = (patch1[y][POINTS_IN_PATCH - 1] + output2[y]) /**0.5f*/;

	for (int x = 1, number = LinearCongruentialGeneratorSeed(rand(), 128); x != POINTS_IN_PATCH - 1; ++x)
	{
		for (int y = 1; y != POINTS_IN_PATCH - 1; ++y)
		{
			number = LinearCongruentialGeneratorSeed(rand(), 128);
//				LinearCongruentialGenerator(number, 17, 44, 128);
			patch1[x][y] = (patch1[x][y] + number) /**0.5f*/;
		}
	}
//	FractalLineSetup2(0, POINTS_IN_PATCH, (p0, p3, p7, p10), &output2[0]);
//	PatchSwap(0, &output2[0]);
//	FractalLineSetup2(0, POINTS_IN_PATCH, (p1, p4, p8, p11), &output2[0]);
//	PatchSwap(POINTS_IN_PATCH - 1, &output2[0]);

}

const int Map::LinearCongruentialGeneratorSeed(const int constant_c, const int modulate_m)
{
	return constant_c % modulate_m;
}

const int Map::LinearCongruentialGenerator(const int number, const int multiplication_factor_a, const int constant_c, const int modulate_m)
{
	return ((number * multiplication_factor_a) + constant_c) % modulate_m;
}

const void Map::FractalLineSetup2(const int start, const int end, const float pos0, const float pos1, const float pos2, const float pos3, float *output)
{
	const D3DXVECTOR2 p0 = D3DXVECTOR2(pos0, end * 0);
	const D3DXVECTOR2 p1 = D3DXVECTOR2(pos1, end * 1);
	const D3DXVECTOR2 p2 = D3DXVECTOR2(pos2, end * 2);
	const D3DXVECTOR2 p3 = D3DXVECTOR2(pos3, end * 3);

//	fprintf(file, "fls %f %f %f %f\n", pos0, pos1, pos2, pos3);

	for (int i = 0; i != (end); ++i)
	{
		const float p = (float)i / (float)(end-1);
		D3DXVECTOR2 pos;
		D3DXVec2CatmullRom(&pos, &p0, &p1, &p2, &p3, p);
		output[i] = pos.x;
//		fprintf(file, "%i %f\n", i, output[i]);
	}
}

const void Map::PatchSwap(const int x, const float * input)
{
	for (int p = 0; p != POINTS_IN_PATCH; ++p)
	{
		patch1[p][x] = input[p];
	}
}

const void Map::Build_Patch(const int lod)
{
	for (int v=0, x=0; x != POINTS_IN_PATCH; ++x)
	{
		for (int y = 0; y != POINTS_IN_PATCH; ++y, ++v)
		{
			screen.Vertex[v].Location = D3DXVECTOR3(load.Vertex[lod][v].Location.x, patch1[y][x], load.Vertex[lod][v].Location.z);
		}
	}
}

/*int output[1024];
const int start = 0;
const int end = 128;
const int top_start = (rand() & 63) + 64;
const int bottom_start = (rand() & 63) + 64;

FractalLineSetup(start, end, top_start, bottom_start, top_start + bottom_start + start + end, &output[0]);

for (int x = 0; x != end - 1; ++x)
{
	Line(SetVector((x * 3) + 0, output[x]), SetVector((x * 3) + 3, output[x + 1]), 0x0ffffff);
}
*/
const void Map::FractalLine(const int start, const int end, const int seed, float *output)
{
	fprintf(file, "fl ses %i %i %i\n", start, end, seed);
	if ((start + 1) == end) return;
	const int middle = (start + end) >> 1;
	const int maxseed = end - start - 1;
	output[middle] = ((int) (output[start] + output[end]) >> 1) + ((seed &(maxseed)) - (maxseed >> 1) *64);
	FractalLine(start, middle, output[start] + output[middle] + seed, &output[0]);
	FractalLine(middle, end, output[middle] + output[end] + seed, &output[0]);
}

const void Map::FractalLineSetup(const int start, const int end, const int startvalue, const int endvalue, const int seed, float *output)
{
	output[start] = startvalue;
	output[end] = endvalue;

	FractalLine(start, end, output[start] + output[end] + seed, &output[start]);
	float average = 0.0f;
	for (int c = start+1; c != end-1; ++c) average += output[c];
	average /= (end-1);
	for (int c = start+1; c != end-1; ++c) output[c]-=average;
}

const int Map::BuildEdge(const float e0, const float e1, const float e2, const float e3)
{
	for (int a = 0; a != em; ++a)
	{
		if ( (edge_array[a].E0 == e0) && (edge_array[a].E1 == e1) && (edge_array[a].E2 == e2) && (edge_array[a].E3==e3) )
		{
			return edge_rand[a];
		}
	}
	edge_array[em].E0 = e0;
	edge_array[em].E1 = e1;
	edge_array[em].E2 = e2;
	edge_array[em].E3 = e3;
	//	fprintf(file, "bm %i %i %i %i %i %i %i %i %i %i %i %i %i\n", bm, diff_array[bm].TopTopLeft, diff_array[bm].TopLeft, diff_array[bm].TopLeftLeft, diff_array[bm].TopTopRight, diff_array[bm].TopRight, diff_array[bm].TopRightRight, diff_array[bm].BottomBottomRight, diff_array[bm].BottomRight, diff_array[bm].BottomRightRight, diff_array[bm].BottomBottomLeft, diff_array[bm].BottomLeft, diff_array[bm].BottomLeftLeft);
	edge_rand[em] = (rand() & 63) *64;
	++em;
	return edge_rand[em - 1];
}

