#ifndef LOAD
#define LOAD

#include <stdio.h>
#include "d3d8_screen.h"

#define MAX_SIZE 8195
//#define UNUSED -1
typedef struct
{
	int X;
	int Y;
	int Point;
} POS;

typedef struct
{
	int X;
	int Y;
} PNT;

typedef struct
{
	int F;
	int S;
	int T;
} TRI;

class Load
{
	FILE	*fileopen;
	char rec[256];
private:
	POS Point[MAX_SIZE][MAX_SIZE];
	TRI Triangle[MAX_SIZE];
	int Size;
	const void AddTriangle(const int f, const int s, const int t);
	const int Model3(const int, const int, const int);
	const void Model2(const int, const int, const int);
	const int Model4();
	//	int VertexReIndex[MAX_SIZE];
public:
	int Points;
	int Triangles;
	const void	Setup();
	~Load();
	const void BuildLOD(const int);
	const int Model(const char *);
//	const void ReIndex(const int, const int);
	IM_VERTEX		Vertex[PATCH_LOD][MAX_VERTICES];
	WORD		Index[PATCH_LOD][MAX_VERTICES];
	int Vertex_Count[PATCH_LOD];
	int Index_Count[PATCH_LOD];

};

#endif
