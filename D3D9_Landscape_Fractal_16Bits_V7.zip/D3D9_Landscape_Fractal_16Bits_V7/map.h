#ifndef MAP
#define MAP

#include <stdio.h>

//todo
// - change corner to not include differences and use normal values
// - change points-in-patch to 33
// - change patch-size to 2048

#define MAP_SIZE 64 // patches across/down
#define PATCH_SIZE 4096 //2048 // each patch is (patch size) across
#define MAP_DETAIL_SIZE MAP_SIZE * PATCH_SIZE	// map size = GRID_SIZE*PASTCH_SIZE = 32000 * 32000
#define MAP_SCALE 4096 // 2048 scale by which map points are increased
#define MAP_HIGHEST 15.0 // maximum height of map point

#define MAP_DIST 48
#define POINTS_IN_PATCH 65

typedef struct
{
	int Model;
} BEZIER_PATCH;

typedef struct
{
	int x;
	int y;
	float mx;
	float my;
	int lod;
} DrawOrderLocation;

typedef struct
{
	float TopTopLeft;
	float TopLeft;
	float TopLeftLeft;
	float TopTopRight;
	float TopRight;
	float TopRightRight;
	float BottomBottomLeft;
	float BottomLeft;
	float BottomLeftLeft;
	float BottomBottomRight;
	float BottomRight;
	float BottomRightRight;
} CORNER;

typedef struct
{
	float E0;
	float E1;
	float E2;
	float E3;
} EDGE;

class Map
{
private:   
	float Rough[MAP_SIZE][MAP_SIZE];			// original map before smoothing	
	const void Generate();
	const void BuildDrawOrder(const int);
	const void AddDrawOrder(const int, const int);
	const void Fractal(const int, const int, const int, const int);
	const void FractalSetup(const int);
	const void Build();
	const int Bitmap(const float, const float, const float, const float, const float, const float, const float, const float, const float, const float, const float, const float);
	WORD type[MAP_SIZE][MAP_SIZE];
	const void ReSize();
	const void ReBuild();
	const void Scale();
	BEZIER_PATCH Patch[PATCH_LOD][MAP_SIZE*MAP_SIZE]; // patches to be drawn
	CORNER diff_array[MAP_SIZE*MAP_SIZE];
	int bm;
	EDGE edge_array[MAP_SIZE*MAP_SIZE];
	int edge_rand[MAP_SIZE*MAP_SIZE];
	int em;
	const void BuildPatch2(const float, const float, const float, const float, const float, const float, const float, const float, const float, const float, const float, const float);
	const void FractalLineSetup2(const int, const int, const float, const float, const float, const float, float *);
	const void PatchSwap(const int, const float *);
	float patch1[POINTS_IN_PATCH][POINTS_IN_PATCH];
	const void Build_Patch(const int);
	const void FractalLine(const int start, const int end, const int seed, float *output);
	const void FractalLineSetup(const int start, const int end, const int startvalue, const int endvalue, const int seed, float *output);
	const int BuildEdge(const float, const float, const float, const float);
	const int LinearCongruentialGeneratorSeed(const int, const int);
	const int LinearCongruentialGenerator(const int, const int, const int, const int);
public:
	float Detail[MAP_SIZE][MAP_SIZE];			// detail map used for collision after smoothing
	BEZIER_PATCH Patch_Grid[MAP_SIZE][MAP_SIZE][PATCH_LOD]; // patches to be drawn
	const float Height2(const D3DXVECTOR3&);
	const void Setup();
	~Map();
	DrawOrderLocation DrawOrder[MAP_SIZE*MAP_SIZE];
	int DrawOrderCount;
};

#endif
