#ifndef MAP
#define MAP

#define TRACK_PATCH_COUNT 128

typedef struct
{
	int Model;
	D3DXVECTOR3 Location;
	int Texture;
} ACTOR;

class Map
{
private:
public:
	const void Setup();
	~Map();
	ACTOR Track[TRACK_PATCH_COUNT];
	ACTOR Ground[MAX_MODELS];
	const void BuildTrack();
	const void BuildGround(const int);
	int TrackSections;
	int GroundSections;
};

#endif
