#include "engine.h"
#include "d3d8_screen.h"
#include "di_mouse.h"
#include "map.h"

extern HWND hwnd;
extern Mouse mouse;
extern Map map;
extern Screen screen;

extern FILE *file;

const void Engine::Setup()
{
	fprintf(file,"engine setup\n");

	Location=D3DXVECTOR3(1000.0f, 100.0f, 1000.0f);
//	Location=D3DXVECTOR3(10000.0f, 15000.0f, -5000.0f);
	Direction=D3DXVECTOR3(0.7f, 0.0f, 0.0f);
	Speed=0.0f;
	Roll=0.0f;
}

Engine::~Engine()
{
	fprintf(file,"engine shutdown\n");
}

const void Engine::Move(D3DXVECTOR3 &location, const D3DXVECTOR3 &direction, const float speed)
{
	D3DXMATRIX matTmp;
	D3DXMatrixRotationYawPitchRoll(&matTmp, direction.y, direction.x, direction.z);      
	D3DXVECTOR4 tmp;
	const D3DXVECTOR3 viewDir(0.0f, 0.0f, 1.0f);
	D3DXVec3Transform(&tmp, &viewDir, &matTmp);
	location += ((D3DXVECTOR3)(tmp)*speed);
}

const void Engine::Input(D3DXVECTOR3 &direction, float &speed)
{
	mouse.Update();

	if (mouse.LB!=0 && mouse.RB!=0)
	{
		PostMessage(hwnd, WM_CLOSE, 0, 0);
		return;
	}
	direction.x -= ((float)mouse.Y*0.00009f);
	Roll+=((float)mouse.X*0.000009f);
	direction.y+=Roll;
	direction.z-=Roll;
	if (mouse.RB!=0)
	{
		speed -=0.16f;
	}
	if (mouse.LB!=0)
	{
		speed +=0.33f;
	}
	speed*=0.999f;
	Roll*=0.95f;
	direction.z*=0.99f;
}

const void Engine::DrawActor(const ACTOR *actor, const int actors)
{
	for (int a=0; a!=actors; ++a)
	{
		const int model = actor[a].Model;
//		const D3DXVECTOR3 location = actor[a].Location + screen.Model[model].Bounding_Sphere_Centre;
		const D3DXVECTOR3 location = actor[a].Location;
		if ((screen.IsSphereInsideFrustum(location, screen.Model[model].Bounding_Sphere_Centre, screen.Model[model].Bounding_Sphere_Radius) == true)
			&& (screen.BoundingBoxInFrustum(&screen.Model[model].Bounding_Box[0], location) == true))
		{
			screen.DrawStaticObject(location, model, actor[a].Texture);
			++Count;
		}
	}
}

const void Engine::Update()
{
	screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, BACKGROUND, 1.0f, 0);

	Input(Direction, Speed);
	Move(Location, Direction, Speed);
	map.Ground[0].Location = D3DXVECTOR3(Location.x,Location.y-1.5f, Location.z);

	screen.View_Matrix(Location, Direction);

	Count=0;
	screen.g_pd3dDevice->BeginScene();

	screen.g_pd3dDevice->SetRenderState(D3DRS_ZENABLE, false);
	DrawActor(&map.Ground[0], map.GroundSections);

	screen.g_pd3dDevice->SetRenderState(D3DRS_ZENABLE, true);
	DrawActor(&map.Track[0], map.TrackSections);

	sprintf(screen.string, "px %5.2f %5.2f %5.2f %5.2f %5.2f %5.2f %5.2f %i\n", Location.x, Location.y, Location.z, Direction.x, Direction.y, Direction.z, Speed, Count);
	screen.DrawText(5, 5, D3DXCOLOR(0, 127, 127, 127));

	screen.g_pd3dDevice->EndScene();
	screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
}
