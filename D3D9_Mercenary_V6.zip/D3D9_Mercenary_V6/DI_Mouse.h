#ifndef DI_MOUSE
#define DI_MOUSE

#include <dinput.h>
#include <stdio.h>

class Mouse
{
private:
	LPDIRECTINPUT8 g_pdi;
	LPDIRECTINPUTDEVICE8 g_pMouse;
	DIMOUSESTATE dims;
	LPDIRECTINPUTDEVICE8 g_pKeyboard;
	BYTE DI_Keyboard[256];

public:
	int	X;
	int	Y;
	BYTE LB;
	BYTE RB;

	const bool Setup(const HINSTANCE, const HWND);
	const void Update();
	~Mouse();
};

#endif

