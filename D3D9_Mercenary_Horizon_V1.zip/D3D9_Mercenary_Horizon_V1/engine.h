#ifndef ENGINE
#define ENGINE

#include "d3d8_screen.h"
#include "map.h"
#include "object.h"

class Engine
{
private:
	float	Speed;
	D3DXVECTOR3 Location;
	D3DXVECTOR3 Direction;
	const void Move(D3DXVECTOR3 &, const D3DXVECTOR3 &, const float);
	const void Input(D3DXVECTOR3 &, float &, const float);
	const void DrawActor(const ACTOR *, const int);
	int Count;
	const D3DXVECTOR3 Rotate(const float ox,const float oy,const float oz,const float sinx,const float cosx,const float sinz,const float cosz); // rotate points about x/z axis
	const void DrawHorizon2D(const float pitch,const float roll);
	const void DrawHorizon3D(const float pitch,const float roll);
	const bool ClipLine(D3DXVECTOR2 &,D3DXVECTOR2 &, const D3DXVECTOR2 &);

public:
	const void Setup();
	~Engine();
	const void Update();
};

#endif

