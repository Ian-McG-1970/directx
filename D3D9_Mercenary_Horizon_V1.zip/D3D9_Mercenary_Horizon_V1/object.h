#ifndef OBJECT
#define OBJECT

const D3DCOLOR red[] = { D3DCOLOR_XRGB(145, 0, 0), D3DCOLOR_XRGB(255, 16, 16), D3DCOLOR_XRGB(255, 48, 48), D3DCOLOR_XRGB(255, 80, 80), D3DCOLOR_XRGB(255, 112, 112), D3DCOLOR_XRGB(255, 144, 144), D3DCOLOR_XRGB(255, 176, 176), D3DCOLOR_XRGB(255, 255, 255) };
const D3DCOLOR green[] = { D3DCOLOR_XRGB(0, 145, 0), D3DCOLOR_XRGB(16, 255, 16), D3DCOLOR_XRGB(48, 255, 48), D3DCOLOR_XRGB(80, 255, 80), D3DCOLOR_XRGB(112, 255, 112), D3DCOLOR_XRGB(144, 255, 144), D3DCOLOR_XRGB(176, 255, 176), D3DCOLOR_XRGB(255, 255, 255) };
const D3DCOLOR blue[] = { D3DCOLOR_XRGB(0, 0, 145), D3DCOLOR_XRGB(16, 16, 255), D3DCOLOR_XRGB(48, 48, 255), D3DCOLOR_XRGB(80, 80, 255), D3DCOLOR_XRGB(112, 112, 255), D3DCOLOR_XRGB(144, 144, 255), D3DCOLOR_XRGB(176, 176, 255), D3DCOLOR_XRGB(255, 255, 255) };
const D3DCOLOR grey[] = { D3DCOLOR_XRGB(145, 145, 145), D3DCOLOR_XRGB(16, 16, 16), D3DCOLOR_XRGB(48, 48, 48), D3DCOLOR_XRGB(80, 80, 80), D3DCOLOR_XRGB(112, 112, 112), D3DCOLOR_XRGB(144, 144, 144), D3DCOLOR_XRGB(176, 176, 176), D3DCOLOR_XRGB(255, 255, 255) };

const D3DXVECTOR3 points01[] = {
	D3DXVECTOR3(-1.000, -1.000, -1.000),
	D3DXVECTOR3(-1.000, -1.000, +1.000),
	D3DXVECTOR3(-1.000, +1.000, -1.000),
	D3DXVECTOR3(-1.000, +1.000, +1.000),
	D3DXVECTOR3(+1.000, -1.000, -1.000),
	D3DXVECTOR3(+1.000, -1.000, +1.000),
	D3DXVECTOR3(+1.000, +1.000, -1.000),
	D3DXVECTOR3(+1.000, +1.000, +1.000) };
const BYTE faces01[] = { 
4,
0, 1, 3, 2,
4,
5, 4, 6, 7,
4,
0, 2, 6, 4,
4,
3, 1, 5, 7,
4,
1, 0, 4, 5,
4,
2, 3, 7, 6 };

const D3DXVECTOR3 points02[] = {
	D3DXVECTOR3(-0.500, -0.350, 0.000),
	D3DXVECTOR3(+0.500, -0.350, 0.000),
	D3DXVECTOR3(0.000, +0.350, -0.500),
	D3DXVECTOR3(0.000, +0.350, +0.500) };
const BYTE faces02[] = { 
3,
0, 2, 1,
3,
0, 1, 3,
3,
3, 2, 0,
3,
2, 3, 1 };

const D3DXVECTOR3 points03[] = {
	D3DXVECTOR3(-10.0, +10.0, +10.0),
	D3DXVECTOR3(+10.0, +10.0, +10.0),
	D3DXVECTOR3(+10.0, +10.0, +00.0),
	D3DXVECTOR3(-02.9, +10.0, +02.9),
	D3DXVECTOR3(+00.0, +10.0, -10.0),
	D3DXVECTOR3(-10.0, +10.0, -10.0) };
const BYTE faces03[] = { 
6,
0, 1, 2, 3, 4, 5,
6,
0, 5, 4, 3, 2, 1 };

const D3DXVECTOR3 points04[] = { // landscape - points in a circle
	D3DXVECTOR3(0.001*63.0f, +0.001, 65000.0*63.0f),
	D3DXVECTOR3(24874.4*63.0f, +0.001, 60052.2*63.0f),
	D3DXVECTOR3(45961.9*63.0f, +0.001, 45961.9*63.0f),
	D3DXVECTOR3(60052.2*63.0f, +0.001, 24874.4*63.0f),
	D3DXVECTOR3(65000.0*63.0f, +0.001,   -0.001*63.0f),
	D3DXVECTOR3(60052.2*63.0f, +0.001, -24874.4*63.0f),
	D3DXVECTOR3(45961.9*63.0f, +0.001, -45962.0*63.0f),
	D3DXVECTOR3(24874.4*63.0f, +0.001, -60052.2*63.0f),
	D3DXVECTOR3(-0.001*63.0f, +0.001, -65000.0*63.0f),
	D3DXVECTOR3(-24874.5*63.0f, +0.001, -60052.1*63.0f),
	D3DXVECTOR3(-45962.0*63.0f, +0.001, -45961.9*63.0f),
	D3DXVECTOR3(-60052.2*63.0f, +0.001, -24874.4*63.0f),
	D3DXVECTOR3(-65000.0*63.0f, +0.001,   -0.001*63.0f),
	D3DXVECTOR3(-60052.2*63.0f, +0.001, 24874.3*63.0f),
	D3DXVECTOR3(-45962.0*63.0f, +0.001, 45961.8*63.0f),
	D3DXVECTOR3(-24874.6*63.0f, +0.001, 60052.1*63.0f) };
const BYTE faces04[] = { 
16,
0, 1, 2, 3, 4, 5, 6, 7, 8, 9,
10, 11, 12, 13, 14, 15 };

const D3DXVECTOR3 points05[] = { // ver road
	D3DXVECTOR3(+0.001, +0.001, +0.001),
	D3DXVECTOR3(+0.001, +0.001, +1024.0),
	D3DXVECTOR3(+8.0, +0.001, +1024.0),
	D3DXVECTOR3(+8.0, +0.001, +0.001) };
const BYTE faces05[] = { 
4,
0, 1, 2, 3 };

const D3DXVECTOR3 points06[] = { // hor road
	D3DXVECTOR3(+0.001, +0.001, +0.001),
	D3DXVECTOR3(+0.001, +0.001, +8.0),
	D3DXVECTOR3(+1024.0, +0.001, +8.0),
	D3DXVECTOR3(+1024.0, +0.001, +0.001) };
const BYTE faces06[] = { 
4,
0, 1, 2, 3 };

#define GROUND 0
#define ROAD_V 1
#define ROAD_H 2
#define GRID_SIZE 4096
#define ROAD_WIDTH 8
#define TEXTURE_OFFSET 0.033f

const D3DXVECTOR3 points07[] = { // ver road with gap
	D3DXVECTOR3(+0.0, +0.001, +0.0 +(ROAD_WIDTH)),
	D3DXVECTOR3(+0.0, +0.001, +GRID_SIZE /*-(ROAD_WIDTH)*/),
	D3DXVECTOR3(+ROAD_WIDTH, +0.001, +GRID_SIZE /*-(ROAD_WIDTH)*/),
	D3DXVECTOR3(+ROAD_WIDTH, +0.001, +0.0 +(ROAD_WIDTH)),
	D3DXVECTOR3(+0.0+ TEXTURE_OFFSET, +0.001, +0.0 +(ROAD_WIDTH)),
	D3DXVECTOR3(+0.0+ TEXTURE_OFFSET, +0.001, +GRID_SIZE /*-(ROAD_WIDTH)*/),
	D3DXVECTOR3(+ROAD_WIDTH - TEXTURE_OFFSET, +0.001, +GRID_SIZE /*-(ROAD_WIDTH)*/),
	D3DXVECTOR3(+ROAD_WIDTH - TEXTURE_OFFSET, +0.001, +0.0 +(ROAD_WIDTH)) };
const BYTE colours07[] = { 1,1,1,1, 0,0,0,0 };
const BYTE lines07[] = { 0,1, 2,3 };
const BYTE triangles07[] = { 0,1,5, 0,5,4, 4,5,6, 4,6,7, 7,6,2, 7,2,3 };

//01
//45
//76
//32

const D3DXVECTOR3 points08[] = { // ver road with gap
	D3DXVECTOR3(+0.0 +(ROAD_WIDTH), +0.001, +0.0),
	D3DXVECTOR3(+0.0 +(ROAD_WIDTH), +0.001, +ROAD_WIDTH),
	D3DXVECTOR3(+GRID_SIZE /*-(ROAD_WIDTH)*/, +0.001, +ROAD_WIDTH),
	D3DXVECTOR3(+GRID_SIZE /*-(ROAD_WIDTH)*/, +0.001, +0.0),
	D3DXVECTOR3(+0.0 +(ROAD_WIDTH), +0.001, +0.0 + TEXTURE_OFFSET),
	D3DXVECTOR3(+0.0 +(ROAD_WIDTH), +0.001, +ROAD_WIDTH - TEXTURE_OFFSET),
	D3DXVECTOR3(+GRID_SIZE /*-(ROAD_WIDTH)*/, +0.001, +ROAD_WIDTH - TEXTURE_OFFSET),
	D3DXVECTOR3(+GRID_SIZE /*-(ROAD_WIDTH)*/, +0.001, +0.0 + TEXTURE_OFFSET) };
const BYTE colours08[] = { 1,1,1,1, 0,0,0,0 };
const BYTE lines08[] = { 0,3, 1,2 };
const BYTE triangles08[] = { 0,4,7, 0,7,3, 4,5,6, 4,6,7, 5,1,2, 5,2,6 };

//0451
//3762

const D3DXVECTOR3 points09[] ={ // cross
	D3DXVECTOR3(+10.0,+0.001,-10.0),
	D3DXVECTOR3(+10.0,+0.001,-100.0),
	D3DXVECTOR3(-10.0,+0.001,-100.0),
	D3DXVECTOR3(-10.0,+0.001,-10.0),
	D3DXVECTOR3(-100.0,+0.001,-10.0),
	D3DXVECTOR3(-100.0,+0.001,+10.0),
	D3DXVECTOR3(-10.0,+0.001,+10.0),
	D3DXVECTOR3(-10.0,+0.001,+100.0),
	D3DXVECTOR3(+10.0,+0.001,+100.0),
	D3DXVECTOR3(+10.0,+0.001,+10.0),
	D3DXVECTOR3(+100.0,+0.001,+10.0),
	D3DXVECTOR3(+100.0,+0.001,-10.0)};
const BYTE faces09[] ={
	12,
	0,1,2,3,4,5,6,7,8,9,10,11};

const D3DXVECTOR3 points10[] ={ // cross
	D3DXVECTOR3(+10.0,+0.001,-10.0),
	D3DXVECTOR3(+10.0,+0.001,-50.0),
	D3DXVECTOR3(-10.0,+0.001,-50.0),
	D3DXVECTOR3(-10.0,+0.001,-10.0),
	D3DXVECTOR3(-50.0,+0.001,-10.0),
	D3DXVECTOR3(-50.0,+0.001,+10.0),
	D3DXVECTOR3(-10.0,+0.001,+10.0),
	D3DXVECTOR3(-10.0,+0.001,+100.0),
	D3DXVECTOR3(+10.0,+0.001,+100.0),
	D3DXVECTOR3(+10.0,+0.001,+10.0),
	D3DXVECTOR3(+100.0,+0.001,+10.0),
	D3DXVECTOR3(+100.0,+0.001,-10.0)};
const BYTE faces10[] ={
	12,
	0,1,2,3,4,5,6,7,8,9,10,11};

//   x x
// x x x x
// x x x x
//   x x

const BYTE map_coords[] = { (0* 16) +0, (0* 16) +15,
(1* 16) +0, (1* 16) +9,
(2* 16) +4, (2* 16) +6, (2* 16) +9, (2* 16) +13,
(3* 16) +3, (3* 16) +12,
(4 * 16) + 4, (4 * 16) + 15,
(5 * 16) + 0, (5 * 16) + 15,
(6 * 16) + 3, (6 * 16) + 7, (6 * 16) + 8, (6 * 16) + 13,
(7 * 16) + 3, (7 * 16) + 13,
(8 * 16) + 11, (8 * 16) + 15,
(9 * 16) + 6, (9 * 16) + 9,
(11 * 16) + 9, (11 * 16) + 13,
(13 * 16) + 0, (13 * 16) + 12,
(15 * 16) + 0, (15 * 16) + 15,

(0 * 16) + 1, (15 * 16) + 1,
(0 * 16) + 2, (15 * 16) + 2,
(3 * 16) + 3/*dup*/, (7 * 16) + 3/*dup*/,
(0 * 16) + 4, (6 * 16) + 4,
(7 * 16) + 5, (15 * 16) + 5,
(1 * 16) + 6, (3 * 16) + 6, (4 * 16) + 6, (6 * 16) + 6, (7 * 16) + 6, (13 * 16) + 6,
(3 * 16) + 7, (7 * 16) + 7,
(3 * 16) + 8, (7 * 16) + 8,
(0 * 16) + 9, (2 * 16) + 9/*dup*/, (7 * 16) + 9, (11 * 16) + 9/*dup*/,
(0 * 16) + 10, (2 * 16) + 10, (3 * 16) + 10, (15 * 16) + 10,
(0 * 16) + 11, (2 * 16) + 11, (3 * 16) + 11, (8 * 16) + 11 /*dup*/,
(6 * 16) + 13 /*dup*/, (11 * 16) + 13 /*dup*/,
(0 * 16) + 15 /*dup*/, (15 * 16) + 15 /*dup*/ };

#endif
