
#include "load.h"
#include "d3d8_screen.h"
#include "map.h"

extern FILE *file;
extern Screen screen;
extern Map map;

const void Load::Setup(const D3DFORMAT format)
{
	fprintf(file, "Load setup\n");
	Format = format;

	Texture2(&grey[0], 0);
	Texture2(&red[0], 1);
	Texture2(&green[0], 2);
	Texture2(&blue[0], 3);

	Model_Skeleton2(points01, faces01, 8, 6, 99);
	Model_Skeleton2(points02, faces02, 4, 4, 100);
	Model_Skeleton2(points03,faces03,6,2,101);
	Model_Skeleton2(points09, faces09,12,1,102);
//	Model_Skeleton2(points10, faces10, 12, 1, 103);

	Model_Skeleton2(points04, faces04, 16, 1, 0); //ground
	Model_Skeleton2(points06, faces06, 4, 1, 4); //ver road
	Model_Skeleton2(points05, faces05, 4, 1, 3); //hor road 

	Model_Complete(points07, colours07, lines07, triangles07, 8, 2, 6, 2);
	Model_Complete(points08, colours08, lines08, triangles08, 8, 2, 6, 1);
}

Load::~Load()
{
	fprintf(file, "Load shutdown\n");
}

const void Load::Texture2(const D3DCOLOR *colours, const int number)
{
fprintf(file,"set texture %i %i\n", number, TEXTURE_SIZE);

D3DXCreateTexture(screen.g_pd3dDevice, TEXTURE_SIZE, TEXTURE_SIZE, 1, D3DUSAGE_DYNAMIC, Format, D3DPOOL_DEFAULT, &screen.Texture[number]);

D3DLOCKED_RECT lock;
screen.Texture[number]->LockRect(0, &lock, NULL, D3DLOCK_DISCARD);

IDirect3DSurface9 *surface;
screen.Texture[number]->GetSurfaceLevel(0, &surface);

D3DSURFACE_DESC surface_desc;
surface->GetDesc(&surface_desc);

fprintf(file, "w %i h %i f %i p %i\n", surface_desc.Width, surface_desc.Height, surface_desc.Format, lock.Pitch);

unsigned __int32 *image_data = (unsigned __int32*)lock.pBits;

for (int h = 0; h != surface_desc.Height; ++h)
{
	const unsigned __int32 colour = colours[h];
	fprintf(file, "h %i c %i\n", h, colour);
	for (int w = 0; w != surface_desc.Width; ++w)
	{
		*(image_data + w) = colour;
	}
	image_data += (lock.Pitch / 4);
}
screen.Texture[number]->UnlockRect(0);
}

const void Load::Model_Skeleton2(const D3DXVECTOR3 *point, const BYTE *face, const int vertices, const int faces, const int object)
{
	for (int x=0; x!=vertices; ++x)
	{
		screen.Vertex[x].Location = point[x];
		screen.Vertex[x].TU = 1.0f; screen.Vertex[x].TV = 1.0f;
		screen.Vertex[x].Colour= D3DCOLOR_XRGB(255, 255, 255);
	}

	for (int f=0, p=0, pos=0; f!=faces; ++f)
	{
		const int lines = face[pos++];
		Line_List[p++] = lines;
		for (int l=0; l!=lines; ++l)
		{
			Line_List[p++] = face[pos++];
		}
	}
	const int lines = Generate_Lines(faces);
	int vertex_count = vertices;
	const int index = Generate_Model_Skeleton2(faces, vertex_count);
	screen.CreateObject(vertex_count, index/3, lines/2, object);
}

const void Load::Model_Complete(const D3DXVECTOR3 *point, const BYTE *colour, const BYTE *line, const BYTE *triangle, const int points, const int lines, const int triangles, const int object)
{
	for (int p=0; p!=points; ++p)
	{
		screen.Vertex[p].Location = point[p];
		const int col = colour[p];
		screen.Vertex[p].TU = col; screen.Vertex[p].TV = col;
		screen.Vertex[p].Colour = D3DCOLOR_XRGB(col*255, col*255, col*255);
	}
	for (int l=0, p=0; l!=lines; ++l, p+=2)
	{
		screen.LineIndex[p] = line[p];
		screen.LineIndex[p+1] = line[p+1];
	}
	for (int t=0, p=0; t!=triangles; ++t, p+=3)
	{
		screen.Index[p] = triangle[p];
		screen.Index[p+1] = triangle[p+1];
		screen.Index[p+2] = triangle[p+2];
	}
	screen.CreateObject(points, triangles, lines, object);
}

const void Load::AddLine(const int start, const int end, int &lines)
{
//	fprintf(file,"als %i %i %i\n", start, end, lines);
	for (int l=0; l!=lines; l+=2)
	{
//		fprintf(file,"l %i %i %i\n", l, screen.LineIndex[l], screen.LineIndex[l+1]);
		if ((screen.LineIndex[l]==start) && (screen.LineIndex[l+1]==end))
		{
			return;
		}
		if ((screen.LineIndex[l]==end) && (screen.LineIndex[l+1]==start))
		{
			return;
		}
	}
	screen.LineIndex[lines] = start;
	screen.LineIndex[lines+1] = end;
//	fprintf(file, "ale %i %i %i\n", screen.LineIndex[lines], screen.LineIndex[lines + 1], lines+2);
	lines += 2;
}

const int Load::Generate_Lines(const int faces)
{
	int linecount = 0;
	int Face_Line_List[MAX_VERTICES];
	for (int f=0, p=0; f!=faces; ++f)
	{
		const int lines=Line_List[p++];
		memcpy(&Face_Line_List[1], &Line_List[p], sizeof(Line_List[0])*lines);
		Face_Line_List[lines + 1] = Face_Line_List[1]; // copy first to last
		Face_Line_List[0] = Face_Line_List[lines]; // copy last to first
		p += lines;

		for (int d=1; d!=lines+1; ++d)
		{
			const int curr_point = Face_Line_List[d + 1];
			const int next_point = Face_Line_List[d];
			AddLine(curr_point, next_point, linecount);
//			screen.LineIndex[linecount] = curr_point;
//			screen.LineIndex[linecount+1] = next_point;
//			linecount+=2;
		}
	}
	return linecount;
}

// for each face
//  for each point in face
//   calculate line for point in face
//  for each point in face
//   calculate intersection point using current and next line
//  for each point in face minus 1
//   calculate 2 triangles for bottom of face using current and next
//  for each point in face minus 1
//   calculate 1 triangle using intersection points

const int Load::Generate_Model_Skeleton2(const int faces, int& vertices)
{
	fprintf(file, "v %i f %i\n", vertices, faces);
	int Face_Line_List[MAX_VERTICES];
	D3DXVECTOR3 IntersectionPoint[MAX_VERTICES];
	int index=0;
	for (int f=0, p=0; f!=faces; ++f)
	{
		const int lines=Line_List[p++];
		memcpy(&Face_Line_List[1],&Line_List[p],sizeof(Line_List[0])*lines);
		Face_Line_List[lines+1]=Face_Line_List[1]; // copy first to last
		Face_Line_List[0]=Face_Line_List[lines]; // copy last to first
		p+=lines;

		D3DXVECTOR3 middle=D3DXVECTOR3(0,0,0);
		for (int d=1; d!=lines+1; ++d)
		{
			const int curr_point=Face_Line_List[d];
			middle+=screen.Vertex[curr_point].Location;
		}
		middle/=lines;
		middle = (middle + screen.Vertex[Face_Line_List[0]].Location)*0.5f;

//		fprintf(file, "m %f %f %f\n", middle.x, middle.y, middle.z); // calculating the middle is the problem
// need to calculate the middle point of each triangle
// use prev point as middle unless its not clockwise to middle then use next point

		D3DXVECTOR3 LineStart[MAX_VERTICES], LineEnd[MAX_VERTICES];
		for (int d = 1; d != lines+1 ; ++d)
		{
			const int curr_point = Face_Line_List[d+1];
			const int next_point = Face_Line_List[d];

			const D3DXVECTOR3 middle2= Middle(&Face_Line_List[1], curr_point, next_point, (d - 1) % lines, (d + 1) % lines);
			Point_Line(middle2, screen.Vertex[curr_point].Location, screen.Vertex[next_point].Location, LineStart[curr_point], LineEnd[curr_point]);
		}

		for (int d = 1; d != lines+1; ++d)
		{
			const int curr_point = Face_Line_List[d];
			const int next_point = Face_Line_List[d + 1];
			LineLineIntersect(LineStart[curr_point], LineEnd[curr_point], LineStart[next_point], LineEnd[next_point], IntersectionPoint[curr_point]);
		}

		int inner_vertex_pointer[MAX_VERTICES];
		for (int d=1; d!=lines+1; ++d)
		{
			const int curr_point=Face_Line_List[d];
			const D3DXVECTOR3 inner_point = IntersectionPoint[curr_point];
			inner_vertex_pointer[curr_point]=vertices; // add pointer to inner point to outer point 
			fprintf(file, "test %i\n", vertices);
			screen.Vertex[vertices].Location=inner_point; // add point to vertex list
			screen.Vertex[vertices].TU=0.0f; screen.Vertex[vertices].TV=0.0f;
			++vertices;
		}
		for (int t=1; t!=lines+1; ++t) // 2 edge triangles
		{
			const int curr_point=Face_Line_List[t];
			const int next_point=Face_Line_List[t+1];
			screen.Index[index]=curr_point;
			screen.Index[index+1]=inner_vertex_pointer[next_point];
			screen.Index[index+2]=inner_vertex_pointer[curr_point];
			index+=3;
			screen.Index[index]=curr_point;
			screen.Index[index+1]=next_point;
			screen.Index[index+2]=inner_vertex_pointer[next_point];
			index+=3;
		}
		fprintf(file, "start\n");
		const int first_point=Face_Line_List[1];
		const int first_point_pos=inner_vertex_pointer[first_point];
		for (int i=2; i!=lines; ++i) // 1 middle triangle
		{
			const int curr_point=Face_Line_List[i];
			const int next_point=Face_Line_List[i+1];
			screen.Index[index]= first_point_pos;
			screen.Index[index+1]=inner_vertex_pointer[curr_point];
			screen.Index[index+2]=inner_vertex_pointer[next_point];
			index+=3;
			fprintf(file, "at i %i fp %i fpp %i cp %i np %i\n", i, first_point, first_point_pos, curr_point, next_point);
		}
		fprintf(file, "end\n");
	}
	return index;
}

const D3DXVECTOR3 Load::Middle(const int* LineList, const int next, const int curr, const int prev_one, const int next_one)
{
	const int next_point = LineList[next_one];
	const int prev_point = LineList[prev_one];

	if (FacesViewer(screen.Vertex[next_point].Location, screen.Vertex[curr].Location, screen.Vertex[next].Location, D3DXVECTOR3(0, 0, 0)) < 0.0f)
	{
		return screen.Vertex[next_point].Location;
	}
	return screen.Vertex[prev_point].Location;
}

const float Load::FacesViewer(const D3DXVECTOR3& P0, const D3DXVECTOR3& P1, const D3DXVECTOR3& P2, const D3DXVECTOR3 &Viewpoint)
{
	const D3DXVECTOR3 viewvec = P0 - Viewpoint;
	const D3DXVECTOR3 edge1 = P0 - P1;
	const D3DXVECTOR3 edge2 = P2 - P1;

	D3DXVECTOR3 normal;
	D3DXVec3Cross(&normal, &edge1, &edge2);

	return (D3DXVec3Dot(&viewvec, &normal));
}

const void Load::Point_Line(const D3DXVECTOR3& point, const D3DXVECTOR3& L0, const D3DXVECTOR3& L1, D3DXVECTOR3& Line_Start_Intersect, D3DXVECTOR3& Line_End_Intersect)
{
	const D3DXVECTOR3 l1l0 = L1 - L0; // line vector
	const D3DXVECTOR3 pl0 = point - L0; // point to line vector
	const float c1 = D3DXVec3Dot(&pl0, &l1l0);
	const float c2 = D3DXVec3Dot(&l1l0, &l1l0);
	const float b = c1 / c2; // distance along
	const D3DXVECTOR3 Pb = L0 + (b * l1l0); // intersection point
	const D3DXVECTOR3 intersect_to_middle = point - Pb; // calculate length of line between middle and pb
	D3DXVECTOR3 unit_length;
	D3DXVec3Normalize(&unit_length, &intersect_to_middle); // calculate vector with direction of middle to pb with a length of 1
	unit_length *= 0.033f;
	Line_Start_Intersect = L0 - l1l0 + unit_length;// L0 + unit_length;
	Line_End_Intersect = L1 + l1l0 + unit_length;// L1 + unit_length;
}

/*
Calculate the line segment PaPb that is the shortest route between
two lines P1P2 and P3P4. Calculate also the values of mua and mub where
Pa = P1 + mua (P2 - P1)
Pb = P3 + mub (P4 - P3)
Return FALSE if no solution exists.
*/
const bool Load::LineLineIntersect(const D3DXVECTOR3& p1, const D3DXVECTOR3& p2, const D3DXVECTOR3& p3, const D3DXVECTOR3& p4, D3DXVECTOR3 &middle)
{
	const D3DXVECTOR3 p43 = D3DXVECTOR3(p4.x - p3.x, p4.y - p3.y, p4.z - p3.z);
	if (fabs(p43.x) < D3DX_16F_EPSILON && fabs(p43.y) < D3DX_16F_EPSILON && fabs(p43.z) < D3DX_16F_EPSILON)
	{
		return false;
	}
	const D3DXVECTOR3 p21 = D3DXVECTOR3(p2.x - p1.x, p2.y - p1.y, p2.z - p1.z);
	if (fabs(p21.x) < D3DX_16F_EPSILON && fabs(p21.y) < D3DX_16F_EPSILON && fabs(p21.z) < D3DX_16F_EPSILON)
	{
		return false;
	}

	const D3DXVECTOR3 p13 = D3DXVECTOR3(p1.x - p3.x, p1.y - p3.y, p1.z - p3.z);
	const float d1343 = p13.x * p43.x + p13.y * p43.y + p13.z * p43.z;
	const float d4321 = p43.x * p21.x + p43.y * p21.y + p43.z * p21.z;
	const float d1321 = p13.x * p21.x + p13.y * p21.y + p13.z * p21.z;
	const float d4343 = p43.x * p43.x + p43.y * p43.y + p43.z * p43.z;
	const float d2121 = p21.x * p21.x + p21.y * p21.y + p21.z * p21.z;

	const float denom = d2121 * d4343 - d4321 * d4321;
	if (fabs(denom) < D3DX_16F_EPSILON)
	{
		return false;
	}
	const float numer = d1343 * d4321 - d1321 * d4343;
	const float mua = numer / denom;
	const float mub = (d1343 + d4321 * (mua)) / d4343;

	const D3DXVECTOR3 start = D3DXVECTOR3(p1.x + mua * p21.x, p1.y + mua * p21.y, p1.z + mua * p21.z);
	const D3DXVECTOR3 end = D3DXVECTOR3(p3.x + mub * p43.x, p3.y + mub * p43.y, p3.z + mub * p43.z);
	middle = (start + end) * 0.5f;
	return true;
}
