#ifndef LOAD
#define LOAD

#include <stdio.h>
#include "d3d8_screen.h"
#include "object.h"

class Load
{
	D3DFORMAT Format;
	int Line_List[MAX_VERTICES];
	const D3DXVECTOR3 Middle(const int*, const int, const int, const int, const int);
	const float FacesViewer(const D3DXVECTOR3 &, const D3DXVECTOR3 &, const D3DXVECTOR3 &, const D3DXVECTOR3 &);
	const int Generate_Lines(const int);
	const void AddLine(const int, const int, int &);
	const int Generate_Model_Skeleton2(const int faces, int& vertices);
	const void Point_Line(const D3DXVECTOR3&, const D3DXVECTOR3&, const D3DXVECTOR3&, D3DXVECTOR3&, D3DXVECTOR3&);
	const bool LineLineIntersect(const D3DXVECTOR3&, const D3DXVECTOR3&, const D3DXVECTOR3&, const D3DXVECTOR3&, D3DXVECTOR3&);
public:
	const void	Setup(const D3DFORMAT);
	~Load();
	const void Texture2(const D3DCOLOR *, const int);
	const void Model_Skeleton2(const D3DXVECTOR3 *, const BYTE *, const int, const int, const int);
	const void Model_Complete(const D3DXVECTOR3 *point, const BYTE *colour, const BYTE *line, const BYTE *triangle, const int points, const int lines, const int triangles, const int object);
};

#endif
