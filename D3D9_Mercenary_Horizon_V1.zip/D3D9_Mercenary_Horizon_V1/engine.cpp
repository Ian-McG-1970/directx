#include "engine.h"
#include "d3d8_screen.h"
#include "di_mouse.h"
#include "map.h"

extern HWND hwnd;
extern Mouse mouse;
extern Map map;
extern Screen screen;

extern FILE *file;

const void Engine::Setup()
{
	fprintf(file,"engine setup\n");

	Location=D3DXVECTOR3(1000.0f, 100.0f, 1000.0f);
//	Location=D3DXVECTOR3(10000.0f, 15000.0f, -5000.0f);
	Direction=D3DXVECTOR3(0.7f, 0.0f, 0.0f);
	Speed=0.0f;
}

Engine::~Engine()
{
	fprintf(file,"engine shutdown\n");
}

const void Engine::Move(D3DXVECTOR3 &location, const D3DXVECTOR3 &direction, const float speed)
{
	D3DXMATRIX  matTmp;
	D3DXMatrixRotationYawPitchRoll(&matTmp, direction.y, direction.x, direction.z);      
	D3DXVECTOR4 tmp;
	const D3DXVECTOR3 viewDir(0.0f, 0.0f, 1.0f);
	D3DXVec3Transform(&tmp, &viewDir, &matTmp);
	location += ((D3DXVECTOR3)(tmp)*speed);
}

const void Engine::Input(D3DXVECTOR3 &direction, float &speed, const float dampen)
{
	mouse.Update();
	if (mouse.LB!=0 && mouse.RB!=0)
	{
		PostMessage(hwnd, WM_CLOSE, 0, 0);
		return;
	}
	if (mouse.LB==0 && mouse.RB==0)
	{
		direction.x -= mouse.Y*dampen;
		direction.y += mouse.X*dampen;
	}
	if (mouse.RB!=0)
	{
		direction.z -= mouse.X*dampen;
	}
	if (mouse.LB!=0)
	{
		speed -= mouse.Y*dampen;
	}
	speed*=0.9999f;
}

const void Engine::DrawActor(const ACTOR *actor, const int actors)
{
	for (int a=0; a!=actors; ++a)
	{
		const int model = actor[a].Model;
//		const D3DXVECTOR3 location = actor[a].Location + screen.Model[model].Bounding_Sphere_Centre;
		const D3DXVECTOR3 location = actor[a].Location;
		if ((screen.IsSphereInsideFrustum(location, screen.Model[model].Bounding_Sphere_Centre, screen.Model[model].Bounding_Sphere_Radius) == true)
			&& (screen.BoundingBoxInFrustum(&screen.Model[model].Bounding_Box[0], location) == true))
		{
			screen.DrawStaticObject(location, model, actor[a].Texture);
			++Count;
		}
	}
}

const void Engine::Update()
{
	screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, BACKGROUND, 1.0f, 0);

	Input(Direction, Speed, 0.003f);
	Move(Location, Direction, Speed);

	screen.View_Matrix(Location, Direction);

	Count=0;
	screen.g_pd3dDevice->BeginScene();

	screen.g_pd3dDevice->SetRenderState(D3DRS_ZENABLE, false);
	DrawActor(&map.Ground[0], map.GroundSections);

	screen.g_pd3dDevice->SetRenderState(D3DRS_ZENABLE, true);
	DrawActor(&map.Track[0], map.TrackSections);

	sprintf(screen.string, "px %5.2f %5.2f %5.2f %5.2f %5.2f %5.2f cnt %i\n", Location.x, Location.y, Location.z, Direction.x, Direction.y, Direction.z, Count);
	screen.DrawText(5, 5, D3DXCOLOR(0, 127, 127, 127));

	screen.g_pd3dDevice->EndScene();
	//	DrawHorizon2D(Direction.x,Direction.z);
	DrawHorizon3D(Direction.x,Direction.z);

	screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
}

const D3DXVECTOR3 Engine::Rotate(const float ox,const float oy,const float oz,const float sinx,const float cosx,const float sinz,const float cosz) // rotate points about x/z axis
{
	const float ry=oy;
	float y = (ry * cosx) + (oz * sinx);
	const float z = (ry * sinx) - (oz * cosx);

	const float rx=ox;
	const float x = (rx * cosz) + (y * sinz);
	y = (rx * sinz) - (y * cosz);

	return D3DXVECTOR3(x,y,z);
}

const void Engine::DrawHorizon2D(const float pitch,const float roll)
{
	D3DVIEWPORT9 view;
	screen.g_pd3dDevice->GetViewport(&view);
	D3DXVECTOR3 p3d[4];
	D3DXVECTOR2 p2d[4];
	D3DXVECTOR3 p[4];

	p3d[0]=D3DXVECTOR3(-10000.0,0.0,+10000.0);
	p3d[1]=D3DXVECTOR3(+10000.0,0.0,+10000.0);
	p3d[2]=D3DXVECTOR3(+10000.0,0.0,-10000.0);
	p3d[3]=D3DXVECTOR3(-10000.0,0.0,-10000.0);

	const float sinx=sinf(pitch);
	const float cosx=cosf(pitch);
	const float sinz=sinf(roll);
	const float cosz=cosf(roll);

	p[0]=Rotate(p3d[0].x,p3d[0].y,p3d[0].z,sinx,cosx,sinz,cosz);
	p[1]=Rotate(p3d[1].x,p3d[1].y,p3d[1].z,sinx,cosx,sinz,cosz);
	p[2]=Rotate(p3d[2].x,p3d[2].y,p3d[2].z,sinx,cosx,sinz,cosz);
	p[3]=Rotate(p3d[3].x,p3d[3].y,p3d[3].z,sinx,cosx,sinz,cosz);

	const float scale = 1024.0f;
	if((p[0].z >0.0f) && (p[1].z >0.0f))
	{
		p2d[0] =D3DXVECTOR2(((p[0].x*scale) / (p[0].z+scale)) + (view.Width/2),((p[0].y*scale) / (p[0].z+scale)) + (view.Height/2)); // perspective projection
		p2d[1] =D3DXVECTOR2(((p[1].x*scale) / (p[1].z+scale)) + (view.Width/2),((p[1].y*scale) / (p[1].z+scale)) + (view.Height/2));
		ClipLine(p2d[0],p2d[1],D3DXVECTOR2(view.Width-20,view.Height-20));
		screen.DrawLine2D(p2d[0],p2d[1],D3DCOLOR_XRGB(255,255,0));
	}
	if((p[2].z >0.0f) && (p[3].z >0.0f))
	{
		p2d[2] =D3DXVECTOR2(((p[2].x*scale) / (p[2].z+scale)) + (view.Width/2),((p[2].y*scale) / (p[2].z+scale)) + (view.Height/2)); // perspective projection
		p2d[3] =D3DXVECTOR2(((p[3].x*scale) / (p[3].z+scale)) + (view.Width/2),((p[3].y*scale) / (p[3].z+scale)) + (view.Height/2));
		ClipLine(p2d[2],p2d[3],D3DXVECTOR2(view.Width-20,view.Height-20));
		screen.DrawLine2D(p2d[2],p2d[3],D3DCOLOR_XRGB(255,0,255));
	}

	screen.DrawLine2D(D3DXVECTOR2((view.Width/2)-10,(view.Height/2)),D3DXVECTOR2((view.Width/2)+10,(view.Height/2)),D3DCOLOR_XRGB(255,255,255));
}

const void Engine::DrawHorizon3D(const float pitch,const float roll)
{
	D3DVIEWPORT9 view;
	screen.g_pd3dDevice->GetViewport(&view);
	D3DXVECTOR3 p3d[4];
	D3DXVECTOR2 p2d[4];
	D3DXVECTOR3 p[4];

	p3d[0]=D3DXVECTOR3(-1000000.0,0.0,+1000000.0);
	p3d[1]=D3DXVECTOR3(+1000000.0,0.0,+1000000.0);
	p3d[2]=D3DXVECTOR3(+1000000.0,0.0,-1000000.0);
	p3d[3]=D3DXVECTOR3(-1000000.0,0.0,-1000000.0);

	const float sinx=sinf(pitch);
	const float cosx=cosf(pitch);
	const float sinz=sinf(roll);
	const float cosz=cosf(roll);

	p[0]=p3d[0];//Rotate(p3d[0].x,p3d[0].y,p3d[0].z,sinx,cosx,sinz,cosz);
	p[1]=p3d[1];//Rotate(p3d[1].x,p3d[1].y,p3d[1].z,sinx,cosx,sinz,cosz);
	p[2]=p3d[2];//Rotate(p3d[2].x,p3d[2].y,p3d[2].z,sinx,cosx,sinz,cosz);
	p[3]=p3d[3];//Rotate(p3d[3].x,p3d[3].y,p3d[3].z,sinx,cosx,sinz,cosz);

//	const float scale = 1024.0f;
	if((p[0].z >0.0f) && (p[1].z >0.0f))
	{
//		p2d[0] =D3DXVECTOR2(((p[0].x*scale) / (p[0].z+scale)) + (view.Width/2),((p[0].y*scale) / (p[0].z+scale)) + (view.Height/2)); // perspective projection
//		p2d[1] =D3DXVECTOR2(((p[1].x*scale) / (p[1].z+scale)) + (view.Width/2),((p[1].y*scale) / (p[1].z+scale)) + (view.Height/2));
//		ClipLine(p2d[0],p2d[1],D3DXVECTOR2(view.Width-20,view.Height-20));
		screen.DrawLine3D(p[0],p[1],D3DCOLOR_XRGB(255,255,0));
	}
	if((p[2].z >0.0f) && (p[3].z >0.0f))
	{
//		p2d[2] =D3DXVECTOR2(((p[2].x*scale) / (p[2].z+scale)) + (view.Width/2),((p[2].y*scale) / (p[2].z+scale)) + (view.Height/2)); // perspective projection
//		p2d[3] =D3DXVECTOR2(((p[3].x*scale) / (p[3].z+scale)) + (view.Width/2),((p[3].y*scale) / (p[3].z+scale)) + (view.Height/2));
//		ClipLine(p2d[2],p2d[3],D3DXVECTOR2(view.Width-20,view.Height-20));
		screen.DrawLine3D(p[2],p[3],D3DCOLOR_XRGB(255,0,255));
	}

//	screen.DrawLine2D(D3DXVECTOR2((view.Width/2)-10,(view.Height/2)),D3DXVECTOR2((view.Width/2)+10,(view.Height/2)),D3DCOLOR_XRGB(255,255,255));
}

//	======================================================================================= 
//	Function:		ClipLine																
//																							
//	Description:	Clip line co-ordinates to screen boundaries								
//					Return FALSE if line is entirely off screen								
//	======================================================================================= 

const bool Engine::ClipLine(D3DXVECTOR2 &start,D3DXVECTOR2 &end,const D3DXVECTOR2 &view)
{
	if (start.x < 0.0f) 	// clip x1
	{
		if(end.x < 0.0f) 		// x1 is off left of screen
		{
			return false; // entire line is off left of screen
		}
		else
		{
			start.y -= ((start.x * (end.y-start.y)) / (end.x-start.x)); // clip line to left edge, giving a new value for y1
			start.x = 0.0f;
		}
	}
	else if(start.x > view.x)
	{
		if(end.x >view.x) 			// x1 is off right of screen
		{
			return false; // entire line is off right of screen
		}
		else
		{
			start.y -= (((start.x-view.x) * (end.y-start.y)) / (end.x-start.x)); 				// clip line to right edge, giving a new value for y1
			start.x = view.x;
		}
	}

	if(start.y < 0.0f) 	// clip y1
	{
		if(end.y < 0.0f) 		// y1 is off top of screen
		{
			return false;// entire line is off top of screen
		}
		else
		{
			start.x -= ((start.y * (end.x-start.x)) / (end.y-start.y)); 			// clip line to top edge, giving a new value for x1
			start.y = 0.0f;
			if((start.x < 0.0f) || (start.x > view.x)) 			// check new x1 is on screen
			{
				return false;
			}
		}
	}
	else if(start.y > view.y)
	{
		if(end.y > view.y) 			// y1 is off bottom of screen
		{
			return false; // entire line is off bottom of screen
		}
		else
		{
			start.x -= (((start.y-view.y) * (end.x-start.x)) / (end.y-start.y)); 				// clip line to bottom edge, giving a new value for x1
			start.y = view.y;
			if((start.x < 0.0f) || (start.x > view.x)) 				// check new x1 is on screen
			{
				return false;
			}
		}
	}

	if(end.x < 0.0f) 	// clip x2
	{
		end.y -= ((end.x * (start.y-end.y)) / (start.x-end.x)); 		// x2 is off left of screen clip line to left edge, giving a new value for y2
		end.x = 0.0f;
	}
	else if(end.x > view.x) 			// x2 is off right of screen
	{
		end.y -= (((end.x-view.x) * (start.y-end.y)) / (start.x-end.x)); // clip line to right edge, giving a new value for y2
		end.x = view.x;
	}


	if(end.y < 0.0f) 	// clip y2
	{
		end.x -= ((end.y * (start.x-end.x)) / (start.y-end.y)); // y2 is off top of screen clip line to top edge, giving a new value for x2
		end.y = 0.0f;
		if((end.x < 0.0f) || (end.x > view.x)) 		// check new x2 is on screen
		{
			return false;
		}
	}
	else if(end.y > view.y) // y2 is off bottom of screen
	{
		end.x -= (((end.y-view.y) * (start.x-end.x)) / (start.y-end.y)); // clip line to bottom edge, giving a new value for x2
		end.y = view.y;

		if((end.x < 0.0f) || (end.x > view.x)) 			// check new x2 is on screen
		{
			return false;
		}
	}
	start+=D3DXVECTOR2(10,10);
	end+=D3DXVECTOR2(10,10);
	return true;
}

/*

(function ()
{
if (!window.requestAnimationFrame)
{ // http://paulirish.com/2011/requestanimationframe-for-smart-animating/
window.requestAnimationFrame = window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || window.msRequestAnimationFrame || function(callback, element)
{
window.setTimeout(callback, 1000 / 60);
}
}

function timestamp()
{
return window.performance && window.performance.now ? window.performance.now() : new Date().getTime();
}

var SPACE = 17,//32,
LEFT = 37,
UP = 38,
RIGHT = 39,
DOWN = 40,
step     = 1/60, //fps
canvas   = document.getElementById('canvas'),
ctx      = canvas.getContext('2d'),
width    = canvas.width  = 1024,
height   = canvas.height = 768,
pitch = 0,
roll = 0;

function onkey(ev, key, down)
{
switch (key)
{
case LEFT: roll-=0.01; ev.preventDefault(); return false;
case RIGHT: roll+=0.01; ev.preventDefault(); return false;
case UP: pitch-=0.01; ev.preventDefault(); return false;
case DOWN: pitch+=0.01; ev.preventDefault(); return false;
}
}

function rotate(ox, oy, oz, sinx, cosx, sinz, cosz) // rotate points about x/z axis
{
var ry=oy;
var y = (ry * cosx) - (oz * sinx);
var z = (ry * sinx) + (oz * cosx);

var rx=ox;
var x = (rx * cosz) - (y * sinz);
y = (rx * sinz) + (y * cosz);

return { x: x, y: y, z: z };
}

function drawhorizon(pitch, roll)
{
var p3d=[];
var p2d=[];
var p=[];

p3d[0]={ x: -1000.0, y: 0.0, z: +1000.0 };
p3d[1]={ x: +1000.0, y: 0.0, z: +1000.0 };

var sinx=Math.sin(pitch);
var cosx=Math.cos(pitch);
var sinz=Math.sin(roll);
var cosz=Math.cos(roll);

p[0]=rotate(p3d[0].x, p3d[0].y, p3d[0].z, sinx, cosx, sinz, cosz);
p[1]=rotate(p3d[1].x, p3d[1].y, p3d[1].z, sinx, cosx, sinz, cosz);

if ((p[0].z >0) && (p[1].z >0))
{
var scale = 32768;
p2d[0] = { x: ((p[0].x*scale) / (p[0].z+scale)) + (width/2), y: ((p[0].y*scale) / (p[0].z+scale)) + (height/2) }; // perspective projection
p2d[1] = { x: ((p[1].x*scale) / (p[1].z+scale)) + (width/2), y: ((p[1].y*scale) / (p[1].z+scale)) + (height/2) };
drawline(p2d[0], p2d[1]);
}
drawline({ x: (width/2)-10, y: (height/2) }, { x: (width/2)+10, y: (height/2) });
}

function drawline(start, end)
{
ctx.fillStyle = '#101010';
ctx.beginPath();
ctx.moveTo(start.x, start.y);
ctx.lineTo(end.x, end.y);
ctx.stroke();
}

var dt = 0, now, last = timestamp();

function frame()
{
now = timestamp();
dt = dt + Math.min(1, (now - last) / 1000);
while (dt > step)
{
dt = dt - step;
}
ctx.clearRect(0, 0, width, height);
drawhorizon(pitch, roll);

last = now;
requestAnimationFrame(frame, canvas);
}

document.addEventListener('keydown', function(ev) { return onkey(ev, ev.keyCode, true);  }, false);
document.addEventListener('keyup',   function(ev) { return onkey(ev, ev.keyCode, false); }, false);
frame();
}

)();

*/