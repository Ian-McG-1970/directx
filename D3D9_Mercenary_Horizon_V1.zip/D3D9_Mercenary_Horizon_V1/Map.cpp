#include "d3d8_screen.h"
#include "load.h"
#include "map.h"

extern FILE *file;

const void Map::Setup()
{
	fprintf(file,"map setup\n");

	BuildTrack();
	BuildGround(33);
}

Map::~Map()
{
	fprintf(file,"map shutdown\n");
}

const void Map::BuildTrack()
{
	TrackSections=TRACK_PATCH_COUNT;
	for (int x=0; x!=TrackSections; ++x)
	{
		Track[x].Model = 99 +(rand() %4);
		Track[x].Location= D3DXVECTOR3( (((int)rand()&2047)-511), (((int)rand()&2047)+10), (((int)rand()&2047)-511));
		Track[x].Texture = rand() &3;
	}
}

const void Map::BuildGround(const int lines)
{
	GroundSections = 0;

//	Ground[0].Location = D3DXVECTOR3(0, 0, 0);
//	Ground[0].Model = GROUND;
//	Ground[0].Texture = 2;

	for (int l=0, p=0; l!=lines; ++l, p+=2)
	{
		const int start_x = map_coords[p] >>4;
		const int start_y = map_coords[p] &15;
		const int end_x = map_coords[p+1] >>4;
		const int end_y = map_coords[p+1] &15;

		//		fprintf(file,"sx %i sy %i ex %i ey %i\n", start_x, start_y, end_x, end_y);
		if (start_x==end_x)
		{
			for (int c = start_y; c != end_y; ++c) 
			{
//				fprintf(file, "yd %i %i %i %i\n", l, c, start_y, end_y);
				Ground[GroundSections].Location = D3DXVECTOR3(start_x*GRID_SIZE, 0, c*GRID_SIZE);
				Ground[GroundSections].Model = ROAD_H;
				Ground[GroundSections].Texture = 3;
				++GroundSections;
				fprintf(file, "gs1 %i %i %i %i %i\n", GroundSections, start_x, start_y, end_x, end_y);
			}
		}
		else
		{
			for (int c = start_x; c != end_x; ++c) 
			{
//				fprintf(file, "xd %i %i %i %i\n", l, c, start_x, end_x);
				Ground[GroundSections].Location = D3DXVECTOR3(c*GRID_SIZE, 0, start_y*GRID_SIZE);
				Ground[GroundSections].Model = ROAD_V;
				Ground[GroundSections].Texture = 3;
				++GroundSections;
				fprintf(file, "gs2 %i %i %i %i %i\n", GroundSections, start_x, start_y, end_x, end_y);
			}
		}
	}
}
