
#include "stdlib.h"
#include "d3d8_screen.h"
#include "portal.h"
#include "engine.h"
#include "log.h"
#include "vector"

extern Screen screen;
extern Engine engine;
extern FILE *file;
extern LogFile logfile;

const void Portal::Setup()
{
	fprintf(file,"portal setup\n");
}

Portal::~Portal()
{
	fprintf(file,"portal shutdown\n");
}

std::vector<D3DXVECTOR3> Portal::Clip_Portal_To_Frustum_Plane(std::vector<D3DXVECTOR3> portal,const D3DXPLANE &frustum,const int frustum_count)
{
	int clipped_portal_count=0;
	std::vector<D3DXVECTOR3> clipped_portal;

	portal.push_back(portal[0]);

	for (int p=0; p!=portal.size()-1; ++p)
	{
		const float curr_dot=D3DXPlaneDotCoord(&frustum,&portal[p]);
		const float next_dot=D3DXPlaneDotCoord(&frustum,&portal[p+1]);

		if (curr_dot<0.0f) // if curr point inside
		{
			clipped_portal.push_back(portal[p]);

			if (next_dot>=0.0f) // if the other isnt
			{
				const float scale=next_dot/(curr_dot-next_dot);
				const D3DXVECTOR3 diff=portal[p+1]-portal[p];
				clipped_portal.push_back(portal[p+1] + (diff * scale));
			}
		}
		else if (next_dot<0.0f) // else if the other is
		{
			const float scale=curr_dot/(next_dot-curr_dot);
			const D3DXVECTOR3 diff=portal[p]-portal[p+1];
			clipped_portal.push_back(portal[p] + (diff * scale));
		}
	}
	return clipped_portal; // return portal clipped against this frustum
}

const std::vector<D3DXVECTOR3> Portal::Clip_Portal_To_Frustum(const std::vector<D3DXVECTOR3> portal,const std::vector<D3DXPLANE> frustum,const int clip_codes)
{
	std::vector<D3DXVECTOR3> clipped_portal=portal;

	for (int f=0,clip_code=1; f!=frustum.size(); ++f)
	{
		const int outside_clip_code=clip_codes&clip_code;
		if ( (outside_clip_code!=0) && (clipped_portal.size()!=0) ) // if some portal points are outside this frustum
		{
			clipped_portal=Clip_Portal_To_Frustum_Plane(clipped_portal,frustum[f],f); // clip the portal to this frustum, return the list of clipped points and set the new point count
		}
		clip_code+=clip_code;
	}
	return clipped_portal; // return the last clipped portal
}

const void Portal::Set_Clip_Planes(const std::vector<D3DXPLANE> &frustum)
{
	DWORD clipplanes=0;
	for (int x=0; x!=frustum.size(); ++x)
	{
		const D3DXPLANE clipplane=-frustum[x];
		screen.g_pd3dDevice->SetClipPlane(x, (float *) &clipplane);
		clipplanes=(clipplanes<<1)+1;
	}
	screen.g_pd3dDevice->SetRenderState(D3DRS_CLIPPLANEENABLE, clipplanes);
}

const void Portal::Reset_Frustum() // set original frustum from screen portal
{
	Portal_Frustum.resize(screen.Frustum.size());
	memcpy(&Portal_Frustum[0], &screen.Frustum[0], sizeof(Portal_Frustum[0])*Portal_Frustum.size());
	Set_Clip_Planes(Portal_Frustum);
}

const std::vector<D3DXPLANE> Portal::Create_Frustum_From_Portal(std::vector<D3DXVECTOR3> portal)
{
	std::vector<D3DXPLANE> frustum(portal.size());
	portal.push_back(portal[0]); // copy first portal point to last

	for (int x=0; x!=frustum.size(); ++x)
	{
		D3DXPlaneFromPoints(&frustum[x],&engine.Location,&portal[x],&portal[x+1]);
	}
	Set_Clip_Planes(frustum);
	return frustum;
}

const long Portal::Test_Portal_Against_Frustum(const std::vector<D3DXVECTOR3> portal, const std::vector<D3DXPLANE> frustum)
{
	int outside_clip_code=PORTAL_POINTS_INSIDE_FRUSTUM;

	for (int f=0, clip_code=1; f!=frustum.size(); ++f)
	{
		int outside_count=0;
		for (int p=0; p!=portal.size(); ++p)
		{
			if (D3DXPlaneDotCoord(&frustum[f], &portal[p]) >=0.0f) // if point is outside frustum
			{
				++outside_count; // 
			}
		}
		if (outside_count==portal.size()) // if all points are outside of this frustum
		{
			return PORTAL_POINTS_OUTSIDE_FRUSTUM; // return outside
		}
		if (outside_count!=0) // if some points are outside of this frustum
		{
			outside_clip_code+=clip_code; // mark frustum to be clipped against
		}
		clip_code+=clip_code;
	}
	return outside_clip_code; // return frustums to be clipped against
}

const void Portal::Draw_Sector(const int to_sector, const int from_sector, const D3DXVECTOR3 &location, std::vector<D3DXPLANE> vector_frustum)
{
	screen.Draw_Object(Sector[to_sector].Model);
	
	for (int p=0; p!=SectorPortals[to_sector].Portal.size(); ++p)
	{
		if (SectorPortals[to_sector].Portal[p].Sector_To!=from_sector)
		{
			std::vector<D3DXVECTOR3> vector_portal=SectorPortals[to_sector].Portal[p].Point;

			const long portal_clip_code=Test_Portal_Against_Frustum(vector_portal, vector_frustum); // test each portal point against each frustum
			if (portal_clip_code!=PORTAL_POINTS_OUTSIDE_FRUSTUM) // not all are outside
			{
				if (portal_clip_code!=PORTAL_POINTS_INSIDE_FRUSTUM) // some are outside
				{
					vector_portal=Clip_Portal_To_Frustum(vector_portal, vector_frustum, portal_clip_code); // clip all portals to frustums based on clip codes
				}
				if (vector_portal.size()>=3)
				{
					std::vector<D3DXPLANE> portal_new_frustum=Create_Frustum_From_Portal(vector_portal); // create a unique frustum and return it and the frustum count
					Draw_Sector(SectorPortals[to_sector].Portal[p].Sector_To, to_sector, location, portal_new_frustum); // draw sector through portal
				}
			}
		}
	}
}

const long Portal::Point_Inside_Sector(const D3DXVECTOR3 *location, const int number)
{
	int plane_pos=Sector_Collision[number].Sector_Collision_Start_Pos;
	const int plane_count=Sector_Collision[number].Sector_Collision_Count;

	for (int x=0; x!=plane_count; ++x, ++plane_pos)
	{
		if (D3DXPlaneDotCoord(&Sector_Collision_Planes[plane_pos].Plane, location) <0.0f) // point is outside sector
		{
			return Sector_Collision_Planes[plane_pos].To_Sector;
		}
	}
	return true;
}

const void Portal::Move_Sphere_Inside_Sector(D3DXVECTOR3 &location, const D3DXVECTOR3 &direction, const float bounding_sphere, int &sector)
{
	int plane_pos=Sector_Collision[sector].Sector_Collision_Start_Pos;
	const int plane_count=Sector_Collision[sector].Sector_Collision_Count;
	const D3DXVECTOR3 to_location=location+direction;

	float smallest_dest_to_plane=bounding_sphere; // the smallest distance to the plane
	int smallest_dest_to_plane_pos;

	for (int x=0; x!=plane_count; ++x, ++plane_pos)
	{	
		const float dest_to_plane=D3DXPlaneDotCoord(&Sector_Collision_Planes[plane_pos].Plane, &to_location);
		if (Sector_Collision_Planes[plane_pos].To_Sector==SECTOR_WALL)
		{
			if (dest_to_plane<bounding_sphere) // sphere is outside sector - (to_dist lt bounding_sphere)
			{
				if (dest_to_plane<smallest_dest_to_plane) //if this point is nearer than the last nearest
				{
					smallest_dest_to_plane=dest_to_plane; // make this point the nearest 
					smallest_dest_to_plane_pos=plane_pos;
				}
			}
		}
		else // this is a portal
		{
			if (dest_to_plane<0.0f) // point is outside sector
			{
				sector=Sector_Collision_Planes[plane_pos].To_Sector; //				sector=Point_Inside_Sector(&location, Sector_Collision_Planes[plane_pos].To_Sector);
				location=to_location;
				return;
			}
		}
	}
	if (smallest_dest_to_plane!=bounding_sphere)
	{
		const float source_to_plane=D3DXPlaneDotCoord(&Sector_Collision_Planes[smallest_dest_to_plane_pos].Plane, &location) -D3DX_16F_EPSILON; // distance to wall
		const float scale=( (smallest_dest_to_plane-bounding_sphere) / (source_to_plane-smallest_dest_to_plane) ) ;
		const D3DXVECTOR3	diff=to_location-location;
		location=to_location + (diff * scale); // clip the point at the collision point
		return;
	}
	location=to_location;
}
 