#include "load.h"
#include "d3d8_screen.h"
#include "portal.h"

extern FILE *file;
extern Screen screen;
extern Portal portal;

void Load::Setup()
{
	fprintf(file, "Load setup\n");
}

Load::~Load()
{
	fprintf(file, "Load shutdown\n");
}

const void Load::Material(const char *name)
{
	if ((fileopen=fopen(name, "r"))==NULL) return;
	fscanf(fileopen, "%s", Rec);
	screen.Max_Material=atol(Rec);

	for (int x=0; x!=screen.Max_Material; ++x)
	{
		ZeroMemory(&screen.Material[x], sizeof(screen.Material[0])); 

		fscanf(fileopen, "%s", Rec);
		screen.Material[x].Diffuse.r=atof(Rec);
		fscanf(fileopen, "%s", Rec);
		screen.Material[x].Diffuse.g=atof(Rec);
		fscanf(fileopen, "%s", Rec);
		screen.Material[x].Diffuse.b=atof(Rec);
		fscanf(fileopen, "%s", Rec);
		screen.Material[x].Diffuse.a=atof(Rec);

		fscanf(fileopen, "%s", Rec);
		screen.Material[x].Ambient.r=atof(Rec);
		fscanf(fileopen, "%s", Rec);
		screen.Material[x].Ambient.g=atof(Rec);
		fscanf(fileopen, "%s", Rec);
		screen.Material[x].Ambient.b=atof(Rec);
		fscanf(fileopen, "%s", Rec);
		screen.Material[x].Ambient.a=atof(Rec);

		fscanf(fileopen, "%s", Rec);
		screen.Material[x].Specular.r=atof(Rec);
		fscanf(fileopen, "%s", Rec);
		screen.Material[x].Specular.g=atof(Rec);
		fscanf(fileopen, "%s", Rec);
		screen.Material[x].Specular.b=atof(Rec);
		fscanf(fileopen, "%s", Rec);
		screen.Material[x].Specular.a=atof(Rec);
		fprintf(file,"m %ld x %ld dr %f dg %f db %f da %f ar %f ag %f ab %f aa %f sr %f sg %f sb %f sa %f\n", screen.Max_Material,x,
			screen.Material[x].Diffuse.r,screen.Material[x].Diffuse.g,screen.Material[x].Diffuse.b,screen.Material[x].Diffuse.a,
			screen.Material[x].Ambient.r,screen.Material[x].Ambient.g,screen.Material[x].Ambient.b,screen.Material[x].Ambient.a,
			screen.Material[x].Specular.r,screen.Material[x].Specular.g,screen.Material[x].Specular.b,screen.Material[x].Specular.a);

	}
	fclose(fileopen);
}

const void Load::Model(const char *name, const int object)
{
	if ((fileopen=fopen(name, "r"))==NULL) return;

	fscanf(fileopen, "%s", Rec);
	const int vertices=atol(Rec);
	fscanf(fileopen, "%s", Rec);
	const int triangles=atol(Rec);

	fscanf(fileopen, "%s", Rec);
	const float Bounding_Sphere=atof(Rec);


	for (int x=0; x!=vertices; ++x)
	{
		fscanf(fileopen, "%s", Rec);
		screen.Vertex[x].Location.x=atof(Rec);
		fscanf(fileopen, "%s", Rec);
		screen.Vertex[x].Location.y=atof(Rec);
		fscanf(fileopen, "%s", Rec);
		screen.Vertex[x].Location.z=atof(Rec);

		fscanf(fileopen, "%s", Rec);
		const int red=atol(Rec);
		fscanf(fileopen, "%s", Rec);
		const int green=atol(Rec);
		fscanf(fileopen, "%s", Rec);
		const int blue=atol(Rec);
	//	screen.Vertex[x].Colour=D3DCOLOR_XRGB(red,green,blue);
//		fprintf(file," %f %f %f\n",screen.Vertex[x].Location.x,screen.Vertex[x].Location.y,screen.Vertex[x].Location.z);
	}

	for (int y=0, z=0; y!=triangles; ++y, z+=3)
	{
		fscanf(fileopen, "%s", Rec);
		screen.Index[z] =atol(Rec);
		fscanf(fileopen, "%s", Rec);
		screen.Index[z+1] =atol(Rec);
		fscanf(fileopen, "%s", Rec);
		screen.Index[z+2] =atol(Rec);
	}

	fclose(fileopen);
	screen.CreateObject(vertices, triangles, object, object&3);
}

void Load::Collision(const char *name, int &start_pos, int &count)
{
	fprintf(file,"load collision %s\n", name);
	start_pos=portal.Collision_Plane_Count;

	if ((fileopen=fopen(name, "r"))==NULL)
	{
		fprintf(file,"not found\n");
		return;
	}

	char rec[256];
	fscanf(fileopen, "%s", rec);
	count=atol(rec);
	for (int x=0; x!=count; ++x)
	{
		fscanf(fileopen, "%s", rec);
		portal.Sector_Collision_Planes[portal.Collision_Plane_Count].Plane.a=atof(rec);
		fscanf(fileopen, "%s", rec);
		portal.Sector_Collision_Planes[portal.Collision_Plane_Count].Plane.b=atof(rec);
		fscanf(fileopen, "%s", rec);
		portal.Sector_Collision_Planes[portal.Collision_Plane_Count].Plane.c=atof(rec);
		fscanf(fileopen, "%s", rec);
		portal.Sector_Collision_Planes[portal.Collision_Plane_Count].Plane.d=atof(rec);
		fscanf(fileopen, "%s", rec);
		portal.Sector_Collision_Planes[portal.Collision_Plane_Count].To_Sector=atol(rec); //todo change from all walls to include portals -1=wall
		fprintf(file,"load collision ts %ld %ld %ld\n", x, count, portal.Sector_Collision_Planes[portal.Collision_Plane_Count].To_Sector);
fprintf(file,"portal.Collision_Plane_Count %ld %f %f %f %f\n",portal.Collision_Plane_Count,portal.Sector_Collision_Planes[portal.Collision_Plane_Count].Plane.a,portal.Sector_Collision_Planes[portal.Collision_Plane_Count].Plane.b,portal.Sector_Collision_Planes[portal.Collision_Plane_Count].Plane.c,portal.Sector_Collision_Planes[portal.Collision_Plane_Count].Plane.d);

		++portal.Collision_Plane_Count;
	}
	fprintf(file,"load collision start %ld count %ld\n", start_pos, count);
}

const void Load::Map(const char *name)
{
	if ((fileopen=fopen(name, "r"))==NULL) return;
	portal.Collision_Plane_Count=0;

	int sector_face_point_index[256];

	fscanf(fileopen, "%s", Rec);
	const int sectors=atol(Rec); // room count

	portal.SectorPortals.resize(sectors);
	
fprintf(file,"sectors %4ld\n",sectors);

	for (int sector=0; sector!=sectors; ++sector)
	{
		SECTOR_PORTALS sector_portals;
		int index=0;

		fscanf(fileopen, "%s", Rec);
		const int sector_number=atol(Rec); // room number

		portal.Sector[sector_number].Model=sector_number;

		fscanf(fileopen, "%s", Rec);
		const int sector_points=atol(Rec); // room points

		fscanf(fileopen, "%s", Rec);
		const int sector_faces=atol(Rec); // room faces

		portal.Sector_Collision[sector_number].Sector_Collision_Start_Pos=portal.Collision_Plane_Count;
		portal.Sector_Collision[sector_number].Sector_Collision_Count=sector_faces;

		for (int sector_point=0; sector_point!=sector_points; ++sector_point) // read all room points
		{
			fscanf(fileopen, "%s", Rec);
			screen.Vertex[sector_point].Location.x=atof(Rec);
			fscanf(fileopen, "%s", Rec);
			screen.Vertex[sector_point].Location.y=atof(Rec);
			fscanf(fileopen, "%s", Rec);
			screen.Vertex[sector_point].Location.z=atof(Rec);

			fscanf(fileopen, "%s", Rec);
			const int red=atol(Rec);
			fscanf(fileopen, "%s", Rec);
			const int green=atol(Rec);
			fscanf(fileopen, "%s", Rec);
			const int blue=atol(Rec);
		}
		for (int sector_face=0; sector_face!=sector_faces; ++sector_face) // read all room faces
		{
			fscanf(fileopen, "%s", Rec);
			const long sector_face_type=atol(Rec); // face type (-1 = wall, not -1 then its the room number that this portal is pointing to)

			fscanf(fileopen, "%s", Rec);
			const int sector_face_points=atol(Rec); // face points

			for (int sector_face_point=0; sector_face_point!=sector_face_points; ++sector_face_point) // read all room face points
			{
				fscanf(fileopen, "%s", Rec);
				sector_face_point_index[sector_face_point]=atol(Rec);
			}

			D3DXPlaneFromPoints(&portal.Sector_Collision_Planes[portal.Collision_Plane_Count].Plane, &screen.Vertex[sector_face_point_index[0]].Location, &screen.Vertex[sector_face_point_index[1]].Location, &screen.Vertex[sector_face_point_index[2]].Location);
			portal.Sector_Collision_Planes[portal.Collision_Plane_Count].To_Sector=sector_face_type;
			++portal.Collision_Plane_Count;

			if (sector_face_type!=SECTOR_WALL) // if room face type is portal
			{
				PORTAL_POINTS portal_points;
				portal_points.Sector_From=sector_number;
				portal_points.Sector_To=sector_face_type;

				for (int sector_face_point=0; sector_face_point!=sector_face_points; ++sector_face_point) // read all room face points
				{
					portal_points.Point.push_back(screen.Vertex[sector_face_point_index[sector_face_point]].Location);
				}
				sector_portals.Portal.push_back(portal_points);
			}
			else
			{
				for (int t=0; t!=sector_face_points-2; ++t) //	convert face into triangles and add triangle to index
				{
					screen.Index[index] =sector_face_point_index[0];
					screen.Index[index+1] =sector_face_point_index[t+1];
					screen.Index[index+2] =sector_face_point_index[t+2];
					index+=3;
				}
			}
		}
		screen.CreateObject(sector_points, index/3, sector_number, sector_number&3); // add room as an object

		portal.SectorPortals[sector_number]=sector_portals;
	}
	fclose(fileopen);
}
