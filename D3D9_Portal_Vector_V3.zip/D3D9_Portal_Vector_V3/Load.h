#ifndef LOAD
#define LOAD

#include <stdio.h>
#include "portal.h"

class Load
{
	FILE	*fileopen;
	char Rec[256];

public:
	void	Setup();
	~Load();
	const void Model(const char *, const int);
	void Collision(const char *, int &, int &);
	const void Map(const char *);
	const void Material(const char *);

};

#endif
