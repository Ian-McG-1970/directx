#ifndef PORTAL
#define PORTAL

#include <stdio.h>
#include "d3d8_screen.h"
#include <vector>

#define MAX_SECTORS 256
#define MAX_SECTOR_PORTALS 256
#define MAX_PORTAL_POINTS 65535

typedef struct
{
	int Model; // object to be drawn
} SECTOR;

typedef struct
{
	int Sector_Collision_Count; // number of planes in sector
	int Sector_Collision_Start_Pos; // pointer to first plane in sector
} SECTOR_COLLISION;

typedef struct
{
	D3DXPLANE Plane; // the plane
	int To_Sector; // sector through this plane (-1 = solid wall, else sector number to go through)
} SECTOR_COLLISION_PLANE;

#define SECTOR_WALL -1
#define PORTAL_POINTS_OUTSIDE_FRUSTUM -1
#define PORTAL_POINTS_INSIDE_FRUSTUM 0

typedef struct
{
	std::vector<D3DXVECTOR3> Point;
	int Sector_From;
	int Sector_To;
} PORTAL_POINTS;

typedef struct
{
	std::vector<PORTAL_POINTS> Portal;
} SECTOR_PORTALS;

class Portal
{
private:
	const long Test_Portal_Against_Frustum(const std::vector<D3DXVECTOR3>, const std::vector<D3DXPLANE>);
	const std::vector<D3DXVECTOR3> Clip_Portal_To_Frustum(const std::vector<D3DXVECTOR3>, const std::vector<D3DXPLANE>, const int);
	std::vector<D3DXVECTOR3> Clip_Portal_To_Frustum_Plane(std::vector<D3DXVECTOR3>, const D3DXPLANE &, const int);
	const void Set_Clip_Planes(const std::vector<D3DXPLANE> &);
	const std::vector<D3DXPLANE> Create_Frustum_From_Portal(std::vector<D3DXVECTOR3>);

public:
	SECTOR Sector[MAX_SECTORS];

	const void Reset_Frustum();
	const void Draw_Sector(const int, const int, const D3DXVECTOR3 &, std::vector<D3DXPLANE>);
	const long Point_Inside_Sector(const D3DXVECTOR3 *, const int);
	const void Move_Sphere_Inside_Sector(D3DXVECTOR3 &, const D3DXVECTOR3 &, const float, int &);

	std::vector<D3DXPLANE> Portal_Frustum;

	SECTOR_COLLISION Sector_Collision[MAX_SECTORS];
	SECTOR_COLLISION_PLANE Sector_Collision_Planes[MAX_PORTAL_POINTS];
	int Collision_Plane_Count;
	int Curr_Sector;

	const void Setup();
	~Portal();
	std::vector<SECTOR_PORTALS> SectorPortals;
};

#endif
