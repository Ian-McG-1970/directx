
#include "d3d8_screen.h"
#include "quake3bsp.h"

extern FILE *file;
extern Screen screen;

#define	CONTENTS_PLAYERCLIP	0x10000

CQuake3BSP::CQuake3BSP() //	This is our object's constructor to initial all it's data members
{
	// Here we simply initialize our member variables to 0

	// Initialize all the dynamic BSP data pointers to NULL
	Q2_m_numOfVerts =0;
	Q2_m_pVerts = NULL;
	Q2_m_numOfEdges =0;
	Q2_m_pEdges = NULL;
	Q2_m_numOfLeafs =0;
	Q2_m_numOfNodes =0;
	Q2_m_pNodes = NULL;
	Q2_m_numOfLeafFaces =0;
	Q2_m_pLeafFaces = NULL;
	Q2_m_numOfFaceEdges =0;
	Q2_m_pFaceEdges = NULL;
	Q2_m_numOfPlanes =0;
	Q2_Planes_D3D = NULL;
	Q2_Cluster_Bitmap =NULL;
	Q2_cluster_leafs = NULL;
	Q2_cluster_leaf_list = NULL;
	Q2_m_pBrushes = NULL;
	Q2_m_pLeafBrushes =NULL;
	Q2_m_pBrusheSides =NULL;
	Q2_m_pTextures =NULL;
}

const D3DXVECTOR3 CQuake3BSP::FlipPoint(const D3DXVECTOR3 &point) // Swap the y and z values, and negate the new z so Y is up.
{
	return D3DXVECTOR3(point.x, point.z, point.y); 
}

const point3s CQuake3BSP::FlipPoint(const point3s &point)
{
	const D3DXVECTOR3 flipped_point=FlipPoint(D3DXVECTOR3(point.x,point.y,point.z));
	point3s flip_point;
	flip_point.x=flipped_point.x;
	flip_point.y=flipped_point.y;
	flip_point.z=flipped_point.z;
	return flip_point;
}

const int CQuake3BSP::LoadLump(FILE *fp, const int count, const int offset, void *dest, const int stride) // This loads in a lump of data
{
	fseek(fp, offset, SEEK_SET);
	fread(dest, stride, count, fp);
	return count;
}

const bool CQuake3BSP::LoadQ2BSP(const char *strFileName) // This loads in all of the .bsp data for the level
{
	fprintf(file,"loadQ2bsp %s\n",strFileName);

	FILE *fp;
	if((fp = fopen(strFileName,"rb"))==NULL) // Check if the .bsp file could be opened
	{
		fprintf(file,"bsp not found\n");
		return false;
	}

	Q2_dheader_t header; // Initialize the header and lump structures
	fread(&header,1,sizeof(Q2_dheader_t),fp); // Read in the header and lump data

	Q2_m_pVerts = new Q2_dvertex_t[header.lumps[Q2_LUMP_VERTEXES].length / sizeof(Q2_dvertex_t)];
	Q2_m_numOfVerts = LoadLump(fp,header.lumps[Q2_LUMP_VERTEXES].length / sizeof(Q2_dvertex_t),header.lumps[Q2_LUMP_VERTEXES].offset,&Q2_m_pVerts[0],sizeof(Q2_dvertex_t));
	for (int v=0; v!=Q2_m_numOfVerts; ++v) // Go through all of the vertices that need to be read and swap axises
	{
		Q2_m_pVerts[v].point = FlipPoint(Q2_m_pVerts[v].point);
	}

	Q2_m_pEdges = new Q2_dedge_t[header.lumps[Q2_LUMP_EDGES].length / sizeof(Q2_dedge_t)];
	Q2_m_numOfEdges = LoadLump(fp,header.lumps[Q2_LUMP_EDGES].length / sizeof(Q2_dedge_t),header.lumps[Q2_LUMP_EDGES].offset,&Q2_m_pEdges[0],sizeof(Q2_dedge_t));

	Q2_m_pFaces = new Q2_dface_t[header.lumps[Q2_LUMP_FACES].length / sizeof(Q2_dface_t)];
	Q2_m_numOfFaces = LoadLump(fp,header.lumps[Q2_LUMP_FACES].length / sizeof(Q2_dface_t),header.lumps[Q2_LUMP_FACES].offset,&Q2_m_pFaces[0],sizeof(Q2_dface_t));

	Q2_dleaf_t *Q2_m_pLeafs = new Q2_dleaf_t[header.lumps[Q2_LUMP_LEAFS].length / sizeof(Q2_dleaf_t)];
	Q2_m_numOfLeafs = LoadLump(fp,header.lumps[Q2_LUMP_LEAFS].length / sizeof(Q2_dleaf_t),header.lumps[Q2_LUMP_LEAFS].offset,&Q2_m_pLeafs[0],sizeof(Q2_dleaf_t));

	Q2_m_pLeafs_D3D = new Q2_D3D_dleaf_t[Q2_m_numOfLeafs];
	for (int l=0; l!=Q2_m_numOfLeafs; ++l) // Go through all of the vertices that need to be read and swap axises
	{
		Q2_m_pLeafs_D3D[l].area = Q2_m_pLeafs[l].area;
		Q2_m_pLeafs_D3D[l].cluster = Q2_m_pLeafs[l].cluster;
		Q2_m_pLeafs_D3D[l].contents = Q2_m_pLeafs[l].contents;
		Q2_m_pLeafs_D3D[l].firstleafbrush = Q2_m_pLeafs[l].firstleafbrush;
		Q2_m_pLeafs_D3D[l].firstleafface = Q2_m_pLeafs[l].firstleafface;
		Q2_m_pLeafs_D3D[l].numleafbrushes = Q2_m_pLeafs[l].numleafbrushes;
		Q2_m_pLeafs_D3D[l].numleaffaces = Q2_m_pLeafs[l].numleaffaces;

		Q2_m_pLeafs[l].mins=FlipPoint(Q2_m_pLeafs[l].mins);
		Q2_m_pLeafs[l].maxs=FlipPoint(Q2_m_pLeafs[l].maxs);

		Q2_m_pLeafs_D3D[l].bounding_box[0] = D3DXVECTOR3(Q2_m_pLeafs[l].mins.x,Q2_m_pLeafs[l].mins.y,Q2_m_pLeafs[l].mins.z);
		Q2_m_pLeafs_D3D[l].bounding_box[1] = D3DXVECTOR3(Q2_m_pLeafs[l].maxs.x,Q2_m_pLeafs[l].mins.y,Q2_m_pLeafs[l].mins.z);
		Q2_m_pLeafs_D3D[l].bounding_box[2] = D3DXVECTOR3(Q2_m_pLeafs[l].mins.x,Q2_m_pLeafs[l].maxs.y,Q2_m_pLeafs[l].mins.z);
		Q2_m_pLeafs_D3D[l].bounding_box[3] = D3DXVECTOR3(Q2_m_pLeafs[l].maxs.x,Q2_m_pLeafs[l].maxs.y,Q2_m_pLeafs[l].mins.z);
		Q2_m_pLeafs_D3D[l].bounding_box[4] = D3DXVECTOR3(Q2_m_pLeafs[l].mins.x,Q2_m_pLeafs[l].mins.y,Q2_m_pLeafs[l].maxs.z);
		Q2_m_pLeafs_D3D[l].bounding_box[5] = D3DXVECTOR3(Q2_m_pLeafs[l].maxs.x,Q2_m_pLeafs[l].mins.y,Q2_m_pLeafs[l].maxs.z);
		Q2_m_pLeafs_D3D[l].bounding_box[6] = D3DXVECTOR3(Q2_m_pLeafs[l].mins.x,Q2_m_pLeafs[l].maxs.y,Q2_m_pLeafs[l].maxs.z);
		Q2_m_pLeafs_D3D[l].bounding_box[7] = D3DXVECTOR3(Q2_m_pLeafs[l].maxs.x,Q2_m_pLeafs[l].maxs.y,Q2_m_pLeafs[l].maxs.z);
	}

	Q2_m_pNodes = new Q2_dnode_t[header.lumps[Q2_LUMP_NODES].length / sizeof(Q2_dnode_t)];
	Q2_m_numOfNodes = LoadLump(fp,header.lumps[Q2_LUMP_NODES].length / sizeof(Q2_dnode_t),header.lumps[Q2_LUMP_NODES].offset,&Q2_m_pNodes[0],sizeof(Q2_dnode_t));

	Q2_m_pLeafFaces = new uint16_t[header.lumps[Q2_LUMP_LEAFFACES].length / sizeof(uint16_t)];
	Q2_m_numOfLeafFaces = LoadLump(fp,header.lumps[Q2_LUMP_LEAFFACES].length / sizeof(uint16_t),header.lumps[Q2_LUMP_LEAFFACES].offset,&Q2_m_pLeafFaces[0],sizeof(uint16_t));

	Q2_m_pFaceEdges = new int32_t[header.lumps[Q2_LUMP_SURFEDGES].length / sizeof(int32_t)];
	Q2_m_numOfFaceEdges = LoadLump(fp,header.lumps[Q2_LUMP_SURFEDGES].length / sizeof(int32_t),header.lumps[Q2_LUMP_SURFEDGES].offset,&Q2_m_pFaceEdges[0],sizeof(int32_t));

	Q2_dplane_t *Q2_m_pPlanes = new Q2_dplane_t[header.lumps[Q2_LUMP_PLANES].length / sizeof(Q2_dplane_t)];
	Q2_m_numOfPlanes = LoadLump(fp,header.lumps[Q2_LUMP_PLANES].length / sizeof(Q2_dplane_t),header.lumps[Q2_LUMP_PLANES].offset,&Q2_m_pPlanes[0],sizeof(Q2_dplane_t));

	Q2_Planes_D3D = new D3DXPLANE[Q2_m_numOfPlanes];
	for (int p=0; p!=Q2_m_numOfPlanes; ++p) // Go through every plane and convert it's normal to the Y-axis being up
	{
		Q2_m_pPlanes[p].normal.point=FlipPoint(Q2_m_pPlanes[p].normal.point);
		Q2_Planes_D3D[p] = D3DXPLANE(Q2_m_pPlanes[p].normal.point.x,Q2_m_pPlanes[p].normal.point.y,Q2_m_pPlanes[p].normal.point.z,-Q2_m_pPlanes[p].dist);
	}


	Q2_m_pBrushes = new Q2_dbrush_t[header.lumps[Q2_LUMP_BRUSHES].length / sizeof(Q2_dbrush_t)];
	Q2_m_numOfBrushes = LoadLump(fp,header.lumps[Q2_LUMP_BRUSHES].length / sizeof(Q2_dbrush_t),header.lumps[Q2_LUMP_BRUSHES].offset,&Q2_m_pBrushes[0],sizeof(Q2_dbrush_t));

	Q2_m_pLeafBrushes = new uint16_t[header.lumps[Q2_LUMP_LEAFBRUSHES].length / sizeof(uint16_t)];
	Q2_m_numOfLeafBrushes = LoadLump(fp,header.lumps[Q2_LUMP_LEAFBRUSHES].length / sizeof(uint16_t),header.lumps[Q2_LUMP_LEAFBRUSHES].offset,&Q2_m_pLeafBrushes[0],sizeof(uint16_t));

	Q2_m_pBrusheSides = new Q2_dbrushside_t[header.lumps[Q2_LUMP_BRUSHSIDES].length / sizeof(Q2_dbrushside_t)];
	Q2_m_numOfBrusheSides = LoadLump(fp,header.lumps[Q2_LUMP_BRUSHSIDES].length / sizeof(Q2_dbrushside_t),header.lumps[Q2_LUMP_BRUSHSIDES].offset,&Q2_m_pBrusheSides[0],sizeof(Q2_dbrushside_t));

	Q2_m_pTextures = new Q2_texinfo_t[header.lumps[Q2_LUMP_TEXINFO].length / sizeof(Q2_texinfo_t)];
	Q2_m_numOfTextures = LoadLump(fp,header.lumps[Q2_LUMP_TEXINFO].length / sizeof(Q2_texinfo_t),header.lumps[Q2_LUMP_TEXINFO].offset,&Q2_m_pTextures[0],sizeof(Q2_texinfo_t));

	if (header.lumps[Q2_LUMP_VISIBILITY].length!=0) // Check if there is any visibility information first
	{
		BYTE *map_visibility = new BYTE[header.lumps[Q2_LUMP_VISIBILITY].length];
		LoadLump(fp,header.lumps[Q2_LUMP_VISIBILITY].length / sizeof(map_visibility[0]),header.lumps[Q2_LUMP_VISIBILITY].offset,&map_visibility[0],sizeof(map_visibility[0]));

		Q2_dvis_t *map_vis;
		map_vis = (Q2_dvis_t *)map_visibility;

		BYTE *Q2_Uncompressed_Vis = new BYTE[map_vis->numclusters*map_vis->numclusters];
		Q2_Cluster_Bitmap = new BYTE *[map_vis->numclusters];

		for (int c=0; c!=map_vis->numclusters; ++c)
		{
			Q2_Cluster_Bitmap[c]=&Q2_Uncompressed_Vis[map_vis->numclusters*c];
			DecompressVis2(&map_visibility[map_vis->bitofs[c][0]], &Q2_Cluster_Bitmap[c][0], map_vis->numclusters);
		}

		Q2_cluster_leafs = new cluster_leaf[map_vis->numclusters];
		Q2_cluster_leaf_list = new Q2_D3D_dleaf_t *[map_vis->numclusters*Q2_m_numOfLeafs];

		for (int from_cluster=0; from_cluster!=map_vis->numclusters; ++from_cluster)
		{
			Q2_cluster_leafs[from_cluster].start=Q2_m_numOfLeafs*from_cluster; // start position from this cluster
			Q2_cluster_leafs[from_cluster].count=0; // reset clusters to draw

			for (int to_leaf=0; to_leaf!=Q2_m_numOfLeafs; ++to_leaf)
			{
				const int to_cluster = Q2_m_pLeafs_D3D[to_leaf].cluster;
				if ((IsQ2ClusterVisible2(from_cluster, to_cluster)) || (from_cluster==to_cluster)) // cluster is in view
				{
					Q2_cluster_leaf_list[(Q2_cluster_leafs[from_cluster].start+Q2_cluster_leafs[from_cluster].count)]=&Q2_m_pLeafs_D3D[to_leaf]; // add leaf to cluster draw list
					++Q2_cluster_leafs[from_cluster].count; // increment cluster draw list
				}
			}
		}
		delete [] map_visibility;
		delete [] Q2_Uncompressed_Vis;
	}

	delete [] Q2_m_pLeafs;
	delete [] Q2_m_pPlanes;

	fprintf(file,"bspheader %i %i %i %i\n",IDBSPHEADER,BSPVERSION,header.ident,header.version);
	fprintf(file,"Q2_m_numOfVerts %i %i\n",Q2_m_numOfVerts,header.lumps[Q2_LUMP_VERTEXES].length);
	fprintf(file,"Q2_m_numOfEdges %i %i\n",Q2_m_numOfEdges,header.lumps[Q2_LUMP_EDGES].length);
	fprintf(file,"Q2_m_numOfFaces %i %i\n",Q2_m_numOfFaces,header.lumps[Q2_LUMP_FACES].length);
	fprintf(file,"Q2_m_numOfLeafs %i %i\n",Q2_m_numOfLeafs,header.lumps[Q2_LUMP_LEAFS].length);
	fprintf(file,"Q2_m_numOfNodes %i %i\n",Q2_m_numOfNodes,header.lumps[Q2_LUMP_NODES].length);
	fprintf(file,"Q2_m_numOfLeafFaces %i %i\n",Q2_m_numOfLeafFaces,header.lumps[Q2_LUMP_LEAFFACES].length);
	fprintf(file,"Q2_m_numOfFaceEdges %i %i\n",Q2_m_numOfFaceEdges,header.lumps[Q2_LUMP_SURFEDGES].length);
	fprintf(file,"Q2_vis %i %i\n",header.lumps[Q2_LUMP_VISIBILITY].length,header.lumps[Q2_LUMP_VISIBILITY].offset);

	for (int l=0; l!=Q2_m_numOfLeafs; ++l)
	{
		fprintf(file,"l %i c %x nlb %i\n", l, Q2_m_pLeafs_D3D[l].contents, Q2_m_pLeafs_D3D[l].numleafbrushes);
	}

	return true;
}

const void CQuake3BSP::DecompressVis2(const BYTE *in, BYTE *out, const int numclusters)
{
	memset(&out[0],0,numclusters);
	for (int u=0, v=0; u<numclusters; ++v)
	{
		if (in[v]==0)
		{
			++v;
			u += 8*in[v];
		}
		else
		{
			for (BYTE ucBit=1; ucBit!=0; ucBit<<=1, ++u)
			{
				if (in[v] & ucBit)
				{
					out[u]=1;
				}
			}
		}
	}
}

const void CQuake3BSP::RenderQ2LeafPoly(const Q2_D3D_dleaf_t *leaf)
{
	const int first_leaf_face=leaf->firstleafface;
	const int last_leaf_face=first_leaf_face+leaf->numleaffaces;

	for(int leaf_face=first_leaf_face; leaf_face!=last_leaf_face; ++leaf_face)
	{
		const int face=Q2_m_pLeafFaces[leaf_face];

		const int first_face_edge=Q2_m_pFaces[face].firstedge;
		const int last_face_edge=first_face_edge+Q2_m_pFaces[face].numedges;

		int pc=0;
		for(int face_edge=first_face_edge; face_edge!=last_face_edge; ++face_edge)
		{
			const int face_edge_index=Q2_m_pFaceEdges[face_edge];
			const int p0= (face_edge_index <0) ? Q2_m_pEdges[-face_edge_index].v[1] : Q2_m_pEdges[face_edge_index].v[0];
			Q2_p[pc++] = Q2_m_pVerts[p0].point;
		}
		const D3DXCOLOR colour = (Q2_m_pFaces[face].texinfo<<17)+(Q2_m_pFaces[face].texinfo<<10)+(Q2_m_pFaces[face].texinfo<<3);
		screen.Polygon(&Q2_p[0],pc,colour);
	}
}

const void CQuake3BSP::RenderQ2Level2(const int cluster) //	Goes through all of the faces and draws them if the type is FACE_POLYGON
{
	const int start = Q2_cluster_leafs[cluster].start;
	const int count = Q2_cluster_leafs[cluster].count;
	for(int x=0; x!=count; ++x)
	{
		const Q2_D3D_dleaf_t *pLeaf = Q2_cluster_leaf_list[start+x]; // Get the current leaf that is to be tested for visibility from our camera's leaf
		if (screen.IsBoxInsideFrustum(&pLeaf->bounding_box[0]))
		{
			RenderQ2LeafPoly(pLeaf);
		}
	}
}

const int CQuake3BSP::FindQ2Leaf(const D3DXVECTOR3 &pos) // This returns the leaf our camera is in
{
	int i=0;
	while (i>=0) // Continue looping until we find a negative index
	{
		const Q2_dnode_t &node = Q2_m_pNodes[i]; // Get the current node, then find the slitter plane from that node's plane index.
		const D3DXPLANE &D3Dplane = Q2_Planes_D3D[node.plane];

		const float distance = D3DXPlaneDotCoord(&D3Dplane,&pos);
		if (distance>=0) // If the camera is in front of the plane
		{
			i = node.children[0]; // Assign the current node to the node in front of itself
		}
		else // Else if the camera is behind the plane
		{
			i = node.children[1]; // Assign the current node to the node behind itself
		}
	}
	return ~i; // Return the leaf index (same thing as saying:  return -(i + 1)).
}

const int CQuake3BSP::FindQ2Cluster(const int leaf) // This returns the leaf our camera is in
{
	return Q2_m_pLeafs_D3D[leaf].cluster;
}

const int CQuake3BSP::IsQ2ClusterVisible2(const int &current,const int &test)
{
	return Q2_Cluster_Bitmap[current][test];
}

CQuake3BSP::~CQuake3BSP() //	This is our deconstructor that is called when the object is destroyed
{
	if(Q2_m_pVerts)
	{
		delete[] Q2_m_pVerts;
		Q2_m_pVerts = NULL;
	}
	if (Q2_m_pEdges)
	{
		delete[] Q2_m_pEdges;
		Q2_m_pEdges = NULL;
	}
	if (Q2_m_pFaces)
	{
		delete[] Q2_m_pFaces;
		Q2_m_pFaces = NULL;
	}
	if (Q2_m_pNodes)
	{
		delete[] Q2_m_pNodes;
		Q2_m_pNodes = NULL;
	}
	if (Q2_m_pLeafFaces)
	{
		delete[] Q2_m_pLeafFaces;
		Q2_m_pLeafFaces = NULL;
	}
	if (Q2_m_pFaceEdges)
	{
		delete[] Q2_m_pFaceEdges;
		Q2_m_pFaceEdges = NULL;
	}
	if (Q2_m_pLeafs_D3D)
	{
		delete[] Q2_m_pLeafs_D3D;
		Q2_m_pLeafs_D3D = NULL;
	}
	if (Q2_Planes_D3D)
	{
		delete[] Q2_Planes_D3D;
		Q2_Planes_D3D = NULL;
	}
	if (Q2_Cluster_Bitmap)
	{
		delete [] Q2_Cluster_Bitmap;
		Q2_Cluster_Bitmap = NULL;
	}
	if (Q2_cluster_leafs)
	{
		delete [] Q2_cluster_leafs;
		Q2_cluster_leafs = NULL;
	}
	if (Q2_cluster_leaf_list)
	{
		delete [] Q2_cluster_leaf_list;
		Q2_cluster_leaf_list = NULL;
	}
	if (Q2_m_pLeafBrushes)
	{
		delete [] Q2_m_pLeafBrushes;
		Q2_m_pLeafBrushes = NULL;
	}
	if (Q2_m_pBrusheSides)
	{
		delete [] Q2_m_pBrusheSides;
		Q2_m_pBrusheSides = NULL;
	}
	if (Q2_m_pBrushes)
	{
		delete [] Q2_m_pBrushes;
		Q2_m_pBrushes = NULL;
	}
	if (Q2_m_pTextures)
	{
		delete[] Q2_m_pTextures;
		Q2_m_pTextures = NULL;
	}
}

const D3DXVECTOR3 CQuake3BSP::Start(const D3DXVECTOR3& extent)
{
	const D3DXVECTOR3 size = extent*2.0f;
	for (int l=0; l!=Q2_m_numOfLeafs; ++l)
	{
		if (Q2_m_pLeafs_D3D[l].area<=0) continue;

		const D3DXVECTOR3 bounding_box = Q2_m_pLeafs_D3D[l].bounding_box[7]-Q2_m_pLeafs_D3D[l].bounding_box[0];
		
		if ((size.x > bounding_box.x) || (size.y > bounding_box.y) || (size.z > bounding_box.z)) continue;

		fprintf(file,"start l %i a %i e %f %f %f s %f %f %f bb %f %f %f mn %f %f %f mx %f %f %f\n",
				l,Q2_m_pLeafs_D3D[l].area,
				extent.x,extent.y,extent.z,size.x,size.y,size.z,
				bounding_box.x,bounding_box.y,bounding_box.z,
				Q2_m_pLeafs_D3D[l].bounding_box[0].x,Q2_m_pLeafs_D3D[l].bounding_box[0].y,Q2_m_pLeafs_D3D[l].bounding_box[0].z,
				Q2_m_pLeafs_D3D[l].bounding_box[7].x,Q2_m_pLeafs_D3D[l].bounding_box[7].y,Q2_m_pLeafs_D3D[l].bounding_box[7].z);

		return (Q2_m_pLeafs_D3D[l].bounding_box[7]+Q2_m_pLeafs_D3D[l].bounding_box[0])*0.5f;
	}
}

// ------------------------------------------------------------//  Movement clipping// ------------------------------------------------------------

const Q3Move CQuake3BSP::checkMove(const D3DXVECTOR3& start,const D3DXVECTOR3& end,const D3DXVECTOR3& extent)
{
	moveMove.size = extent*0.5f;
	moveMove.start = start;
	moveMove.end = end;			// If nothing is hit, full movement by default
	moveMove.fraction = 1.0f;
	moveMove.allSolid = false;
	checkMoveNode(0.0f,1.0f,start,end,0.0f);		// Calculate final coordinates
	if(moveMove.fraction < 1.0f)
	{
		moveMove.end = start + moveMove.fraction*(end - start);
	}
	return moveMove;
}

#define	CONTENTS_SOLID			1		// an eye is never valid in a solid
#define	CONTENTS_WINDOW			2		// translucent, but not watery
#define	CONTENTS_AUX			4
#define	CONTENTS_LAVA			8
#define	CONTENTS_SLIME			16
#define	CONTENTS_WATER			32
#define	CONTENTS_MIST			64
#define	LAST_VISIBLE_CONTENTS	64

// remaining contents are non-visible, and don't eat brushes

#define	CONTENTS_AREAPORTAL		0x8000
#define	CONTENTS_PLAYERCLIP		0x10000
#define	CONTENTS_MONSTERCLIP	0x20000

// currents can be added to any other contents, and may be mixed
#define	CONTENTS_CURRENT_0		0x40000
#define	CONTENTS_CURRENT_90		0x80000
#define	CONTENTS_CURRENT_180	0x100000
#define	CONTENTS_CURRENT_270	0x200000
#define	CONTENTS_CURRENT_UP		0x400000
#define	CONTENTS_CURRENT_DOWN	0x800000
#define	CONTENTS_ORIGIN			0x1000000	// removed before bsping an entity
#define	CONTENTS_MONSTER		0x2000000	// should never be on a brush, only in game
#define	CONTENTS_DEADMONSTER	0x4000000
#define	CONTENTS_DETAIL			0x8000000	// brushes to be added after vis leafs
#define	CONTENTS_TRANSLUCENT	0x10000000	// auto set if any surface has trans
#define	CONTENTS_LADDER			0x20000000


const void CQuake3BSP::checkMoveNode(const float sf,const float ef,const D3DXVECTOR3& sp,const D3DXVECTOR3& ep,const int node)
{
	if(moveMove.fraction < sf) // If the path was blocked by a nearer obstacle, don't bother checking
	{
		return;
	}
	if(node < 0) // We found a leaf, check the whole path against its brushes
	{
		checkMoveLeaf(-(node + 1));
		return;
	}

	const D3DXPLANE& D3Dplane = Q2_Planes_D3D[Q2_m_pNodes[node].plane];
	const float t1 = D3DXPlaneDotCoord(&D3Dplane,&sp);
	const float t2 = D3DXPlaneDotCoord(&D3Dplane,&ep);
	const float offset = fabs(moveMove.size.x*D3Dplane.a) + fabs(moveMove.size.y*D3Dplane.b) + fabs(moveMove.size.z*D3Dplane.c);

	if((t1 >= offset) && (t2 >= offset)) // The whole volume is in front of the plane
	{
		checkMoveNode(sf,ef,sp,ep,Q2_m_pNodes[node].children[Q3_FRONT]);
		return;
	}

	if((t1 < -offset) && (t2 < -offset)) // The whole volume is in the back of the plane
	{
		checkMoveNode(sf,ef,sp,ep,Q2_m_pNodes[node].children[Q3_BACK]);
		return;
	}

	// Else, the box is split. Check the two halves.
	int side;
	float frac,frac2;

	if(t1 < t2)
	{
		side  = Q3_BACK;
		const float idist = 1.0f / (t1 - t2);
		frac  = (t1 - offset - DIST_EPSILON) * idist;
		frac2 = (t1 + offset + DIST_EPSILON) * idist;
	}
	else if(t1 > t2)
	{
		side  = Q3_FRONT;
		const float idist = 1.0f / (t1 - t2);
		frac  = (t1 + offset + DIST_EPSILON) * idist;
		frac2 = (t1 - offset - DIST_EPSILON) * idist;
	}
	else
	{
		side  = Q3_FRONT;
		frac  = 1.0f;
		frac2 = 0.0f;
	}

	if(frac < 0.0f)
	{
		frac = 0.0f;
	}
	else if(frac > 1.0f)
	{
		frac = 1.0f;
	}
	float midf = sf + (ef - sf)*frac; // Move from start to the plane
	D3DXVECTOR3 midp = sp + frac*(ep - sp);
	checkMoveNode(sf,midf,sp,midp,Q2_m_pNodes[node].children[side]);

	midf = sf + (ef - sf)*frac2; // Move from the plane to the end
	midp = sp + frac2*(ep - sp);
	checkMoveNode(midf,ef,midp,ep,Q2_m_pNodes[node].children[1-side]);
}

#define TRACE_CONTENTS (CONTENTS_SOLID)//|CONTENTS_PLAYERCLIP|CONTENTS_WINDOW|CONTENTS_MONSTER)

const void CQuake3BSP::checkMoveLeaf(const int leaf)
{
	const int leaf_contents = Q2_m_pLeafs_D3D[leaf].contents;
//	if ((leaf_contents & TRACE_CONTENTS)) return;

	const int bb = Q2_m_pLeafs_D3D[leaf].firstleafbrush;
	int bc = Q2_m_pLeafs_D3D[leaf].numleafbrushes;
	while(bc--)
	{
		const int bi = Q2_m_pLeafBrushes[bb+bc];
		const Q2_dbrush_t& brush = Q2_m_pBrushes[bi];
		if (brush.numsides == 0) continue;

		const int brush_contents = brush.contents;
//		if ((brush_contents & TRACE_CONTENTS)) continue;

		const int sb = brush.firstside;
		int sc = brush.numsides;
		float enterf = -1.0f;
		float exitf = 1.0f;
		bool startOut = false;
		bool endOut = false;
		bool fullOut = false;
		D3DXVECTOR3 hitNormal;
		while(sc--)
		{
			const int pi = Q2_m_pBrusheSides[sb+sc].planenum; // if (!(m_pBrushSides[sb+sc].content >=0)) continue;
			const D3DXPLANE& planeD3D = Q2_Planes_D3D[pi];

			D3DXVECTOR3 ofs = -moveMove.size; // Calculate distances, taking the bounding box dimensions into account
			if(planeD3D.a < 0.0f)
			{
				ofs.x = -ofs.x;
			}
			if(planeD3D.b < 0.0f)
			{
				ofs.y = -ofs.y;
			}
			if(planeD3D.c < 0.0f)
			{
				ofs.z = -ofs.z;
			}
			const D3DXVECTOR3 plane_normal = D3DXVECTOR3(planeD3D.a,planeD3D.b,planeD3D.c);
			const float dist = D3DXVec3Dot(&ofs,&plane_normal) + planeD3D.d;
			const float d1 = D3DXVec3Dot(&moveMove.start,&plane_normal) + dist;
			const float d2 = D3DXVec3Dot(&moveMove.end,&plane_normal) + dist;
			if(d1 >= -DIST_EPSILON)
			{
				startOut = true;
			}
			if(d2 >= -DIST_EPSILON)
			{
				endOut = true;
			}

			if((d1 > 0.0f) && (d2 >= d1)) // Both in front of face : outside this brush
			{
				fullOut = true;
				break;
			}

			if((d1 <= 0.0f) && (d2 <= 0.0f)) // Both behind the face : will get clipped by another plane
			{
				continue;
			}

			if(d1 > d2) // Entering the brush
			{
				const float f = (d1 - DIST_EPSILON) / (d1 - d2);
				if(f > enterf)
				{
					enterf = f;
					hitNormal = plane_normal;
				}
			}
			else
			{
				const float f = (d1 + DIST_EPSILON) / (d1 - d2);
				if(f < exitf)
				{
					exitf = f;
				}
			}
		}
		if(!fullOut)
		{
			if(!startOut && !endOut)
			{
				moveMove.fraction = 0.0f;
				moveMove.allSolid = true;
				moveMove.normal = hitNormal;
				return;
			}
			if(enterf < exitf)
			{
				if(enterf > -1.0f && enterf < moveMove.fraction)
				{
					if(enterf < 0.0f)
					{
						enterf = 0.0f;
					}
					moveMove.fraction = enterf;
					moveMove.normal = hitNormal;
				}
			}
		}

		if(moveMove.fraction == 0.0f) // Already fully blocked
		{
			return;
		}
	}
}

// And a little example on how to use it :

// We get the desired direction externally (from the animation or the AI). We try the following ://
// if could move in the desired direction, at least partially
// 		move;
// else
//		try stepping up
//		if could step up
//			move down to exactly the step's height
//		else
//			slide along the plane which blocked the movement

const float CQuake3BSP::OnGround(const D3DXVECTOR3 &location,const D3DXVECTOR3 &extents)
{
	const Q3Move move = checkMove(location,D3DXVECTOR3(location.x,location.y+DELTA_DOWN,location.z),extents);
	return move.fraction;
}

const void CQuake3BSP::update(const float dTime,D3DXVECTOR3 &position,const D3DXVECTOR3 &reqMove,const D3DXVECTOR3 &extents,float &vSpeed)
{
	D3DXVECTOR3 startPoint,endPoint;
	Q3Move move;
	bool stepDown = false;
	const bool jumping = (vSpeed > 0.0f);
	if(D3DXVec3Length(&reqMove))
	{
		endPoint = position + reqMove;
		move = checkMove(position,endPoint,extents);
		if(move.fraction == 0.0f) // Try stepping up
		{
			startPoint = position + STEP_UP;
			endPoint = startPoint + reqMove;
			move = checkMove(startPoint,endPoint,extents);
			if(move.fraction) // Move down. We need to go up exactly the step height.
			{
				startPoint = move.end;
				endPoint = startPoint - STEP_UP;
				move = checkMove(startPoint,endPoint,extents);
			}
			else // Try sliding along the hit plane
			{
				D3DXVec3Normalize(&move.normal,&move.normal);
				const D3DXVECTOR3 remain = reqMove*(1-move.fraction); // Remaining to move
				const D3DXVECTOR3 slide = remain - move.normal*D3DXVec3Dot(&move.normal,&remain);
				startPoint = position;
				endPoint = startPoint + slide;
				move = checkMove(startPoint,endPoint,extents);
			}
		}
		position = move.end;
	}

	move = checkMove(position,D3DXVECTOR3(position.x,position.y+DELTA_DOWN,position.z),extents);
	if(move.fraction >= DIST_EPSILON)
	{
		if((vSpeed == 0.0f) && (!jumping)) // Might be stepping down
		{
			startPoint = position;
			endPoint = startPoint - STEP_UP;
			move = checkMove(startPoint,endPoint,extents);
			if(move.fraction < 1.0f) // Hit the step
			{
				position = move.end;
				stepDown = true;
			}
		}
		if(!stepDown)
		{
			vSpeed += GRAVITY_INCH*dTime;
		}
	}
	if(vSpeed)
	{
		endPoint = position + D3DXVECTOR3(0,vSpeed*dTime,0);
		move = checkMove(position,endPoint,extents);
		position = move.end;
		if(move.fraction < DIST_EPSILON)
		{
			if(jumping)
			{
				vSpeed = DIST_EPSILON;
			}
			else
			{
				vSpeed = 0.0f;
			}
		}
	}
}
