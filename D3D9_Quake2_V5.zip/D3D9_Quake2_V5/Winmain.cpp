#define NAME "PORTAL"
#define TITLE "PORTAL"

#define WIN32_LEAN_AND_MEAN
#define WIN32_EXTRA_LEAN

#define D3D_OVERLOADS
#define STRICT

#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>

#include "d3d8_screen.h"
#include "di_mouse.h"
#include "engine.h"
#include "quake3bsp.h"

Mouse		mouse;
Screen	screen;
Engine	engine;
CQuake3BSP g_bsp;

HWND	hwnd;
FILE	*file;

long frame=0;

void ReleaseObjects()
{
	fprintf(file, "windows shutdown\n");
}

long FAR PASCAL WindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
    case	WM_DESTROY:
			ReleaseObjects();
			PostQuitMessage(0);
			break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
  WNDCLASS wc;
  wc.style = CS_HREDRAW | CS_VREDRAW;
  wc.lpfnWndProc = WindowProc;
  wc.cbClsExtra = 0;
  wc.cbWndExtra = 0;
  wc.hInstance = hInstance;
  wc.hIcon = LoadIcon(hInstance, IDI_APPLICATION);
  wc.hCursor = LoadCursor(NULL, IDC_ARROW);
  wc.hbrBackground = NULL;
  wc.lpszMenuName = NAME;
  wc.lpszClassName = NAME;
  RegisterClass(&wc);
    
  hwnd = CreateWindowEx(WS_EX_TOPMOST, NAME, TITLE, WS_POPUP, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), NULL, NULL, hInstance, NULL);
  if (!hwnd)
  {
		return false;
  }
  ShowWindow(hwnd, nCmdShow);
	UpdateWindow(hwnd);

	if ((file=fopen("log.txt","w"))==NULL)
	{
		return false;
	}
	fprintf(file, "windows startup\n");

	if (!mouse.Setup(hInstance, hwnd))
	{
		return false;
	}

	engine.Setup();

	if (!screen.Setup(1024, 768, D3DFMT_A8R8G8B8, 1.0f, 32767.0f, D3DFMT_D24X8, 2, hwnd))
	{
		return false;
	}

//	if (!g_bsp.LoadBSP("casdm7v1.bsp")) 
//	if (!g_bsp.LoadBSP("obiwanshouse.bsp")) 
//	if (!g_bsp.LoadBSP("charon3dm11v2.bsp"))
//	if (!g_bsp.LoadBSP("chartres.bsp")) 
//	if (!g_bsp.LoadBSP("fpb.bsp")) 
//	if (!g_bsp.LoadBSP("tutorial.bsp")) 
//	if (!g_bsp.LoadBSP("q3dm11.bsp")) 
//	if (!g_bsp.LoadQ2BSP("2cocedm01.bsp"))
	if (!g_bsp.LoadQ2BSP("spirit2dm3.bsp"))
	{
		return false;
	}
//	engine.Location=g_bsp.Start(engine.Extent);

	MSG msg;
memset(&msg,0,sizeof(msg));
	while (msg.message!=WM_QUIT)
	{
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
		{
			engine.Update();
			++frame;
		}
	}
}
