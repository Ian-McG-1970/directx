#include <d3d9.h>
#include <d3dx9.h>

//#include <d3dfont.h>

#ifndef D3D_SCREEN
#define D3D_SCREEN

#define MAX_VERTEX_BUFFER 16
#define MAX_VERTEX 300

#define MAX_MODELS 256
#define MAX_ACTORS 256
#define MAX_TEXTURES 256
#define MAX_PLANES 6

#define BACKGROUND 0 //255

#define D3D_RELEASE(pObject) if(pObject != NULL) {pObject->Release(); pObject=NULL;}

typedef struct
{
	D3DXVECTOR3	Location;	// Vertex position
	D3DCOLOR		Colour;		// Vertex color
} D3D_VERTEX;
#define D3DFVF_D3D_VERTEX (D3DFVF_XYZ | D3DFVF_DIFFUSE)
                  
class Screen
{
private:
	const void ExtractFrustumPlanes(void);
	LPD3DXFONT Font;

	LPDIRECT3D9	g_pD3D;
	D3DXPLANE Frustum[MAX_PLANES];

	D3DXMATRIX Matrix_Projection;
	D3DXMATRIX Matrix_View;
	D3DXMATRIX Matrix_World;
	D3DXMATRIX Matrix_Translation;
	D3DXMATRIX Matrix_Rotation;

	LPDIRECT3DVERTEXBUFFER9 TL_Vertex_Buffer[MAX_VERTEX_BUFFER];

	D3D_VERTEX PolygonPoint[65535];
public:
	const bool Setup(const int, const int, const D3DFORMAT, const float, const float, const D3DFORMAT, const int, const HWND);
	~Screen();
	const void View_Matrix(const D3DXVECTOR3 &, const D3DXVECTOR3 &);
	const bool IsPointInsideFrustum(const D3DXVECTOR3 &);
	const bool IsSphereInsideFrustum(const D3DXVECTOR3 &, const float);
	const bool IsBoxInsideFrustum(const D3DXVECTOR3 *);
	const void Drawface(const int, const int);
	const void DrawText(const int,const int,const D3DCOLOR);
	const void Plot(const D3DXVECTOR3 &);
	const void Line(const D3DXVECTOR3 &, const D3DXVECTOR3 &);
	const void Triangle(const D3DXVECTOR3 &,const D3DXVECTOR3 &,const D3DXVECTOR3 &,const D3DXCOLOR);
	const void Polygon(const D3DXVECTOR3 *, const int, const D3DXCOLOR);

	char string[255];
	LPDIRECT3DDEVICE9	g_pd3dDevice;
	D3DFORMAT					Format;

//	CD3DFont* Font;
};

#endif