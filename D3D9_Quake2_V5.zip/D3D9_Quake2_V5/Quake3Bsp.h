#ifndef _QUAKE3BSP_H
#define _QUAKE3BSP_H

#include <string>

#define IDBSPHEADER	(('P'<<24)+('S'<<16)+('B'<<8)+'I')
// little-endian "IBSP"
#define BSPVERSION	38

#define	Q2_LUMP_ENTITIES		0
#define	Q2_LUMP_PLANES		1
#define	Q2_LUMP_VERTEXES		2
#define	Q2_LUMP_VISIBILITY		3
#define	Q2_LUMP_NODES		4
#define	Q2_LUMP_TEXINFO		5
#define	Q2_LUMP_FACES		6
#define	Q2_LUMP_LIGHTING		7
#define	Q2_LUMP_LEAFS		8
#define	Q2_LUMP_LEAFFACES		9
#define	Q2_LUMP_LEAFBRUSHES	10
#define	Q2_LUMP_EDGES		11
#define	Q2_LUMP_SURFEDGES		12
#define	Q2_LUMP_MODELS		13
#define	Q2_LUMP_BRUSHES		14
#define	Q2_LUMP_BRUSHSIDES		15
#define	Q2_LUMP_POP		16
#define	Q2_LUMP_AREAS		17
#define	Q2_LUMP_AREAPORTALS	18
#define	Q2_HEADER_LUMPS		19

#define	MIPLEVELS	4
typedef struct
{
	char		name[32];
	unsigned	width;
	unsigned height;
	unsigned	offsets[MIPLEVELS];	// four mip maps stored
	char		animname[32];	// next frame in animation chain
	int		flags;
	int		contents;
	int		value;
} Q2_miptex_t;

typedef struct
{
	uint32_t offset;
	uint32_t length;
} Q2_lump_t;

typedef struct
{
	uint32_t ident;
	uint32_t version;
	Q2_lump_t	lumps[Q2_HEADER_LUMPS];
} Q2_dheader_t;

typedef struct
{
	int16_t x;
	int16_t y;
	int16_t z;
} point3s;

typedef struct
{
	D3DXVECTOR3	point;
} Q2_dvertex_t;

typedef struct
{
	Q2_dvertex_t mins;
	Q2_dvertex_t maxs;
	Q2_dvertex_t origin;		// for sounds or lights
	int	headnode;
	int	firstface;	// submodels just draw faces without walking the bsp tree
	int numfaces;
} Q2_dmodel_t;

typedef struct
{
	Q2_dvertex_t normal;
	float	dist;
	uint32_t type;	// PLANE_X - PLANE_ANYZ ?remove? trivial to regenerate
} Q2_dplane_t;

typedef struct
{
	uint32_t plane;
	int32_t children[2];	// negative numbers are -(leafs+1), not nodes
	point3s mins;	// for frustom culling
	point3s maxs;
	uint16_t firstface;
	uint16_t numfaces;	// counting both sides
} Q2_dnode_t;

typedef struct texinfo_s
{
	float		vecs[2][4];	// [s/t][xyz offset]
	int		flags;		// miptex flags + overrides
	int		value;		// light emission, etc
	char		texture[32];	// texture name (textures/*.wal)
	int		nexttexinfo;	// for animations, -1 = end of chain
} Q2_texinfo_t;

// note that edge 0 is never used, because negative edge nums are used for counterclockwise use of the edge in a face
typedef struct
{
	uint16_t v[2];		// vertex numbers
} Q2_dedge_t;

#define	MAXLIGHTMAPS	4
typedef struct
{
	uint16_t planenum;
	uint16_t side;
	uint32_t firstedge;		// we must support > 64k edges
	uint16_t numedges;
	uint16_t texinfo;
	uint8_t styles[MAXLIGHTMAPS]; // lighting info
	uint32_t lightofs;		// start of [numstyles*surfsize] samples
} Q2_dface_t;

typedef struct
{
	uint32_t contents;			// OR of all brushes (not needed?)
	int16_t cluster;
	uint16_t area;
	point3s mins;			// for frustum culling
	point3s maxs;
	uint16_t firstleafface;
	uint16_t numleaffaces;
	uint16_t firstleafbrush;
	uint16_t numleafbrushes;
} Q2_dleaf_t;

typedef struct
{
	uint32_t contents;			// OR of all brushes (not needed?)
	int16_t cluster;
	uint16_t area;
	uint16_t firstleafface;
	uint16_t numleaffaces;
	uint16_t firstleafbrush;
	uint16_t numleafbrushes;
	D3DXVECTOR3 bounding_box[8];
} Q2_D3D_dleaf_t;

typedef struct
{
	unsigned short	planenum;		// facing out of the leaf
	short	texinfo;
} Q2_dbrushside_t;

typedef struct
{
	int	firstside;
	int	numsides;
	int	contents;
} Q2_dbrush_t;

// the visibility lump consists of a header with a count, then byte offsets for the PVS and PHS of each cluster, then the raw compressed bit vectors
//#define	DVIS_PVS	0
//#define	DVIS_PHS	1
typedef struct
{
	int	numclusters;
	int	bitofs[8][2];	// bitofs[numclusters][2]
} Q2_dvis_t;

// each area has a list of portals that lead into other areas when portals are closed, other areas may not be visible or hearable even if the vis info says that it should be
typedef struct
{
	int	portalnum;
	int	otherarea;
} Q2_dareaportal_t;

typedef struct
{
	int	numareaportals;
	int	firstareaportal;
} Q2_darea_t;

#define VERT_FVF D3DFVF_XYZ | D3DFVF_DIFFUSE

#define FACE_POLYGON	1 // This is the number that is associated with a face that is of type "polygon"
#define Q3_FRONT 0
#define Q3_BACK 1
#define DIST_EPSILON 1.0f/32.0f
#define GRAVITY_INCH -1.0f
#define STEP_UP D3DXVECTOR3(0.0f, 16.0f, 0.0f);
#define DELTA_DOWN -1.0f

#define	CONTENTS_SOLID			1
#define	CONTENTS_PLAYERCLIP	0x10000

struct tBSPLump // This is our BSP lump structure
{
	int offset;					// The offset into the file for the start of this lump
	int length;					// The length in bytes for this lump
};

struct cluster_leaf
{
	int start;	// start of this clusters leafs
	int count;	// number of leafs to draw
};

struct Q3Move
{	
	float	fraction;
	D3DXVECTOR3	start;
	D3DXVECTOR3	end;
	D3DXVECTOR3	size;	// Size of the bounding box / 2
	D3DXVECTOR3	mins;	// Bounding box	
	D3DXVECTOR3	maxs;
	D3DXVECTOR3	normal;	// Normal at collision point
	bool	allSolid;
};

class CQuake3BSP
{
private:
	const Q3Move checkMove(const D3DXVECTOR3& start,const D3DXVECTOR3& end,const D3DXVECTOR3& extent);
	const void checkMoveLeaf(const int leaf);
	const void checkMoveNode(const float sf,const float ef,const D3DXVECTOR3& sp,const D3DXVECTOR3& ep,const int node);
	const D3DXVECTOR3 FlipPoint(const D3DXVECTOR3&);
	const point3s FlipPoint(const point3s &);
	const int LoadLump(FILE *fp, const int count, const int offset, void *dest, const int stride);
	const void DecompressVis2(const BYTE *, BYTE *, const int);
	const int IsQ2ClusterVisible2(const int &, const int &);
	const void RenderQ2LeafPoly(const Q2_D3D_dleaf_t *leaf);

	Q3Move moveMove;

	D3DXVECTOR3 Q2_p[65535];

	int Q2_m_numOfVerts;
	Q2_dvertex_t *Q2_m_pVerts;
	int Q2_m_numOfEdges;
	Q2_dedge_t *Q2_m_pEdges;
	int Q2_m_numOfFaces;
	Q2_dface_t *Q2_m_pFaces;
	int Q2_m_numOfLeafs;
	int Q2_m_numOfNodes;
	Q2_dnode_t *Q2_m_pNodes;
	int Q2_m_numOfLeafFaces;
	uint16_t *Q2_m_pLeafFaces;
	int Q2_m_numOfFaceEdges;
	int32_t *Q2_m_pFaceEdges;
	Q2_D3D_dleaf_t *Q2_m_pLeafs_D3D;
	int Q2_m_numOfPlanes;
	D3DXPLANE	*Q2_Planes_D3D;
	BYTE **Q2_Cluster_Bitmap;
	cluster_leaf	*Q2_cluster_leafs;			// pointers into cluster leaf list for each cluster
	Q2_D3D_dleaf_t **Q2_cluster_leaf_list;	// list of leafs to be drawn from each cluster

	int Q2_m_numOfLeafBrushes;
	uint16_t *Q2_m_pLeafBrushes;

	int Q2_m_numOfBrushes;
	Q2_dbrush_t *Q2_m_pBrushes;

	int Q2_m_numOfBrusheSides;
	Q2_dbrushside_t *Q2_m_pBrusheSides;

	int Q2_m_numOfTextures;
	Q2_texinfo_t *Q2_m_pTextures;

public:
	CQuake3BSP(); // Our constructor
	~CQuake3BSP(); // Our deconstructor. This destroys the level data
	const void update(const float dTime, D3DXVECTOR3 &position, const D3DXVECTOR3 &reqMove, const D3DXVECTOR3 &extents, float &vSpeed);
	const float OnGround(const D3DXVECTOR3 &,const D3DXVECTOR3 &);

	const bool LoadQ2BSP(const char *strFileName);
	const int FindQ2Leaf(const D3DXVECTOR3 &);
	const int FindQ2Cluster(const int);
	const void RenderQ2Level2(const int);
	const D3DXVECTOR3 Start(const D3DXVECTOR3&);
};

#endif
