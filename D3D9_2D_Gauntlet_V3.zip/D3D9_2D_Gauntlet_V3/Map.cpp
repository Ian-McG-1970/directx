#include <time.h>

#include "Map.h"
#include "Load.h"
#include "Engine.h"

extern FILE	*file;
extern Engine engine;

const void Floor::FloodFill(const int x, const int y, const WORD room, const WORD fill)
{
	if (Level[x][y] == room)
	{
		Level[x][y] = fill;
		FloodFill(x - 1, y, room, fill);
		FloodFill(x + 1, y, room, fill);
		FloodFill(x, y - 1, room, fill);
		FloodFill(x, y + 1, room, fill);
	}
}

const void Floor::Fill(const int start_x, const int start_y, const int end_x, const int end_y, const WORD colour)
{
	for (int x = start_x; x != end_x; ++x)
	{
		for (int y = start_y; y != end_y; ++y)
		{
			Level[x][y] = colour;
		}
	}
}

const bool Floor::LinkRooms(const int direction)
{
	if (direction == 0)
	{
		return LinkVertical(rand() &(MAP_SIZE - 1), rand() &(MAP_SIZE - 1));
	}
	return LinkHorizontal(rand() &(MAP_SIZE - 1), rand() &(MAP_SIZE - 1));
}

const bool Floor::LinkVertical(int x, const int start_y)
{
	for (int mx = 0; mx != MAP_SIZE; ++mx)
	{
		int y = start_y;
		for (int my = 0; my != MAP_SIZE; ++my)
		{
			const int py = (y - 1) &(MAP_SIZE - 1);
			const int ny = (y + 1) &(MAP_SIZE - 1);

			if (Level[x][y] == WALL)
			{
				if ((Level[x][py] != WALL) && (Level[x][ny] != WALL))
				{
					if (Level[x][py] != Level[x][ny])
					{
						Level[x][y] = Level[x][ny];
						FloodFill(x, y, Level[x][y], Level[x][py]);
						return false;
					}
				}
			}
			y = (++y) &(MAP_SIZE - 1);
		}
		x = (++x) &(MAP_SIZE - 1);
	}
	return true;
}

const bool Floor::LinkHorizontal(int x, const int start_y)
{
	for (int mx = 0; mx != MAP_SIZE; ++mx)
	{
		const int px = (x - 1) &(MAP_SIZE - 1);
		const int nx = (x + 1) &(MAP_SIZE - 1);
		int y = start_y;
		for (int my = 0; my != MAP_SIZE; ++my)
		{
			if (Level[x][y] == WALL)
			{
				if ((Level[px][y] != WALL) && (Level[nx][y] != WALL))
				{
					if (Level[px][y] != Level[nx][y])
					{
						Level[x][y] = Level[nx][y];
						FloodFill(x, y, Level[x][y], Level[px][y]);
						return false;
					}
				}
			}
			y = (++y) &(MAP_SIZE - 1);
		}
		x = (++x) &(MAP_SIZE - 1);
	}
	return true;
}

const bool Floor::FindEmpty(int &x, int &y)
{
	x = rand() &(MAP_SIZE - 1), y = rand() &(MAP_SIZE - 1);
	return Find(x, y, MAP_SIZE - 1, MAP_SIZE - 1, EMPTY);
}

const bool Floor::FindFirst(const int start_x, const int start_y, const int end_x, const int end_y, const WORD colour)
{
	int x = start_x, y = start_y;
	return Find(x, y, end_x, end_y, colour);
}

const bool Floor::Find(int &x, int &y, const int end_x, const int end_y, const WORD colour)
{
	const int start_y = y;
	for (int mx = 0; mx != MAP_SIZE; ++mx)
	{
		y = start_y;
		for (int my = 0; my != MAP_SIZE; ++my)
		{
			if (Level[x][y] == colour)
			{
				return true;
			}
			y = (++y) &(MAP_SIZE - 1);
		}
		x = (++x) &(MAP_SIZE - 1);
	}
	return false;
}

const void Floor::RoomWallGap(const int rooms)
{
	for (int r = 0; r != rooms; ++r)
	{
		WallGap(Room[r].SX, Room[r].SY, Room[r].EX, Room[r].EY, Room[r].Value);
	}
}

const void Floor::AddGap(const int x, const int y)
{
	for (int g = 0; g != Gaps; ++g)
	{
		if ((Gap[g].x == x) && (Gap[g].y == y))
		{
			return;
		}
	}
	Gap[Gaps].x = x;
	Gap[Gaps].y = y;
	++Gaps;
}

const void Floor::WallGap(const int sx, const int sy, const int ex, const int ey, WORD colour)
{
	Gaps = 0;
	for (int x = 0; x != MAP_SIZE; ++x)
	{
		for (int y = 0; y != MAP_SIZE; ++y)
		{
			if (Level[x][y] == colour)
			{
				if ((Level[x - 1][y] == WALL) && (Level[x - 2][y] == FLOOR))
				{
					AddGap(x - 1, y);
				}
				if ((Level[x + 1][y] == WALL) && (Level[x + 2][y] == FLOOR))
				{
					AddGap(x + 1, y);
				}
				if ((Level[x][y - 1] == WALL) && (Level[x][y - 2] == FLOOR))
				{
					AddGap(x, y - 1);
				}
				if ((Level[x][y + 1] == WALL) && (Level[x][y + 2] == FLOOR))
				{
					AddGap(x, y + 1);
				}
			}
		}
	}

	const int random = rand() % Gaps;
	const int x = Gap[random].x;
	const int y = Gap[random].y;
	Level[x][y] = colour;
}

const void Floor::Draw()
{
	for (int x = 0; x != MAP_SIZE; ++x)
	{
		for (int y = 0; y != MAP_SIZE; ++y)
		{
			if (Level[x][y] == WALL)
			{
//				if ((x == 0) || (Level[x-1][y] == FLOOR))
				{
					engine.Add_Object(
					D3DXVECTOR2(x*SCALE, y*SCALE),
					D3DCOLOR_XRGB(255, 0, 0),
					LINE_SHAPE,
					NULL,
					&D3DXVECTOR2(0, SCALE - 3),
					NULL, &engine.Rooms[0], engine.RoomCount);
				}
//				if ((x == (MAP_SIZE - 1)) || (Level[x + 1][y] == FLOOR))
				{
					engine.Add_Object(
						D3DXVECTOR2(x*SCALE, y*SCALE),
						D3DCOLOR_XRGB(255, 63, 0),
						LINE_SHAPE,
						NULL,
						&D3DXVECTOR2(SCALE - 3, 0),
						NULL, &engine.Rooms[0], engine.RoomCount);
				}
//				if ((y == 0) || (Level[x][y-1] == FLOOR))
				{
					engine.Add_Object(
						D3DXVECTOR2(((x + 1)*SCALE) - 3, y*SCALE),
						D3DCOLOR_XRGB(127, 127, 0),
						LINE_SHAPE,
						NULL,
						&D3DXVECTOR2(0, SCALE - 3),
						NULL, &engine.Rooms[0], engine.RoomCount);
				}
//				if ((y == (MAP_SIZE - 1)) || (Level[x][y + 1] == FLOOR))
				{
					engine.Add_Object(
						D3DXVECTOR2(x*SCALE, ((y + 1)*SCALE) - 3),
						D3DCOLOR_XRGB(127, 191, 0),
						LINE_SHAPE,
						NULL,
						&D3DXVECTOR2(SCALE - 3, 0),
						NULL, &engine.Rooms[0], engine.RoomCount);
				}
			}
		}
	}
}

const void Floor::AddLine(const LINE line)
{
	LINE templine;
	if ((line.start.x < line.end.x) || (line.start.y < line.end.y))
	{
		templine.start.x = line.start.x; templine.start.y = line.start.y; templine.end.x = line.end.x; templine.end.y = line.end.y;
	}
	else
	{
		templine.start.x = line.end.x; templine.start.y = line.end.y; templine.end.x = line.start.x; templine.end.y = line.start.y;
	}
	for (int l = 0; l != Lines; ++l)
	{
		if ( (templine.start.x == Line[l].start.x) && (templine.start.y == Line[l].start.y) && (templine.end.x == Line[l].end.x) && (templine.end.y == Line[l].end.y) )
		{
			return;
		}
	}
	Line[Lines].start.x = templine.start.x;
	Line[Lines].start.y = templine.start.y;
	Line[Lines].end.x = templine.end.x;
	Line[Lines].end.y = templine.end.y;
	++Lines;
}

const LINE Floor::SetLine(const int startx, const int starty, const int endx, const int endy)
{
	LINE line;
	line.start.x = startx;
	line.start.y = starty;
	line.end.x = endx;
	line.end.y = endy;
	return line;
}

const void Floor::MergeLines1()
{
	bool swap = true;
	while (swap == true)
	{
		swap = true;
		for (int x = 0; x < (Lines - 1); ++x)
		{
			bool hor_x = false;
			if (Line[x].start.x == Line[x].end.x) hor_x = true;

			for (int y = x+1; y < Lines; ++y)
			{
				bool hor_y = false;
				if (Line[y].start.x == Line[y].end.x) hor_y = true;

				if (hor_x != hor_y) continue;

				swap = false;
				if ( (hor_x == true) && (Line[x].start.x == Line[y].end.x) )
				{

					if (Line[x].start.y == Line[y].end.y)
					{
						Line[x].start.y = Line[y].start.y;
						--Lines;
						memcpy(&Line[y], &Line[Lines], sizeof(Line[y]));
						--y;
						swap = true;
					}
					if (Line[x].end.y == Line[y].start.y)
					{
						Line[x].end.y = Line[y].end.y;
						--Lines;
						memcpy(&Line[y], &Line[Lines], sizeof(Line[y]));
						--y;
						swap = true;
					}
				}
				else if (Line[x].start.y == Line[y].end.y)
				{
					if (Line[x].start.x == Line[y].end.x)
					{
						Line[x].start.x = Line[y].start.x;
						--Lines;
						memcpy(&Line[y], &Line[Lines], sizeof(Line[y]));
						--y;
						swap = true;
					}
					if (Line[x].end.x == Line[y].start.x)
					{
						Line[x].end.x = Line[y].end.x;
						--Lines;
						memcpy(&Line[y], &Line[Lines], sizeof(Line[y]));
						--y;
						swap = true;
					}
				}
			}
		}
	}
}

const void Floor::MergeLines2()
{
	bool used[MAP_SIZE*MAP_SIZE];

	for (int l=0; l!=Lines; ++l) used[l]=true;

	bool swap = true;
	while (swap == true)
	{
		swap = false;
		for (int x=0; x!=Lines; ++x)
		{
			if (used[x]==false) continue;

			for (int y=0; y!=Lines; ++y)
			{
				if (used[y]==false) continue;

				if (x==y) continue;

				if ( (Line[x].start.x==Line[x].end.x) && (Line[y].start.x==Line[y].end.x) && (Line[x].start.x==Line[y].start.x) )
				{
					if (Line[x].start.y==Line[y].end.y)
					{
						Line[x].start.y=Line[y].start.y;
						used[y]=false;
						swap=true;
					}
					if (Line[x].end.y==Line[y].start.y)
					{
						Line[x].end.y=Line[y].end.y;
						used[y]=false;
						swap=true;
					}
				}

				if ((Line[x].start.y==Line[x].end.y) && (Line[y].start.y==Line[y].end.y) && (Line[x].start.y==Line[y].start.y))
				{
					if (Line[x].start.x==Line[y].end.x)
					{
						Line[x].start.x=Line[y].start.x;
						used[y]=false;
						swap=true;
					}
					if (Line[x].end.x==Line[y].start.x)
					{
						Line[x].end.x=Line[y].end.x;
						used[y]=false;
						swap=true;
					}
				}
			}
		}
	}
	for (int l = 0; l < Lines; ++l)
	{
		if (used[l] == false)
		{
			memcpy(&used[l], &used[l + 1], sizeof(used[0])*Lines);
			memcpy(&Line[l], &Line[l + 1], sizeof(Line[0])*Lines);
			--Lines;
			--l;
		}
	}
}

const void Floor::Draw1()
{
	Lines = 0;
	for (int x = 0; x != MAP_SIZE; ++x)
	{
		for (int y = 0; y != MAP_SIZE; ++y)
		{

			// if this is a wall
			 // if above is a floor
			  // draw a line
			 // if left is a floor
			  // draw a line
      // if this is a floor
			 // if above is a wall
			  // draw a line
			 // if left is a wall
			  // draw a line

			if (Level[x][y] == WALL)
			{
				if ((x == 0) || (Level[x-1][y] == FLOOR))
				{
					AddLine(SetLine((x)*SCALE, (y)*SCALE, (x)*SCALE, (y+1)*SCALE));
				}
				if ((y == 0) || (Level[x][y - 1] == FLOOR))
				{
					AddLine(SetLine((x)*SCALE, (y)*SCALE, (x+1)*SCALE, (y)*SCALE));
				}
			}
			else
			{
				if ((x == 0) || (Level[x - 1][y] == WALL))
				{
					AddLine(SetLine((x)*SCALE, (y)*SCALE, (x)*SCALE, (y+1)*SCALE));
				}
				if ((y == 0) || (Level[x][y - 1] == WALL))
				{
					AddLine(SetLine((x)*SCALE, (y)*SCALE, (x+1)*SCALE, (y)*SCALE));
				}
			}
			if (y == (MAP_SIZE - 1)) AddLine(SetLine((x+1)*SCALE, (y+1)*SCALE, (x)*SCALE, (y+1)*SCALE));
			if (x == (MAP_SIZE - 1)) AddLine(SetLine((x+1)*SCALE, (y)*SCALE, (x+1)*SCALE, (y+1)*SCALE));
		}
	}

	MergeLines2();

	for (int l = 0; l != Lines; ++l)
	{
		const int startx = Line[l].start.x;
		const int starty = Line[l].start.y;
		const int endx = Line[l].end.x-Line[l].start.x;
		const int endy = Line[l].end.y-Line[l].start.y;
		engine.Add_Object(D3DXVECTOR2(startx, starty), D3DCOLOR_XRGB(rand(), rand(), rand()), LINE_SHAPE, NULL, &D3DXVECTOR2(endx, endy), NULL, &engine.Rooms[0], engine.RoomCount);
	}
}

const void Floor::Draw2()
{
	int start, end;
	for (int x = 0; x != MAP_SIZE; ++x)
	{
		bool current_line = false;
		for (int y = 0; y != MAP_SIZE; ++y)
		{
			if (current_line == true)
			{
				if (Level[x][y] == WALL)
				{
					end = x;
				}
				else
				{
					engine.Add_Object(D3DXVECTOR2(start*SCALE, y*SCALE), D3DCOLOR_XRGB(63, 0, 255), LINE_SHAPE, NULL, &D3DXVECTOR2(((end-start)*SCALE)-3, 0), NULL, &engine.Rooms[0], engine.RoomCount);
					current_line = false;
				}
			}
			else
//			if (current_line == false)
			{
				if (Level[x][y] == WALL)
				{
					start = end = x;
					current_line = true;
				}
			}
		}
		if (current_line == true)
		{
//			engine.Add_Object( D3DXVECTOR2(start*SCALE, MAP_SIZE*SCALE), D3DCOLOR_XRGB(127, 0, 255), LINE_SHAPE, NULL, &D3DXVECTOR2(((end-start)*SCALE) - 3, 0), NULL, &engine.Rooms[0], engine.RoomCount);
			current_line = false;
		}
	}

	for (int y = 0; y != MAP_SIZE; ++y)
	{
		bool current_line = false;
		for (int x = 0; x != MAP_SIZE; ++x)
		{
			if (current_line == true)
			{
				if (Level[x][y] == WALL)
				{
					end = y;
				}
				else
				{
					engine.Add_Object(D3DXVECTOR2(x*SCALE, start*SCALE),D3DCOLOR_XRGB(191, 0, 255),LINE_SHAPE,NULL,&D3DXVECTOR2(0, ((end-start)*SCALE) - 3),NULL, &engine.Rooms[0], engine.RoomCount);
					current_line = false;
				}
			}
			else
//			if (current_line == false)
			{
				if (Level[x][y] == WALL)
				{
					start = end = y;
					current_line = true;
				}
			}
		}
		if (current_line == true)
		{
//			engine.Add_Object(D3DXVECTOR2(MAP_SIZE*SCALE, start*SCALE), D3DCOLOR_XRGB(223, 0, 255), LINE_SHAPE, NULL, &D3DXVECTOR2(0, ((end-start)*SCALE) - 3), NULL, &engine.Rooms[0], engine.RoomCount);
			current_line = false;
		}
	}
}

const void Floor::Calc(const int seed)
{
	srand(seed);
	Fill(0, 0, MAP_SIZE, MAP_SIZE, EMPTY);

	Rooms = 0;
	for (; FindEmpty(Room[Rooms].SX, Room[Rooms].SY) == true; )
	{
		Room[Rooms].EX = (rand() &MAP_MAX_ROOM) + MAP_MIN_ROOM;
		Room[Rooms].EY = (rand() &MAP_MAX_ROOM) + MAP_MIN_ROOM;
		if ((Room[Rooms].EX < (Room[Rooms].EY >> 1)) || (Room[Rooms].EY < (Room[Rooms].EX >> 1))) continue;

		Room[Rooms].Value = Rooms;
		if ((Room[Rooms].SX + Room[Rooms].EX) > MAP_SIZE) Room[Rooms].EX = MAP_SIZE - Room[Rooms].SX;
		if ((Room[Rooms].SY + Room[Rooms].EY) > MAP_SIZE) Room[Rooms].EY = MAP_SIZE - Room[Rooms].SY;

		Fill(Room[Rooms].SX, Room[Rooms].SY, Room[Rooms].SX + Room[Rooms].EX, Room[Rooms].SY + Room[Rooms].EY, Room[Rooms].Value);
		++Rooms;
	}

	for (int x = 0; x != MAP_SIZE - 1; ++x)
	{
		for (int y = 0; y != MAP_SIZE - 1; ++y)
		{
			if (Level[x][y] != FLOOR)
			{
				if ((Level[x][y] != Level[x + 1][y]) || (Level[x][y] != Level[x][y + 1]))
				{
					Level[x][y] = FLOOR;
				}
			}
		}
	}

	for (int x = 1; x != MAP_SIZE - 1; ++x)
	{
		for (int y = 1; y != MAP_SIZE - 1; ++y)
		{
			if (Level[x][y] == FLOOR)
			{
				if (Level[x - 1][y] != FLOOR) Level[x - 1][y] = WALL;
				if (Level[x + 1][y] != FLOOR) Level[x + 1][y] = WALL;
				if (Level[x][y - 1] != FLOOR) Level[x][y - 1] = WALL;
				if (Level[x][y + 1] != FLOOR) Level[x][y + 1] = WALL;
				if (Level[x - 1][y - 1] != FLOOR) Level[x - 1][y - 1] = WALL;
				if (Level[x - 1][y + 1] != FLOOR) Level[x - 1][y + 1] = WALL;
				if (Level[x + 1][y - 1] != FLOOR) Level[x + 1][y - 1] = WALL;
				if (Level[x + 1][y + 1] != FLOOR) Level[x + 1][y + 1] = WALL;
			}
		}
	}

	Fill(0, 0, 1, MAP_SIZE, WALL);
	Fill(0, 0, MAP_SIZE, 1, WALL);
	Fill(0, MAP_SIZE - 1, MAP_SIZE, MAP_SIZE, WALL);
	Fill(MAP_SIZE - 1, 0, MAP_SIZE, MAP_SIZE, WALL);

	for (int r = 0; r != Rooms; ++r)
	{
		if (FindFirst(Room[r].SX, Room[r].SY, Room[r].SX + Room[r].EX, Room[r].SY + Room[r].EY, Room[r].Value) == false)
		{
			--Rooms;
			memcpy(&Room[r], &Room[Rooms], sizeof(Room[r]));
			--r;
		}
	}

	RoomWallGap(Rooms);
	for (; LinkRooms(rand() & 1) != true; );

	for (int x = 0; x != MAP_SIZE; ++x) for (int y = 0; y != MAP_SIZE; ++y) if (Level[x][y] != WALL) Level[x][y] = FLOOR;

	engine.RoomCount = 0;
//	Draw();
	Draw1();
}
