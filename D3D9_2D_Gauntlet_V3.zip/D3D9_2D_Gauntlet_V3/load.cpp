#include "load.h"
#include "d3d8_screen.h"
#include "map.h"

extern FILE *file;
extern Screen screen;

const void Load::Setup()
{
	fprintf(file, "Load setup\n");
}

Load::~Load()
{
	fprintf(file, "Load shutdown\n");
}

const bool Load::Texture(const char *name, const int number)
{
	D3DXIMAGE_INFO texture_format;
	fprintf(file,"load texture %s number %ld\n", name, number);

	if (screen.Texture_List[number]!=NULL)
	{
		screen.Texture_List[number]->Release();
		screen.Texture_List[number]=NULL;
	}

	D3DXCreateTextureFromFileEx(screen.g_pd3dDevice, name, D3DX_DEFAULT, D3DX_DEFAULT, 1,	0, SCREEN_FORMAT, D3DPOOL_MANAGED, D3DX_FILTER_NONE, D3DX_FILTER_NONE, 0x0ff000000,	&texture_format, NULL, &screen.Texture_List[number]);
//	if (Texture==NULL)
//	{
//		fprintf(file, "not found\n");
//		return false;
//	}
	fprintf(file, "width %ld height %ld depth %ld format %ld mipmap %ld\n", texture_format.Width, texture_format.Height, texture_format.Depth, texture_format.MipLevels, texture_format.Format,	texture_format.MipLevels);

	return true;
}
