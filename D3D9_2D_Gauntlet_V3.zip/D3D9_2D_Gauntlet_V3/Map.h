#ifndef MAP
#define MAP

#include "D3D8_Screen.h"

#define EMPTY 0x0fffd
#define FLOOR 0x0fffe
#define WALL 0x0ffff
#define MAP_SIZE 64 // check scale
#define MAP_MAX_ROOM 15
#define MAP_MIN_ROOM 7
#define ROOM_MAX 32767
#define SCALE 16

// 0 0 0
// 0 1 0
// 0 0 0

typedef struct
{
	int SX;
	int SY;
	int EX;
	int EY;
	WORD Value;
} ROOM;

typedef struct
{
	short x;
	short y;
} VECTOR;

typedef struct
{
	VECTOR start;
	VECTOR end;
} LINE;

class Floor
{
private:
	WORD Level[MAP_SIZE][MAP_SIZE];
	ROOM Room[ROOM_MAX];
	int Rooms;
	int Gaps;
	VECTOR Gap[MAP_SIZE];
	const bool Find(int &, int &, const int, const int, const WORD);
	const void Fill(const int, const int, const int, const int, const WORD);
	const void FloodFill(const int, const int, const WORD, const WORD);
	const bool LinkRooms(const int);
	const bool LinkVertical(int, const int);
	const bool LinkHorizontal(int, const int);
	const void AddGap(const int, const int);
	const void WallGap(const int, const int, const int, const int, WORD);
	const void RoomWallGap(const int);
	const bool FindEmpty(int &, int &);
	const bool FindFirst(const int, const int, const int, const int, const WORD);
	const void Draw();
	const void Draw1();
	const void Draw2();
	const void AddLine(const LINE);
	const LINE SetLine(const int, const int, const int, const int);
	const void MergeLines1();
	const void MergeLines2();
	int Lines;
	LINE Line[MAP_SIZE*MAP_SIZE];
public:
	const void Calc(const int);
};

#endif
