#include <d3d9.h>
#include <d3dx9.h>
#include <Box2D/Box2D.h>

#ifndef D3D_SCREEN
#define D3D_SCREEN

enum
{
	MAX_TEXTURES=16,
	MAX_VERTEX=4096*6,
	MAX_VERTEX_BUFFER=16,
	CIRCLE_SHAPE=0,
	LINE_SHAPE=1,
	BOX_SHAPE=2,
	POLYGON_SHAPE=3
};

#define SCREEN_FORMAT D3DFMT_A8R8G8B8

typedef struct
{
	D3DXVECTOR4 Position;
	D3DCOLOR Colour;
	float TU;
	float TV;
} TL_VERTEX;
#define D3DFVF_TL_VERTEX (D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1)

typedef struct
{
	float Radius;
	D3DCOLOR Colour;
	b2Body* Body;
	unsigned char Shape;
	D3DXVECTOR2 Vertex;
	void *UserData;
} Object;

typedef struct
{
	D3DXVECTOR2 Position;
	Object* object;
} DisplayObject;
             
class Screen
{
private:
	const void Draw_Primitive();
	const void Lock_Vertex_Buffer();
	LPDIRECT3D9	g_pD3D;
	LPDIRECT3DVERTEXBUFFER9 TL_Vertex_Buffer[MAX_VERTEX_BUFFER];
	LPDIRECT3DINDEXBUFFER9 TL_Index_Buffer[MAX_VERTEX_BUFFER];
	LPD3DXFONT Font;
	D3DXVECTOR2 Map_Location;
	int Vertex_Count;
	int Index_Count;
	int Vertex_Buffer_Count;
	TL_VERTEX* Vertex_Buffer;
	WORD* Index_Buffer;
public:
	D3DXVECTOR2 ScreenSize;
	D3DXVECTOR2 ScreenSizeHalf;

	const bool Setup(const int, const int, const D3DFORMAT, const int, const HWND);
	~Screen();
	const void Draw_Map(const int);
	const D3DXVECTOR2 SetScreenPos(const D3DXVECTOR2 &, const D3DXVECTOR2 &);
	const void Draw_Objects(const DisplayObject *, const int);
	const void DrawText(int, int, D3DCOLOR, char *);
	char string[255];
	LPDIRECT3DDEVICE9	g_pd3dDevice;
	LPDIRECT3DTEXTURE9 Texture_List[MAX_TEXTURES];
	const void DrawLine(const D3DXVECTOR2 &, const D3DXVECTOR2 &, const D3DCOLOR);
	const void DrawCircle(const D3DXVECTOR2 &centre, const float radius, const D3DCOLOR);
	const void DrawAABox(const D3DXVECTOR2 &, const D3DXVECTOR2 &, const D3DCOLOR);
	const void DrawBox(const D3DXVECTOR2 &, const D3DXVECTOR2 &, const D3DXVECTOR2 &, const D3DXVECTOR2 &, const D3DCOLOR);
	const void Draw_Primitive_Forced();
	const void DrawTriangle(const D3DXVECTOR2 &start, const D3DXVECTOR2 &middle, const D3DXVECTOR2 &end, const float texture, const D3DCOLOR colour);
const void Screen::DrawBullet(const D3DXVECTOR2 &point, const D3DCOLOR colour);
};


#endif