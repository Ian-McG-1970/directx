#include "d3d8_screen.h"
#include "di_mouse.h"

extern FILE *file;
extern HWND hwnd;

const bool Mouse::Setup(const HINSTANCE hInstance, const HWND hwnd)
{
	fprintf(file, "directinput setup\n");
	g_pdi				=NULL;
	g_pMouse		=NULL;
	g_pKeyboard	=NULL;

	if (FAILED(DirectInput8Create(hInstance, DIRECTINPUT_VERSION, IID_IDirectInput8, (VOID**)&g_pdi, NULL)))
	{
		return false;
	}
	if (FAILED(g_pdi->CreateDevice(GUID_SysMouse, &g_pMouse, NULL)))
	{
		return false;
	}
	if (FAILED(g_pMouse->SetDataFormat(&c_dfDIMouse)))
	{
		return false;
	}
	if (FAILED(g_pMouse->SetCooperativeLevel(hwnd, DISCL_EXCLUSIVE | DISCL_FOREGROUND)))
	{
		return false;
	}

	if (FAILED(g_pdi->CreateDevice(GUID_SysKeyboard, &g_pKeyboard, NULL)))
	{
		return false;
	}
	if (FAILED(g_pKeyboard->SetDataFormat(&c_dfDIKeyboard)))
	{
		return false;
	}
	if (FAILED(g_pKeyboard->SetCooperativeLevel(hwnd, DISCL_FOREGROUND | DISCL_EXCLUSIVE)))
	{
		return false;
	}

	g_pMouse->Acquire();
	g_pKeyboard->Acquire();

	X=Y=LB=RB=0;

	return true;
}

Mouse::~Mouse()
{
	fprintf(file, "directinput shutdown\n");
	if (g_pKeyboard)
	{
		g_pKeyboard->Unacquire();
		g_pKeyboard->Release();
		g_pKeyboard = NULL;
	}
	if (g_pMouse)
	{
		g_pMouse->Unacquire();
		g_pMouse->Release();
		g_pMouse = NULL;
	}
	if (g_pdi)
	{
		g_pdi->Release();
		g_pdi = NULL;
	}
}

const void Mouse::Update()
{
	HRESULT hr = g_pMouse->GetDeviceState(sizeof(DIMOUSESTATE), &dims);
	if (hr==DIERR_NOTACQUIRED || hr==DIERR_INPUTLOST)
	{
		g_pMouse->Acquire();
		hr = g_pMouse->GetDeviceState(sizeof(DIMOUSESTATE), &dims);
	}
	if (SUCCEEDED(hr))
	{
		X=dims.lX;
		Y=dims.lY;
		LB=dims.rgbButtons[0] & 0x80;
		RB=dims.rgbButtons[1] & 0x80;
	}
	else
	{
		X=Y=LB=RB=0;
	}

	g_pKeyboard->GetDeviceState(sizeof(DI_Keyboard), &DI_Keyboard);
	if (DI_Keyboard[DIK_ESCAPE] & 0x80)
	{
		PostMessage(hwnd, WM_CLOSE, 0, 0);
	}
}
