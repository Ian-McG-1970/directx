#ifndef LOAD
#define LOAD

#include <stdio.h>

class Load
{
	FILE	*fileopen;
public:
	const void	Setup();
	~Load();
	const bool Texture(const char *, const int);
};

#endif
