#define NAME "PORTAL"
#define TITLE "PORTAL"

#define WIN32_LEAN_AND_MEAN
#define WIN32_EXTRA_LEAN

#define D3D_OVERLOADS
#define STRICT

#include <windows.h>

#include "d3d8_screen.h"
#include "di_mouse.h"
#include "load.h"
#include "engine.h"
#include "map.h"

Mouse		mouse;
Screen	screen;
Load		load;
Engine	engine;
Map map;

HWND	hwnd;
FILE	*file;

extern void Update();
extern void Setup();

void ReleaseObjects()
{
	fprintf(file, "windows shutdown\n");
}

long FAR PASCAL WindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
    case	WM_DESTROY:
			ReleaseObjects();
			PostQuitMessage(0);
			break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
  WNDCLASS wc;
  wc.style = CS_HREDRAW | CS_VREDRAW;
  wc.lpfnWndProc = WindowProc;
  wc.cbClsExtra = 0;
  wc.cbWndExtra = 0;
  wc.hInstance = hInstance;
  wc.hIcon = LoadIcon(hInstance, IDI_APPLICATION);
  wc.hCursor = LoadCursor(NULL, IDC_ARROW);
  wc.hbrBackground = NULL;
  wc.lpszMenuName = NAME;
  wc.lpszClassName = NAME;
  RegisterClass(&wc);
    
  if (!(hwnd = CreateWindowEx(WS_EX_TOPMOST, NAME, TITLE, WS_POPUP, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), NULL, NULL, hInstance, NULL))) return false;

  ShowWindow(hwnd, nCmdShow);
	UpdateWindow(hwnd);

	if ((file=fopen("log.txt","w"))==NULL) return false;
	fprintf(file, "windows startup\n");

	if (!mouse.Setup(hInstance, hwnd)) return false;

	if (!screen.Setup(GetSystemMetrics(SM_CXSCREEN),GetSystemMetrics(SM_CYSCREEN), D3DFMT_X8R8G8B8, 1.0f, 32256.0f, D3DFMT_D24X8, 2, hwnd)) return false;

	load.Setup();

	load.Material("materials.txt");

//	load.Model("box06.txt",99);
//	load.Model("sphere04.txt",100);
//	load.Model("sphere06.txt",101);
//	load.Model("sphere08.txt",102);
//	load.Model("sphere10.txt",103);

	map.Setup();
	engine.Setup();

	MSG msg;
	while (msg.message!=WM_QUIT)
	{
		if (PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
		{
			if (!GetMessage(&msg, NULL, 0, 0))
			{
				return msg.wParam;
			}
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
		{
			engine.Update();
		}
	}
}

/*
float projectSphere( in vec4 sph,  // sphere in world space
                     in mat4 cam,  // camera matrix (world to camera)
                     in float fl ) // projection (focal length)
{
    // transform to camera space
    vec3  o = (cam*vec4(sph.xyz,1.0)).xyz;

    float r2 = sph.w*sph.w;
    float z2 = o.z*o.z;
    float l2 = dot(o,o);

    return -3.14159*fl*fl*r2*sqrt(abs((l2-r2)/(r2-z2)))/(r2-z2);
}

vec2 sphDistances( vec3 ro, vec3 rd, vec4 sph )
{
    vec3 oc = ro - sph.xyz;
    float b = dot( oc, rd );
    float c = dot( oc, oc ) - sph.w*sph.w;
    float h = b*b - c;
    float d = sqrt( max(0.0,sph.w*sph.w-h)) - sph.w;
    return vec2( d, -b-sqrt(max(h,0.0)) );
}

int sphereVisibility( vec4 sA, vec4 sB, vec3 c )
{
    vec3 ac = sA.xyz - c;
    vec3 bc = sB.xyz - c;
    float ia = 1.0/length(ac);
    float ib = 1.0/length(bc);
    float k0 = dot(ac,bc)*ia*ib;
    float k1 = sA.w*ia;
    float k2 = sB.w*ib;
    float m1 = k0*k0 + k1*k1 + k2*k2;
    float m2 = 2.0*k0*k1*k2;

         if( m1 + m2 - 1.0 < 0.0 ) return 1;
    else if( m1 - m2 - 1.0 < 0.0 ) return 2;
    return 3;
}


int visible( const vec3 & o, const float R, const vec3 & op, const float Rp, const vec3 & c )
{
  const vec3 ac = o  - c;
  const vec3 bc = op - c;

  const float ia = 1.0/length( ac );
  const float ib = 1.0/length( bc );

  const float k0 = dot( ac, bc ) * ia*ib;
  const float k1 = R  * ia;
  const float k2 = Rp * ib;

  if( k0*k0 + k1*k1 + k2*k2 + 2.0f*k0*k1*k2 - 1.0f < 0.0f ) return 1;
  if( k0*k0 + k1*k1 + k2*k2 - 2.0f*k0*k1*k2 - 1.0f < 0.0f ) return 2;

  return 3;
}


float projectSphere( in vec4 sph,  // sphere in world space
                     in mat4 cam,  // camera matrix (world to camera)
                     in float fl ) // projection (focal length)
{
    // transform to camera space
    vec3  o = (cam*vec4(sph.xyz,1.0)).xyz;

    float r2 = sph.w*sph.w;
    float z2 = o.z*o.z;
    float l2 = dot(o,o);

    return -3.14159*fl*fl*r2*sqrt(abs((l2-r2)/(r2-z2)))/(r2-z2);
}

const float Project(const D3DXVECTOR3 &location, const D3DXVECTOR3 &position, const float &radius)
{
	const D3DXVECTOR3 difference=location-position;
	const float distance=sqrtf(fabs(D3DXVec3Dot(&difference, &difference)));
	return (1.0f / (distance+1) ) * radius;
}

*/
