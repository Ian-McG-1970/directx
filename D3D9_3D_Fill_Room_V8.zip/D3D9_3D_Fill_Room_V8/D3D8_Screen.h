#ifndef D3D_SCREEN
#define D3D_SCREEN

#include <d3d9.h>
#include <d3dx9.h>

#define MAX_MODELS 65535
#define MAX_ACTORS 64
#define MAX_PLANES 6
#define MAX_BOUNDING_BOX 8
#define MAX_VERTICES 65535
#define MAX_MATERIALS 64

#define BACKGROUND D3DCOLOR_XRGB(32, 32, 32)

typedef struct
{
	D3DXVECTOR3 Location;
	D3DCOLOR Colour;
} IM_VERTEX;
#define D3DFVF_IM_VERTEX (D3DFVF_XYZ | D3DFVF_DIFFUSE)

typedef struct
{
	D3DXVECTOR3											Bounding_Sphere_Centre;
	float																			Bounding_Sphere_Radius;
	D3DXVECTOR3											Bounding_Box[MAX_BOUNDING_BOX];
	LPDIRECT3DVERTEXBUFFER9	Vertex_Buffer;
	IDirect3DIndexBuffer9*					Index_Buffer;
	unsigned long													Vertices;
	unsigned long													Triangles;
} MODEL;

typedef struct
{
	unsigned long Model;
	unsigned long Material;
	D3DXVECTOR3		Location;
	D3DXVECTOR3		Direction;
} ACTOR;
                  
class Screen
{
private:
	const void ExtractFrustumPlanes(void);
	LPD3DXFONT Font;

	LPDIRECT3D9	g_pD3D;
	D3DXPLANE Frustum[MAX_PLANES];

	D3DXMATRIX Matrix_Projection;
	D3DXMATRIX Matrix_View;
//	D3DXMATRIX Matrix_World;
//	D3DXMATRIX Matrix_Translation;
//	D3DXMATRIX Matrix_Rotation;

	unsigned long Current_Model;
	unsigned long Current_Material;

	const void DrawBoundingBox(const unsigned long);

public:
	const bool Setup(const unsigned long, const unsigned long, const D3DFORMAT, const float, const float, const D3DFORMAT, const unsigned long, const HWND);
	~Screen();
	const void View_Matrix(const D3DXVECTOR3 &, const D3DXVECTOR3 *);
	const bool IsPointInsideFrustum(const D3DXVECTOR3 *);
	const bool IsSphereInsideFrustum(const D3DXVECTOR3 *, const float);
	const bool IsBoundingBoxInsideFrustum(const D3DXVECTOR3 *);
	const void DrawObject(const D3DXVECTOR3 *, const D3DXVECTOR3 *, const unsigned long, const unsigned long);
	const void DrawLookAtObject(const D3DXVECTOR3 &, const D3DXVECTOR3 &, const unsigned long, const unsigned long);
	const void DrawStaticObject(const D3DXVECTOR3 *, const unsigned long, const unsigned long);
	char string[255];
	const void DrawText(const unsigned long, const unsigned long, const D3DCOLOR);
	const void CreateObject(const unsigned long, const unsigned long, const unsigned long);
	const bool BoundingBoxInFrustum(const D3DXVECTOR3 *, const D3DXVECTOR3 &);
	const bool BoundingBoxStaticInFrustum(const D3DXVECTOR3 *);

	LPDIRECT3DDEVICE9	g_pd3dDevice;

	IM_VERTEX					Vertex[MAX_VERTICES];
	WORD									Index[MAX_VERTICES];
	MODEL								Model[MAX_MODELS]; // list of models loaded in
	ACTOR								Actor[MAX_ACTORS]; // list of models in world
	D3DMATERIAL9		Material[MAX_MATERIALS];

	unsigned long Max_Material;
};

#endif