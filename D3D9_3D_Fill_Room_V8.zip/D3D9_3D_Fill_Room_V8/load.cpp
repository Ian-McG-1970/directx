#include "load.h"
#include "d3d8_screen.h"
#include "map.h"

extern FILE *file;
extern Screen screen;
extern Map map;

void Load::Setup()
{
	fprintf(file, "Load setup\n");
}

Load::~Load()
{
	fprintf(file, "Load shutdown\n");
}

const void Load::Material(const char *name)
{
	if ((fileopen=fopen(name, "r"))==NULL) return;
	fscanf(fileopen, "%s", rec);
	screen.Max_Material=atol(rec);

	for (unsigned long x=0; x!=screen.Max_Material; ++x)
	{
		ZeroMemory(&screen.Material[x], sizeof(screen.Material[0])); // A matte clay look is easy. All we really have to do is set the color to  look like clay pottery.

		fscanf(fileopen, "%s", rec);
		screen.Material[x].Diffuse.r=atof(rec);
		fscanf(fileopen, "%s", rec);
		screen.Material[x].Diffuse.g=atof(rec);
		fscanf(fileopen, "%s", rec);
		screen.Material[x].Diffuse.b=atof(rec);
		fscanf(fileopen, "%s", rec);
		screen.Material[x].Diffuse.a=atof(rec);

		fscanf(fileopen, "%s", rec);
		screen.Material[x].Ambient.r=atof(rec);
		fscanf(fileopen, "%s", rec);
		screen.Material[x].Ambient.g=atof(rec);
		fscanf(fileopen, "%s", rec);
		screen.Material[x].Ambient.b=atof(rec);
		fscanf(fileopen, "%s", rec);
		screen.Material[x].Ambient.a=atof(rec);

		fscanf(fileopen, "%s", rec);
		screen.Material[x].Specular.r=atof(rec);
		fscanf(fileopen, "%s", rec);
		screen.Material[x].Specular.g=atof(rec);
		fscanf(fileopen, "%s", rec);
		screen.Material[x].Specular.b=atof(rec);
		fscanf(fileopen, "%s", rec);
		screen.Material[x].Specular.a=atof(rec);
		fprintf(file,"m %ld x %ld dr %f dg %f db %f da %f ar %f ag %f ab %f aa %f sr %f sg %f sg %f sa %f\n", screen.Max_Material,x,
			screen.Material[x].Diffuse.r,screen.Material[x].Diffuse.g,screen.Material[x].Diffuse.b,screen.Material[x].Diffuse.a,
			screen.Material[x].Ambient.r,screen.Material[x].Ambient.g,screen.Material[x].Ambient.b,screen.Material[x].Ambient.a,
			screen.Material[x].Specular.r,screen.Material[x].Specular.g,screen.Material[x].Specular.b,screen.Material[x].Specular.a);

	}
	fclose(fileopen);
}


const void Load::Model(const char *name, const unsigned long object)
{
	if ((fileopen=fopen(name, "r"))==NULL) return;

	fscanf(fileopen, "%s", rec);
	const unsigned long vertices=atol(rec);
	fscanf(fileopen, "%s", rec);
	const unsigned long triangles=atol(rec);

	for (unsigned long x=0; x!=vertices; ++x)
	{
		fscanf(fileopen, "%s", rec);
		screen.Vertex[x].Location.x=atof(rec);
		fscanf(fileopen, "%s", rec);
		screen.Vertex[x].Location.y=atof(rec);
		fscanf(fileopen, "%s", rec);
		screen.Vertex[x].Location.z=atof(rec);

		screen.Vertex[x].Colour = D3DCOLOR_XRGB(rand(), rand(), rand());

//		screen.Vertex[x].Normal=screen.Vertex[x].Location;
//		D3DXVec3Normalize(&screen.Vertex[x].Normal, &screen.Vertex[x].Location);
	}

	for (unsigned long y=0, z=0; y!=triangles; ++y, z+=3)
	{
		fscanf(fileopen, "%s", rec);
		screen.Index[z] =atol(rec);
		fscanf(fileopen, "%s", rec);
		screen.Index[z+1] =atol(rec);
		fscanf(fileopen, "%s", rec);
		screen.Index[z+2] =atol(rec);
	}

	fclose(fileopen);
	screen.CreateObject(vertices, triangles, object);
}
