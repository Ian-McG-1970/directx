#ifndef MAP
#define MAP

#define MAX_ROOM_SIZE 64
#define MIN_ROOM_SIZE 32
#define ROOMS 125 //250
#define ROOMLINKS ROOMS*ROOMS
#define MAP_SIZE 2048
#define TOP 0
#define BOTTOM 1
#define LEFT 2
#define RIGHT 3
#define FRONT 4
#define BACK 5
#define SIDES 6
#define UNUSED -1

typedef struct
{
	int X;
	int Y;
	int Z;
} XYZ;

typedef struct
{
	XYZ Start;
	XYZ End;
	bool Side[SIDES];
	int Linked[SIDES];
	XYZ TopLeft[SIDES];
	XYZ TopRight[SIDES];
	XYZ BottomLeft[SIDES];
	XYZ BottomRight[SIDES];
} ROOM3D;

typedef struct
{
	int X;
	int Y;
} XY;

typedef struct
{
	int Room1;
	int Room2;
	int Direction;
} ROOMLINK;

typedef struct
{
	unsigned long Model;
	D3DXVECTOR3 Location;
	D3DXVECTOR3 Direction;
} TRACK_PATCH;

class Map
{
private:
	ROOM3D Room[ROOMS];
int Rooms;

int Random_Room; // the room that current room is being linked to
int Wall; // the side in the current room that is being linked being 

ROOMLINK LinkRoom[65535];
int LinkRooms;

	void BuildRoom(const int room, const int object);
	const XYZ xyz(const int x, const int y, const int z);
	const void CreateRoom(const int room); // calc new room of random height and width
	const bool CheckRoom(const int room);
	const void ResetMap();
const void Link_Rooms(const int Room1, const int Room2, const int Direction);
const bool AttachToRandomRoom(const int room);
const void CreateRooms(const int rooms);
const int RandomPosition(const int, const int, const int, const int);
const bool Collision(const ROOM3D &, const ROOM3D &);
const void MarkWalls(const int, const int, const int);
const bool Used(const int, const int);
const bool BuildGap(const int);
const void WallGaps(const int);
const void WallGap(const int);
const void GapY(const XYZ room_start, const XYZ room_end, const XYZ random_room_start, const XYZ random_room_end, const D3DXVECTOR3 room_size, const D3DXVECTOR3 random_room_size, const int room_y, const int random_room_y, XYZ &room_top_left, XYZ &room_top_right, XYZ &room_bottom_left, XYZ &room_bottom_right, XYZ &random_room_top_left, XYZ &random_room_top_right, XYZ &random_room_bottom_left, XYZ &random_room_bottom_right);
const void GapX(const XYZ room_start, const XYZ room_end, const XYZ random_room_start, const XYZ random_room_end, const D3DXVECTOR3 room_size, const D3DXVECTOR3 random_room_size, const int room_x, const int random_room_x, XYZ &room_top_left, XYZ &room_top_right, XYZ &room_bottom_left, XYZ &room_bottom_right, XYZ &random_room_top_left, XYZ &random_room_top_right, XYZ &random_room_bottom_left, XYZ &random_room_bottom_right);
const void GapZ(const XYZ room_start, const XYZ room_end, const XYZ random_room_start, const XYZ random_room_end, const D3DXVECTOR3 room_size, const D3DXVECTOR3 random_room_size, const int room_z, const int random_room_z, XYZ &room_top_left, XYZ &room_top_right, XYZ &room_bottom_left, XYZ &room_bottom_right, XYZ &random_room_top_left, XYZ &random_room_top_right, XYZ &random_room_bottom_left, XYZ &random_room_bottom_right);
public:
	void Setup();
	~Map();
	ACTOR Track[65535];
	const void BuildRooms(const int rooms);
	unsigned long TrackSections;
};

#endif
