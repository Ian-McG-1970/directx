#include "d3d8_screen.h"
#include "load.h"
#include "map.h"

extern Screen screen;
extern Load load;
extern FILE *file;

void Map::Setup()
{
	fprintf(file,"map setup\n");

	BuildRooms(ROOMS);
}

Map::~Map()
{
	fprintf(file,"map shutdown\n");
}

void Map::BuildRoom(const int room, const int object)
{
	const D3DXVECTOR3 start = D3DXVECTOR3(Room[room].Start.X, Room[room].Start.Y, Room[room].Start.Z);
	const D3DXVECTOR3 end = D3DXVECTOR3(Room[room].Start.X + Room[room].End.X, Room[room].Start.Y + Room[room].End.Y, Room[room].Start.Z + Room[room].End.Z);
	const D3DXVECTOR3 offset = (end + start)*0.5f;
	const D3DXVECTOR3 size = end - offset;

	const D3DXVECTOR3 Vertex[] = {
		D3DXVECTOR3(-size.x, -size.y, -size.z), //0
		D3DXVECTOR3(+size.x, -size.y, -size.z), //1
		D3DXVECTOR3(-size.x, -size.y, +size.z), //2
		D3DXVECTOR3(+size.x, -size.y, +size.z), //3
		D3DXVECTOR3(-size.x, +size.y, -size.z), //4
		D3DXVECTOR3(+size.x, +size.y, -size.z), //5
		D3DXVECTOR3(-size.x, +size.y, +size.z), //6
		D3DXVECTOR3(+size.x, +size.y, +size.z), //7

		D3DXVECTOR3(Room[room].TopLeft[LEFT].X,Room[room].TopLeft[LEFT].Y,Room[room].TopLeft[LEFT].Z),D3DXVECTOR3(Room[room].TopRight[LEFT].X,Room[room].TopRight[LEFT].Y,Room[room].TopRight[LEFT].Z),D3DXVECTOR3(Room[room].BottomLeft[LEFT].X,Room[room].BottomLeft[LEFT].Y,Room[room].BottomLeft[LEFT].Z),D3DXVECTOR3(Room[room].BottomRight[LEFT].X,Room[room].BottomRight[LEFT].Y,Room[room].BottomRight[LEFT].Z),
		D3DXVECTOR3(Room[room].TopLeft[RIGHT].X,Room[room].TopLeft[RIGHT].Y,Room[room].TopLeft[RIGHT].Z),D3DXVECTOR3(Room[room].TopRight[RIGHT].X,Room[room].TopRight[RIGHT].Y,Room[room].TopRight[RIGHT].Z),D3DXVECTOR3(Room[room].BottomLeft[RIGHT].X,Room[room].BottomLeft[RIGHT].Y,Room[room].BottomLeft[RIGHT].Z),D3DXVECTOR3(Room[room].BottomRight[RIGHT].X,Room[room].BottomRight[RIGHT].Y,Room[room].BottomRight[RIGHT].Z),
		D3DXVECTOR3(Room[room].TopLeft[TOP].X,Room[room].TopLeft[TOP].Y,Room[room].TopLeft[TOP].Z),D3DXVECTOR3(Room[room].TopRight[TOP].X,Room[room].TopRight[TOP].Y,Room[room].TopRight[TOP].Z),D3DXVECTOR3(Room[room].BottomLeft[TOP].X,Room[room].BottomLeft[TOP].Y,Room[room].BottomLeft[TOP].Z),D3DXVECTOR3(Room[room].BottomRight[TOP].X,Room[room].BottomRight[TOP].Y,Room[room].BottomRight[TOP].Z),
		D3DXVECTOR3(Room[room].TopLeft[BOTTOM].X,Room[room].TopLeft[BOTTOM].Y,Room[room].TopLeft[BOTTOM].Z),D3DXVECTOR3(Room[room].TopRight[BOTTOM].X,Room[room].TopRight[BOTTOM].Y,Room[room].TopRight[BOTTOM].Z),D3DXVECTOR3(Room[room].BottomLeft[BOTTOM].X,Room[room].BottomLeft[BOTTOM].Y,Room[room].BottomLeft[BOTTOM].Z),D3DXVECTOR3(Room[room].BottomRight[BOTTOM].X,Room[room].BottomRight[BOTTOM].Y,Room[room].BottomRight[BOTTOM].Z),
		D3DXVECTOR3(Room[room].TopLeft[FRONT].X,Room[room].TopLeft[FRONT].Y,Room[room].TopLeft[FRONT].Z),D3DXVECTOR3(Room[room].TopRight[FRONT].X,Room[room].TopRight[FRONT].Y,Room[room].TopRight[FRONT].Z),D3DXVECTOR3(Room[room].BottomLeft[FRONT].X,Room[room].BottomLeft[FRONT].Y,Room[room].BottomLeft[FRONT].Z),D3DXVECTOR3(Room[room].BottomRight[FRONT].X,Room[room].BottomRight[FRONT].Y,Room[room].BottomRight[FRONT].Z),
		D3DXVECTOR3(Room[room].TopLeft[BACK].X,Room[room].TopLeft[BACK].Y,Room[room].TopLeft[BACK].Z),D3DXVECTOR3(Room[room].TopRight[BACK].X,Room[room].TopRight[BACK].Y,Room[room].TopRight[BACK].Z),D3DXVECTOR3(Room[room].BottomLeft[BACK].X,Room[room].BottomLeft[BACK].Y,Room[room].BottomLeft[BACK].Z),D3DXVECTOR3(Room[room].BottomRight[BACK].X,Room[room].BottomRight[BACK].Y,Room[room].BottomRight[BACK].Z),
	};

	const WORD IndexTop[] = { 4,5,7, 4,7,6 };
	const WORD IndexTopHole[] = {8 + (2*4) + 0, 4, 5, 8 + (2*4) + 0, 5, 8 + (2*4) + 3, 8 + (2*4) + 3, 5, 7, 8 + (2*4) + 3, 7, 8 + (2*4) + 2,
		8 + (2*4) + 2, 7, 6, 8 + (2*4) + 2, 6, 8 + (2*4) + 1, 8 + (2*4) + 1, 6, 4, 8 + (2*4) + 1, 4, 8 + (2*4) + 0};

	const WORD IndexBottom[] = { 0,3,1, 0,2,3 };
	const WORD IndexBottomHole[] = {8 + (3*4) + 0, 8 + (3*4) + 3, 1, 8 + (3*4) + 0, 1, 0, 8 + (3*4) + 1, 8 + (3*4) + 0, 0, 8 + (3*4) + 1, 0, 2,
		8 + (3*4) + 2, 8 + (3*4) + 1, 2, 8 + (3*4) + 2, 2, 3, 8 + (3*4) + 3, 8 + (3*4) + 2, 3, 8 + (3*4) + 3, 3, 1};

	const WORD IndexLeft[] = { 6, 2, 0, 6, 0, 4 };
	const WORD IndexLeftHole[]  = {8 + (0 * 4) + 0, 8 + (0 * 4) + 1, 2, 8 + (0 * 4) + 0, 2, 0, 8 + (0 * 4) + 1, 8 + (0 * 4) + 2, 6, 8 + (0 * 4) + 1, 6, 2,
		8 + (0 * 4) + 2, 8 + (0 * 4) + 3, 4, 8 + (0 * 4) + 2, 4, 6, 8 + (0 * 4) + 3, 8 + (0 * 4) + 0, 0, 8 + (0 * 4) + 3, 0, 4};

	const WORD IndexRight[] = { 1, 3, 7, 1, 7, 5 };
	const WORD IndexRightHole[] = {8 + (1 * 4) + 0, 8 + (1 * 4) + 3, 5, 8 + (1 * 4) + 0, 5, 1, 8 + (1 * 4) + 1, 8 + (1 * 4) + 0, 1, 8 + (1 * 4) + 1, 1, 3,
		8 + (1 * 4) + 2, 8 + (1 * 4) + 1, 3, 8 + (1 * 4) + 2, 3, 7, 8 + (1 * 4) + 3, 8 + (1 * 4) + 2, 7, 8 + (1 * 4) + 3, 7, 5};

	const WORD IndexBack[] = { 2, 7, 3, 2, 6, 7 };
	const WORD IndexBackHole[] = {8 + (5 * 4) + 0, 8 + (5 * 4) + 3, 3, 8 + (5 * 4) + 0, 3, 2, 8 + (5 * 4) + 1, 8 + (5 * 4) + 0, 2, 8 + (5 * 4) + 1, 2, 6, 
		8 + (5 * 4) + 2, 8 + (5 * 4) + 1, 6, 8 + (5 * 4) + 2, 6, 7, 8 + (5 * 4) + 3, 8 + (5 * 4) + 2, 7, 8 + (5 * 4) + 3, 7, 3};

	const WORD IndexFront[] = { 5, 0, 1, 5, 4, 0 };
	const WORD IndexFrontHole[]  = {
		8 + (4 * 4) + 0, 8 + (4 * 4) + 1, 4, 
		8 + (4 * 4) + 0, 4, 0, 
		8 + (4 * 4) + 3, 8 + (4 * 4) + 0, 0, 
		8 + (4 * 4) + 3, 0, 1,
		8 + (4 * 4) + 2, 8 + (4 * 4) + 3, 1, 
		8 + (4 * 4) + 2, 1, 5, 
		8 + (4 * 4) + 1, 8 + (4 * 4) + 2, 5, 
		8 + (4 * 4) + 1, 5, 4};

	const BYTE red1 = rand();
	const BYTE red2 = red1 >> 1;
	const BYTE red3 = red1 << 1;
	const BYTE red4 = red1 + red2;
	const BYTE red5 = red1 + red3;
	const BYTE red6 = red2 + red3;
	const BYTE green1 = rand();
	const BYTE green2 = green1 >> 1;
	const BYTE green3 = green1 << 1;
	const BYTE green4 = green1 + green2;
	const BYTE green5 = green1 + green3;
	const BYTE green6 = green2 + green3;
	const BYTE blue1 = rand();
	const BYTE blue2 = blue1 >> 1;
	const BYTE blue3 = blue1 << 1;
	const BYTE blue4 = blue1 + blue2;
	const BYTE blue5 = blue1 + blue3;
	const BYTE blue6 = blue2 + blue3;
	const BYTE gray1 = rand();
	const BYTE gray2 = gray1 >> 1;
	const BYTE gray3 = gray1 << 1;
	const BYTE gray4 = gray1 + gray2;
	const BYTE gray5 = gray1 + gray3;
	const BYTE gray6 = gray2 + gray3;
	const D3DCOLOR Shade[] = { D3DCOLOR_XRGB(red1,green1,blue1), D3DCOLOR_XRGB(red2,green2,blue2), D3DCOLOR_XRGB(red3,green3,blue3), 0, D3DCOLOR_XRGB(red4,green4,blue4), D3DCOLOR_XRGB(red5,green5,blue5), D3DCOLOR_XRGB(red6,green6,blue6), 0,
		D3DCOLOR_XRGB(red4,green4,blue4),
		D3DCOLOR_XRGB(red1,green1,blue1),
		D3DCOLOR_XRGB(red5,green5,blue5),
		D3DCOLOR_XRGB(red2,green2,blue2),
		D3DCOLOR_XRGB(red3,green3,blue3),
		D3DCOLOR_XRGB(red4,green4,blue4)	};

	D3DCOLOR Colour[] = {
		Shade[0],
		Shade[1],
		Shade[2],
		Shade[3],
		Shade[4],
		Shade[5],
		Shade[6],
		Shade[7],
		Shade[8], Shade[8], Shade[8], Shade[8], 
		Shade[9], Shade[9], Shade[9], Shade[9], 
		Shade[10], Shade[10], Shade[10], Shade[10],
		Shade[11], Shade[11], Shade[11], Shade[11], 
		Shade[12], Shade[12], Shade[12], Shade[12], 
		Shade[13], Shade[13], Shade[13], Shade[13]};
	int index=0;

	if (Room[room].Side[TOP] == true)
	{
		memcpy(&screen.Index[index], &IndexTopHole[0], sizeof(screen.Index[index])*24);
		index += 24;
	}
	else
	{
		memcpy(&screen.Index[index], &IndexTop[0], sizeof(screen.Index[index]) * 6);
		index += 6;
	}

	if (Room[room].Side[BOTTOM] == true) 
	{
		memcpy(&screen.Index[index], &IndexBottomHole[0], sizeof(screen.Index[index]) * 24);
		index += 24;
	}
	else
	{
		memcpy(&screen.Index[index], &IndexBottom[0], sizeof(screen.Index[index]) * 6);
		index += 6;
	}

	if (Room[room].Side[LEFT] == true)
	{
		memcpy(&screen.Index[index], &IndexLeftHole[0], sizeof(screen.Index[index]) * 24);
		index += 24;
	}
	else
	{
		memcpy(&screen.Index[index], &IndexLeft[0], sizeof(screen.Index[index]) * 6);
		index += 6;
	}

	if (Room[room].Side[RIGHT] == true)
	{ 
		memcpy(&screen.Index[index], &IndexRightHole[0], sizeof(screen.Index[index]) * 24);
		index += 24;
	}
	else
	{
		memcpy(&screen.Index[index], &IndexRight[0], sizeof(screen.Index[index]) * 6);
		index += 6;
	}
	if (Room[room].Side[FRONT] == true)
	{ 
		memcpy(&screen.Index[index], &IndexFrontHole[0], sizeof(screen.Index[index]) * 24);
		index += 24;
	}
	else
	{
		memcpy(&screen.Index[index], &IndexFront[0], sizeof(screen.Index[index]) * 6);
		index += 6;
	}
	if (Room[room].Side[BACK] == true)
	{ 
		memcpy(&screen.Index[index], &IndexBackHole[0], sizeof(screen.Index[index]) * 24);
		index += 24;
	}
	else
	{
		memcpy(&screen.Index[index], &IndexBack[0], sizeof(screen.Index[index]) * 6);
		index += 6;
	}

	int vertex = 0;
	for (vertex=0; vertex!=32; ++vertex)
	{
		screen.Vertex[vertex].Location = Vertex[vertex];
		screen.Vertex[vertex].Colour = Colour[vertex];
	}

	screen.CreateObject(vertex, index/3, object);
}

const bool Map::Collision(const ROOM3D &r1, const ROOM3D &r2)
{
	const XYZ r1end = xyz(r1.Start.X + r1.End.X, r1.Start.Y + r1.End.Y, r1.Start.Z + r1.End.Z);
	const XYZ r2end = xyz(r2.Start.X + r2.End.X, r2.Start.Y + r2.End.Y, r2.Start.Z + r2.End.Z);
	if ((r1.Start.X < r2end.X) && (r1end.X > r2.Start.X) && (r1.Start.Y < r2end.Y) && (r1end.Y > r2.Start.Y) && (r1.Start.Z < r2end.Z) && (r1end.Z > r2.Start.Z))
	{
		return true;
	}
	return false;
}

const void Map::BuildRooms(const int rooms)
{
	ResetMap();
	CreateRooms(rooms);
	TrackSections=rooms;
	for (int x=0; x!=TrackSections; ++x)
	{
		BuildRoom(x, x);
		Track[x].Model=x;
		Track[x].Location= D3DXVECTOR3(Room[x].Start.X+(Room[x].End.X*0.5), Room[x].Start.Y+(Room[x].End.Y*0.5), Room[x].Start.Z+(Room[x].End.Z*0.5));
	}
}

const XYZ Map::xyz(const int x, const int y, const int z)
{
	XYZ rc;
	rc.X = x;
	rc.Y = y;
	rc.Z = z;
	return rc;
}

const void Map::GapY(const XYZ room_start, const XYZ room_end, const XYZ random_room_start, const XYZ random_room_end, const D3DXVECTOR3 room_size, const D3DXVECTOR3 random_room_size, const int room_y, const int random_room_y, XYZ &room_top_left, XYZ &room_top_right, XYZ &room_bottom_left, XYZ &room_bottom_right, XYZ &random_room_top_left, XYZ &random_room_top_right, XYZ &random_room_bottom_left, XYZ &random_room_bottom_right)
{
	const int near_x = max(room_start.X, random_room_start.X);
	const int far_x = min(room_start.X + room_end.X, random_room_start.X + random_room_end.X);

	const int near_z = max(room_start.Z, random_room_start.Z);
	const int far_z = min(room_start.Z + room_end.Z, random_room_start.Z + random_room_end.Z);

	room_top_left = xyz(near_x - room_start.X - room_size.x, room_y, near_z - room_start.Z - room_size.z);
	room_top_right = xyz(near_x - room_start.X - room_size.x, room_y, far_z - room_start.Z - room_size.z);
	room_bottom_right = xyz(far_x - room_start.X - room_size.x, room_y, near_z - room_start.Z - room_size.z);
	room_bottom_left = xyz(far_x - room_start.X - room_size.x, room_y, far_z - room_start.Z - room_size.z);

	random_room_top_left = xyz(near_x - random_room_start.X - random_room_size.x, random_room_y, near_z - random_room_start.Z - random_room_size.z);
	random_room_top_right = xyz(near_x - random_room_start.X - random_room_size.x, random_room_y, far_z - random_room_start.Z - random_room_size.z);
	random_room_bottom_right = xyz(far_x - random_room_start.X - random_room_size.x, random_room_y, near_z - random_room_start.Z - random_room_size.z);
	random_room_bottom_left = xyz(far_x - random_room_start.X - random_room_size.x, random_room_y, far_z - random_room_start.Z - random_room_size.z);
}

const void Map::GapX(const XYZ room_start, const XYZ room_end, const XYZ random_room_start, const XYZ random_room_end, const D3DXVECTOR3 room_size, const D3DXVECTOR3 random_room_size, const int room_x, const int random_room_x, XYZ &room_top_left, XYZ &room_top_right, XYZ &room_bottom_left, XYZ &room_bottom_right, XYZ &random_room_top_left, XYZ &random_room_top_right, XYZ &random_room_bottom_left, XYZ &random_room_bottom_right)
{
	const int near_y = max(room_start.Y, random_room_start.Y);
	const int far_y = min(room_start.Y + room_end.Y, random_room_start.Y + random_room_end.Y);

	const int near_z = max(room_start.Z, random_room_start.Z);
	const int far_z = min(room_start.Z + room_end.Z, random_room_start.Z + random_room_end.Z);

	room_top_left = xyz(room_x, near_y - room_start.Y - room_size.y, near_z - room_start.Z - room_size.z);
	room_top_right = xyz(room_x, near_y - room_start.Y - room_size.y, far_z - room_start.Z - room_size.z);
	room_bottom_right = xyz(room_x, far_y - room_start.Y - room_size.y, near_z - room_start.Z - room_size.z);
	room_bottom_left = xyz(room_x, far_y - room_start.Y - room_size.y, far_z - room_start.Z - room_size.z);

	random_room_top_left = xyz(random_room_x, near_y - random_room_start.Y - random_room_size.y, near_z - random_room_start.Z - random_room_size.z);
	random_room_top_right = xyz(random_room_x, near_y - random_room_start.Y - random_room_size.y, far_z - random_room_start.Z - random_room_size.z);
	random_room_bottom_right = xyz(random_room_x, far_y - random_room_start.Y - random_room_size.y, near_z - random_room_start.Z - random_room_size.z);
	random_room_bottom_left = xyz(random_room_x, far_y - random_room_start.Y - random_room_size.y, far_z - random_room_start.Z - random_room_size.z);
}

const void Map::GapZ(const XYZ room_start, const XYZ room_end, const XYZ random_room_start, const XYZ random_room_end, const D3DXVECTOR3 room_size, const D3DXVECTOR3 random_room_size, const int room_z, const int random_room_z, XYZ &room_top_left, XYZ &room_top_right, XYZ &room_bottom_left, XYZ &room_bottom_right, XYZ &random_room_top_left, XYZ &random_room_top_right, XYZ &random_room_bottom_left, XYZ &random_room_bottom_right)
{
	const int near_x = max(room_start.X, random_room_start.X);
	const int far_x = min(room_start.X + room_end.X, random_room_start.X + random_room_end.X);

	const int near_y = max(room_start.Y, random_room_start.Y);
	const int far_y = min(room_start.Y + room_end.Y, random_room_start.Y + random_room_end.Y);

	room_top_left = xyz(near_x - room_start.X - room_size.x, near_y - room_start.Y - room_size.y, room_z);
	room_top_right = xyz(near_x - room_start.X - room_size.x, far_y - room_start.Y - room_size.y, room_z);
	room_bottom_right = xyz(far_x - room_start.X - room_size.x, near_y - room_start.Y - room_size.y, room_z);
	room_bottom_left = xyz(far_x - room_start.X - room_size.x, far_y - room_start.Y - room_size.y, room_z);

	random_room_top_left = xyz(near_x - random_room_start.X - random_room_size.x, near_y - random_room_start.Y - random_room_size.y, random_room_z);
	random_room_top_right = xyz(near_x - random_room_start.X - random_room_size.x, far_y - random_room_start.Y - random_room_size.y, random_room_z);
	random_room_bottom_right = xyz(far_x - random_room_start.X - random_room_size.x, near_y - random_room_start.Y - random_room_size.y, random_room_z);
	random_room_bottom_left = xyz(far_x - random_room_start.X - random_room_size.x, far_y - random_room_start.Y - random_room_size.y, random_room_z);
}

const void Map::MarkWalls(const int room, const int random_room, const int wall)
{
	if (Rooms != 0)
	{
		const D3DXVECTOR3 room_start = D3DXVECTOR3(Room[room].Start.X, Room[room].Start.Y, Room[room].Start.Z);
		const D3DXVECTOR3 room_end = D3DXVECTOR3(Room[room].Start.X + Room[room].End.X, Room[room].Start.Y + Room[room].End.Y, Room[room].Start.Z + Room[room].End.Z);
		const D3DXVECTOR3 room_offset = (room_end + room_start)*0.5f;
		const D3DXVECTOR3 room_size = room_end - room_offset;

		const D3DXVECTOR3 random_room_start = D3DXVECTOR3(Room[random_room].Start.X, Room[random_room].Start.Y, Room[random_room].Start.Z);
		const D3DXVECTOR3 random_room_end = D3DXVECTOR3(Room[random_room].Start.X + Room[random_room].End.X, Room[random_room].Start.Y + Room[random_room].End.Y, Room[random_room].Start.Z + Room[random_room].End.Z);
		const D3DXVECTOR3 random_room_offset = (random_room_end + random_room_start)*0.5f;
		const D3DXVECTOR3 random_room_size = random_room_end - random_room_offset;

		switch (wall)
		{
		case TOP:
			Room[room].Side[BOTTOM] = true; 
			Room[random_room].Side[TOP] = true;
			Room[room].Linked[BOTTOM] = random_room; 
			Room[random_room].Linked[TOP] = room;

			GapY(Room[random_room].Start, Room[random_room].End,
				Room[room].Start, Room[room].End,
				random_room_size, room_size,
				+random_room_size.y, -room_size.y,
				Room[random_room].TopLeft[TOP], Room[random_room].TopRight[TOP], Room[random_room].BottomLeft[TOP], Room[random_room].BottomRight[TOP],
				Room[room].TopLeft[BOTTOM], Room[room].TopRight[BOTTOM], Room[room].BottomLeft[BOTTOM], Room[room].BottomRight[BOTTOM]);
			break;

		case BOTTOM:
			Room[room].Side[TOP] = true;			
			Room[random_room].Side[BOTTOM] = true;
			Room[room].Linked[TOP] = random_room; 
			Room[random_room].Linked[BOTTOM] = room;

			GapY(Room[room].Start, Room[room].End,
				Room[random_room].Start, Room[random_room].End,
				room_size, random_room_size,
				+room_size.y, -random_room_size.y,
				Room[room].TopLeft[TOP], Room[room].TopRight[TOP], Room[room].BottomLeft[TOP], Room[room].BottomRight[TOP],
				Room[random_room].TopLeft[BOTTOM], Room[random_room].TopRight[BOTTOM], Room[random_room].BottomLeft[BOTTOM], Room[random_room].BottomRight[BOTTOM]);
			break;

		case LEFT:
			Room[room].Side[RIGHT] = true;			
			Room[random_room].Side[LEFT] = true;
			Room[room].Linked[RIGHT] = random_room; 
			Room[random_room].Linked[LEFT] = room;

			GapX(Room[random_room].Start, Room[random_room].End,
				Room[room].Start, Room[room].End,
				random_room_size, room_size,
				-random_room_size.x, +room_size.x,
				Room[random_room].TopLeft[LEFT], Room[random_room].TopRight[LEFT], Room[random_room].BottomLeft[LEFT], Room[random_room].BottomRight[LEFT],
				Room[room].TopLeft[RIGHT], Room[room].TopRight[RIGHT], Room[room].BottomLeft[RIGHT], Room[room].BottomRight[RIGHT]);
			break;

		case RIGHT:
			Room[room].Side[LEFT] = true;			
			Room[random_room].Side[RIGHT] = true;
			Room[room].Linked[LEFT] = random_room; 
			Room[random_room].Linked[RIGHT] = room;

			GapX(Room[room].Start, Room[room].End,
				Room[random_room].Start, Room[random_room].End,
				room_size, random_room_size,
				-room_size.x, +random_room_size.x,
				Room[room].TopLeft[LEFT], Room[room].TopRight[LEFT], Room[room].BottomLeft[LEFT], Room[room].BottomRight[LEFT],
				Room[random_room].TopLeft[RIGHT], Room[random_room].TopRight[RIGHT], Room[random_room].BottomLeft[RIGHT], Room[random_room].BottomRight[RIGHT]);
			break;

		case FRONT:
			Room[room].Side[BACK] = true;			
			Room[random_room].Side[FRONT] = true;
			Room[room].Linked[BACK] = random_room; 
			Room[random_room].Linked[FRONT] = room;

			GapZ(Room[random_room].Start, Room[random_room].End,
				Room[room].Start, Room[room].End,
				random_room_size, room_size,
				-random_room_size.z, +room_size.z,
				Room[random_room].TopLeft[FRONT], Room[random_room].TopRight[FRONT], Room[random_room].BottomLeft[FRONT], Room[random_room].BottomRight[FRONT],
				Room[room].TopLeft[BACK], Room[room].TopRight[BACK], Room[room].BottomLeft[BACK], Room[room].BottomRight[BACK]);
			break;

		case BACK:
			Room[room].Side[FRONT] = true;			
			Room[random_room].Side[BACK] = true;
			Room[room].Linked[FRONT] = random_room; 
			Room[random_room].Linked[BACK] = room;

			GapZ(Room[room].Start, Room[room].End,
				Room[random_room].Start, Room[random_room].End,
				room_size, random_room_size,
				-room_size.z, +random_room_size.z,
				Room[room].TopLeft[FRONT], Room[room].TopRight[FRONT], Room[room].BottomLeft[FRONT], Room[room].BottomRight[FRONT],
				Room[random_room].TopLeft[BACK], Room[random_room].TopRight[BACK], Room[random_room].BottomLeft[BACK], Room[random_room].BottomRight[BACK]);
			break;

		default:
			break;
		}
	}
}

const void Map::CreateRoom(const int room) // calc new room of random height and width
{
	for (int s=0; s!=SIDES; ++s)
	{
		Room[room].Side[s] = false;
		Room[room].Linked[s]=UNUSED;
	}

	while(true)
	{
		Room[room].End.X=(rand() &MAX_ROOM_SIZE) +MIN_ROOM_SIZE;
		Room[room].End.Y=(rand() &MAX_ROOM_SIZE) +MIN_ROOM_SIZE;
		Room[room].End.Z=(rand() &MAX_ROOM_SIZE) +MIN_ROOM_SIZE;

		if ( (Room[room].End.X<(Room[room].End.Y>>1))
			|| (Room[room].End.X<(Room[room].End.Z>>1))
			|| (Room[room].End.Y<(Room[room].End.X>>1))
			|| (Room[room].End.Y<(Room[room].End.Z>>1))
			|| (Room[room].End.Z<(Room[room].End.X>>1))
			|| (Room[room].End.Z<(Room[room].End.Y>>1)) )
		{
				continue;
		}
		return;
	}
}

const bool Map::Used(const int room, const int side)
{
	if (Room[room].Side[side]==true) return true;
	return false;
}

const bool Map::CheckRoom(const int room)
{
	if ( (Room[room].Start.X<0) || (Room[room].Start.X+Room[room].End.X>MAP_SIZE)
		|| (Room[room].Start.Y<0) || (Room[room].Start.Y+Room[room].End.Y>MAP_SIZE)
		|| (Room[room].Start.Z<0) || (Room[room].Start.Z+Room[room].End.Z>MAP_SIZE)
		) return false;

	const XYZ end=xyz(Room[room].Start.X+Room[room].End.X, Room[room].Start.Y+Room[room].End.Y, Room[room].Start.Z+Room[room].End.Z);

	for (int r=0; r!=room; ++r)
	{
		if (Collision(Room[room], Room[r])==true)
		{
			return false;
		}
	}
	return true;
}

const void Map::ResetMap()
{
	Rooms=0;
	LinkRooms=0;
}

const void Map::Link_Rooms(const int Room1, const int Room2, const int Direction)
{
	LinkRoom[LinkRooms].Room1=Room1;
	LinkRoom[LinkRooms].Room2=Room2;
	LinkRoom[LinkRooms].Direction=Direction;
	++LinkRooms;
}

const int Map::RandomPosition(const int random_room_start, const int random_room_end, const int room_start, const int room_end)
{
	if (random_room_end == room_end)
	{
		return random_room_start;
	}
	if (random_room_end < room_end) //< LT
	{
		return random_room_start - (rand() % (random_room_end - room_end));
	}
	return random_room_start + (rand() % (room_end - random_room_end));
}

const bool Map::AttachToRandomRoom(const int room)
{
	if (Rooms!=0)
	{
		Random_Room=rand()%Rooms;
		Wall = rand() % SIDES;
		fprintf(file, "Wall t2 %ld\n", Wall);
		Random_Room = rand() % Rooms;
//		if (Used(Random_Room, Wall)==true)
		if (Room[Random_Room].Side[Wall]==true)
		{
			return false;
		}

		switch (Wall)
		{
		case TOP:
		case BOTTOM:
		{
			const int room_diff_y = Room[room].End.Y;
			const int room_diff_z = Room[room].End.Z;
			const int random_room_diff_y = Room[Random_Room].End.Y;
			const int random_room_diff_z = Room[Random_Room].End.Z;
			if ((random_room_diff_y > room_diff_y) && (random_room_diff_z < room_diff_z)) return false;
			if ((random_room_diff_y < room_diff_y) && (random_room_diff_z > room_diff_z)) return false;
			if ((random_room_diff_z > room_diff_z) && (random_room_diff_y < room_diff_y)) return false;
			if ((random_room_diff_z < room_diff_z) && (random_room_diff_y > room_diff_y)) return false;
			break;
		}
		case LEFT:
		case RIGHT:
		{
			const int room_diff_x = Room[room].End.X;
			const int room_diff_z = Room[room].End.Z;
			const int random_room_diff_x = Room[Random_Room].End.X;
			const int random_room_diff_z = Room[Random_Room].End.Z;
			if ((random_room_diff_x > room_diff_x) && (random_room_diff_z < room_diff_z)) return false;
			if ((random_room_diff_x < room_diff_x) && (random_room_diff_z > room_diff_z)) return false;
			if ((random_room_diff_z > room_diff_z) && (random_room_diff_x < room_diff_x)) return false;
			if ((random_room_diff_z < room_diff_z) && (random_room_diff_x > room_diff_x)) return false;
			break;
		}
		case FRONT: 
		case BACK:
		{
			const int room_diff_x = Room[room].End.X;
			const int room_diff_y = Room[room].End.Y;
			const int random_room_diff_x = Room[Random_Room].End.X;
			const int random_room_diff_y = Room[Random_Room].End.Y;
			if ((random_room_diff_y > room_diff_y) && (random_room_diff_x < room_diff_x)) return false;
			if ((random_room_diff_y < room_diff_y) && (random_room_diff_x > room_diff_x)) return false;
			if ((random_room_diff_x > room_diff_x) && (random_room_diff_y < room_diff_y)) return false;
			if ((random_room_diff_x < room_diff_x) && (random_room_diff_y > room_diff_y)) return false;
			break;
		}
		}

		switch (Wall)
		{
		case RIGHT:
			Room[room].Start.X = Room[Random_Room].Start.X + Room[Random_Room].End.X;
			Room[room].Start.Y= RandomPosition(Room[Random_Room].Start.Y, Room[Random_Room].End.Y, Room[room].Start.Y, Room[room].End.Y);
			Room[room].Start.Z= RandomPosition(Room[Random_Room].Start.Z, Room[Random_Room].End.Z, Room[room].Start.Z, Room[room].End.Z);
			Link_Rooms(room, Random_Room, Wall);
			break;
		case LEFT:
			Room[room].Start.X = Room[Random_Room].Start.X - Room[room].End.X;
			Room[room].Start.Y= RandomPosition(Room[Random_Room].Start.Y, Room[Random_Room].End.Y, Room[room].Start.Y, Room[room].End.Y);
			Room[room].Start.Z= RandomPosition(Room[Random_Room].Start.Z, Room[Random_Room].End.Z, Room[room].Start.Z, Room[room].End.Z);
			Link_Rooms(room, Random_Room, Wall);
			break;
		case BOTTOM:
			Room[room].Start.Y= Room[Random_Room].Start.Y-Room[room].End.Y;
			Room[room].Start.X= RandomPosition(Room[Random_Room].Start.X, Room[Random_Room].End.X, Room[room].Start.X, Room[room].End.X);
			Room[room].Start.Z= RandomPosition(Room[Random_Room].Start.Z, Room[Random_Room].End.Z, Room[room].Start.Z, Room[room].End.Z);
			Link_Rooms(room, Random_Room, Wall);
			break;
		case TOP:
			Room[room].Start.Y= Room[Random_Room].Start.Y+Room[Random_Room].End.Y;
			Room[room].Start.X= RandomPosition(Room[Random_Room].Start.X, Room[Random_Room].End.X, Room[room].Start.X, Room[room].End.X);
			Room[room].Start.Z= RandomPosition(Room[Random_Room].Start.Z, Room[Random_Room].End.Z, Room[room].Start.Z, Room[room].End.Z);
			Link_Rooms(room, Random_Room, Wall);
			break;
		case FRONT:
			Room[room].Start.Z= Room[Random_Room].Start.Z-Room[room].End.Z;
			Room[room].Start.X= RandomPosition(Room[Random_Room].Start.X, Room[Random_Room].End.X, Room[room].Start.X, Room[room].End.X);
			Room[room].Start.Y= RandomPosition(Room[Random_Room].Start.Y, Room[Random_Room].End.Y, Room[room].Start.Y, Room[room].End.Y);
			Link_Rooms(room, Random_Room, Wall);
			break;
		case BACK:
			Room[room].Start.Z= Room[Random_Room].Start.Z+Room[Random_Room].End.Z;
			Room[room].Start.X= RandomPosition(Room[Random_Room].Start.X, Room[Random_Room].End.X, Room[room].Start.X, Room[room].End.X);
			Room[room].Start.Y= RandomPosition(Room[Random_Room].Start.Y, Room[Random_Room].End.Y, Room[room].Start.Y, Room[room].End.Y);
			Link_Rooms(room, Random_Room, Wall);
			break;
		default:
			break;
		}
	}
	else
	{
		Room[room].Start.X=(rand() &(MAP_SIZE-1)) +Room[room].End.X;
		Room[room].Start.Y=(rand() &(MAP_SIZE-1)) +Room[room].End.Y;
		Room[room].Start.Z=(rand() &(MAP_SIZE-1)) +Room[room].End.Z;
	}
	return true;
}

const void Map::CreateRooms(const int rooms)
{
	for (; Rooms!=rooms;)
	{
		CreateRoom(Rooms);
		if (AttachToRandomRoom(Rooms)==false) continue;
		if (CheckRoom(Rooms)==false) continue;
		MarkWalls(Rooms, Random_Room, Wall);
		++Rooms;
	}
}
