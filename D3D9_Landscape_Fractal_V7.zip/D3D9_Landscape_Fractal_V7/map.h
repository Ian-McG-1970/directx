#ifndef MAP
#define MAP

#include <stdio.h>

#define MAP_SIZE 64 // patches across/down
#define PATCH_SIZE 4096 //2048 // each patch is (patch size) across
#define MAP_DETAIL_SIZE MAP_SIZE * PATCH_SIZE	// map size = GRID_SIZE*PASTCH_SIZE = 32000 * 32000
#define MAP_SCALE 256
#define MAP_DIST 48
#define POINTS_IN_PATCH 65

typedef struct
{
	int Model;
} BEZIER_PATCH;

typedef struct
{
	int x;
	int y;
	float mx;
	float my;
} DrawOrderLocation;

typedef struct
{
	signed char TopLeft;
	signed char TopRight;
	signed char BottomLeft;
	signed char BottomRight;
} CORNER;

class Map
{
private:   
	float Rough[MAP_SIZE][MAP_SIZE];			// original map before smoothing	
	const void Generate();
	const void BuildDrawOrder(const int);
	const void AddDrawOrder(const int, const int);
	const void Fractal(const int, const int, const int, const int);
	const void FractalSetup(const int);
	const int ValuePos(const int number);
	const WORD BitPos(const WORD number);
	const CORNER Lookup(const int);
	const void Build();
	const int Bitmap(const signed char, const signed char, const signed char, const signed char);
	WORD type[MAP_SIZE][MAP_SIZE];
	const void ReSize();
	const void ReBuild();
	const void Scale();
	BEZIER_PATCH Patch[65535]; // patches to be drawn
	CORNER diff_array[65535];
	int bm;
	const void BuildPatch(const float, const float, const float, const float);
	const void FractalLine(const long, const long, const long, float *);
	const void FractalLineSetup(const long, const long, const long, const long, const long, float *);
	const void PatchSwap(const int, const float *);
	float patch1[POINTS_IN_PATCH][POINTS_IN_PATCH];
	const void Build_Patch(const int);
public:
	float Detail[MAP_SIZE][MAP_SIZE];			// detail map used for collision after smoothing
	BEZIER_PATCH Patch_Grid[MAP_SIZE][MAP_SIZE]; // patches to be drawn
	const float Height2(const D3DXVECTOR3&);
	const void Setup();
	~Map();
	DrawOrderLocation DrawOrder[MAP_SIZE*MAP_SIZE];
	int DrawOrderCount;
};

#endif
