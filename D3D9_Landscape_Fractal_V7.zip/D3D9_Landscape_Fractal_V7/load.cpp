#include "load.h"
#include "d3d8_screen.h"
#include "map.h"

extern FILE *file;
extern Screen screen;
extern Map map;

const void Load::Setup()
{
	fprintf(file, "Load setup\n");
}

Load::~Load()
{
	fprintf(file, "Load shutdown\n");
}

const int Load::Model(const char *name)
{
	fprintf(file,"load model %s\n", name);
	if ((fileopen=fopen(name, "r"))==NULL)
	{
		fprintf(file,"not found\n");
		return 0;
	}

	char rec[256];
	fscanf(fileopen, "%s", rec);
	const int vertices=atol(rec);
	fscanf(fileopen, "%s", rec);
	const int triangles=atol(rec);

	fprintf(file,"verts %ld tris %ld\n", vertices, triangles);

	fscanf(fileopen, "%s", rec);

	for (int b=0; b!=8; ++b)
	{
		fscanf(fileopen, "%s", rec);
		fscanf(fileopen, "%s", rec);
		fscanf(fileopen, "%s", rec);
	}
	
	for (int x=0; x!=vertices; ++x)
	{
		fscanf(fileopen, "%s", rec);
		screen.Vertex[x].Location.x=atof(rec);
		fscanf(fileopen, "%s", rec);
		screen.Vertex[x].Location.y=atof(rec);
		fscanf(fileopen, "%s", rec);
		screen.Vertex[x].Location.z=atof(rec);

		fscanf(fileopen, "%s", rec);
//		screen.Vertex[x].TU =atof(rec);
		fscanf(fileopen, "%s", rec);
//		screen.Vertex[x].TV =atof(rec);
	}

	for (int y=0, z=0; y!=triangles; ++y, z+=3)
	{
		fscanf(fileopen, "%s", rec);
		screen.Index[z] =atol(rec);
		fscanf(fileopen, "%s", rec);
		screen.Index[z+1] =atol(rec);
		fscanf(fileopen, "%s", rec);
		screen.Index[z+2] =atol(rec);
	}
	fclose(fileopen);
	fprintf(file, "t1 %ld %ld \n", vertices, triangles);

	return screen.CreateObject_NoNormal_Optimise(vertices, triangles);
}

const int Load::Model3(const int size, const int scale, const int stride)
{
	Model2(size, scale, stride);//(32, 64, 1);
	return screen.CreateObject_NoNormal_Optimise(Points, Triangles);
}

const int Load::Model4()
{
	screen.Vertex[0].Location = D3DXVECTOR3(0 * PATCH_SIZE, 0, 0 * PATCH_SIZE);
	screen.Vertex[1].Location = D3DXVECTOR3(1 * PATCH_SIZE, 0, 0 * PATCH_SIZE);
	screen.Vertex[2].Location = D3DXVECTOR3(0 * PATCH_SIZE, 0, 1 * PATCH_SIZE);
	screen.Vertex[3].Location = D3DXVECTOR3(1 * PATCH_SIZE, 0, 1 * PATCH_SIZE);

	Points=4;
	screen.Index[(0 * 3)] = 0;
	screen.Index[(0 * 3) + 1] = 3;
	screen.Index[(0 * 3) + 2] = 1;

	screen.Index[(1 * 3)] = 0;
	screen.Index[(1 * 3) + 1] = 2;
	screen.Index[(1 * 3) + 2] = 3;
	Triangles = 2;
	return screen.CreateObject_Normal_Optimise(Points, Triangles);
}

const void Load::AddTriangle(const int f, const int s, const int t)
{
	screen.Index[(Triangles * 3)] = s;
	screen.Index[(Triangles * 3)+1] = f;
	screen.Index[(Triangles*3)+2] = t;
	Triangle[Triangles].F = f;
	Triangle[Triangles].S = s;
	Triangle[Triangles].T = t;
	++Triangles;
}

const void Load::Model2(const int size, const int scale, const int stride)
{
	Size = size;
	Points = 0;
	for (int x = 0; x != Size + 1; ++x)
	{
		for (int y = 0; y != Size + 1; ++y)
		{
			Point[x][y].X = x;
			Point[x][y].Y = y;
			Point[x][y].Point = Points;
			screen.Vertex[Points].Location.x = x*scale;
			screen.Vertex[Points].Location.y = 0;
			screen.Vertex[Points].Location.z = y*scale;
			++Points;
		}
	}

	Triangles = 0;
	for (int s = 0; s != stride; ++s)
	{
		AddTriangle(Point[stride][stride].Point, Point[s][0].Point, Point[s + 1][0].Point);
		AddTriangle(Point[stride][stride].Point, Point[0][s + 1].Point, Point[0][s].Point);
		AddTriangle(Point[size - stride][size - stride].Point, Point[size - stride + s + 1][size].Point, Point[size - stride + s][size].Point);
		AddTriangle(Point[size - stride][size - stride].Point, Point[size][size - stride + s].Point, Point[size][size - stride + s + 1].Point);
		AddTriangle(Point[size - stride][stride].Point, Point[size - stride + s][0].Point, Point[size - stride + s + 1][0].Point);
		AddTriangle(Point[size - stride][stride].Point, Point[size][s].Point, Point[size][s + 1].Point);
		AddTriangle(Point[stride][size - stride].Point, Point[0][size - stride + s + 1].Point, Point[0][size - stride + s].Point);
		AddTriangle(Point[stride][size - stride].Point, Point[s + 1][size].Point, Point[s][size].Point);
	}

	for (int t = stride; t != Size - stride; t += stride)
	{
		for (int s = 0; s != stride; ++s)
		{
			AddTriangle(Point[t][stride].Point, Point[t + s][0].Point, Point[t + s + 1][0].Point);
			AddTriangle(Point[stride][t].Point, Point[0][t + s + 1].Point, Point[0][t + s].Point);
			AddTriangle(Point[t][size - stride].Point, Point[t + s + 1][size].Point, Point[t + s][size].Point);
			AddTriangle(Point[size - stride][t].Point, Point[size][t + s].Point, Point[size][t + s + 1].Point);
		}
		AddTriangle(Point[t][stride].Point, Point[t + stride][0].Point, Point[t + stride][stride].Point);
		AddTriangle(Point[stride][t].Point, Point[stride][t + stride].Point, Point[0][t + stride].Point);
		AddTriangle(Point[t][size - stride].Point, Point[t + stride][size - stride].Point, Point[t + stride][size].Point);
		AddTriangle(Point[size - stride][t].Point, Point[size][t + stride].Point, Point[size - stride][t + stride].Point);
	}

	for (int x = stride; x != Size - stride; x += stride)
	{
		for (int y = stride; y != Size - stride; y += stride)
		{
			AddTriangle(Point[x][y].Point, Point[x + stride][y + stride].Point, Point[x][y + stride].Point);
			AddTriangle(Point[x][y].Point, Point[x + stride][y].Point, Point[x + stride][y + stride].Point);
		}
	}
	fprintf(file, "t2 %ld %ld \n", Points, Triangles);
}
