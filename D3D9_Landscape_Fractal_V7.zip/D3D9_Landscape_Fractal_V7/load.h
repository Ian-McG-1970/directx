#ifndef LOAD
#define LOAD

#include <stdio.h>

#define MAX_SIZE 8192
typedef struct
{
	int X;
	int Y;
	int Point;
} POS;

typedef struct
{
	int X;
	int Y;
} PNT;

typedef struct
{
	int F;
	int S;
	int T;
} TRI;

class Load
{
	FILE	*fileopen;
	char rec[256];
private:
	POS Point[MAX_SIZE][MAX_SIZE];
	TRI Triangle[MAX_SIZE];
	int Size;
	const void AddTriangle(const int f, const int s, const int t);
public:
	int Points;
	int Triangles;
	const void	Setup();
	~Load();
	const int Model(const char *);
	const int Model3(const int, const int, const int);
	const void Model2(const int, const int, const int);
	const int Model4();
};

#endif
