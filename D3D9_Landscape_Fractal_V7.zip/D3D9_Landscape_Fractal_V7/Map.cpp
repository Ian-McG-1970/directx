#include "stdlib.h"
#include "time.h"

#include "d3d8_screen.h"
#include "load.h"
#include "map.h"

extern Screen screen;
extern Load load;
extern FILE *file;

const void Map::Setup()
{
	fprintf(file,"map setup\n");

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(255, 0, 0), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
	Generate();

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 255, 0), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
	FractalSetup(rand());

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(255, 0, 0), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
	ReSize();

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 255, 0), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
BuildDrawOrder(((((MAP_DIST+ (PATCH_SIZE*2 / 1024)) / (PATCH_SIZE / 1024)) +1) *2)+1);

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 0, 255), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
	Build();

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 0, 255), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
	ReBuild();
	Scale();
}

Map::~Map()
{
	fprintf(file,"map shutdown\n");
}

const void Map::FractalSetup(const int seed)
{
	srand(seed);
	for (int inc=MAP_SIZE>>1, loop=2; inc!=1; inc=inc>>1, loop+=loop)
	{
		for (int x=0, xs=0; x!=loop; ++x, xs+=inc)
		{
			for (int y=0, ys=0; y!=loop; ++y, ys+=inc)
			{
				Fractal(xs,ys,xs+inc,ys+inc);
			}
		}
	}
}

const void Map::Fractal(const int sx, const int sy, const int ex, const int ey)
{
	const int mx=(sx+ex)>>1;
	const int my=(sy+ey)>>1;

	const int sxp=sx &(MAP_SIZE-1);
	const int syp=sy &(MAP_SIZE-1);
	const int mxp=mx &(MAP_SIZE-1);
	const int myp=my &(MAP_SIZE-1);
	const int exp=ex &(MAP_SIZE-1);
	const int eyp=ey &(MAP_SIZE-1);

	const float top_left=Detail[sxp][syp];
	const float top_right=Detail[sxp][eyp];
	const float bottom_left=Detail[exp][syp];
	const float bottom_right=Detail[exp][eyp];

	const float top_max=max(top_left, top_right);
	const float bottom_max=max(bottom_left, bottom_right);
	const float left_max=max(top_left, bottom_right);
	const float right_max=max(top_right, bottom_right);

	float middle_max=max(top_max, bottom_max);
	middle_max=max(bottom_max, middle_max);
	middle_max=max(left_max, middle_max);
	middle_max=max(right_max, middle_max);

	const float middle=(top_left+top_right+bottom_right+bottom_left)*0.25f;
	const float top=(top_left+top_right)*0.5f;
	const float bottom=(bottom_left+bottom_right)*0.5f;
	const float left=(top_left+bottom_left)*0.5f;
	const float right=(top_right+bottom_right)*0.5f;

	const int middle_diff=labs(middle_max-middle);
	const int top_diff=labs(top_max-top);
	const int bottom_diff=labs(bottom_max-bottom);
	const int left_diff=labs(left_max-left);
	const int right_diff=labs(right_max-right);

	Detail[mxp][myp]=middle +(rand() %(middle_diff+1)) -(middle_diff>>1);
	Detail[sxp][myp]=top +(rand() %(top_diff+1)) -(top_diff>>1);
	Detail[exp][myp]=bottom +(rand() %(bottom_diff+1)) -(bottom_diff>>1);
	Detail[mxp][syp]=left +(rand() %(left_diff+1)) -(left_diff>>1);
	Detail[mxp][eyp]=right +(rand() %(right_diff+1)) -(right_diff>>1);
}

const void Map::Generate()
{
	for (int x=0; x!=MAP_SIZE; ++x)
	{
		for (int y=0; y!=MAP_SIZE; ++y)
		{
			Detail[x][y]=rand() &255;
		}
	}
}

const float Map::Height2(const D3DXVECTOR3 &location)
{
	const int map_tile_x = location.x / PATCH_SIZE;
	const int map_tile_z = location.z / PATCH_SIZE;
	return Detail[map_tile_x][map_tile_z];
}

const void Map::AddDrawOrder(const int x, const int y)
{
	for (int c=0; c!=DrawOrderCount; ++c)
	{
		if ((DrawOrder[c].x==x) && (DrawOrder[c].y==y))
	 {
			return;
		}
	}
	++DrawOrderCount;
	DrawOrder[DrawOrderCount].x=x;
	DrawOrder[DrawOrderCount].y=y;
	DrawOrder[DrawOrderCount].mx=x*PATCH_SIZE;
	DrawOrder[DrawOrderCount].my=y*PATCH_SIZE;
}

const void Map::BuildDrawOrder(const int patch_end)
{
	fprintf(file, "bdo %i\n", patch_end);
	DrawOrderCount=0;
	const int distance=(patch_end-1)>>1;
	AddDrawOrder(0, 0);
	for (int d=0; d!=distance; ++d)
	{
		for (int x=0; x!=d; ++x)
		{
			for (int y=0; y!=d; ++y)
			{
				if ((sqrtf( (x*x)+(y*y) )) > (float)distance) continue;
				AddDrawOrder(x, y);
				AddDrawOrder(x, -y);
				AddDrawOrder(-x, y);
				AddDrawOrder(-x, -y);
			}
		}
	}
}

const CORNER Map::Lookup(const int number)
{
	CORNER corner;
	corner.TopLeft = diff_array[number].TopLeft;
	corner.TopRight = diff_array[number].TopRight;
	corner.BottomRight = diff_array[number].BottomRight;
	corner.BottomLeft = diff_array[number].BottomLeft;
	return corner;
}

const int Map::Bitmap(const signed char tl, const signed char tr, const signed char bl, const signed char br)
{
	for (int a = 0; a != bm; ++a)
	{
		if ( (diff_array[a].TopLeft == tl) && (diff_array[a].TopRight == tr) && (diff_array[a].BottomRight == br) && (diff_array[a].BottomLeft == bl) )
		{
			return a;
		}
	}
	diff_array[bm].TopLeft = tl;
	diff_array[bm].TopRight = tr;
	diff_array[bm].BottomRight = br;
	diff_array[bm].BottomLeft = bl;
	++bm;
	return bm - 1;
}

const void Map::Build()
{
	bm = 0;
	for (int x = 0; x != MAP_SIZE; ++x)
	{
		const int nx = (x + 1)  &(MAP_SIZE - 1);
		for (int y = 0; y != MAP_SIZE; ++y)
		{
			const int ny = (y + 1)  &(MAP_SIZE - 1);

			const float tl= Detail[x][y];
			const float bl= Detail[x][ny];
			const float tr= Detail[nx][y];
			const float br= Detail[nx][ny];
			const signed char tltl= tl - tl;
			const signed char tltr= tr - tl;
			const signed char tlbr= br - tl;
			const signed char tlbl= bl - tl;
			type[x][y] = Bitmap(tltl, tltr, tlbl, tlbr);
		}
	}
}

const void Map::ReBuild()
{
	for (int a=0; a!=bm; ++a)
	{
		memcpy(&screen.Vertex[0], &screen.Copy_Vertex[0], sizeof(screen.Vertex[0])*screen.Copy_Vertex_Count);
		const CORNER corner = Lookup(a);
		BuildPatch(corner.TopLeft *MAP_SCALE, corner.TopRight *MAP_SCALE, corner.BottomLeft *MAP_SCALE, corner.BottomRight *MAP_SCALE);
		Build_Patch(1/*2*//*4*//*8*//*16*//*32*/);
		memcpy(&screen.Index[0], &screen.Copy_Index[0], sizeof(screen.Index[0])*screen.Copy_Index_Count * 3);
		Patch[a].Model = screen.CreateObject_NoNormal_Optimise(screen.Copy_Vertex_Count, screen.Copy_Index_Count);
	}
	fprintf(file, "tst99 %i %i %i\n", bm, screen.Copy_Vertex_Count, screen.Copy_Index_Count);

	for (int x=0; x!=MAP_SIZE; ++x)
	{
		for (int y=0; y!=MAP_SIZE; ++y)
		{
			Patch_Grid[x][y].Model = Patch[type[x][y]].Model;
		}
	}
}

const void Map::ReSize()
{
	float lowest=Detail[0][0], highest=Detail[0][0];
	for (int x=0; x!=MAP_SIZE; ++x)
	{
		for (int y=0; y!=MAP_SIZE; ++y)
		{
			lowest = min(lowest, Detail[x][y]);
			highest = max(highest, Detail[x][y]);
		}
	}
	highest -= lowest;
	for (int x=0; x!=MAP_SIZE; ++x)
	{
		for (int y=0; y!=MAP_SIZE; ++y)
		{
			Detail[x][y] -= lowest;
		}
	}
	const float ratio = 255.0f / (highest);
	for (int x=0; x!=MAP_SIZE; ++x)
	{
		for (int y=0; y!=MAP_SIZE; ++y)
		{
			Detail[x][y] *= ratio;
			Detail[x][y] = (int)Detail[x][y];
		}
	}
}

const void Map::Scale()
{
	for (int x = 0; x != MAP_SIZE; ++x)
	{
		for (int y = 0; y != MAP_SIZE; ++y)
		{
			Detail[x][y] *= MAP_SCALE;
		}
	}
}

const void Map::BuildPatch(const float tl, const float tr, const float bl, const float br)
{
	FractalLineSetup(0, POINTS_IN_PATCH - 1, tl, tr, fabs(tl) + fabs(tr) + fabs(bl) + fabs(br)/*tl + tr + bl + br*/, &patch1[0][0]);
	FractalLineSetup(0, POINTS_IN_PATCH - 1, bl, br, fabs(tl) + fabs(tr) + fabs(bl) + fabs(br), &patch1[POINTS_IN_PATCH - 1][0]);

	float output[POINTS_IN_PATCH];
	FractalLineSetup(0, POINTS_IN_PATCH - 1, tl, bl, fabs(tl) + fabs(tr) + fabs(bl) + fabs(br), &output[0]);
	PatchSwap(0, &output[0]);
	FractalLineSetup(0, POINTS_IN_PATCH - 1, tr, br, fabs(tl) + fabs(tr) + fabs(bl) + fabs(br), &output[0]);
	PatchSwap(POINTS_IN_PATCH - 1, &output[0]);

	for (int y = 1; y != POINTS_IN_PATCH - 1; ++y)
	{
		FractalLineSetup(0, POINTS_IN_PATCH - 1, patch1[y][0], patch1[y][POINTS_IN_PATCH - 1], fabs(tl) + fabs(tr) + fabs(bl) + fabs(br), &patch1[y][0]);
	}

	float patch2[POINTS_IN_PATCH][POINTS_IN_PATCH];
	for (int x = 0; x != POINTS_IN_PATCH; ++x)
	{
		for (int y = 0; y != POINTS_IN_PATCH; ++y)
		{
			patch2[x][y] = patch1[x][y];
		}
	}

	for (int y = 1; y != POINTS_IN_PATCH - 1; ++y)
	{
		FractalLineSetup(0, POINTS_IN_PATCH - 1, patch1[0][y], patch1[POINTS_IN_PATCH - 1][y], fabs(tl) + fabs(tr) + fabs(bl) + fabs(br), &output[0]);
		PatchSwap(y, &output[0]);
	}

	for (int x = 0; x != POINTS_IN_PATCH; ++x)
	{
		for (int y = 0; y != POINTS_IN_PATCH; ++y)
		{
			patch1[x][y] = (patch2[x][y] + patch1[x][y]) *0.5f;
		}
	}

}

const void Map::FractalLine(const long start, const long end, const long seed, float *output)
{
	if ((start + 1) == end) return;
	const int middle = (start + end) >> 1;
	const int maxseed = end - start - 1;
	output[middle] = ((output[start] + output[end]) *0.5f) + (seed &(maxseed)) - (maxseed >> 1);
	FractalLine(start, middle, output[start] + output[middle] + seed, &output[0]);
	FractalLine(middle, end, output[middle] + output[end] + seed, &output[0]);
}

const void Map::FractalLineSetup(const long start, const long end, const long startvalue, const long endvalue, const long seed, float *output)
{
	output[start] = startvalue;
	output[end] = endvalue;

	FractalLine(start, end, output[start] + output[end] + seed, &output[start]);
}

const void Map::PatchSwap(const int x, const float * input)
{
	for (int p = 0; p != POINTS_IN_PATCH; ++p)
	{
		patch1[p][x] = input[p];
	}
}

const void Map::Build_Patch(const int stride)
{
	int stride_count= POINTS_IN_PATCH;
	if (stride!=1)
	{
		stride_count = (POINTS_IN_PATCH / stride) + 1;
	}

	for (int v=0, sx = 0, x=0; sx != stride_count; x+=stride, ++sx)
	{
		for (int sy=0, y = 0; sy != stride_count; y+=stride, ++sy, ++v)
		{
			screen.Vertex[v].Location = D3DXVECTOR3(screen.Copy_Vertex[v].Location.x, patch1[y][x], screen.Copy_Vertex[v].Location.z);
		}
	}

/*	int v = 0;
	for (int x = 0; x < POINTS_IN_PATCH; x+=stride)
	{
		for (int y = 0; y < POINTS_IN_PATCH; y+=stride)
		{
			screen.Vertex[v].Location = D3DXVECTOR3(screen.Copy_Vertex[v].Location.x, patch1[y][x], screen.Copy_Vertex[v].Location.z);
			++v;
		}
	}*/
}
