#ifndef MAP
#define MAP

#include <stdio.h>
#include "map_size.h"

typedef struct
{
	int Model;
	D3DXVECTOR3	BoundingSphereCentre;
	float				BoundingSphereRadius;
	D3DXVECTOR3	BoundingBox[MAX_BOUNDING_BOX];
} BEZIER_PATCH;

typedef struct
{
	int x;
	int y;
	float mx;
	float my;
	int lod;
} DrawOrderLocation;

typedef struct
{
	int x;
	int y;
	int Lod;
	int Model;
	int Frame;
} PATCHBUFFER;

#define MAX_PATCHBUFFER 1000

#define MAP_MAX_HEIGHT 32767 // 32767 //8191 //16383 //4095 //1023 //511
#define PATCH_SIZE 4096 // 4096 //8192 // each patch is (patch size) across
#define MAP_SIZE PATCH_POINTS * PATCH_COUNT // points across/down
#define MAP_DETAIL_SIZE PATCH_COUNT * PATCH_SIZE	// map size = GRID_SIZE*PASTCH_SIZE = 32000 * 32000
#define MAP_TILE_SIZE PATCH_SIZE / PATCH_POINTS // each tile is PATCH_SIZE / BEZIER CURVE SIZE

class Map
{
private:   
	unsigned short Rough[MAP_SIZE][MAP_SIZE];			// original map before smoothing
	const void Generate();
	const void Build_Patch(const int, const int, const int);
	const void Build_Grid();
	const void Stretch();
	const void BuildDrawOrder(const int);
	const void AddDrawOrder(const int, const int);
	const void Fractal(const int, const int, const int, const int);
	const void FractalSetup(const int);
	const int FindPatch(const int, const int, const int, const int);
	PATCHBUFFER PatchBuffer[MAX_PATCHBUFFER];
public:
	unsigned short  Detail[MAP_SIZE][MAP_SIZE];			// detail map used for collision after smoothing
	BEZIER_PATCH Patch_Grid[PATCH_COUNT][PATCH_COUNT][PATCH_LOD]; // patches to be drawn
	const float Height(const D3DXVECTOR3*);
	const void Setup();
	~Map();
	DrawOrderLocation DrawOrder[PATCH_COUNT*PATCH_COUNT];
	int DrawOrderCount;
};

#endif
