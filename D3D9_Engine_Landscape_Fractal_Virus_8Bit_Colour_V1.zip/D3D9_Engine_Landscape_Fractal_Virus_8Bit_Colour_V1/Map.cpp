#include "stdlib.h"
#include "time.h"

#include "d3d8_screen.h"
#include "load.h"
#include "map.h"

extern Screen screen;
extern Load load;
extern FILE *file;

const void Map::Setup()
{
	fprintf(file,"map setup\n");

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(255, 0, 0), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
	Generate();

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 255, 0), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
	FractalSetup(rand());

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 0, 255), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
	Stretch();

//screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(255, 0, 0), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 255, 0), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
	Build_Grid();

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 0, 255), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
	BuildDrawOrder(29);
}

Map::~Map()
{
	fprintf(file,"map shutdown\n");
}

const void Map::FractalSetup(const int seed)
{
	srand(seed);
	for (int inc=MAP_SIZE>>1, loop=2; inc!=1; inc=inc>>1, loop+=loop)
	{
		for (int x=0, xs=0; x!=loop; ++x, xs+=inc)
		{
			for (int y=0, ys=0; y!=loop; ++y, ys+=inc)
			{
				Fractal(xs,ys,xs+inc,ys+inc);
			}
		}
	}
}

const void Map::Fractal(const int sx, const int sy, const int ex, const int ey)
{
	const int mx=(sx+ex)>>1;
	const int my=(sy+ey)>>1;

	const int sxp=sx &(MAP_SIZE-1);
	const int syp=sy &(MAP_SIZE-1);
	const int mxp=mx &(MAP_SIZE-1);
	const int myp=my &(MAP_SIZE-1);
	const int exp=ex &(MAP_SIZE-1);
	const int eyp=ey &(MAP_SIZE-1);

	const float top_left=Detail[sxp][syp];
	const float top_right=Detail[sxp][eyp];
	const float bottom_left=Detail[exp][syp];
	const float bottom_right=Detail[exp][eyp];

	const float top_max=max(top_left, top_right);
	const float bottom_max=max(bottom_left, bottom_right);
	const float left_max=max(top_left, bottom_right);
	const float right_max=max(top_right, bottom_right);

	float middle_max=max(top_max, bottom_max);
	middle_max=max(bottom_max, middle_max);
	middle_max=max(left_max, middle_max);
	middle_max=max(right_max, middle_max);

	const float middle=(top_left+top_right+bottom_right+bottom_left)*0.25f;
	const float top=(top_left+top_right)*0.5f;
	const float bottom=(bottom_left+bottom_right)*0.5f;
	const float left=(top_left+bottom_left)*0.5f;
	const float right=(top_right+bottom_right)*0.5f;

	const int middle_diff=labs(middle_max-middle);
	const int top_diff=labs(top_max-top);
	const int bottom_diff=labs(bottom_max-bottom);
	const int left_diff=labs(left_max-left);
	const int right_diff=labs(right_max-right);

	Detail[mxp][myp]=middle +(rand() %(middle_diff+1)) -(middle_diff>>1);
	Detail[sxp][myp]=top +(rand() %(top_diff+1)) -(top_diff>>1);
	Detail[exp][myp]=bottom +(rand() %(bottom_diff+1)) -(bottom_diff>>1);
	Detail[mxp][syp]=left +(rand() %(left_diff+1)) -(left_diff>>1);
	Detail[mxp][eyp]=right +(rand() %(right_diff+1)) -(right_diff>>1);
}

const void Map::Build_Grid()
{
	D3DXVECTOR3 point[MAX_VERTICES];

	for (int x=0; x<PATCH_COUNT; ++x)
	{
		for (int y=0; y!= PATCH_COUNT; ++y)
		{
			Build_Patch(x, y, 0);

			for (int v=0; v!=load.Vertex_Count[0]; ++v) point[v]=screen.Vertex[v].Location;
			screen.BoundingBox(&point[0], load.Vertex_Count[0], &Patch_Grid[x][y][0].BoundingBox[0]);
			screen.BoundingSphere(&Patch_Grid[x][y][0].BoundingBox[0], MAX_BOUNDING_BOX, Patch_Grid[x][y][0].BoundingSphereRadius, Patch_Grid[x][y][0].BoundingSphereCentre);

//			Patch_Grid[x][y][0].Model = screen.CreateObject_Normal_Optimise(load.Vertex_Count[0], load.Index_Count[0]);

			Build_Patch(x, y, 1);
//			Patch_Grid[x][y][1].Model = screen.CreateObject_Normal_Optimise(load.Vertex_Count[1], load.Index_Count[1]);

			Build_Patch(x, y, 2);
//			Patch_Grid[x][y][2].Model = screen.CreateObject_Normal_Optimise(load.Vertex_Count[2], load.Index_Count[2]);

			Build_Patch(x, y, 3);
//			Patch_Grid[x][y][3].Model = screen.CreateObject_Normal_Optimise(load.Vertex_Count[3], load.Index_Count[3]);

			Build_Patch(x, y, 4);
			Patch_Grid[x][y][4].Model = screen.CreateObject_Normal_Optimise(load.Vertex_Count[4], load.Index_Count[4]);
			Patch_Grid[x][y][0].Model = Patch_Grid[x][y][1].Model = Patch_Grid[x][y][2].Model = Patch_Grid[x][y][3].Model = Patch_Grid[x][y][4].Model;
		}
	}
}

const void Map::Build_Patch(const int patch_x, const int patch_y, const int lod)
{
	memcpy(&screen.Index[0], &load.Index[lod][0], sizeof(screen.Index[0])*load.Index_Count[lod] * 3);

	const int detail_x = patch_x*PATCH_POINTS;
	const int detail_y = patch_y*PATCH_POINTS;
	int v=0;
	for (int x=0; x!= PATCH_POINTS + 1; ++x)
	{
		const int bezier_x=(detail_x+x) &(MAP_SIZE-1);
		for (int y=0; y!= PATCH_POINTS + 1; ++y)
		{
			const int bezier_y=(detail_y+y) &(MAP_SIZE-1);
			screen.Vertex[v].Location = D3DXVECTOR3(load.Vertex[lod][v].Location.x, Detail[bezier_x][bezier_y], load.Vertex[lod][v].Location.z);
			screen.Vertex[v].TU = load.Vertex[lod][v].TU + load.TextureCoords2[patch_x];
			screen.Vertex[v].TV = load.Vertex[lod][v].TV + load.TextureCoords2[patch_y];
			++v;
		}
	}
//	fprintf(file, "bp %i %i %f %f %f %f\n", detail_x, detail_y, screen.Vertex[0].TU, screen.Vertex[0].TV, screen.Vertex[v-1].TU, screen.Vertex[v-1].TV);
}

const void Map::Generate()
{
	for (int x=0; x!=MAP_SIZE; ++x)
	{
		for (int y=0; y!=MAP_SIZE; ++y)
		{
			Detail[x][y]=(rand() &MAP_MAX_HEIGHT) +MAP_MAX_HEIGHT;
		}
	}
}

const void Map::Stretch()
{
	float lowest=Detail[0][0];
	for (int x=0; x!=MAP_SIZE; ++x)
	{
		for (int y=0; y!=MAP_SIZE; ++y)
		{
			lowest=min(lowest, Detail[x][y]);
		}
	}
	lowest--;
	for (int x=0; x!=MAP_SIZE; ++x)
	{
		for (int y=0; y!=MAP_SIZE; ++y)
		{
			Detail[x][y]-=lowest;
		}
	}
	float highest=Detail[0][0];
	for (int x=0; x!=MAP_SIZE; ++x)
	{
		for (int y=0; y!=MAP_SIZE; ++y)
		{
			highest=max(highest, Detail[x][y]);
		}
	}
	++highest;
	const float stretch_ratio=(float) MAP_MAX_HEIGHT/highest;
	for (int x=0; x!=MAP_SIZE; ++x)
	{
		for (int y=0; y!=MAP_SIZE; ++y)
		{
			Detail[x][y]*=stretch_ratio;
		}
	}
	fprintf(file,"lowest %f highest %f\n",lowest,highest);

	highest = lowest = Detail[0][0];
	for (int x = 0; x != MAP_SIZE; ++x)
	{
		for (int y = 0; y != MAP_SIZE; ++y)
		{
			lowest = min(lowest, Detail[x][y]);
			highest = max(highest, Detail[x][y]);
		}
	}
	fprintf(file, "lowest %f highest %f\n", lowest, highest);
}

const float Map::Height(const D3DXVECTOR3* location) //todo could be made more accurate if across and down were calculated with float accuracy
{
	const float MTS = MAP_TILE_SIZE;
	const int map_tile_x=location->x / MTS;
	const int map_tile_z=location->z / MTS;
	const int across = (int) location->x &(MAP_TILE_SIZE-1);
	const int down = (int) location->z &(MAP_TILE_SIZE-1);
	
	float x0z1, x1z0;
	const float x0z0=Detail[map_tile_x][map_tile_z];
	const float x1z1=Detail[map_tile_x+1][map_tile_z+1];
	const float ave=(x0z0+x1z1)/2.0f;
	if (across>down)
	{
		x1z0=Detail[map_tile_x+1][map_tile_z];
		x0z1=ave+ave-x1z0;
	}
	else
	{
		x0z1=Detail[map_tile_x][map_tile_z+1];
		x1z0=ave+ave-x0z1;
	}
	const float slope_x1 = x0z0 - (((x0z0-x1z0) * across) / MTS);
	const float slope_x2 = x0z1 - (((x0z1-x1z1) * across) / MTS);
	const float slope_y1 = slope_x1 - (((slope_x1 - slope_x2) * down) / MTS);

	return slope_y1;
}

const void Map::AddDrawOrder(const int x, const int y)
{
	for (int c=0; c!=DrawOrderCount; ++c)
	{
		if ((DrawOrder[c].x==x) && (DrawOrder[c].y==y))
		{
			return;
		}
	}
//	++DrawOrderCount;
	DrawOrder[DrawOrderCount].x=x;
	DrawOrder[DrawOrderCount].y=y;
	DrawOrder[DrawOrderCount].mx=x*PATCH_SIZE;
	DrawOrder[DrawOrderCount].my=y*PATCH_SIZE;
	DrawOrder[DrawOrderCount].lod = sqrt(abs(x*x) + abs(y*y));
//	DrawOrder[DrawOrderCount].lod = max(abs(x), abs(y));
//	DrawOrder[DrawOrderCount].lod=min(abs(x),abs(y));

//	fprintf(file,"ado1 c %i x %i y %i lod %i\n", DrawOrderCount, DrawOrder[DrawOrderCount].x, DrawOrder[DrawOrderCount].y, DrawOrder[DrawOrderCount].lod);
	DrawOrder[DrawOrderCount].lod /= 3;
//	fprintf(file,"ado2 c %i x %i y %i lod %i\n",DrawOrderCount,DrawOrder[DrawOrderCount].x,DrawOrder[DrawOrderCount].y, DrawOrder[DrawOrderCount].lod);
	++DrawOrderCount;
}

const void Map::BuildDrawOrder(const int patch_end)
{
	DrawOrderCount=0;
	AddDrawOrder(0, 0);
	const int distance = (patch_end - 1) >> 1;
	for (int d=0; d!=distance; ++d)
	{
		for (int x=0; x!=d; ++x)
		{
			for (int y=0; y!=d; ++y)
			{
				if ((sqrtf( (x*x)+(y*y) )) > (float)distance) continue;
				AddDrawOrder(x, y);
				AddDrawOrder(x, -y);
				AddDrawOrder(-x, y);
				AddDrawOrder(-x, -y);
			}
		}
	}
}

const int Map::FindPatch(const int x, const int y, const int lod, const int frame)
{
	for (int i=0; i!=MAX_PATCHBUFFER; ++i)
	{
		if ((PatchBuffer[i].x == x) && (PatchBuffer[i].y == y) && (PatchBuffer[i].Lod == lod))
		{
			PatchBuffer[i].Frame = frame;
			return PatchBuffer[i].Model;
		}
	}
	int smallest_frame = PatchBuffer[0].Frame;
	for (int i=0; i!=MAX_PATCHBUFFER; ++i)
	{
		smallest_frame = min(PatchBuffer[i].Frame, smallest_frame);
	}
//	delete PatchBuffer[smallest_frame].model;
//	PatchBuffer[smallest_frame].Model = build(x, y, lod, i);
	PatchBuffer[smallest_frame].Frame = frame;
	return PatchBuffer[smallest_frame].Model;
}
