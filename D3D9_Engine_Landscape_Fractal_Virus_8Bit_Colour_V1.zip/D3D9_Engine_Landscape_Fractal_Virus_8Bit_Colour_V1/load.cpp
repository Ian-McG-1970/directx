#include "load.h"
#include "d3d8_screen.h"
#include "map.h"

extern FILE *file;
extern Screen screen;
extern Map map;

const void Load::Setup(const D3DFORMAT format)
{
	fprintf(file, "Load setup\n");
	Format = format;
	const double tc_ratio = (double)1.0 / (double)(PATCH_COUNT*PATCH_POINTS);
	for (int t = 0; t != (PATCH_POINTS + 1); ++t)
	{
		Texture_Coord[t] = tc_ratio *(double)t;
//		fprintf(file, "tc %i %f\n", t, Texture_Coord[t]);
	}

	const double tc2_ratio = (double)1.0 / (double)PATCH_COUNT;
	for (int t = 0; t != PATCH_COUNT; ++t)
	{
		TextureCoords2[t] = tc2_ratio *(double)t;
//		fprintf(file, "tc2 %i %f\n", t, TextureCoords2[t]);
	}

}

Load::~Load()
{
	fprintf(file, "Load shutdown\n");
}

const int Load::Model3(const int size, const int scale, const int stride)
{
	Model2(size, scale, stride);
	return screen.CreateObject_NoNormal_Optimise(Points, Triangles);
}

const void Load::AddTriangle(const int f, const int s, const int t)
{
	screen.Index[(Triangles * 3)] = s;
	screen.Index[(Triangles * 3)+1] = f;
	screen.Index[(Triangles*3)+2] = t;
	Triangle[Triangles].F = f;
	Triangle[Triangles].S = s;
	Triangle[Triangles].T = t;
	++Triangles;
}

const void Load::Model2(const int size, const int scale, const int stride)
{
	Size = size;
	Points = 0;
	for (int x = 0; x != Size + 1; ++x)
	{
		for (int y = 0; y != Size + 1; ++y)
		{
			Point[x][y].X = x;
			Point[x][y].Y = y;
			Point[x][y].Point = Points;
			Pnt[Points].X = x;
			Pnt[Points].Y = y;
			screen.Vertex[Points].Location.x = x*scale;
			screen.Vertex[Points].Location.y = 0;
			screen.Vertex[Points].Location.z = y*scale;
			screen.Vertex[Points].TU = Texture_Coord[x];
			screen.Vertex[Points].TV = Texture_Coord[y];
			++Points;
		}
	}

	Triangles = 0;
	for (int s = 0; s != stride; ++s)
	{
		AddTriangle(Point[stride][stride].Point, Point[s][0].Point, Point[s + 1][0].Point);
		AddTriangle(Point[stride][stride].Point, Point[0][s + 1].Point, Point[0][s].Point);
		AddTriangle(Point[size - stride][size - stride].Point, Point[size - stride + s + 1][size].Point, Point[size - stride + s][size].Point);
		AddTriangle(Point[size - stride][size - stride].Point, Point[size][size - stride + s].Point, Point[size][size - stride + s + 1].Point);
		AddTriangle(Point[size - stride][stride].Point, Point[size - stride + s][0].Point, Point[size - stride + s + 1][0].Point);
		AddTriangle(Point[size - stride][stride].Point, Point[size][s].Point, Point[size][s + 1].Point);
		AddTriangle(Point[stride][size - stride].Point, Point[0][size - stride + s + 1].Point, Point[0][size - stride + s].Point);
		AddTriangle(Point[stride][size - stride].Point, Point[s + 1][size].Point, Point[s][size].Point);
	}

	for (int t = stride; t != Size - stride; t += stride)
	{
		for (int s = 0; s != stride; ++s)
		{
			AddTriangle(Point[t][stride].Point, Point[t + s][0].Point, Point[t + s + 1][0].Point);
			AddTriangle(Point[stride][t].Point, Point[0][t + s + 1].Point, Point[0][t + s].Point);
			AddTriangle(Point[t][size - stride].Point, Point[t + s + 1][size].Point, Point[t + s][size].Point);
			AddTriangle(Point[size - stride][t].Point, Point[size][t + s].Point, Point[size][t + s + 1].Point);
		}
		AddTriangle(Point[t][stride].Point, Point[t + stride][0].Point, Point[t + stride][stride].Point);
		AddTriangle(Point[stride][t].Point, Point[stride][t + stride].Point, Point[0][t + stride].Point);
		AddTriangle(Point[t][size - stride].Point, Point[t + stride][size - stride].Point, Point[t + stride][size].Point);
		AddTriangle(Point[size - stride][t].Point, Point[size][t + stride].Point, Point[size - stride][t + stride].Point);
	}

	for (int x = stride; x != Size - stride; x += stride)
	{
		for (int y = stride; y != Size - stride; y += stride)
		{
			AddTriangle(Point[x][y].Point, Point[x + stride][y + stride].Point, Point[x][y + stride].Point);
			AddTriangle(Point[x][y].Point, Point[x + stride][y].Point, Point[x + stride][y + stride].Point);
		}
	}
	fprintf(file, "t2 %ld %ld \n", Points, Triangles);
}

const void Load::Texture(const int number)
{
	fprintf(file,"set texture %i %i\n", number, MAP_SIZE);

	D3DXCreateTexture(screen.g_pd3dDevice, MAP_SIZE, MAP_SIZE, 1, D3DUSAGE_DYNAMIC, Format, D3DPOOL_DEFAULT/*D3DPOOL_MANAGED D3DPOOL_DEFAULT D3DPOOL_SYSTEMMEM*/, &screen.Texture_List[number]);

	IDirect3DSurface9 *surface;
	screen.Texture_List[number]->GetSurfaceLevel(0, &surface);

	D3DSURFACE_DESC surface_desc;
	surface->GetDesc(&surface_desc);

	D3DLOCKED_RECT lock;
	surface->LockRect(&lock, NULL, D3DLOCK_DISCARD);
	unsigned __int16 *image_data = (unsigned __int16*)lock.pBits;

	fprintf(file, "w %ld h %ld f %ld p %ld\n", surface_desc.Width, surface_desc.Height, surface_desc.Format, lock.Pitch);

	for (int h=0; h!=surface_desc.Height; ++h)
	{
		for (int w=0; w!=surface_desc.Width; ++w)
		{
			*(image_data + w) = rand() + rand();
		}
		image_data += (lock.Pitch / 2); //?
	}
	surface->UnlockRect();
	surface->Release();
}

const void Load::Texture2(const int number)
{
	fprintf(file, "set texture2 %i %i\n", number, PATCH_POINTS);

	D3DXCreateTexture(screen.g_pd3dDevice, PATCH_POINTS, PATCH_POINTS, 1, D3DUSAGE_DYNAMIC, Format, D3DPOOL_DEFAULT/*D3DPOOL_MANAGED D3DPOOL_DEFAULT D3DPOOL_SYSTEMMEM*/, &screen.Texture_List[number]);

	IDirect3DSurface9 *surface;
	screen.Texture_List[number]->GetSurfaceLevel(0, &surface);

	D3DSURFACE_DESC surface_desc;
	surface->GetDesc(&surface_desc);

	D3DLOCKED_RECT lock;
	surface->LockRect(&lock, NULL, D3DLOCK_DISCARD);
	unsigned __int16 *image_data = (unsigned __int16*)lock.pBits;

	fprintf(file, "w %ld h %ld f %ld p %ld\n", surface_desc.Width, surface_desc.Height, surface_desc.Format, lock.Pitch);

	for (int h = 0; h != surface_desc.Height; ++h)
	{
		for (int w = 0; w != surface_desc.Width; ++w)
		{
			*(image_data + w) = rand() + rand();
		}
		image_data += (lock.Pitch / 2); //?
	}
	surface->UnlockRect();
	surface->Release();
}


const void Load::BuildLOD(const int lod)
{
	Model3(64, 64, 1);
	Vertex_Count[0] = Points;
	memcpy(&Vertex[0][0], &screen.Vertex[0], sizeof(screen.Vertex[0])*Vertex_Count[0]);
	Index_Count[0] = Triangles;
	memcpy(&Index[0][0], &screen.Index[0], sizeof(screen.Index[0])*Index_Count[0] * 3);

	Model3(64, 64, 2);
	Vertex_Count[1] = Points;
	memcpy(&Vertex[1][0], &screen.Vertex[0], sizeof(screen.Vertex[0])*Vertex_Count[1]);
	Index_Count[1] = Triangles;
	memcpy(&Index[1][0], &screen.Index[0], sizeof(screen.Index[0])*Index_Count[1] * 3);

	Model3(64, 64, 4);
	Vertex_Count[2] = Points;
	memcpy(&Vertex[2][0], &screen.Vertex[0], sizeof(screen.Vertex[0])*Vertex_Count[2]);
	Index_Count[2] = Triangles;
	memcpy(&Index[2][0], &screen.Index[0], sizeof(screen.Index[0])*Index_Count[2] * 3);

	Model3(64, 64, 8);
	Vertex_Count[3] = Points;
	memcpy(&Vertex[3][0], &screen.Vertex[0], sizeof(screen.Vertex[0])*Vertex_Count[3]);
	Index_Count[3] = Triangles;
	memcpy(&Index[3][0], &screen.Index[0], sizeof(screen.Index[0])*Index_Count[3] * 3);

	Model3(64, 64, 16);
	Vertex_Count[4] = Points;
	memcpy(&Vertex[4][0], &screen.Vertex[0], sizeof(screen.Vertex[0])*Vertex_Count[4]);
	Index_Count[4] = Triangles;
	memcpy(&Index[4][0], &screen.Index[0], sizeof(screen.Index[0])*Index_Count[4] * 3);
}