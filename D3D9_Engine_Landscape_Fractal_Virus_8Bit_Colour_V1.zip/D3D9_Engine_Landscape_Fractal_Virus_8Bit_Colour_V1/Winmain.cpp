#define WIN32_LEAN_AND_MEAN
#define WIN32_EXTRA_LEAN

#define D3D_OVERLOADS
#define STRICT

#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <omp.h>

#include "d3d8_screen.h"
#include "di_mouse.h"
#include "map.h"
#include "load.h"
#include "engine.h"

Mouse		mouse;
Screen	screen;
Load		load;
Engine	engine;
Map map;

HWND	hwnd;
FILE	*file;

time_t start_time;
int frame=0;

void ReleaseObjects()
{
	fprintf(file, "windows shutdown\n");

	time_t end_time;
	time(&end_time);
	fprintf(file, "frames %ld seconds %ld fps %f\n", frame, end_time-start_time, (float) frame/(end_time-start_time));
}

long FAR PASCAL WindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
    case	WM_DESTROY:
			ReleaseObjects();
			PostQuitMessage(0);
			break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	srand(time(0));

	MSG msg;

  WNDCLASS wc;
  wc.style = CS_HREDRAW | CS_VREDRAW;
  wc.lpfnWndProc = WindowProc;
  wc.cbClsExtra = 0;
  wc.cbWndExtra = 0;
  wc.hInstance = hInstance;
  wc.hIcon = LoadIcon(hInstance, IDI_APPLICATION);
  wc.hCursor = LoadCursor(NULL, IDC_ARROW);
  wc.hbrBackground = NULL;
  wc.lpszMenuName = "PORTAL";
  wc.lpszClassName = "PORTAL";
  RegisterClass(&wc);
    
  hwnd = CreateWindowEx(WS_EX_TOPMOST, "PORTAL", "PORTAL", WS_POPUP, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), NULL, NULL, hInstance, NULL);
  if (!hwnd)
  {
		return false;
  }
  ShowWindow(hwnd, nCmdShow);
	UpdateWindow(hwnd);

	if ((file=fopen("log.txt","w"))==NULL) return false;

	fprintf(file, "windows startup\n");

//	SetPriorityClass(GetCurrentProcess(), REALTIME_PRIORITY_CLASS);
//	SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_HIGHEST);

	if (!mouse.Setup(hInstance, hwnd)) return false;

	engine.Setup();

	if (!screen.Setup(GetSystemMetrics(SM_CXSCREEN),GetSystemMetrics(SM_CYSCREEN), D3DFMT_X8R8G8B8, 1.0f, 48*1024.0f, D3DFMT_D24X8, 2, hwnd)) return false;

	load.Setup(D3DFMT_X1R5G5B5/*R3G3B2*/);
	load.BuildLOD(PATCH_LOD);

	time_t c_time;
	time(&c_time);
	fprintf(file, "map.setup %s\n", ctime(&c_time));
	load.Texture(0);
//	for (int t=1, x=0; x!=PATCH_COUNT; ++x) for (int y=0; y!=PATCH_COUNT; ++y, ++t) load.Texture2(t);
	map.Setup();

//	load.Texture(0);

	fprintf(file,"Starting Program!\n"); // This statement should only print once

	#pragma omp parallel
	{
		fprintf(file, "Running on multiple threads\n"); // This statement will run on each thread.
	}

	fprintf(file,"Finished!\n"); // We're out of the parallelized secion so this should execute only once

	time(&start_time);
	fprintf(file, "start %s\n", ctime(&start_time));

	srand(start_time);

	while (msg.message!=WM_QUIT)
	{
		if (PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
		{
			if (!GetMessage(&msg, NULL, 0, 0))
			{
				return msg.wParam;
			}
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
		{
			engine.Update();
			++frame;
		}
	}
}

