#ifndef ENGINE
#define ENGINE

#include "d3d8_screen.h"

class Engine
{
private:
	float	Speed;
	D3DXVECTOR3 Location;
	D3DXVECTOR3 Direction;
	D3DXVECTOR3 BoundingBox;
	const void Move(D3DXVECTOR3 &, const D3DXVECTOR3 &, const float);
	const void Input(D3DXVECTOR3 &, float &, const float);
	const void DrawTrack();
public:
	const void Setup();
	~Engine();
	const void Update();
};

#endif

