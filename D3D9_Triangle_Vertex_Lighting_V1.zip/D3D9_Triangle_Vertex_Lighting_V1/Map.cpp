#include "d3d8_screen.h"
#include "load.h"
#include "map.h"

extern Screen screen;
extern Load load;
extern FILE *file;

D3DXVECTOR3 mid;

void Map::Setup()
{
	fprintf(file,"map setup\n");

	BuildTrack();
}

Map::~Map()
{
	fprintf(file,"map shutdown\n");
}

void Map::BuildTrack()
{
	TrackSections=TRACK_PATCH_COUNT;
	for (int x=0; x!=TrackSections; ++x)
	{
		Track[x].Model=99;//+(rand()&3);
		Track[x].Material=rand()&3;
		Track[x].Location= D3DXVECTOR3( (((int)rand()&1023)/*+32767*/), (((int)rand()&1023)/*+32767*/), (((int)rand()&1023)/*+32767*/));
		Track[x].Direction=D3DXVECTOR3(rand(),rand(),rand());
	}
}
