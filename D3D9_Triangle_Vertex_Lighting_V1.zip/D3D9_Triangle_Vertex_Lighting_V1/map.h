#ifndef MAP
#define MAP

#define TRACK_PATCH_COUNT 1024

typedef struct
{
	unsigned long Model;
	D3DXVECTOR3 Location;
	D3DXVECTOR3 Direction;
} TRACK_PATCH;

class Map
{
private:
public:
	void Setup();
	~Map();
	ACTOR Track[TRACK_PATCH_COUNT];
	void BuildTrack();
	unsigned long TrackSections;
};

#endif
