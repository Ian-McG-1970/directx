#ifndef LOAD
#define LOAD

#include <stdio.h>

class Load
{
	FILE	*fileopen;
	char rec[256];
public:
	void Setup();
	~Load();
	const void Model(const char *, const int);
};

#endif
