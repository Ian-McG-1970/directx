#ifndef D3D_SCREEN
#define D3D_SCREEN

#include <d3d9.h>
#include <d3dx9.h>

#define MAX_MODELS 1024
#define MAX_ACTORS 64
#define MAX_PLANES 6
#define MAX_BOUNDING_BOX 8
#define MAX_VERTICES 1024

#define BACKGROUND D3DCOLOR_XRGB(0, 0, 0)

typedef struct
{
	D3DXVECTOR3 Location;
	D3DCOLOR Colour;
} IM_VERTEX;
#define D3DFVF_IM_VERTEX (D3DFVF_XYZ | D3DFVF_DIFFUSE)

typedef struct
{
	D3DXVECTOR3											Bounding_Sphere_Centre;
	float																			Bounding_Sphere_Radius;
	D3DXVECTOR3											Bounding_Box[MAX_BOUNDING_BOX];
	LPDIRECT3DVERTEXBUFFER9	Vertex_Buffer;
	IDirect3DIndexBuffer9*					Index_Buffer;
	int													Vertices;
	int													Triangles;
} MODEL;

typedef struct
{
	int Model;
	int Material;
	D3DXVECTOR3		Location;
	D3DXVECTOR3		Direction;
} ACTOR;
                  
class Screen
{
private:
	const void ExtractFrustumPlanes(void);
	LPD3DXFONT Font;

	LPDIRECT3D9	g_pD3D;
	D3DXPLANE Frustum[MAX_PLANES];

	D3DXMATRIX Matrix_Projection;
	D3DXMATRIX Matrix_View;
	D3DXMATRIX Matrix_World;
	D3DXMATRIX Matrix_Translation;
	D3DXMATRIX Matrix_Rotation;

	int Current_Model;

	const void DrawBoundingBox(const int);
	const void Screen::Polygon(const D3DXVECTOR3 *point,const int points,const D3DXCOLOR colour);
	IM_VERTEX PolygonPoint[65535];

public:
	const bool Setup(const int, const int, const D3DFORMAT, const float, const float, const D3DFORMAT, const int, const HWND);
	~Screen();
	const void View_Matrix(const D3DXVECTOR3 &, const D3DXVECTOR3 *);
	const bool IsPointInsideFrustum(const D3DXVECTOR3 *);
	const bool IsSphereInsideFrustum(const D3DXVECTOR3 *, const float);
	const bool IsBoundingBoxInsideFrustum(const D3DXVECTOR3 *);
	const void DrawObject(const D3DXVECTOR3 *, const D3DXVECTOR3 *, const int, const int);
	const void DrawLookAtObject(const D3DXVECTOR3 &, const D3DXVECTOR3 &, const int, const int);
	const void DrawStaticObject(const D3DXVECTOR3 *, const int, const int);
	char string[255];
	const void DrawText(const int, const int, const D3DCOLOR);
	const void CreateObject(const int, const int, const int);
	const bool BoundingBoxInFrustum(const D3DXVECTOR3 *, const D3DXVECTOR3 &);
	const bool BoundingBoxStaticInFrustum(const D3DXVECTOR3 *);
	const void DrawDebugObject(const D3DXVECTOR3 &, const int);

	LPDIRECT3DDEVICE9	g_pd3dDevice;

	IM_VERTEX					Vertex[MAX_VERTICES];
	WORD									Index[MAX_VERTICES];
	MODEL								Model[MAX_MODELS]; // list of models loaded in
	ACTOR								Actor[MAX_ACTORS]; // list of models in world
};

#endif