#include "engine.h"
#include "d3d8_screen.h"
#include "di_mouse.h"
#include "map.h"

extern HWND hwnd;
extern Mouse mouse;
extern Map map;
extern Screen screen;

extern FILE *file;

unsigned long count;

const void Engine::Setup()
{
	fprintf(file,"engine setup\n");
	Direction=D3DXVECTOR3(0.0f, 0.0f, 0.0f);

	for(int x=0; x!=MAX_PHYSICS_OBJECT; ++x)
	{
		Physics_Object[x].RigidBody=NULL;
	}

	broadphase = new btDbvtBroadphase();
	collisionConfiguration = new btDefaultCollisionConfiguration();
	dispatcher = new btCollisionDispatcher(collisionConfiguration);

	solver = new btSequentialImpulseConstraintSolver;
	dynamicsWorld = new btDiscreteDynamicsWorld(dispatcher,broadphase,solver,collisionConfiguration);

	dynamicsWorld->setGravity(btVector3(0,-0.981f,0));

	Speed=0.0f;
}

Engine::~Engine()
{
	for(int x=0; x!=MAX_PHYSICS_OBJECT; ++x)
	{
		if(Physics_Object[x].RigidBody!=NULL)
		{
			dynamicsWorld->removeRigidBody(Physics_Object[x].RigidBody);
			delete Physics_Object[x].RigidBody->getMotionState();
			delete Physics_Object[x].RigidBody;
			delete Physics_Object[x].Shape;
			Physics_Object[x].RigidBody=NULL;
		}
	}

	delete dynamicsWorld;
	delete solver;
	delete collisionConfiguration;
	delete dispatcher;
	delete broadphase;

	fprintf(file,"engine shutdown\n");
}

const D3DXVECTOR3 Engine::Move(const D3DXVECTOR3 &direction, const float speed)
{
	D3DXMATRIX matTmp;
	D3DXMatrixRotationYawPitchRoll(&matTmp, direction.y, direction.x, direction.z);
	D3DXVECTOR4 tmp;
	D3DXVec3Transform(&tmp, &D3DXVECTOR3(0.0f, 0.0f, 1.0f), &matTmp);
	return D3DXVECTOR3(tmp)*speed;
}

const void Engine::Input(D3DXVECTOR3 &direction, float &speed, const float dampen)
{
	mouse.Update();
	if (mouse.LB!=0 && mouse.RB!=0)
	{
		PostMessage(hwnd, WM_CLOSE, 0, 0);
		return;
	}
	if (mouse.LB==0 && mouse.RB==0)
	{
		direction.x -= mouse.Y*dampen;
		direction.y += mouse.X*dampen;
	}
	if (mouse.RB!=0)
	{
//		direction.z -= mouse.X*dampen;
	}
	if (mouse.LB!=0)
	{
		speed -= mouse.Y*dampen;
	}
	speed*=0.9999f;
}

const void Engine::DrawTrack()
{
	for (int ts=0; ts!=map.TrackSections; ++ts)
	{
		const int model=map.Track[ts].Model;

		const btRigidBody* fallRigidBody=Physics_Object[ts].RigidBody;
		btTransform transform;
		fallRigidBody->getMotionState()->getWorldTransform(transform);

		const D3DXVECTOR3 location =D3DXVECTOR3(transform.getOrigin().getX(),transform.getOrigin().getY(),transform.getOrigin().getZ());

//		if (screen.IsSphereInsideFrustum(&location, screen.Model[model].Bounding_Sphere_Radius)==true)
		{
			screen.DrawObject(&location,&map.Track[ts].Direction,model,map.Track[ts].Material);
//			screen.DrawDebugObject(location, model);
			++count;
		}
	}
}

const int Engine::InsideObject(const D3DXVECTOR3 &position)
{
	for (int o=0; o!=map.TrackSections; ++o)
	{
		const int model=map.Track[o].Model;
		const D3DXVECTOR3 location=position-map.Track[o].Location;
		const D3DXVECTOR3 start=screen.Model[model].Bounding_Box[0];
		const D3DXVECTOR3 end=screen.Model[model].Bounding_Box[MAX_BOUNDING_BOX-1];

		if ((location.x >= start.x) && (location.y >= start.y) && (location.z >= start.z) && (location.x <= end.x) && (location.y <= end.y) && (location.z <= end.z))
		{
			return o;
		}
	}
	return TRC_OUTSIDE;
}

const void Engine::Update()
{
	Input(Direction,Speed,0.0013f);

	btRigidBody* body=Physics_Object[Camera].RigidBody;
	btTransform transform;
	body->getMotionState()->getWorldTransform(transform);
	const D3DXVECTOR3 movement = Move(Direction,Speed);

	body->activate();
	body->applyForce(btVector3(movement.x,movement.y,movement.z),btVector3(movement.x,movement.y,movement.z));
//	body->setLinearVelocity(btVector3(movement.x,
//		movement.y,
//		body->getGravity().getY(), 
//		movement.z));
	const D3DXVECTOR3 location = D3DXVECTOR3(transform.getOrigin().getX(),transform.getOrigin().getY(),transform.getOrigin().getZ());
//	body->activate();

	dynamicsWorld->stepSimulation(1.0f/60.0f,10.0f);

	count=0;
	screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, BACKGROUND, 1.0f, 0);

	screen.View_Matrix(D3DXVECTOR3(location.x,location.y+EXTENT_STAND.y-EXTENT_SIZE,location.z),&Direction);

	screen.g_pd3dDevice->BeginScene();
	DrawTrack();

	sprintf(screen.string, "px %5f py %5f pz %5f cnt %i io %i %f\n", location.x, location.y, location.z, count, InsideObject(location),Speed);
	screen.DrawText(5, 5, D3DCOLOR_XRGB(160, 160, 160));

	screen.g_pd3dDevice->EndScene();
	screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
}

const EXTENT Engine::Extent(const D3DXVECTOR3 &pos, const D3DXVECTOR3 &extent)
{
	EXTENT bb;
	bb.Bounding_Box[TFL]=D3DXVECTOR3(pos.x-extent.x, pos.y-extent.y, pos.z-extent.z);//TFL
	bb.Bounding_Box[TBL]=D3DXVECTOR3(pos.x-extent.x, pos.y-extent.y, pos.z+extent.z);//TBL
	bb.Bounding_Box[TFR]=D3DXVECTOR3(pos.x-extent.x, pos.y+extent.y, pos.z-extent.z);//BFL
	bb.Bounding_Box[TBR]=D3DXVECTOR3(pos.x-extent.x, pos.y+extent.y, pos.z+extent.z);//BBL
	bb.Bounding_Box[BFL]=D3DXVECTOR3(pos.x+extent.x, pos.y-extent.y, pos.z-extent.z);//TFR
	bb.Bounding_Box[BBL]=D3DXVECTOR3(pos.x+extent.x, pos.y-extent.y, pos.z+extent.z);//TBR
	bb.Bounding_Box[BFR]=D3DXVECTOR3(pos.x+extent.x, pos.y+extent.y, pos.z-extent.z);//BFR
	bb.Bounding_Box[BBR]=D3DXVECTOR3(pos.x+extent.x, pos.y+extent.y, pos.z+extent.z);//BBR
	return bb;
}

const void Engine::AddBody2(PHYSICS_OBJECT &Object,const D3DXVECTOR3 &Location,const D3DXVECTOR3 &Direction,const float Mass)
{
	btDefaultMotionState* MotionState = new btDefaultMotionState(btTransform(btQuaternion(0,0,0,1),btVector3(Location.x,Location.y,Location.z)));

	btVector3 inertia(0.0f,0.0f,0.0f);
	Object.Shape->calculateLocalInertia(Mass,inertia);

	btRigidBody::btRigidBodyConstructionInfo RigidBodyCI(Mass,MotionState,Object.Shape,inertia);
	Object.RigidBody = new btRigidBody(RigidBodyCI);
	dynamicsWorld->addRigidBody(Object.RigidBody);

	btTransform trans=Object.RigidBody->getWorldTransform();
	btQuaternion quat;
	quat.setEuler(Direction.x,Direction.y,Direction.z); //or quat.setEulerZYX depending on the ordering you want
	trans.setRotation(quat);
	Object.RigidBody->setWorldTransform(trans);
	Object.RigidBody->setCenterOfMassTransform(trans);

	Object.RigidBody->setDamping(0.1f,0.1f);
}

const void Engine::AddBody(PHYSICS_OBJECT &Object, const D3DXVECTOR3 &Location, const D3DXVECTOR3 &Direction, const float Mass)
{
	btDefaultMotionState* MotionState = new btDefaultMotionState(btTransform(btQuaternion(0,0,0,1),btVector3(Location.x,Location.y,Location.z)));

	btVector3 inertia(0.0f,0.0f,0.0f);
	Object.Shape->calculateLocalInertia(Mass,inertia);
	btRigidBody::btRigidBodyConstructionInfo RigidBodyCI(Mass,MotionState,Object.Shape,inertia);
	Object.RigidBody = new btRigidBody(RigidBodyCI);
	dynamicsWorld->addRigidBody(Object.RigidBody);

	btTransform trans=Object.RigidBody->getWorldTransform();
	btQuaternion quat;
	quat.setEuler(Direction.x,Direction.y,Direction.z); //or quat.setEulerZYX depending on the ordering you want
	trans.setRotation(quat);
	Object.RigidBody->setWorldTransform(trans);
	Object.RigidBody->setCenterOfMassTransform(trans);

	Object.RigidBody->setDamping(0.1f,1.0f);
}

const void Engine::AddPhysicsMesh(const std::vector<D3DXVECTOR3> &Vertex, const std::vector<WORD> &Index, const D3DXVECTOR3 &Location,const int Actor)
{
	btTriangleMesh *mesh = new btTriangleMesh(false, false);
	for (int t=0; t!=Index.size(); t+=3)
	{
		const WORD i0=Index[t+0];
		const WORD i1=Index[t+1];
		const WORD i2=Index[t+2];
		const btVector3 v0(Vertex[i0].x, Vertex[i0].y, Vertex[i0].z);
		const btVector3 v1(Vertex[i1].x, Vertex[i1].y, Vertex[i1].z);
		const btVector3 v2(Vertex[i2].x, Vertex[i2].y, Vertex[i2].z);
		mesh->addTriangle(v0, v1, v2);
	}
	Physics_Object[Actor].Shape = new btBvhTriangleMeshShape(mesh,true);
	fprintf(file,"AB Location %f %f %f %i %i\n",Location.x,Location.y,Location.z,Vertex.size(),Index.size());

	AddBody(Physics_Object[Actor],Location,D3DXVECTOR3(0.0f,0.0f,0.0f), 0.0f);
}

const void Engine::AddPhysicsBox(const D3DXVECTOR3 &Size,const D3DXVECTOR3 &Location,const float Mass,const int Actor)
{
	Physics_Object[Actor].Shape = new btBoxShape(btVector3(Size.x,Size.y,Size.z));
	AddBody(Physics_Object[Actor],Location,D3DXVECTOR3(0.0f,0.0f,0.0f),Mass);
}

const void Engine::AddPhysicsSphere(const float Size,const D3DXVECTOR3 &Location,const float Mass,const int Actor)
{
	Physics_Object[Actor].Shape = new btSphereShape(Size);
	AddBody(Physics_Object[Actor],Location,D3DXVECTOR3(0.0f,0.0f,0.0f),Mass);
}

const void Engine::AddPhysicsCapsule(const float Radius, const float Height,const D3DXVECTOR3 &Location,const float Mass,const int Actor)
{
	Physics_Object[Actor].Shape = new btCapsuleShape(Radius, Height);
	AddBody(Physics_Object[Actor],Location,D3DXVECTOR3(0.0f,0.0f,0.0f),Mass);
}

const void Engine::AddPhysicsActor(const int Shape, const D3DXVECTOR3 &Size, const D3DXVECTOR3 &Location, const D3DXVECTOR3 &Direction, const float Mass, const int Actor)
{
	switch(Shape)
	{
	case	1:
		Physics_Object[Actor].Shape = new btSphereShape(Size.y);
		break;
	case 2:
		Physics_Object[Actor].Shape = new btStaticPlaneShape(btVector3(Size.x,Size.y,Size.z),1);
		break;
	case 3:
		Physics_Object[Actor].Shape = new btBoxShape(btVector3(Size.x,Size.y,Size.z));
		break;
	case 4:
		Physics_Object[Actor].Shape = new btConvexHullShape();
	case 5:
		float* vertices;
		unsigned int vertexCount;
		btTriangleMesh mesh = new btTriangleMesh(false,false);
		for(unsigned int i = 0; i < vertexCount; i+=9)
		{
			btVector3 v0(vertices[i+0],vertices[i+1],vertices[i+2]);
			btVector3 v1(vertices[i+3],vertices[i+4],vertices[i+5]);
			btVector3 v2(vertices[i+6],vertices[i+7],vertices[i+8]);
			mesh.addTriangle(v0,v1,v2,true);
		}
		Physics_Object[Actor].Shape = new btBvhTriangleMeshShape(&mesh,true);

		//		mIndexVertexArray = new btTriangleIndexVertexArray(Mesh->GetNumFaces(),
		//                                          (int*) &pIndexBuffer,
		//                                          Mesh->GetNumBytesPerVertex() * 3,
		//                                          Mesh->GetNumVertices,
		//                                          (btScalar*) &pVertexBuffer,
		//                                          Mesh->GetNumBytesPerVertex());
		//   Mesh->UnlockIndexBuffer();
		//   Mesh->UnlockVertexBuffer();
		//   btVector3 aabbMin(-10000,-10000,-10000), aabbMax(10000,10000,10000);
		//   bool useQuantizedAabbCompression = true;
		//   btTriMeshShape  = new btBvhTriangleMeshShape(mIndexVertexArray, true);
	}
	AddBody(Physics_Object[Actor],Location,Direction,Mass);
}

/*
{
//3
btTriangleMesh* mesh = new btTriangleMesh();
for (int i=0; i < vertexCount; i += 3)
{
Vertex v1 = vertices[i];
Vertex v2 = vertices[i+1];
Vertex v3 = vertices[i+2];

btVector3 bv1 = btVector3(v1.Position[0], v1.Position[1], v1.Position[2]);
btVector3 bv2 = btVector3(v2.Position[0], v2.Position[1], v2.Position[2]);
btVector3 bv3 = btVector3(v3.Position[0], v3.Position[1], v3.Position[2]);

mesh->addTriangle(bv1, bv2, bv3);
}
_shape = new btBvhTriangleMeshShape(mesh, true);
*/
