#ifndef ENGINE
#define ENGINE

#include "d3d8_screen.h"
#include "map.h"
#include "btBulletDynamicsCommon.h"

#define TRC_OUTSIDE -1
#define TRC_EPS 0.01f
#define TRC_MOVE_EPS 0.1f

#define TRC_GRAVITY D3DXVECTOR3(0,-0.99,0)
#define TRC_SML_UP D3DXVECTOR3(0,+0.01f,0)
#define TRC_BIG_UP D3DXVECTOR3(0,+1.01f,0)
#define TRC_SML_DOWN D3DXVECTOR3(0,-0.01f,0)
#define TRC_BIG_DOWN D3DXVECTOR3(0,-1.02f,0)
#define TRC_COL_INC 0.98f

#define EXTENT_SIZE 1.40f
#define EXTENT_STAND D3DXVECTOR3(EXTENT_SIZE,EXTENT_SIZE*3.0f,EXTENT_SIZE)
//#define EXTENT_CROUCH D3DXVECTOR3(EXTENT_SIZE,EXTENT_SIZE,EXTENT_SIZE)
//#define EXTENT_STAND_UP D3DXVECTOR3(0.0f,EXTENT_STAND.y-EXTENT_CROUCH.y,0.0f)

typedef struct
{
	D3DXVECTOR3 Bounding_Box[MAX_BOUNDING_BOX];
} EXTENT;

typedef struct
{
	float Distance;
	D3DXVECTOR3 Direction;
} TRACE;

typedef struct
{
	btCollisionShape* Shape;
	btRigidBody* RigidBody;
} PHYSICS_OBJECT;
#define MAX_PHYSICS_OBJECT 1024

class Engine
{
private:
	float	Speed;
	D3DXVECTOR3 Direction;
	const D3DXVECTOR3 Move(const D3DXVECTOR3 &, const float);
	const void Input(D3DXVECTOR3 &, float &, const float);
	const void DrawTrack();
	const int InsideObject(const D3DXVECTOR3 &);
	const bool Overlap(const float,const float,const float);
	const EXTENT Extent(const D3DXVECTOR3 &,const D3DXVECTOR3 &);
	int dir;

	btDiscreteDynamicsWorld* dynamicsWorld;
	btSequentialImpulseConstraintSolver* solver;
	btCollisionDispatcher* dispatcher;
	btDefaultCollisionConfiguration* collisionConfiguration;
	btBroadphaseInterface* broadphase;
	const void AddBody(PHYSICS_OBJECT &Object,const D3DXVECTOR3 &Location,const D3DXVECTOR3 &Direction,const float Mass);
	const void AddBody2(PHYSICS_OBJECT &Object,const D3DXVECTOR3 &Location,const D3DXVECTOR3 &Direction,const float Mass);
	PHYSICS_OBJECT Physics_Object[MAX_PHYSICS_OBJECT]; // list of models in world

public:
	const void Setup();
	~Engine();
	const void Update();
	const void AddPhysicsMesh(const std::vector<D3DXVECTOR3> &, const std::vector<WORD> &, const D3DXVECTOR3 &, const int);
	const void AddPhysicsBox(const D3DXVECTOR3 &Size,const D3DXVECTOR3 &Location,const float Mass,const int Actor);
	const void AddPhysicsSphere(const float Size,const D3DXVECTOR3 &Location,const float Mass,const int Actor);
	const void Engine::AddPhysicsActor(const int,const D3DXVECTOR3 &,const D3DXVECTOR3 &,const D3DXVECTOR3 &,const float,const int);
	const void Engine::AddPhysicsCapsule(const float Radius,const float Height,const D3DXVECTOR3 &Location,const float Mass,const int Actor);

	int Camera;
};

#endif

