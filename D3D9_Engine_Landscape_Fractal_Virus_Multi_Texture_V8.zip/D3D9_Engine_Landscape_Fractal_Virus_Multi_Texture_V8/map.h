#ifndef MAP
#define MAP

#include <stdio.h>
#include <vector>
#include "map_size.h"

typedef struct
{
	WORD Model;
	D3DXVECTOR3	BoundingSphereCentre;
	float				BoundingSphereRadius;
	D3DXVECTOR3	BoundingBox[MAX_BOUNDING_BOX];
} BEZIER_PATCH;

typedef struct
{
	int x;
	int y;
	float mx;
	float my;
	int lod;
} DrawOrderLocation;

#define MAP_MAX_HEIGHT 32767
#define PATCH_SIZE 4096 //16384//4096
#define MAP_SIZE PATCH_POINTS * PATCH_COUNT
#define MAP_DETAIL_SIZE PATCH_COUNT * PATCH_SIZE
#define MAP_TILE_SIZE PATCH_SIZE / PATCH_POINTS

class Map
{
private:   
	WORD Rough[MAP_SIZE][MAP_SIZE];			// original map before smoothing
	const void Generate();
	const void Build_Patch(const int, const int, const int);
	const void Build_Grid1();
	const void Stretch();
	const void BuildDrawOrder(const int);
	const void AddDrawOrder(const int, const int);
	const void Fractal(const int, const int, const int, const int);
	const void FractalSetup(const int);
public:
	WORD Detail[MAP_SIZE][MAP_SIZE];			// detail map used for collision after smoothing
	BEZIER_PATCH Patch_Grid[PATCH_COUNT][PATCH_COUNT]; // patches to be drawn
	const float Height(const D3DXVECTOR3*);
	const void Setup();
	~Map();
	std::vector<DrawOrderLocation> DrawOrder2;
	int DrawOrderCount;
};

#endif
