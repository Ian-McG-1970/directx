#include <math.h>
#include <stdio.h>
#include "engine.h"
#include "d3d8_screen.h"
#include "di_mouse.h"
#include "map.h"
#include "log.h"

extern HWND hwnd;
extern Mouse mouse;
extern Map map;
extern Screen screen;
extern LogFile logfile;

const void Engine::Setup()
{
	sprintf(logfile.file_output,"engine setup\n"); logfile.Write();

	Location = D3DXVECTOR3(10000.0f, 0.0f, 10000.0f);
	Direction = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	Speed = 0.0f;
}

Engine::~Engine()
{
	sprintf(logfile.file_output,"engine shutdown\n"); logfile.Write();
}

const void Engine::Move(D3DXVECTOR3 &location, const D3DXVECTOR3 &direction, const float speed)
{
	D3DXMATRIX matTmp;
	D3DXMatrixRotationYawPitchRoll(&matTmp, direction.y, direction.x, direction.z);      
	D3DXVECTOR4 tmp;
	D3DXVec3Transform(&tmp, &D3DXVECTOR3(0.0f,0.0f,1.0f), &matTmp);

	location += (D3DXVECTOR3)tmp * speed;
	if (location.x <0.0f)
	{
		location.x+=MAP_DETAIL_SIZE;
	}
	else if (location.x >=MAP_DETAIL_SIZE)
	{
		location.x-=MAP_DETAIL_SIZE;
	}
	if (location.z <0.0f)
	{
		location.z+=MAP_DETAIL_SIZE;
	}
	else if (location.z >=MAP_DETAIL_SIZE)
	{
		location.z-=MAP_DETAIL_SIZE;
	}
}

const int Engine::DrawMap(const D3DXVECTOR3* location)
{
	screen.g_pd3dDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);

	int drawn=0;

	const int map_x_start = location->x / (float)PATCH_SIZE;
	const int map_z_start = location->z / (float)PATCH_SIZE;

	const float map_x_offset = (map_x_start*(float)PATCH_SIZE);
	const float map_z_offset = (map_z_start*(float)PATCH_SIZE);

//	#pragma omp parallel for private (x,z,model)
	for (int m=0; m<map.DrawOrderCount; ++m)
	{
		const int x=(map_x_start+map.DrawOrder2[m].x) &(PATCH_COUNT-1);
		const int z=(map_z_start+map.DrawOrder2[m].y) &(PATCH_COUNT-1);
		const int model=map.Patch_Grid[x][z].Model;

		const D3DXVECTOR3 patch_location=D3DXVECTOR3(map.DrawOrder2[m].mx+map_x_offset, 0, map.DrawOrder2[m].my+map_z_offset);
		const int visible = screen.IsSphereInsideFrustum2(&D3DXVECTOR3(patch_location + map.Patch_Grid[x][z].BoundingSphereCentre), map.Patch_Grid[x][z].BoundingSphereRadius);

		if (visible == ALL_OFF) continue;
		if ( (visible == INTERSECTING) && (screen.IsBoundingBoxInsideFrustum2(&patch_location, &map.Patch_Grid[x][z].BoundingBox[0]) == false) ) continue;

		screen.DrawMap4(&patch_location, model, map.Patch_Grid[0][map.DrawOrder2[m].lod].Model,map.DrawOrder2[m].lod);
		++drawn;
	}

	return drawn;
}

const void Engine::Input(D3DXVECTOR3& direction, float& speed)
{
	mouse.Update();
	if (mouse.LB!=0 && mouse.RB!=0)
	{
		PostMessage(hwnd, WM_CLOSE, 0, 0);
		return;
	}
	if (mouse.LB==0 && mouse.RB==0)
	{
		direction.x -= mouse.Y*0.001f;
		direction.y += mouse.X*0.001f;
	}
	if (mouse.LB!=0)
	{
		speed -= mouse.Y*0.01f;
	}
	if (mouse.RB!=0)
	{
		direction.z -= mouse.X*0.001f;
	}
}

const void Engine::Update()
{
	Input(Direction, Speed);
	Move(Location, Direction, Speed);
	screen.View_Matrix(Location, Direction);

	screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, BACKGROUND, 1.0f, 0);
	screen.g_pd3dDevice->BeginScene();

	int drawn=DrawMap(&Location);
	
	sprintf(screen.string, "px %6.1f pz %6.1f py %6.1f hgt %6.1f mx %6.1f mz %6.1f s %4.2f d %i\n", Location.x, Location.z, Location.y, map.Height(&Location), Location.x/(float)PATCH_SIZE, Location.z/(float)PATCH_SIZE, Speed, drawn);
	screen.DrawText(5, 5, D3DXCOLOR(0, 127, 127, 127));

	screen.g_pd3dDevice->EndScene();
	screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
}
