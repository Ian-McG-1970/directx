#include "game.h"
#include "window.h"
#include <stdio.h>

#define STRICT
#define WIN32_LEAN_AND_MEAN

const static BITMAPINFOHEADER bmih = {sizeof(BITMAPINFOHEADER), MAP_HOR, MAP_VER, 1, 32, BI_RGB, 0, 0, 0, 0, 0};

extern CWindow window;
extern int px;
extern int py;
extern int pz;

extern FILE *file;

#define LT <
#define GT >
#define LE =<
#define GE >=

const bool Game::Collision(const obj &o1, const obj &o2)
{
	if (o1.min.x < (o2.max.x) && (o1.max.x) > o2.min.x 
		&& o1.min.y < (o2.max.y) && (o1.max.y) > o2.min.y
		&& o1.min.z < (o2.max.z) && (o1.max.z) > o2.min.z)
	{
		return true;
	}
	return false;
}

const bool Game::Movement(const xyz &centre, const int pos)
{
	obj item2;
	item2.centre=XYZ(object[pos].centre.x+centre.x, object[pos].centre.y+centre.y, object[pos].centre.z+centre.z);
	item2.min=XYZ(item2.centre.x-shape_dimension[object[pos].shape].x, item2.centre.y-shape_dimension[object[pos].shape].y, item2.centre.z-shape_dimension[object[pos].shape].z);
	item2.max=XYZ(item2.centre.x+shape_dimension[object[pos].shape].x, item2.centre.y+shape_dimension[object[pos].shape].y, item2.centre.z+shape_dimension[object[pos].shape].z);

	for (int o=0; o!=objects; ++o)
	{
		if (o==pos) continue;
		if (Collision(item2, object[o])==true)
		{
			return false;
		}
	}
	memcpy(&object[pos].min,&item2.min,sizeof(object[pos].min));
	memcpy(&object[pos].max,&item2.max,sizeof(object[pos].max));
	object[pos].centre=item2.centre;
	const xy loc=IsometricPoint(centre);
	object[pos].pos=XY(loc.x-shape_offset[object[pos].shape].x,loc.y-shape_offset[object[pos].shape].y);
	object[pos].overlap_x=XY(object[pos].min.x-object[pos].max.z,object[pos].max.x-object[pos].min.z);
	object[pos].overlap_y=XY(object[pos].min.y-object[pos].max.z,object[pos].max.y-object[pos].min.z);
	const xy fs=IsometricPoint(XYZ(object[pos].min.x,object[pos].max.y,object[pos].min.z));
	const xy fe=IsometricPoint(XYZ(object[pos].max.x,object[pos].min.y,object[pos].min.z));
	object[pos].overlap_h=XY(fs.y,fe.y);

	return true;
}

const void Game::AddObject(const int shape)
{
	object[objects].centre=XYZ(0,0,0);
	object[objects].shape=shape;
	++objects;
}

const void Game::Setup()
{
	srand(GetTickCount());

	for (int o=0; o!=8; ++o)
	{
		fprintf(file,"o %ld\n",o);
		xyz p1[8];
		xy p2[8];
		p1[0]=XYZ(shape_dimension[o].x,shape_dimension[o].y,shape_dimension[o].z);
		p1[1]=XYZ(shape_dimension[o].x,shape_dimension[o].y,-shape_dimension[o].z);
		p1[2]=XYZ(shape_dimension[o].x,-shape_dimension[o].y,shape_dimension[o].z);
		p1[3]=XYZ(shape_dimension[o].x,-shape_dimension[o].y,-shape_dimension[o].z);
		p1[4]=XYZ(-shape_dimension[o].x,shape_dimension[o].y,shape_dimension[o].z);
		p1[5]=XYZ(-shape_dimension[o].x,shape_dimension[o].y,-shape_dimension[o].z);
		p1[6]=XYZ(-shape_dimension[o].x,-shape_dimension[o].y,shape_dimension[o].z);
		p1[7]=XYZ(-shape_dimension[o].x,-shape_dimension[o].y,-shape_dimension[o].z);
		p2[0]=IsometricPoint(p1[0]);
		p2[1]=IsometricPoint(p1[1]);
		p2[2]=IsometricPoint(p1[2]);
		p2[3]=IsometricPoint(p1[3]);
		p2[4]=IsometricPoint(p1[4]);
		p2[5]=IsometricPoint(p1[5]);
		p2[6]=IsometricPoint(p1[6]);
		p2[7]=IsometricPoint(p1[7]);
		int minx=p2[0].x;
		int maxx=p2[0].x;
		int miny=p2[0].y;
		int maxy=p2[0].y;
		for (int p=0; p!=8; ++p)
		{
			minx=min(minx,p2[p].x);
			maxx=max(maxx,p2[p].x);
			miny=min(miny,p2[p].y);
			maxy=max(maxy,p2[p].y);
			fprintf(file,"p %ld p1x %ld p1y %ld p1z %ld p2x %ld p2y %ld\n",p,p1[p].x,p1[p].y,p1[p].z,p2[p].x,p2[p].y);

		}
		fprintf(file,"minx %ld miny %ld maxx %ld maxy %ld xdiff %ld ydiff %ld\n",minx,maxx,miny,maxy,maxx-minx,maxy-miny);
	}

	objects=0;

	for (int i=0; i!=33;)
	{
		AddObject(rand()%9);
		do
		{
		}
//		while (Movement(XYZ(rand()&127, rand()&127, rand()&31+shape_dimension[object[objects-1].shape].z), objects-1)!=true);
		while (Movement(XYZ(rand()&127, rand()&127, 0+shape_dimension[object[objects-1].shape].z), objects-1)!=true);
		++i;
	}
}

const void Game::Update()
{
	const DWORD LoopStartTime = GetTickCount();
	sprintf(string,"Iso - %ld %ld %ld %ld",px,py,pz,drawn);

	clearScreen();

	Movement(XYZ(px,py,pz),objects-1);

	SortObjectList(objects);

	SetWindowText(window.GetHandle(),string);
	StretchDIBits(GetDC(window.GetHandle()), 0, 0, MAP_HOR*SCALE, MAP_VER*SCALE, 0, 0, MAP_HOR, MAP_VER, &screen[0][0], (BITMAPINFO*)&bmih, DIB_RGB_COLORS, SRCCOPY);	// Render the bitmap to the DC

	while ((GetTickCount() - LoopStartTime) < MillisecondsFrame); //20 milliseconds=50th second
}

const xy Game::XY(const int x, const int y)
{
	xy rc;
	rc.x=x;
	rc.y=y;
	return rc;
}

const xyz Game::XYZ(const int x, const int y, const int z)
{
	xyz rc;
	rc.x=x;
	rc.y=y;
	rc.z=z;
	return rc;
}

const void Game::Plot(const xy pos, const BYTE colour)
{
	screen[MAP_VER-1-pos.x][pos.y]=Colour[colour];
}

const void Game::clearScreen()
{
	memset(&screen[0][0],0,MAP_VER*MAP_HOR*sizeof(screen[0][0]));
}

const xy Game::IsometricPoint(const xyz &pos)
{
	return XY(iso_top + ( (pos.x + pos.y) >>1) -pos.z, iso_left + pos.x - pos.y);
}

const void Game::Draw2D(const int pos, const BYTE colour)
{
	for (int x=object[pos].min.x; x!=object[pos].max.x; ++x)
	{
		for (int y=object[pos].min.y; y!=object[pos].max.y; ++y)
		{
			Plot(XY(x+17,MAP_HOR-y-17),colour);
		}
	}
}

const void Game::DrawFast(const obj &o)
{
	const BYTE col1=shape_colour[o.shape][0];
	const BYTE col2=shape_colour[o.shape][1];
	const BYTE col3=shape_colour[o.shape][2];

	for (int x=o.min.x; x!=o.max.x+1; ++x)
	{
		for (int y=o.min.y; y!=o.max.y+1; ++y)
		{
			Plot(IsometricPoint(XYZ(x,y,o.max.z)),col1);
		}
		for (int z=o.min.z; z!=o.max.z+1; ++z)
		{
			Plot(IsometricPoint(XYZ(x,o.max.y,z)),col2);
		}
	}

	for (int y=o.min.y; y!=o.max.y+1; ++y)
	{
		for (int z=o.min.z; z!=o.max.z+1; ++z)
		{
			Plot(IsometricPoint(XYZ(o.max.x,y,z)),col3);
		}
	}
}

const bool Game::Overlap(const obj &first, const obj &second)
{
	if ( (IsBehind2(first.overlap_x,second.overlap_x)==true) && (IsBehind2(first.overlap_y,second.overlap_y)==true) && (IsBehind2(first.overlap_h,second.overlap_h)==true) )
	{
		return true;
	}
	return false;
}

const void Game::SortObjectList(const int objects)
{
	for (int o=0; o!=objects; ++o)
	{
		object_pos[o]=o;
	}

	for (int objects_left=objects, drawn=0; objects_left!=0; )
	{

		for (int o=0; o!=objects_left; ++o)
		{
			object[object_pos[o]].behind=true;
		}

		for (int f=0; f!=objects_left-1; ++f)
		{
			for (int b=f+1; b!=objects_left; ++b)
			{
				if (Overlap(object[object_pos[f]],object[object_pos[b]])==true)
				{
					if (IsBehind(object[object_pos[f]],object[object_pos[b]])==true)
					{
						object[object_pos[f]].behind=false;
					}
					else
					{
						object[object_pos[b]].behind=false;
					}
				}
			}
		}

		for (int o=0; o!=objects_left; ++o)
		{
			if (object[object_pos[o]].behind==true)
			{
				DrawFast((object[object_pos[o]]));
				Draw2D(object_pos[o],5);

				++drawn;
				--objects_left;
				object_pos[o]=object_pos[objects_left];
				--o;
			}
		}
	}
}

const bool Game::IsBehind2(const xy &first, const xy &second)
{
	if ( (first.y LT second.x) || (second.y LT first.x) ) return false;
	return true;
}

const bool Game::IsBehind(const obj &o1, const obj &o2)
{
	if ( (o1.min.z GE o2.max.z) || (o1.min.x GE o2.max.x) || (o1.min.y GE o2.max.y) ) return true;
	return false;
}
