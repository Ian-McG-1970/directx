#ifndef ENGINE
#define ENGINE

#include "d3d8_screen.h"
#include "map.h"

#define TRC_OUTSIDE -1
#define TRC_EPS 0.01f
#define TRC_MOVE_EPS 0.1f

#define TRC_GRAVITY D3DXVECTOR3(0,-0.99,0)
#define TRC_SML_UP D3DXVECTOR3(0,+0.01f,0)
#define TRC_BIG_UP D3DXVECTOR3(0,+1.01f,0)
#define TRC_SML_DOWN D3DXVECTOR3(0,-0.01f,0)
#define TRC_BIG_DOWN D3DXVECTOR3(0,-1.02f,0)
#define TRC_COL_INC 0.98f

#define EXTENT_SIZE 1.49f
#define EXTENT_STAND D3DXVECTOR3(EXTENT_SIZE,EXTENT_SIZE*3.0f,EXTENT_SIZE)
#define EXTENT_CROUCH D3DXVECTOR3(EXTENT_SIZE,EXTENT_SIZE,EXTENT_SIZE)
#define EXTENT_STAND_UP D3DXVECTOR3(0.0f,EXTENT_STAND.y-EXTENT_CROUCH.y,0.0f)
//#define EXTENT_CROUCH_DOWN D3DXVECTOR3(0.0f,EXTENT_CROUCH.y-EXTENT_CROUCH.y,0.0f)

typedef struct
{
	D3DXVECTOR3 Bounding_Box[MAX_BOUNDING_BOX];
} EXTENT;

typedef struct
{
	float Distance;
	D3DXVECTOR3 Direction;
} TRACE;

class Engine
{
private:
	float	Speed;
	D3DXVECTOR3 Location;
	D3DXVECTOR3 Direction;
	D3DXVECTOR3 BoundingBox;
	D3DXVECTOR3 Stature;
	const D3DXVECTOR3 Move(const D3DXVECTOR3 &, const float);
	const void Input(D3DXVECTOR3 &, float &, const float);
	const void DrawTrack();
	const int InsideObject(const D3DXVECTOR3 &);
	const TRACE TraceCheck(const D3DXVECTOR3 &, const D3DXVECTOR3 &,const D3DXVECTOR3 &,const D3DXVECTOR3 &, const EXTENT &, const EXTENT &, const int);
	const D3DXVECTOR3 TraceMove(const D3DXVECTOR3 &, const D3DXVECTOR3 &,const D3DXVECTOR3 &,const D3DXVECTOR3 &);
	const bool Overlap(const float,const float,const float);
	const TRACE Trace(const D3DXVECTOR3 &,const D3DXVECTOR3 &,const D3DXVECTOR3 &,const D3DXVECTOR3 &);
	const float TraceLeft(const D3DXVECTOR3 &,const D3DXVECTOR3 &,const std::vector<COLLISION> &);
	const float TraceBottom(const D3DXVECTOR3 &, const D3DXVECTOR3 &,const std::vector<COLLISION> &);
	const float TraceRight(const D3DXVECTOR3 &,const D3DXVECTOR3 &,const std::vector<COLLISION> &);
	const float TraceTop(const D3DXVECTOR3 &,const D3DXVECTOR3 &,const std::vector<COLLISION> &);
	const float TraceBack(const D3DXVECTOR3 &,const D3DXVECTOR3 &,const std::vector<COLLISION> &);
	const float TraceFront(const D3DXVECTOR3 &,const D3DXVECTOR3 &,const std::vector<COLLISION> &);
	const D3DXVECTOR3 MoveTrace(const D3DXVECTOR3 &, const D3DXVECTOR3 &, const float);
	const EXTENT Extent(const D3DXVECTOR3 &,const D3DXVECTOR3 &);
	int dir;
public:
	const void Setup();
	~Engine();
	const void Update();
};

#endif

