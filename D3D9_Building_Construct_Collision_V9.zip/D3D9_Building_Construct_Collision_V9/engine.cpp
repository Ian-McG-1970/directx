#include "engine.h"
#include "d3d8_screen.h"
#include "di_mouse.h"
#include "map.h"

extern HWND hwnd;
extern Mouse mouse;
extern Map map;
extern Screen screen;

extern FILE *file;

unsigned long count;

const void Engine::Setup()
{
	fprintf(file,"engine setup\n");

	Location=D3DXVECTOR3(RM_CENTRE+50.0f,RM_CENTRE+50.0f,RM_CENTRE+50.0f);
	Stature=EXTENT_STAND;//EXTENT_CROUCH;//EXTENT_STAND;
	Direction=D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	Speed=0.0f;
}

Engine::~Engine()
{
	fprintf(file,"engine shutdown\n");
}

const D3DXVECTOR3 Engine::Move(const D3DXVECTOR3 &direction, const float speed)
{
	D3DXMATRIX matTmp;
	D3DXMatrixRotationYawPitchRoll(&matTmp, direction.y, direction.x, direction.z);
	D3DXVECTOR4 tmp;
	D3DXVec3Transform(&tmp, &D3DXVECTOR3(0.0f, 0.0f, 1.0f), &matTmp);
	tmp.y=0;
	return D3DXVECTOR3(tmp)*speed;
}

const void Engine::Input(D3DXVECTOR3 &direction, float &speed, const float dampen)
{
	mouse.Update();
	if (mouse.LB!=0 && mouse.RB!=0)
	{
		PostMessage(hwnd, WM_CLOSE, 0, 0);
		return;
	}
	if (mouse.LB==0 && mouse.RB==0)
	{
		direction.x -= mouse.Y*dampen;
		direction.y += mouse.X*dampen;
	}
	if (mouse.RB!=0)
	{
		if (Stature==EXTENT_STAND)
		{
			Stature=EXTENT_CROUCH;
			Location-=EXTENT_STAND_UP;
		}
		else
		{
			const TRACE trace=Trace(Location,Location+EXTENT_STAND_UP,Stature,EXTENT_STAND_UP); // trace how far can be moved
			if (trace.Distance >=1.0f) // can move forward
			{
				Location+=EXTENT_STAND_UP;
				Stature=EXTENT_STAND;
			}
		}
//		direction.z -= mouse.X*dampen;
	}
	if (mouse.LB!=0)
	{
		speed -= mouse.Y*dampen;
	}
	speed*=0.9999f;
}

const void Engine::DrawTrack()
{
	for (int ts=0; ts!=map.TrackSections; ++ts)
	{
		const int model=map.Track[ts].Model;
		const D3DXVECTOR3 location=map.Track[ts].Location;

//		if (screen.IsSphereInsideFrustum(&location, screen.Model[model].Bounding_Sphere_Radius)==true)
		{
			screen.DrawObject(&location,&map.Track[ts].Direction,model,map.Track[ts].Material);
//			screen.DrawDebugObject(location, model);
			++count;
		}
	}
}

const int Engine::InsideObject(const D3DXVECTOR3 &position)
{
	for (int o=0; o!=map.TrackSections; ++o)
	{
		const int model=map.Track[o].Model;
		const D3DXVECTOR3 location=position-map.Track[o].Location;
		const D3DXVECTOR3 start=screen.Model[model].Bounding_Box[0];
		const D3DXVECTOR3 end=screen.Model[model].Bounding_Box[MAX_BOUNDING_BOX-1];

		if ((location.x >= start.x) && (location.y >= start.y) && (location.z >= start.z) && (location.x <= end.x) && (location.y <= end.y) && (location.z <= end.z))
		{
			return o;
		}
	}
	return TRC_OUTSIDE;
}

const bool Engine::Overlap(const float min, const float max, const float point) // less than	a < b
{
	if ( (point <max) && (point >min) ) return true;
	return false;
}

const float Engine::TraceBack(const D3DXVECTOR3 &start,const D3DXVECTOR3 &end,const std::vector<COLLISION> &wall)
{
	for(int f=0; f!=wall.size(); ++f)
	{
		if(Overlap(start.z,end.z,wall[f].pos)==true)
		{
			if ( (Overlap(wall[f].min.x,wall[f].max.x,end.x)==true) && (Overlap(wall[f].min.y,wall[f].max.y,end.y)==true) )
			{
				return ( (wall[f].pos -start.z) / (end.z -start.z) ) -TRC_EPS;
			}
		}
	}
	return 1.0f;
}

const float Engine::TraceFront(const D3DXVECTOR3 &start,const D3DXVECTOR3 &end,const std::vector<COLLISION> &wall)
{
	for(int f=wall.size()-1; f!=-1; --f)
	{
		if(Overlap(start.z,end.z,wall[f].pos)==true)
		{
			if ( (Overlap(wall[f].min.x,wall[f].max.x,end.x)==true) && (Overlap(wall[f].min.y,wall[f].max.y,end.y)==true) )
			{
				return ( (start.z -wall[f].pos) / (end.z - start.z) ) +TRC_EPS;
			}
		}
	}
	return 1.0f;
}

const float Engine::TraceRight(const D3DXVECTOR3 &start, const D3DXVECTOR3 &end, const std::vector<COLLISION> &wall)
{
	for (int f=0; f!=wall.size(); ++f)
	{
		if (Overlap(start.x, end.x,wall[f].pos)==true)
		{
			if ( (Overlap(wall[f].min.x,wall[f].max.x, end.y)==true) && (Overlap(wall[f].min.y,wall[f].max.y, end.z)==true) )
			{
				return ( (wall[f].pos -start.x) / (end.x -start.x) ) -TRC_EPS;
			}
		}
	}
	return 1.0f;
}

const float Engine::TraceLeft(const D3DXVECTOR3 &start,const D3DXVECTOR3 &end,const std::vector<COLLISION> &wall)
{
	for(int f=wall.size()-1; f!=-1; --f)
	{
		if(Overlap(start.x,end.x,wall[f].pos)==true)
		{
			if ( (Overlap(wall[f].min.x,wall[f].max.x,end.y)==true) && (Overlap(wall[f].min.y,wall[f].max.y,end.z)==true) )
			{
				return ( (start.x -wall[f].pos) / (end.x -start.x) ) +TRC_EPS;
			}
		}
	}
	return 1.0f;
}

const float Engine::TraceTop(const D3DXVECTOR3 &start,const D3DXVECTOR3 &end,const std::vector<COLLISION> &wall)
{
	for (int f=0; f!=wall.size(); ++f)
	{
		if (Overlap(start.y,end.y,wall[f].pos)==true)
		{
			if ( (Overlap(wall[f].min.x,wall[f].max.x,end.x)==true) && (Overlap(wall[f].min.y,wall[f].max.y,end.z)==true) )
			{
				return ( (wall[f].pos -start.y) / (end.y -start.y) ) -TRC_EPS;
			}
		}
	}
	return 1.0f;
}

const float Engine::TraceBottom(const D3DXVECTOR3 &start,const D3DXVECTOR3 &end,const std::vector<COLLISION> &wall)
{
	for(int f=wall.size()-1; f!=-1; --f)
	{
		if(Overlap(start.y,end.y,wall[f].pos)==true)
		{
			if ( (Overlap(wall[f].min.x,wall[f].max.x,end.x)==true) && (Overlap(wall[f].min.y,wall[f].max.y,end.z)==true) )
			{
				return ( (start.y -wall[f].pos) / (end.y - start.y) ) +TRC_EPS;
			}
		}
	}
	return 1.0f;
}

const TRACE Engine::Trace(const D3DXVECTOR3 &start, const D3DXVECTOR3 &end,const D3DXVECTOR3 &extent, const D3DXVECTOR3 &direction)
{
	TRACE trace;
	trace.Distance=1.0f;
	const EXTENT s_bb=Extent(start, extent);
	const EXTENT e_bb=Extent(end, extent);
	const int end_object=InsideObject(end);
	const int start_object=InsideObject(start);
	const TRACE end_trace=TraceCheck(start,end,extent,direction,s_bb,e_bb,end_object);
	if (end_trace.Distance <trace.Distance)
	{
		trace.Distance=end_trace.Distance;
		trace.Direction=end_trace.Direction;
	}
	if (start_object!=end_object)
	{
		const TRACE start_trace=TraceCheck(start,end,extent,direction,s_bb,e_bb,start_object);
		if (start_trace.Distance <trace.Distance)
		{
			trace.Distance=start_trace.Distance;
			trace.Direction=start_trace.Direction;
		}
	}
	return trace;
}

const TRACE Engine::TraceCheck(const D3DXVECTOR3 &start, const D3DXVECTOR3 &end,const D3DXVECTOR3 &extent,const D3DXVECTOR3 &direction, const EXTENT &se,const EXTENT &ee, const int object)
{
	TRACE trace;
	dir=0;
	const D3DXVECTOR3 start_loc=start-map.Track[object].Location;
	const D3DXVECTOR3 end_loc=end-map.Track[object].Location;
	const int model=map.Track[object].Model;

	trace.Distance=1.0f;
	trace.Direction=direction;
	if (start.z > end.z)
	{
		float dist=1.0f;
		for (float x=-extent.x; x<extent.x; x+=TRC_COL_INC)
		{
			for (float y=-extent.y; y<extent.y; y+=TRC_COL_INC)
			{
				dist=min(dist,TraceFront(D3DXVECTOR3(end_loc.x+x,end_loc.y+y,end_loc.z-extent.z),D3DXVECTOR3(start_loc.x+x,start_loc.y+y,start_loc.z-extent.z),map.ModelCollisionList[COLLIDE_FRONT][model].Collision));
			}
		}
		if (dist <trace.Distance)
		{
			trace.Distance=dist;
			trace.Direction=D3DXVECTOR3(direction.x,direction.y, 0);
		}
	}
	else if (start.z < end.z)
	{
		float dist=1.0f;
		for(float x=-extent.x; x<extent.x; x+=TRC_COL_INC)
		{
			for(float y=-extent.y; y<extent.y; y+=TRC_COL_INC)
			{
				dist=min(dist,TraceBack(D3DXVECTOR3(start_loc.x+x,start_loc.y+y,start_loc.z+extent.z),D3DXVECTOR3(end_loc.x+x,end_loc.y+y,end_loc.z+extent.z),map.ModelCollisionList[COLLIDE_BACK][model].Collision));
			}
		}
		if(dist <trace.Distance)
		{
			trace.Distance=dist;
			trace.Direction=D3DXVECTOR3(direction.x,direction.y, 0);
		}
	}
	if (start.x > end.x)
	{
		float dist=1.0f;
		for (float z=-extent.z; z<extent.z; z+=TRC_COL_INC)
		{
			for (float y=-extent.y; y<extent.y; y+=TRC_COL_INC)
			{
				dist=min(dist,TraceLeft(D3DXVECTOR3(end_loc.x-extent.x,end_loc.y+y,end_loc.z+z),D3DXVECTOR3(start_loc.x-extent.x,start_loc.y+y,start_loc.z+z),map.ModelCollisionList[COLLIDE_LEFT][model].Collision));
			}
		}
		if(dist <trace.Distance)
		{
			trace.Distance=dist;
			trace.Direction=D3DXVECTOR3(0, direction.y,direction.z);
		}
	}
	else if(start.x < end.x)
	{
		float dist=1.0f;
		for(float z=-extent.z; z<extent.z; z+=TRC_COL_INC)
		{
			for(float y=-extent.y; y<extent.y; y+=TRC_COL_INC)
			{
				dist=min(dist,TraceRight(D3DXVECTOR3(start_loc.x+extent.x,start_loc.y+y,start_loc.z+z),D3DXVECTOR3(end_loc.x+extent.x,end_loc.y+y,end_loc.z+z),map.ModelCollisionList[COLLIDE_RIGHT][model].Collision));
			}
		}
		if(dist <trace.Distance)
		{
			trace.Distance=dist;
			trace.Direction=D3DXVECTOR3(0, direction.y,direction.z);
		}
	}
	if (start.y > end.y)
	{
		float dist=1.0f;
		for(float x=-extent.x; x<extent.x; x+=TRC_COL_INC)
		{
			for(float z=-extent.z; z<extent.z; z+=TRC_COL_INC)
			{
				dist=min(dist,TraceBottom(D3DXVECTOR3(end_loc.x+x,end_loc.y-extent.y,end_loc.z+z),D3DXVECTOR3(start_loc.x+x,start_loc.y-extent.y,start_loc.z+z),map.ModelCollisionList[COLLIDE_BOTTOM][model].Collision));
			}
		}
		if(dist <trace.Distance)
		{
			trace.Distance=dist;
			trace.Direction=D3DXVECTOR3(direction.x, 0, direction.z);
		}
	}
	else if(start.y < end.y)
	{
		float dist=1.0f;
		for(float x=-extent.x; x<extent.x; x+=TRC_COL_INC)
		{
			for(float z=-extent.z; z<extent.z; z+=TRC_COL_INC)
			{
				dist=min(dist, TraceTop(D3DXVECTOR3(start_loc.x+x, start_loc.y+extent.y, start_loc.z+z), D3DXVECTOR3(end_loc.x+x,	end_loc.y+extent.y,	end_loc.z+z), map.ModelCollisionList[COLLIDE_TOP][model].Collision));
			}
		}
		if(dist <trace.Distance)
		{
			trace.Distance=dist;
			trace.Direction=D3DXVECTOR3(direction.x, 0, direction.z);
		}
	}
	return trace;
}

const D3DXVECTOR3 Engine::MoveTrace(const D3DXVECTOR3 &start,const D3DXVECTOR3 &end,const float distance)
{
	if (distance >=1.0f) return end;
	return start + ((end-start) *distance);
}

const D3DXVECTOR3 Engine::TraceMove(const D3DXVECTOR3 &start, const D3DXVECTOR3 &end,const D3DXVECTOR3 &extent,const D3DXVECTOR3 &direction)
{
	const TRACE trace = Trace(start, end, extent, direction);
	return MoveTrace(start, end, trace.Distance);
}

const void Engine::Update()
{
	count=0;
	screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, BACKGROUND, 1.0f, 0);

	Input(Direction, Speed, 0.0003f);

	const D3DXVECTOR3 extent=Stature;
//	Location=TraceMove(Location,Location+TRC_SML_UP,extent,Direction); // move up a little bit
	D3DXVECTOR3 start=Location; // store current location
	const D3DXVECTOR3 movement=Move(Direction,Speed); // move forward
	Location+=movement;
	TRACE trace=Trace(start,Location,extent,Direction); // trace how far can be moved
	if (trace.Distance >=TRC_MOVE_EPS) // can move forward
	{
		Location=MoveTrace(start,Location, trace.Distance); // move forward
//		Location=TraceMove(Location,Location+TRC_SML_DOWN,extent,movement); // move down a little bit
	}
	else // cant move forward
	{
		Location=TraceMove(start,start+TRC_BIG_UP,extent,movement); // move up a big bit

		trace=Trace(Location,Location+movement,extent,movement); // trace how far can be moved
		if (trace.Distance >=TRC_MOVE_EPS) // can move forward
		{
			Location=MoveTrace(Location,Location+movement,trace.Distance); // move forward
		}
		else
		{
			Location=TraceMove(Location,Location+trace.Direction,extent,movement); // slide
		}
		Location=TraceMove(Location,Location-TRC_BIG_UP,extent,movement); // move down a big bit
	}
	Location=TraceMove(Location,Location+TRC_GRAVITY,extent,movement); // gravity

	screen.View_Matrix(D3DXVECTOR3(Location.x,Location.y+Stature.y-EXTENT_SIZE,Location.z), &Direction);

	screen.g_pd3dDevice->BeginScene();
	DrawTrack();

	sprintf(screen.string, "px %5f py %5f pz %5f cnt %i io %i %f %f %f\n", Location.x, Location.y, Location.z, count, InsideObject(Location),Speed,Stature.y,EXTENT_SIZE);
	screen.DrawText(5, 5, D3DCOLOR_XRGB(160, 160, 160));

	screen.g_pd3dDevice->EndScene();
	screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
}

const EXTENT Engine::Extent(const D3DXVECTOR3 &pos, const D3DXVECTOR3 &extent)
{
	EXTENT bb;
	bb.Bounding_Box[TFL]=D3DXVECTOR3(pos.x-extent.x, pos.y-extent.y, pos.z-extent.z);//TFL
	bb.Bounding_Box[TBL]=D3DXVECTOR3(pos.x-extent.x, pos.y-extent.y, pos.z+extent.z);//TBL
	bb.Bounding_Box[TFR]=D3DXVECTOR3(pos.x-extent.x, pos.y+extent.y, pos.z-extent.z);//BFL
	bb.Bounding_Box[TBR]=D3DXVECTOR3(pos.x-extent.x, pos.y+extent.y, pos.z+extent.z);//BBL
	bb.Bounding_Box[BFL]=D3DXVECTOR3(pos.x+extent.x, pos.y-extent.y, pos.z-extent.z);//TFR
	bb.Bounding_Box[BBL]=D3DXVECTOR3(pos.x+extent.x, pos.y-extent.y, pos.z+extent.z);//TBR
	bb.Bounding_Box[BFR]=D3DXVECTOR3(pos.x+extent.x, pos.y+extent.y, pos.z-extent.z);//BFR
	bb.Bounding_Box[BBR]=D3DXVECTOR3(pos.x+extent.x, pos.y+extent.y, pos.z+extent.z);//BBR
	return bb;
}
//		-extent.x,-extent.y,-extent.z),map.ModelCollisionList[COLLIDE_FRONT][model].Collision); TFL
//		-extent.x,+extent.y,-extent.z),map.ModelCollisionList[COLLIDE_FRONT][model].Collision); TFR
//		+extent.x,-extent.y,-extent.z),map.ModelCollisionList[COLLIDE_FRONT][model].Collision); bfl
//		+extent.x,+extent.y,-extent.z),map.ModelCollisionList[COLLIDE_FRONT][model].Collision); bfr
//front
//		-extent.x,-extent.y,+extent.z),map.ModelCollisionList[COLLIDE_BACK][model].Collision); tbl
//		-extent.x,+extent.y,+extent.z),map.ModelCollisionList[COLLIDE_BACK][model].Collision); tbr
//		+extent.x,-extent.y,+extent.z),map.ModelCollisionList[COLLIDE_BACK][model].Collision); bbl
//		+extent.x,+extent.y,+extent.z),map.ModelCollisionList[COLLIDE_BACK][model].Collision); bbr
//back

//		-extent.x,-extent.y,-extent.z),map.ModelCollisionList[COLLIDE_LEFT][model].Collision); tfl
//		-extent.x,+extent.y,-extent.z),map.ModelCollisionList[COLLIDE_LEFT][model].Collision); tfr
//		-extent.x,-extent.y,+extent.z),map.ModelCollisionList[COLLIDE_LEFT][model].Collision); tbl
//		-extent.x,+extent.y,+extent.z),map.ModelCollisionList[COLLIDE_LEFT][model].Collision); tbr
//top
//		+extent.x,-extent.y,-extent.z),map.ModelCollisionList[COLLIDE_RIGHT][model].Collision); bfl
//		+extent.x,+extent.y,-extent.z),map.ModelCollisionList[COLLIDE_RIGHT][model].Collision); bfr
//		+extent.x,-extent.y,+extent.z),map.ModelCollisionList[COLLIDE_RIGHT][model].Collision); bbl
//		+extent.x,+extent.y,+extent.z),map.ModelCollisionList[COLLIDE_RIGHT][model].Collision); bbr
//bottom

//		-extent.x,-extent.y,-extent.z),map.ModelCollisionList[COLLIDE_BOTTOM][model].Collision); tfl
//		-extent.x,-extent.y,+extent.z),map.ModelCollisionList[COLLIDE_BOTTOM][model].Collision); tbl
//		+extent.x,-extent.y,-extent.z),map.ModelCollisionList[COLLIDE_BOTTOM][model].Collision); bfl
//		+extent.x,-extent.y,+extent.z),map.ModelCollisionList[COLLIDE_BOTTOM][model].Collision); bbl
//left
//		-extent.x,+extent.y,-extent.z),map.ModelCollisionList[COLLIDE_TOP][model].Collision); tfr
//		-extent.x,+extent.y,+extent.z),map.ModelCollisionList[COLLIDE_TOP][model].Collision); tbr
//		+extent.x,+extent.y,-extent.z),map.ModelCollisionList[COLLIDE_TOP][model].Collision); bfr
//		+extent.x,+extent.y,+extent.z),map.ModelCollisionList[COLLIDE_TOP][model].Collision); bbr
//right
