#include "d3d8_screen.h"
#include "load.h"
#include "map.h"
#include <algorithm>

extern Screen screen;
extern Load load;
extern FILE *file;

//todo
//routine to identify if inside object or not using model bounding box - done
//routine to return object number and model number - done
//collision list structure - done
// sort collision lists into order - done
//mesh type which stores indices/vertices/collision lists/bounding box - done
// pass inside/outside to add collision - and if inside store in opposite wall

const void Map::Setup()
{
	fprintf(file,"map setup\n");
	BuildTrack();
}

Map::~Map()
{
	fprintf(file,"map shutdown\n");
}

const void Map::BuildTrack()
{
	TrackSections=room.size();

	for (int r=0; r!=room.size(); ++r)
	{
		const ROOM rm=Room(room[r]);
		Track[r].Model=rm.object;
		Track[r].Material=rand()&3;
		Track[r].Location=rm.location;
		Track[r].Direction=D3DXVECTOR3(0,0,0);
	}
}

const GAP_TYPE Map::AddGapSide(const unsigned char side, const D3DXVECTOR2 start, const D3DXVECTOR2 end)
{
	GAP_TYPE gap;
	gap.side=side;
	gap.start=start;
	gap.end=end;
	return gap;
}

const int Map::AddPoint(const D3DXVECTOR3 &point)
{
	for (int p=0; p!=Point.size(); ++p)
	{
		if ((Point[p].x==point.x) && (Point[p].y==point.y) && (Point[p].z==point.z))
		{
			return p;
		}
	}
	Point.push_back(point);
	return Point.size()-1;
}

const void Map::AddTriangle(const int p0,const int p1,const int p2)
{
	Triangle.push_back(p0);
	Triangle.push_back(p1);
	Triangle.push_back(p2);
}

const void Map::AddFace(const int p0,const int p1,const int p2,const int p3)
{
	AddTriangle(p0,p1,p2);
	AddTriangle(p0,p2,p3);
}

const void Map::BuildLeftWalls(const D3DXVECTOR3 &start,const D3DXVECTOR3 &end, const bool inside)
{
	FindGaps(GP_LT);
	AddGaps(start.y,end.y,start.z,end.z);
	FindPartitions();
	FindUsedPartitions();
	LinkPartitions();
	X_2D_3D(start.x, false);
	AddWallsToObject(inside, COLLIDE_LEFT);
}

const void Map::BuildRightWalls(const D3DXVECTOR3 &start,const D3DXVECTOR3 &end,const bool inside)
{
	FindGaps(GP_RT);
	AddGaps(start.y,end.y,start.z,end.z);
	FindPartitions();
	FindUsedPartitions();
	LinkPartitions();
	X_2D_3D(end.x, true);
	AddWallsToObject(inside, COLLIDE_RIGHT);
}

const void Map::BuildTopWalls(const D3DXVECTOR3 &start,const D3DXVECTOR3 &end,const bool inside)
{
	FindGaps(GP_TP);
	AddGaps(start.x,end.x,start.z,end.z);
	FindPartitions();
	FindUsedPartitions();
	LinkPartitions();
	Y_2D_3D(end.y,false);
	AddWallsToObject(inside, COLLIDE_TOP);
}

const void Map::BuildBottomWalls(const D3DXVECTOR3 &start,const D3DXVECTOR3 &end,const bool inside)
{
	FindGaps(GP_BM);
	AddGaps(start.x,end.x,start.z,end.z);
	FindPartitions();
	FindUsedPartitions();
	LinkPartitions();
	Y_2D_3D(start.y,true);
	AddWallsToObject(inside, COLLIDE_BOTTOM);
}

const void Map::BuildFrontWalls(const D3DXVECTOR3 &start,const D3DXVECTOR3 &end,const bool inside)
{
	FindGaps(GP_FT);
	AddGaps(start.x,end.x,start.y,end.y);
	FindPartitions();
	FindUsedPartitions();
	LinkPartitions();
	Z_2D_3D(start.z,false);
	AddWallsToObject(inside, COLLIDE_FRONT);
}

const void Map::BuildBackWalls(const D3DXVECTOR3 &start,const D3DXVECTOR3 &end,const bool inside)
{
	FindGaps(GP_BK);
	AddGaps(start.x,end.x,start.y,end.y);
	FindPartitions();
	FindUsedPartitions();
	LinkPartitions();
	Z_2D_3D(end.z,true);
	AddWallsToObject(inside, COLLIDE_BACK);
}

const PI Map::AddPI(const int p0, const int p1, const int p2, const int p3)
{
	PI pi;
	pi.first=p0;
	pi.second=p1;
	pi.third=p2;
	pi.fourth=p3;
	return pi;
}
const void Map::X_2D_3D(const float x, const bool reverse)
{
	PartitionIndex.clear();

	for (int p=0; p!=UsedPartitions.size(); ++p)
	{
		const D3DXVECTOR3 point_first=D3DXVECTOR3(x,UsedPartitions[p].start.x,UsedPartitions[p].start.y);
		const D3DXVECTOR3 point_second=D3DXVECTOR3(x,UsedPartitions[p].start.x,UsedPartitions[p].end.y);
		const D3DXVECTOR3 point_third=D3DXVECTOR3(x,UsedPartitions[p].end.x,UsedPartitions[p].end.y);
		const D3DXVECTOR3 point_fourth=D3DXVECTOR3(x,UsedPartitions[p].end.x,UsedPartitions[p].start.y);
		if (reverse==false)
		{
			PartitionIndex.push_back(AddPI(AddPoint(point_first),AddPoint(point_second),AddPoint(point_third),AddPoint(point_fourth)));
		}
		else
		{
			PartitionIndex.push_back(AddPI(AddPoint(point_fourth),AddPoint(point_third),AddPoint(point_second),AddPoint(point_first)));
		}
	}
}

const void Map::Y_2D_3D(const float y,const bool reverse)
{
	PartitionIndex.clear();

	for (int p=0; p!=UsedPartitions.size(); ++p)
	{
		const D3DXVECTOR3 point_first=D3DXVECTOR3(UsedPartitions[p].start.x,y,UsedPartitions[p].start.y);
		const D3DXVECTOR3 point_second=D3DXVECTOR3(UsedPartitions[p].start.x,y,UsedPartitions[p].end.y);
		const D3DXVECTOR3 point_third=D3DXVECTOR3(UsedPartitions[p].end.x,y,UsedPartitions[p].end.y);
		const D3DXVECTOR3 point_fourth=D3DXVECTOR3(UsedPartitions[p].end.x,y,UsedPartitions[p].start.y);
		if (reverse==false)
		{
			PartitionIndex.push_back(AddPI(AddPoint(point_first),AddPoint(point_second),AddPoint(point_third),AddPoint(point_fourth)));
		}
		else
		{
			PartitionIndex.push_back(AddPI(AddPoint(point_fourth),AddPoint(point_third),AddPoint(point_second),AddPoint(point_first)));
		}
	}
}

const void Map::Z_2D_3D(const float z,const bool reverse)
{
	PartitionIndex.clear();

	for (int p=0; p!=UsedPartitions.size(); ++p)
	{
		const D3DXVECTOR3 point_first=D3DXVECTOR3(UsedPartitions[p].start.x,UsedPartitions[p].start.y,z);
		const D3DXVECTOR3 point_second=D3DXVECTOR3(UsedPartitions[p].start.x,UsedPartitions[p].end.y,z);
		const D3DXVECTOR3 point_third=D3DXVECTOR3(UsedPartitions[p].end.x,UsedPartitions[p].end.y,z);
		const D3DXVECTOR3 point_fourth=D3DXVECTOR3(UsedPartitions[p].end.x,UsedPartitions[p].start.y,z);
		if (reverse==false)
		{
			PartitionIndex.push_back(AddPI(AddPoint(point_first),AddPoint(point_second),AddPoint(point_third),AddPoint(point_fourth)));
		}
		else
		{
			PartitionIndex.push_back(AddPI(AddPoint(point_fourth),AddPoint(point_third),AddPoint(point_second),AddPoint(point_first)));
		}
	}
}


const void Map::AddWallsToObject(const bool inside, const int side)
{
	for (int p=0; p!=PartitionIndex.size(); ++p)
	{
		if (inside==false)
		{
			AddFace(PartitionIndex[p].first,PartitionIndex[p].second,PartitionIndex[p].third,PartitionIndex[p].fourth);
			Colliders.push_back(Collider(PartitionIndex[p].first, PartitionIndex[p].third, side, inside)); // pass inside as well?
		}
		else
		{
			AddFace(PartitionIndex[p].fourth,PartitionIndex[p].third,PartitionIndex[p].second,PartitionIndex[p].first);
			Colliders.push_back(Collider(PartitionIndex[p].fourth, PartitionIndex[p].second, side, inside)); // pass inside as well?
		}
	}
}

const void Map::BuildObject(const std::vector<unsigned long long> shape, const int object)
{
	fprintf(file,"shapes %i\n",shape.size());

	Point.clear();
	Triangle.clear();
//	Gap.clear();
	Colliders.clear();

	for(int s=0; s!=shape.size(); ++s)
	{
		const BLOCK block=Block(shape[s]);
		Gap.clear();
		if (block.gap==true) 
		{
			++s;
			GAP_HDR gap_header=GapHeader(shape[s]);

			for (int g=0; g!=gap_header.gaps/2; ++g)
			{
				++s;
				GapDetail(shape[s], &gap_header.start[(g*2)+1], &gap_header.end[(g*2)+1]);
			}
			for (int g=0; g!=gap_header.gaps; ++g)
			{
				Gap.push_back(AddGapSide(gap_header.side[g], gap_header.start[g], gap_header.end[g]));
			}
		}

		if (block.wall.left==true) BuildLeftWalls(block.start,block.end,block.inside);
		if (block.wall.right==true) BuildRightWalls(block.start,block.end, block.inside);
		if (block.wall.top==true) BuildTopWalls(block.start,block.end,block.inside);
		if (block.wall.bottom==true) BuildBottomWalls(block.start,block.end,block.inside);
		if (block.wall.front==true) BuildFrontWalls(block.start,block.end,block.inside);
		if (block.wall.back==true) BuildBackWalls(block.start,block.end,block.inside);
	}

	CollisionLists();
	for (int c=0; c!=COLLIDE_SIDES; ++c) ModelCollisionList[c][object]=CollisionList[c];

	for (int c=0; c!=COLLIDE_SIDES; ++c)
	{
		for (int e=0; e!=CollisionList[c].Collision.size(); ++e)
		{
			fprintf(file,"ce1 %i %i mx %f %f mn %f %f p %f\n",c,e,CollisionList[c].Collision[e].max.x,CollisionList[c].Collision[e].max.y,CollisionList[c].Collision[e].min.x,CollisionList[c].Collision[e].min.y,CollisionList[c].Collision[e].pos);
		}
	}


	for (int c=0; c!=COLLIDE_SIDES; ++c)
	{
		for (int e=0; e!=ModelCollisionList[c][object].Collision.size(); ++e)
		{
			fprintf(file,"ce2 %i %i mx %f %f mn %f %f p %f\n",c,e,ModelCollisionList[c][object].Collision[e].max.x,ModelCollisionList[c][object].Collision[e].max.y,ModelCollisionList[c][object].Collision[e].min.x,ModelCollisionList[c][object].Collision[e].min.y,ModelCollisionList[c][object].Collision[e].pos);
		}
	}


	for (int p=0; p!=Point.size(); ++p)
	{
		screen.Vertex[p].Location=Point[p];
		screen.Vertex[p].Colour=D3DCOLOR_XRGB(rand(),rand(),rand());
	}
	memcpy(&screen.Index[0],&Triangle[0],sizeof(screen.Index[0])*Triangle.size());
	screen.CreateObject(Point.size(),Triangle.size()/3,object);
	fprintf(file,"ts %i cs %i\n",Triangle.size()/3,Colliders.size());
}

const BLOCK Map::Block(const unsigned long long Block)
{
	BLOCK block;
//	fprintf(file,"blk %i %i %i\n",(Block >>S_X) &255,(Block >>S_Y) &255,(Block >>S_Z) &255);
	block.start=D3DXVECTOR3( (((Block >>S_X) &255) *B_SCL), (((Block >>S_Y) &255) *B_SCL), (((Block >>S_Z) &255) *B_SCL) );
	block.end=D3DXVECTOR3( (((Block >>E_X) &255) *B_SCL), (((Block >>E_Y) &255) *B_SCL), (((Block >>E_Z) &255) *B_SCL) );
	block.wall.top=(Block >>W_TP) &YS;
	block.wall.bottom=(Block >>W_BM) &YS;
	block.wall.left=(Block >>W_LT) &YS;
	block.wall.right=(Block >>W_RT) &YS;
	block.wall.front=(Block >>W_FT) &YS;
	block.wall.back=(Block >>W_BK) &YS;
	block.collision.top=(Block >>C_TP) &YS;
	block.collision.bottom=(Block >>C_BM) &YS;
	block.collision.left=(Block >>C_LT) &YS;
	block.collision.right=(Block >>C_RT) &YS;
	block.collision.front=(Block >>C_FT) &YS;
	block.collision.back=(Block >>C_BK) &YS;
	block.gap=(Block >>GP) &YS;
	block.slope=(Block >>SLP) &3; // now needs to be only 1 bit and not 3 ?
	block.inside=Block &YS;
//	fprintf(file,"block gap %i\n",block.gap);
	return block;
}

const GAP_HDR Map::GapHeader(const unsigned long long GapHeader)
{
	GAP_HDR gap_header;
	gap_header.gaps=(GapHeader >>GH_CNT) &15;
	gap_header.side[0]=(GapHeader >>GH_S1) &7;
	gap_header.side[1]=(GapHeader >>GH_S2) &7;
	gap_header.side[2]=(GapHeader >>GH_S3) &7;
	gap_header.side[3]=(GapHeader >>GH_S4) &7;
	gap_header.side[4]=(GapHeader >>GH_S5) &7;
	gap_header.side[5]=(GapHeader >>GH_S6) &7;
	gap_header.side[6]=(GapHeader >>GH_S7) &7;
	gap_header.side[7]=(GapHeader >>GH_S8) &7;
	gap_header.side[8]=(GapHeader >>GH_S9) &7;
	gap_header.start[0]=D3DXVECTOR2((((GapHeader >>GH_SX) &255) *B_SCL),(((GapHeader >>GH_SY) &255) *B_SCL));
	gap_header.end[0]=D3DXVECTOR2((((GapHeader >>GH_EX) &255) *B_SCL),(((GapHeader >>GH_EY) &255) *B_SCL));
	return gap_header;
}

const void Map::GapDetail(const unsigned long long GapDetail, D3DXVECTOR2 *start, D3DXVECTOR2 *end)
{
	start[0]=D3DXVECTOR2((((GapDetail >>GD_SX1) &255) *B_SCL),(((GapDetail >>GD_SY1) &255) *B_SCL));
	end[0]=D3DXVECTOR2((((GapDetail >>GD_EX1) &255) *B_SCL),(((GapDetail >>GD_EY1) &255) *B_SCL));
	start[1]=D3DXVECTOR2((((GapDetail >>GD_SX2) &255) *B_SCL),(((GapDetail >>GD_SY2) &255) *B_SCL));
	end[1]=D3DXVECTOR2((((GapDetail >>GD_EX2) &255) *B_SCL),(((GapDetail >>GD_EY2) &255) *B_SCL));
}

const GAP Map::AddGap(const float sx,const float sy,const float ex,const float ey)
{
	GAP gap;
	gap.start.x=sx;
	gap.start.y=sy;
	gap.end.x=ex;
	gap.end.y=ey;
	return gap;
}

const void Map::FindGaps(const int side)
{
	Gaps.clear();

	for (int g=0; g!=Gap.size(); ++g)
	{
		if (Gap[g].side==side)
		{
			Gaps.push_back(AddGap(Gap[g].start.x,Gap[g].start.y,Gap[g].end.x,Gap[g].end.y));
		}
	}
//	fprintf(file,"findgaps %i %i\n",Gap.size(),Gaps.size());
}

const void Map::AddGapX(const float x)
{
	for (int g=0; g!=GapX.size(); ++g)
	{
		if (GapX[g]==x)
		{
			return;
		}
	}
	GapX.push_back(x);
}

const void Map::AddGapY(const float y)
{
	for (int g=0; g!=GapY.size(); ++g)
	{
		if (GapY[g]==y)
		{
			return;
		}
	}
	GapY.push_back(y);
}

const void Map::AddGaps(const float sx,const float ex,const float sy,const float ey)
{
	GapX.clear();
	GapY.clear();

	AddGapX(sx);
	AddGapX(ex);
	AddGapY(sy);
	AddGapY(ey);

	for (int g=0; g!=Gaps.size(); ++g)
	{
		AddGapX(Gaps[g].start.x);
		AddGapX(Gaps[g].end.x);
		AddGapY(Gaps[g].start.y);
		AddGapY(Gaps[g].end.y);
	}
	std::sort(GapX.begin(),GapX.end());
	std::sort(GapY.begin(),GapY.end());
}

const void Map::FindPartitions()
{
	Partitions.clear();
	for(int x=0; x!=GapX.size()-1; ++x)
	{
		const float sx=GapX[x];
		const float ex=GapX[x+1];
		for(int y=0; y!=GapY.size()-1; ++y)
		{
			const float sy=GapY[y];
			const float ey=GapY[y+1];
			Partitions.push_back(AddGap(sx,sy,ex,ey));
		}
	}
//	fprintf(file,"FindPartitions %i\n",Partitions.size());
//	fprintf(file,"FindPartitions %f %f %f %f\n",Partitions[0].start.x,Partitions[0].start.y,Partitions[0].end.x,Partitions[0].end.y);
}

const void Map::FindUsedPartitions()
{
	UsedPartitions.clear();
	for(int p=0; p!=Partitions.size(); ++p)
	{
		bool found=false;
		for(int g=0; g!=Gaps.size(); ++g)
		{
			if((Gaps[g].start.x <= Partitions[p].start.x) && (Gaps[g].end.x >= Partitions[p].end.x) && (Gaps[g].start.y <= Partitions[p].start.y) && (Gaps[g].end.y >= Partitions[p].end.y))
			{
				found=true;
				break;
			}
		}
		if(found==false)
		{
			UsedPartitions.push_back(Partitions[p]);
		}
	}
}

const void Map::LinkPartitions()
{
	for(bool removed=true; removed==true; )
	{
		removed=false;
		for(int p=0; (p!=UsedPartitions.size()) && (removed==false); ++p)
		{
			for(int q=0; (q!=UsedPartitions.size()) && (removed==false); ++q)
			{
				if(p!=q)
				{
					if((UsedPartitions[p].end.x==UsedPartitions[q].start.x) && (UsedPartitions[p].start.y==UsedPartitions[q].start.y) && (UsedPartitions[p].end.y==UsedPartitions[q].end.y))
					{
						UsedPartitions[p].end.x=UsedPartitions[q].end.x;
						UsedPartitions.erase(UsedPartitions.begin() + q);
						removed=true;
					}
					else if((UsedPartitions[p].end.y==UsedPartitions[q].start.y) && (UsedPartitions[p].start.x==UsedPartitions[q].start.x) && (UsedPartitions[p].end.x==UsedPartitions[q].end.x))
					{
						UsedPartitions[p].end.y=UsedPartitions[q].end.y;
						UsedPartitions.erase(UsedPartitions.begin() + q);
						removed=true;
					}
				}
			}
		}
	}
}

const COLLIDER Map::Collider(const int start_index,const int end_index, const int side, const bool inside_outside)
{
	COLLIDER collider;
	collider.side=side;

	if (inside_outside==false)
	{
//		fprintf(file,"collider test %i %i %i %i %i %i %i\n",side,COLLIDE_TOP,COLLIDE_BOTTOM,COLLIDE_LEFT,COLLIDE_RIGHT,COLLIDE_FRONT,COLLIDE_BACK);
		if (side==COLLIDE_TOP) collider.side=COLLIDE_BOTTOM;
		if (side==COLLIDE_BOTTOM) collider.side=COLLIDE_TOP;
		if (side==COLLIDE_LEFT) collider.side=COLLIDE_RIGHT;
		if (side==COLLIDE_RIGHT) collider.side=COLLIDE_LEFT;
		if (side==COLLIDE_FRONT) collider.side=COLLIDE_BACK;
		if (side==COLLIDE_BACK) collider.side=COLLIDE_FRONT;
	}

	collider.start_index=start_index;
	collider.end_index=end_index;
	return collider;
}

const void Map::CollisionLists()
{
	for (int c=0; c!=COLLIDE_SIDES; ++c)
	{
		CollisionList[c].Collision.clear();
	}

	for (int c=0; c!=Colliders.size(); ++c)
	{
		const D3DXVECTOR3 start=Point[Colliders[c].start_index];
		const D3DXVECTOR3 end=Point[Colliders[c].end_index];

		switch (Colliders[c].side)
		{
			case COLLIDE_TOP:
			case COLLIDE_BOTTOM:
				CollisionList[Colliders[c].side].Collision.push_back(Collision(
					D3DXVECTOR2(max(start.x,end.x),max(start.z,end.z)), 
					D3DXVECTOR2(min(start.x,end.x),min(start.z,end.z)),
					start.y));
				break;
			case COLLIDE_LEFT:
			case COLLIDE_RIGHT:
				CollisionList[Colliders[c].side].Collision.push_back(Collision(
					D3DXVECTOR2(max(start.y,end.y),max(start.z,end.z)),
					D3DXVECTOR2(min(start.y,end.y),min(start.z,end.z)),
					start.x));
				break;
			case COLLIDE_FRONT:
			case COLLIDE_BACK:
				CollisionList[Colliders[c].side].Collision.push_back(Collision(
					D3DXVECTOR2(max(start.x,end.x),max(start.y,end.y)),
					D3DXVECTOR2(min(start.x,end.x),min(start.y,end.y)),
					start.z));
				break;
		}
	}
	for (int c=0; c!=COLLIDE_SIDES; ++c)
	{
		std::sort(CollisionList[c].Collision.begin(),CollisionList[c].Collision.end(), 
			[](COLLISION a, COLLISION b) { return a.pos < b.pos; } );
	}

	for (int c=0; c!=COLLIDE_SIDES; ++c)
	{
		for (int e=0; e!=CollisionList[c].Collision.size(); ++e)
		{
			fprintf(file,"ce %i %i mx %f %f mn %f %f p %f\n",c,e, CollisionList[c].Collision[e].max.x, CollisionList[c].Collision[e].max.y, CollisionList[c].Collision[e].min.x, CollisionList[c].Collision[e].min.y, CollisionList[c].Collision[e].pos);
		}
	}

	fprintf(file,"size tblrfb %i %i %i %i %i %i %i\n",Colliders.size(), CollisionList[COLLIDE_TOP].Collision.size(), CollisionList[COLLIDE_BOTTOM].Collision.size(), CollisionList[COLLIDE_LEFT].Collision.size(), CollisionList[COLLIDE_RIGHT].Collision.size(), CollisionList[COLLIDE_FRONT].Collision.size(), CollisionList[COLLIDE_BACK].Collision.size());
}

const COLLISION Map::Collision(const D3DXVECTOR2 &start, const D3DXVECTOR2 &end, const float pos)
{
	COLLISION collision;
	collision.pos=pos;
	collision.max=D3DXVECTOR2(max(start.x,end.x),max(start.y,end.y));
	collision.min=D3DXVECTOR2(min(start.x,end.x),min(start.y,end.y));
	return collision;
}

const ROOM Map::Room(const unsigned long long Room)
{
	ROOM room;
	room.location.x=(Room >>RM_X) &RM_LIMIT;
	room.location.y=(Room >>RM_Y) &RM_LIMIT;
	room.location.z=(Room >>RM_Z) &RM_LIMIT;
	room.location*=B_SCL;
	room.object=(Room >>RM_OBJ) &RM_LIMIT;
	return room;
}
