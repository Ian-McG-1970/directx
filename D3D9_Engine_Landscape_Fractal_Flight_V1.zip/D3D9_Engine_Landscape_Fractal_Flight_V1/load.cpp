#include "load.h"
#include "d3d8_screen.h"
#include "map.h"
#include <algorithm> 

extern FILE *file;
extern Screen screen;
extern Map map;

const void Load::Setup(const D3DFORMAT format)
{
	fprintf(file, "Load setup\n");
	Format = format;
	const double tc_ratio = (double)1.0 / (double)(/*PATCH_COUNT**/PATCH_POINTS);
	for (int t = 0; t != (PATCH_POINTS + 1); ++t)
	{
		Texture_Coord[t] = tc_ratio *(double)t;
	}
}

Load::~Load()
{
	fprintf(file, "Load shutdown\n");
}

/*const int Load::Model3(const int size, const int scale, const int stride)
{
	Model2(size, scale, stride);
	return NULL;
}*/

const void Load::AddTriangle(const int f, const int s, const int t)
{
	screen.Index[(Triangles * 3)] = s;
	screen.Index[(Triangles * 3)+1] = f;
	screen.Index[(Triangles*3)+2] = t;
	Triangle[Triangles].F = f;
	Triangle[Triangles].S = s;
	Triangle[Triangles].T = t;
	++Triangles;
}

const void Load::Model3(const int size, const int scale, const int stride)
{
	POS Point[MAX_SIZE][MAX_SIZE];
	PNT Pnt[MAX_SIZE];

	const int Size = size;
	Points = 0;
	for (int x = 0; x != Size + 1; ++x)
	{
		for (int y = 0; y != Size + 1; ++y)
		{
			Point[x][y].X = x;
			Point[x][y].Y = y;
			Point[x][y].Point = Points;
			Pnt[Points].X = x;
			Pnt[Points].Y = y;
			screen.Vertex[Points].Location.x = x*scale;
			screen.Vertex[Points].Location.y = 0;
			screen.Vertex[Points].Location.z = y*scale;
			screen.Vertex[Points].TU = Texture_Coord[x];
			screen.Vertex[Points].TV = Texture_Coord[y];
			++Points;
		}
	}

	Triangles = 0;
	for (int s = 0; s != stride; ++s)
	{
		AddTriangle(Point[stride][stride].Point, Point[s][0].Point, Point[s + 1][0].Point);
		AddTriangle(Point[stride][stride].Point, Point[0][s + 1].Point, Point[0][s].Point);
		AddTriangle(Point[size - stride][size - stride].Point, Point[size - stride + s + 1][size].Point, Point[size - stride + s][size].Point);
		AddTriangle(Point[size - stride][size - stride].Point, Point[size][size - stride + s].Point, Point[size][size - stride + s + 1].Point);
		AddTriangle(Point[size - stride][stride].Point, Point[size - stride + s][0].Point, Point[size - stride + s + 1][0].Point);
		AddTriangle(Point[size - stride][stride].Point, Point[size][s].Point, Point[size][s + 1].Point);
		AddTriangle(Point[stride][size - stride].Point, Point[0][size - stride + s + 1].Point, Point[0][size - stride + s].Point);
		AddTriangle(Point[stride][size - stride].Point, Point[s + 1][size].Point, Point[s][size].Point);
	}

	for (int t = stride; t != Size - stride; t += stride)
	{
		for (int s = 0; s != stride; ++s)
		{
			AddTriangle(Point[t][stride].Point, Point[t + s][0].Point, Point[t + s + 1][0].Point);
			AddTriangle(Point[stride][t].Point, Point[0][t + s + 1].Point, Point[0][t + s].Point);
			AddTriangle(Point[t][size - stride].Point, Point[t + s + 1][size].Point, Point[t + s][size].Point);
			AddTriangle(Point[size - stride][t].Point, Point[size][t + s].Point, Point[size][t + s + 1].Point);
		}
		AddTriangle(Point[t][stride].Point, Point[t + stride][0].Point, Point[t + stride][stride].Point);
		AddTriangle(Point[stride][t].Point, Point[stride][t + stride].Point, Point[0][t + stride].Point);
		AddTriangle(Point[t][size - stride].Point, Point[t + stride][size - stride].Point, Point[t + stride][size].Point);
		AddTriangle(Point[size - stride][t].Point, Point[size][t + stride].Point, Point[size - stride][t + stride].Point);
	}

	for (int x = stride; x != Size - stride; x += stride)
	{
		for (int y = stride; y != Size - stride; y += stride)
		{
			AddTriangle(Point[x][y].Point, Point[x + stride][y + stride].Point, Point[x][y + stride].Point);
			AddTriangle(Point[x][y].Point, Point[x + stride][y].Point, Point[x + stride][y + stride].Point);
		}
	}
	fprintf(file, "t2 %ld %ld \n", Points, Triangles);
}

const void Load::Texture3(const int number)
{
	fprintf(file, "set texture %i %i\n", number, PATCH_POINTS);

	D3DXCreateTexture(screen.g_pd3dDevice, PATCH_POINTS, PATCH_POINTS, 1, D3DUSAGE_DYNAMIC, Format, D3DPOOL_DEFAULT/*D3DPOOL_MANAGED D3DPOOL_DEFAULT D3DPOOL_SYSTEMMEM*/, &screen.Texture_List[number]);

	IDirect3DSurface9 *surface;
	screen.Texture_List[number]->GetSurfaceLevel(0, &surface);

	D3DSURFACE_DESC surface_desc;
	surface->GetDesc(&surface_desc);

	D3DLOCKED_RECT lock;
	surface->LockRect(&lock, NULL, D3DLOCK_DISCARD);
	unsigned __int16 *image_data = (unsigned __int16*)lock.pBits;

	fprintf(file, "w %i h %i f %i p %i\n", surface_desc.Width, surface_desc.Height, surface_desc.Format, lock.Pitch);

	//		const int texel = rand() + rand();
	for (int h = 0; h != surface_desc.Height; ++h)
	{
//		const int texel = rand() + rand();
		for (int w = 0; w != surface_desc.Width; ++w)
		{
			const int texel = rand() + rand();
			*(image_data + w) = texel;
		}
		image_data += (lock.Pitch / 2); //?
	}
	surface->UnlockRect();
	surface->Release();
}

const void Load::Texture2(const int number)
{
	fprintf(file, "set texture2 %i %i\n", number, PATCH_POINTS);

	D3DXCreateTexture(screen.g_pd3dDevice, PATCH_POINTS, PATCH_POINTS, 1, D3DUSAGE_DYNAMIC, Format, D3DPOOL_DEFAULT/*D3DPOOL_MANAGED D3DPOOL_DEFAULT D3DPOOL_SYSTEMMEM*/, &screen.Texture_List[number]);

	IDirect3DSurface9 *surface;
	screen.Texture_List[number]->GetSurfaceLevel(0, &surface);

	D3DSURFACE_DESC surface_desc;
	surface->GetDesc(&surface_desc);

	D3DLOCKED_RECT lock;
	surface->LockRect(&lock, NULL, D3DLOCK_DISCARD);
	unsigned __int16 *image_data = (unsigned __int16*)lock.pBits;

	fprintf(file, "w %ld h %ld f %ld p %ld\n", surface_desc.Width, surface_desc.Height, surface_desc.Format, lock.Pitch);

	for (int h = 0; h != surface_desc.Height; ++h)
	{
		for (int w = 0; w != surface_desc.Width; ++w)
		{
			*(image_data + w) = rand() + rand();
		}
		image_data += (lock.Pitch / 2); //?
	}
	surface->UnlockRect();
	surface->Release();
}

const void Load::ReIndexIndex(WORD *point, const std::vector<INDEX> &index, const int points)
{
	for (int p=0; p!=points; ++p)
	{
		const int i=point[p];
		point[p]=index[i].New;
	}
}

const void Load::BuildLOD()
{
	Model3(PATCH_POINTS, MAP_TILE_SIZE, 1);
	Vertex_Count[0] = Points;
	Index_Count[0] = Triangles;
	memcpy(&Index[0][0],&screen.Index[0],sizeof(screen.Index[0])*Index_Count[0] * 3);
	memcpy(&Vertex[0],&screen.Vertex[0],sizeof(screen.Vertex[0])*Vertex_Count[0]);

	Model3(PATCH_POINTS,MAP_TILE_SIZE, 2);
	Index_Count[1] = Triangles;
	memcpy(&Index[1][0],&screen.Index[0],sizeof(screen.Index[0])*Index_Count[1] * 3);

	Model3(PATCH_POINTS,MAP_TILE_SIZE, 4);
	Index_Count[2] = Triangles;
	memcpy(&Index[2][0],&screen.Index[0],sizeof(screen.Index[0])*Index_Count[2] * 3);

	Model3(PATCH_POINTS,MAP_TILE_SIZE, 8);
	Index_Count[3] = Triangles;
	memcpy(&Index[3][0], &screen.Index[0], sizeof(screen.Index[0])*Index_Count[3] * 3);

	Model3(PATCH_POINTS,MAP_TILE_SIZE, 16);
	Index_Count[4] = Triangles;
	memcpy(&Index[4][0], &screen.Index[0], sizeof(screen.Index[0])*Index_Count[4] * 3);

	const std::vector<BYTE> vu0=VertexUsedInIndex(&Index[0][0], Index_Count[0]*3, Vertex_Count[0]);
	const std::vector<BYTE> vu1=VertexUsedInIndex(&Index[1][0], Index_Count[1]*3, Vertex_Count[0]);
	const std::vector<BYTE> vu2=VertexUsedInIndex(&Index[2][0], Index_Count[2]*3, Vertex_Count[0]);
	const std::vector<BYTE> vu3=VertexUsedInIndex(&Index[3][0], Index_Count[3]*3, Vertex_Count[0]);
	const std::vector<BYTE> vu4=VertexUsedInIndex(&Index[4][0], Index_Count[4]*3, Vertex_Count[0]);

	const std::vector<BYTE> i01=VertexTotalIndex(vu0, vu1);
	const std::vector<BYTE> i02=VertexTotalIndex(i01, vu2);
	const std::vector<BYTE> i03=VertexTotalIndex(i02, vu3);
	std::vector<BYTE> i04=VertexTotalIndex(i03, vu4);

	Vertex_Count[0]=VertexCountIndex(vu0);
	Vertex_Count[1]=VertexCountIndex(vu1);
	Vertex_Count[2]=VertexCountIndex(vu2);
	Vertex_Count[3]=VertexCountIndex(vu3);
	Vertex_Count[4]=VertexCountIndex(vu4);

	ReIndex=Reindex(i04);

	std::sort(ReIndex.begin(), ReIndex.end(), [](INDEX a,INDEX b) { return a.Count > b.Count; });

	for (int i=0; i!=ReIndex.size(); ++i) ReIndex[i].New=i;

	std::sort(ReIndex.begin(),ReIndex.end(),[](INDEX a,INDEX b) { return a.Old < b.Old; });

	ReIndexIndex(&Index[0][0], ReIndex, Index_Count[0] * 3);
	ReIndexIndex(&Index[1][0], ReIndex, Index_Count[1] * 3);
	ReIndexIndex(&Index[2][0], ReIndex, Index_Count[2] * 3);
	ReIndexIndex(&Index[3][0], ReIndex, Index_Count[3] * 3);
	ReIndexIndex(&Index[4][0], ReIndex, Index_Count[4] * 3);
}

const std::vector<INDEX> Load::Reindex(const std::vector<BYTE> totalled_index)
{
	std::vector<INDEX> index(totalled_index.size());
	for (int i=0; i!=totalled_index.size(); ++i)
	{
		index[i].Old=i;
		index[i].Count=totalled_index[i];
	}
	return index;
}

const std::vector<BYTE> Load::VertexUsedInIndex(const WORD *index, const int index_count, const int vertex_count)
{
	std::vector<BYTE> vertex_used(vertex_count);
	std::fill(vertex_used.begin(),vertex_used.end(),0);
	for (int i=0; i!=index_count; ++i)
	{
		const int v=index[i];
		if (vertex_used[v]==0)
		{
			vertex_used[v]=1;
		}
	}
	return vertex_used;
}

const std::vector<BYTE> Load::VertexTotalIndex(const std::vector<BYTE> &vertex_1, const std::vector<BYTE> &vertex_2)
{
	std::vector<BYTE> vertex_total(vertex_1.size());
	for (int v=0; v!=vertex_1.size(); ++v)
	{
		vertex_total[v]=vertex_1[v]+vertex_2[v];
	}
	return vertex_total;
}

const int Load::VertexCountIndex(const std::vector<BYTE> &vertex)
{
	int count=0;
	for (int v=0; v!=vertex.size(); ++v)
	{
		count+=vertex[v];
	}
	return count;
}
