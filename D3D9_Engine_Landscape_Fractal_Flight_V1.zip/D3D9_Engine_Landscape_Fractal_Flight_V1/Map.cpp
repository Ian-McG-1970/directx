#include "stdlib.h"
#include "time.h"

#include "d3d8_screen.h"
#include "load.h"
#include "map.h"
#include "log.h"

extern Screen screen;
extern Load load;
extern LogFile logfile;
extern FILE *file;

const void Map::Setup()
{
screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(255, 0, 0), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
	Generate();

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 255, 0), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
	FractalSetup(rand());

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 0, 255), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
	Stretch();

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(255, 255, 0), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
	Build_Grid1();

screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 255, 255), 1.0f, 0); screen.g_pd3dDevice->BeginScene(); screen.g_pd3dDevice->EndScene(); screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
	BuildDrawOrder(21/*29*/);
}

Map::~Map()
{
	sprintf(logfile.file_output,"map shutdown\n"); logfile.Write();
}

const void Map::FractalSetup(const int seed)
{
	srand(seed);
	for (int inc=MAP_SIZE>>1, loop=2; inc!=1; inc=inc>>1, loop+=loop)
	{
		for (int x=0, xs=0; x!=loop; ++x, xs+=inc)
		{
			for (int y=0, ys=0; y!=loop; ++y, ys+=inc)
			{
				Fractal(xs,ys,xs+inc,ys+inc);
			}
		}
	}
}

const void Map::Fractal(const int sx, const int sy, const int ex, const int ey)
{
	const int mx=(sx+ex)>>1;
	const int my=(sy+ey)>>1;

	const int sxp=sx &(MAP_SIZE-1);
	const int syp=sy &(MAP_SIZE-1);
	const int mxp=mx &(MAP_SIZE-1);
	const int myp=my &(MAP_SIZE-1);
	const int exp=ex &(MAP_SIZE-1);
	const int eyp=ey &(MAP_SIZE-1);

	const float top_left=Detail[sxp][syp];
	const float top_right=Detail[sxp][eyp];
	const float bottom_left=Detail[exp][syp];
	const float bottom_right=Detail[exp][eyp];

	const float top_max=max(top_left, top_right);
	const float bottom_max=max(bottom_left, bottom_right);
	const float left_max=max(top_left, bottom_right);
	const float right_max=max(top_right, bottom_right);

	float middle_max=max(top_max, bottom_max);
	middle_max=max(bottom_max, middle_max);
	middle_max=max(left_max, middle_max);
	middle_max=max(right_max, middle_max);

	const float middle=(top_left+top_right+bottom_right+bottom_left)*0.25f;
	const float top=(top_left+top_right)*0.5f;
	const float bottom=(bottom_left+bottom_right)*0.5f;
	const float left=(top_left+bottom_left)*0.5f;
	const float right=(top_right+bottom_right)*0.5f;

	const int middle_diff=labs(middle_max-middle);
	const int top_diff=labs(top_max-top);
	const int bottom_diff=labs(bottom_max-bottom);
	const int left_diff=labs(left_max-left);
	const int right_diff=labs(right_max-right);

	Detail[mxp][myp]=middle +(rand() %(middle_diff+1)) -(middle_diff>>1);
	Detail[sxp][myp]=top +(rand() %(top_diff+1)) -(top_diff>>1);
	Detail[exp][myp]=bottom +(rand() %(bottom_diff+1)) -(bottom_diff>>1);
	Detail[mxp][syp]=left +(rand() %(left_diff+1)) -(left_diff>>1);
	Detail[mxp][eyp]=right +(rand() %(right_diff+1)) -(right_diff>>1);
}

const void Map::Build_Grid1()
{
	D3DXVECTOR3 point[MAX_VERTICES];

	for (int x=0; x<PATCH_COUNT; ++x)
	{
//		sprintf(logfile.file_output,"map setup pcx %i\n",x); logfile.Write();

		for (int y=0; y!=PATCH_COUNT; ++y)
		{
			Build_Patch(x, y, 0);

			for (int v=0; v!=load.Vertex_Count[0]; ++v)
			{
				point[v] = screen.Vertex[v].Location;
			}
			screen.BoundingBox2(&point[0],load.Vertex_Count[0],&Patch_Grid[x][y].BoundingBox[0]);
//			screen.BoundingBox(&point[0], load.Vertex_Count[0], &Patch_Grid[x][y].BoundingBox[0]);
			screen.BoundingSphere2(&Patch_Grid[x][y].BoundingBox[0],MAX_BOUNDING_BOX,Patch_Grid[x][y].BoundingSphereRadius,Patch_Grid[x][y].BoundingSphereCentre);
//			screen.BoundingSphere(&Patch_Grid[x][y].BoundingBox[0], MAX_BOUNDING_BOX, Patch_Grid[x][y].BoundingSphereRadius, Patch_Grid[x][y].BoundingSphereCentre);

			Patch_Grid[x][y].Model = screen.CreateObjectVB(load.Vertex_Count[0]);
			screen.SetTexture(Patch_Grid[x][y].Model, rand() &4095);
		}
	}
//	sprintf(logfile.file_output,"map setup ib\n"); logfile.Write();

	memcpy(&screen.Index[0], &load.Index[0][0], sizeof(screen.Index[0])*load.Index_Count[0] * 3);
	screen.CreateIB(load.Index_Count[0], Patch_Grid[0][0].Model);

	memcpy(&screen.Index[0], &load.Index[1][0], sizeof(screen.Index[0])*load.Index_Count[1] * 3);
	screen.CreateIB(load.Index_Count[1], Patch_Grid[0][1].Model);

	memcpy(&screen.Index[0], &load.Index[2][0], sizeof(screen.Index[0])*load.Index_Count[2] * 3);
	screen.CreateIB(load.Index_Count[2], Patch_Grid[0][2].Model);

	memcpy(&screen.Index[0], &load.Index[3][0], sizeof(screen.Index[0])*load.Index_Count[3] * 3);
	screen.CreateIB(load.Index_Count[3], Patch_Grid[0][3].Model);

	memcpy(&screen.Index[0], &load.Index[4][0], sizeof(screen.Index[0])*load.Index_Count[4] * 3);
	screen.CreateIB(load.Index_Count[4], Patch_Grid[0][4].Model);
}

const void Map::Build_Patch(const int patch_x, const int patch_y, const int lod)
{
	const int detail_x = patch_x*PATCH_POINTS;
	const int detail_y = patch_y*PATCH_POINTS;
	for (int v=0, x=0; x!= PATCH_POINTS + 1; ++x)
	{
		const int bezier_x=(detail_x+x) &(MAP_SIZE-1);
		for (int y=0; y!= PATCH_POINTS + 1; ++y)
		{
			const int bezier_y=(detail_y+y) &(MAP_SIZE-1);
			const int nv=load.ReIndex[v].New;
			screen.Vertex[nv].Location = D3DXVECTOR3(load.Vertex[v].Location.x,Detail[bezier_x][bezier_y],load.Vertex[v].Location.z);
			screen.Vertex[nv].TU = load.Texture_Coord[x];
			screen.Vertex[nv].TV = load.Texture_Coord[y];
			++v;
		}
	}
}

const void Map::Generate()
{
	for (int x=0; x!=MAP_SIZE; ++x)
	{
		for (int y=0; y!=MAP_SIZE; ++y)
		{
			Detail[x][y]=(rand() &MAP_MAX_HEIGHT) +MAP_MAX_HEIGHT;
		}
	}
}

const void Map::Stretch()
{
	float lowest=Detail[0][0];
	for (int x=0; x!=MAP_SIZE; ++x)
	{
		for (int y=0; y!=MAP_SIZE; ++y)
		{
			lowest=min(lowest, Detail[x][y]);
		}
	}
	lowest--;
	for (int x=0; x!=MAP_SIZE; ++x)
	{
		for (int y=0; y!=MAP_SIZE; ++y)
		{
			Detail[x][y]-=lowest;
		}
	}
	float highest=Detail[0][0];
	for (int x=0; x!=MAP_SIZE; ++x)
	{
		for (int y=0; y!=MAP_SIZE; ++y)
		{
			highest=max(highest, Detail[x][y]);
		}
	}
	++highest;
	const float stretch_ratio=(float) MAP_MAX_HEIGHT/highest;
	for (int x=0; x!=MAP_SIZE; ++x)
	{
		for (int y=0; y!=MAP_SIZE; ++y)
		{
			Detail[x][y]*=stretch_ratio;
		}
	}

	highest = lowest = Detail[0][0];
	for (int x = 0; x != MAP_SIZE; ++x)
	{
		for (int y = 0; y != MAP_SIZE; ++y)
		{
			lowest = min(lowest, Detail[x][y]);
			highest = max(highest, Detail[x][y]);
		}
	}
}

const float Map::Height(const D3DXVECTOR3* location) //todo could be made more accurate if across and down were calculated with float accuracy
{
	const float MTS = MAP_TILE_SIZE;
	const int map_tile_x=location->x / MTS;
	const int map_tile_z=location->z / MTS;
	const int across = (int) location->x &(MAP_TILE_SIZE-1);
	const int down = (int) location->z &(MAP_TILE_SIZE-1);
	
	float x0z1, x1z0;
	const float x0z0=Detail[map_tile_x][map_tile_z];
	const float x1z1=Detail[map_tile_x+1][map_tile_z+1];
	const float ave=(x0z0+x1z1)/2.0f;
	if (across>down)
	{
		x1z0=Detail[map_tile_x+1][map_tile_z];
		x0z1=ave+ave-x1z0;
	}
	else
	{
		x0z1=Detail[map_tile_x][map_tile_z+1];
		x1z0=ave+ave-x0z1;
	}
	const float slope_x1 = x0z0 - (((x0z0-x1z0) * across) / MTS);
	const float slope_x2 = x0z1 - (((x0z1-x1z1) * across) / MTS);
	const float slope_y1 = slope_x1 - (((slope_x1 - slope_x2) * down) / MTS);

	return slope_y1;
}

const void Map::AddDrawOrder(const int x, const int y)
{
	for (int c=0; c!=DrawOrder2.size(); ++c)
	{
		if ((DrawOrder2[c].x==x) && (DrawOrder2[c].y==y))
		{
			return;
		}
	}
	DrawOrderLocation dol;
	dol.x=x;
	dol.y=y;
	dol.mx=x*PATCH_SIZE;
	dol.my=y*PATCH_SIZE;
	dol.lod = max(abs(x),abs(y)) -1;
	//	dol.lod = (sqrtf(abs(x*x) + abs(y*y))) +0;
	if (dol.lod <0) dol.lod=0;///3.0f;
	if (dol.lod >4) dol.lod=4;///3.0f;
	DrawOrder2.push_back(dol);
	fprintf(file,"dol %i %i %i %i\n",DrawOrder2.size(),dol.x,dol.y,dol.lod);
}

const void Map::BuildDrawOrder(const int patch_end)
{
	DrawOrder2.clear();
	AddDrawOrder(0, 0);
	const int distance = (patch_end - 1) >> 1;
	for (int d=0; d!=distance; ++d)
	{
		for (int x=0; x!=d; ++x)
		{
			for (int y=0; y!=d; ++y)
			{
				if ((sqrtf((x*x)+(y*y))) > (float)distance)
				{
					continue;
				}
				AddDrawOrder(x, y);
				AddDrawOrder(x, -y);
				AddDrawOrder(-x, y);
				AddDrawOrder(-x, -y);
			}
		}
	}
	DrawOrderCount=DrawOrder2.size();
}
