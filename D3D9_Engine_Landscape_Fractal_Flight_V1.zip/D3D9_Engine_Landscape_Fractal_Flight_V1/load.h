#ifndef LOAD
#define LOAD

#include <stdio.h>
#include <vector>
#include "d3d8_screen.h"
#include "map_size.h"

#define MAX_SIZE 66

typedef struct
{
	int Old;
	int New;
	int Count;
} INDEX;

typedef struct
{
	int X;
	int Y;
	int Point;
} POS;

typedef struct
{
	int X;
	int Y;
} PNT;

typedef struct
{
	int F;
	int S;
	int T;
} TRI;

class Load
{
private:
	TRI Triangle[MAX_SIZE*MAX_SIZE*3];
	const void AddTriangle(const int f, const int s, const int t);
	D3DFORMAT Format;
	const int VertexCountIndex(const std::vector<BYTE> &);
	const std::vector<INDEX> Reindex(const std::vector<BYTE>);
	const std::vector<BYTE> VertexUsedInIndex(const WORD *,const int,const int);
	const std::vector<BYTE> VertexTotalIndex(const std::vector<BYTE> &,const std::vector<BYTE> &);
	const void ReIndexIndex(WORD *,const std::vector<INDEX> &,const int);
public:
	int Points;
	int Triangles;
	const void Setup(const D3DFORMAT);
	~Load();
	const void Model3(const int, const int, const int);
	const void Texture2(const int);
	const void Texture3(const int);
	const void BuildLOD();
	double Texture_Coord[PATCH_POINTS+1];
	IM_VERTEX	Vertex[MAX_VERTICES];
	WORD Index[PATCH_LOD][MAX_VERTICES*3];
	int Vertex_Count[PATCH_LOD];
	int Index_Count[PATCH_LOD];
	std::vector<INDEX> ReIndex;
};

#endif
