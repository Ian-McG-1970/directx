#include <math.h>
#include <stdio.h>
#include "engine.h"
#include "d3d8_screen.h"
#include "di_mouse.h"
#include "portal.h"

extern HWND hwnd;
extern Mouse mouse;
extern Portal portal;
extern Screen screen;

extern FILE *file;

void Engine::Setup()
{
	fprintf(file,"engine setup\n");
	portal.Curr_Sector=0;
	Location = D3DXVECTOR3(35.0f, 35.0f, 35.0f);// (-30.0f, 20.0f, +10.0f) //(-30.0f, 20.0f, -30.0f)
	Direction = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	Speed = 0.0f;
	Frame=0;
}

Engine::~Engine()
{
	fprintf(file,"engine shutdown\n");
}

void Engine::Move(D3DXVECTOR3 &location, const D3DXVECTOR3 *direction, const float speed)
{
	D3DXMATRIX  matTmp;
	D3DXVECTOR3 viewDir(0.0f, 0.0f, 1.0f);
	D3DXVECTOR4 tmp;
	D3DXMatrixRotationYawPitchRoll(&matTmp, direction->y, direction->x, direction->z);      
	D3DXVec3Transform(&tmp, &viewDir, &matTmp);

	D3DXVECTOR3 dir=(D3DXVECTOR3)tmp*speed;
	portal.Move_Sphere_Inside_Sector(location, dir, /*1.5*/0.0f, portal.Curr_Sector); // todo - remove hardcoded sector 0 and fix to move between sectors
}

void Engine::Update()
{
	mouse.Update();
	if (mouse.LB!=0 && mouse.RB!=0)
	{
		PostMessage(hwnd, WM_CLOSE, 0, 0);
		return;
	}
	if (mouse.LB==0 && mouse.RB==0)
	{
		Direction.x -= mouse.Y*0.001f;
		Direction.y += mouse.X*0.001f;
	}
	if (mouse.LB!=0)
	{
		Speed -= mouse.Y*0.001f;
	}
	if (mouse.RB!=0)
	{
		Direction.z -= mouse.X*0.001f;
	}

	screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(BACKGROUND, BACKGROUND, BACKGROUND), 1.0f, 0);
	Move(Location, &Direction, Speed);
	screen.View_Matrix(&Location, &Direction);

	portal.Reset_Frustum(4);


	portal.Draw_Sector(portal.Curr_Sector, portal.Curr_Sector, &Location, &portal.Portal_Frustum[0], 4);

	long o=0;
	for (int y=0; y!=MAX_ACTORS; ++y)
	{
//		const int model=screen.Actor[y].Model;
		if (screen.IsPointInsideFrustum(&screen.Actor[y].Location)==true) // if (screen.IsSphereInsideFrustum(&screen.Actor[y].Location, screen.Model[model].Bounding_Sphere)==true)
		{
//			screen.Draw_Translated_Object(&screen.Actor[y].Location, model); // screen.DrawObject(&screen.Actor_List[y].Location, &screen.Actor_List[y].Direction, model);
			++o;
		}
	}

	sprintf(screen.string, "test %ld %ld %ld %f %f %f\n",++Frame,o,portal.Curr_Sector, Location.x, Location.y, Location.z);
	screen.DrawText(3, 3, D3DXCOLOR(0, 127, 127, 127), &screen.string[0]);

	screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
}
