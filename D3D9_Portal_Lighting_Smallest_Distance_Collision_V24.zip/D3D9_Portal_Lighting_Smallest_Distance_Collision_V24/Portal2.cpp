#include "stdlib.h"
#include "d3d8_screen.h"
#include "portal.h"
#include "engine.h"

extern Screen screen;
extern Engine engine;
extern FILE *file;

void Portal::Setup()
{
	fprintf(file,"portal setup\n");

	Sector[0].Sector_Portal_Count=2; //2 portals
	Sector[0].Sector_Portal_Start_Pos=0; //starting at sector_portal 0

	Sector_Portal[0].Sector_From=0; // from sector0 to sector1
	Sector_Portal[0].Sector_To=1;
	Sector_Portal[0].Portal_Point_Start_Pos=0; //starting at point list 0
	Sector_Portal[0].Portal_Point_Count=4; //4 points

	Portal_Point[0]=D3DXVECTOR3(+00.0,00.0,-40.0);
	Portal_Point[1]=D3DXVECTOR3(+00.0,00.0,-20.0);
	Portal_Point[2]=D3DXVECTOR3(+00.0,50.0,-20.0);
	Portal_Point[3]=D3DXVECTOR3(+00.0,50.0,-40.0);

	Sector_Portal[1].Sector_From=0; // from sector0 to sector2
	Sector_Portal[1].Sector_To=3;
	Sector_Portal[1].Portal_Point_Start_Pos=5; //starting at point list 5
	Sector_Portal[1].Portal_Point_Count=4; //4 points

	Portal_Point[5]=D3DXVECTOR3(-20.0,00.0,+00.0);
	Portal_Point[6]=D3DXVECTOR3(-40.0,00.0,+00.0);
	Portal_Point[7]=D3DXVECTOR3(-40.0,50.0,+00.0);
	Portal_Point[8]=D3DXVECTOR3(-20.0,50.0,+00.0);


	Sector[1].Sector_Portal_Count=2; //2 portals
	Sector[1].Sector_Portal_Start_Pos=2; //starting at sector_portal 2

	Sector_Portal[2].Sector_From=1; // from sector1 to sector0
	Sector_Portal[2].Sector_To=0;
	Sector_Portal[2].Portal_Point_Start_Pos=10; //starting at point list 10
	Sector_Portal[2].Portal_Point_Count=4; //4 points

	Portal_Point[10]=D3DXVECTOR3(+00.0,00.0,-20.0);
	Portal_Point[11]=D3DXVECTOR3(+00.0,00.0,-40.0);
	Portal_Point[12]=D3DXVECTOR3(+00.0,50.0,-40.0);
	Portal_Point[13]=D3DXVECTOR3(+00.0,50.0,-20.0);

	Sector_Portal[3].Sector_From=1; // from sector1 to sector2
	Sector_Portal[3].Sector_To=2;
	Sector_Portal[3].Portal_Point_Start_Pos=15; //starting at point list 15
	Sector_Portal[3].Portal_Point_Count=4; //4 points

	Portal_Point[15]=D3DXVECTOR3(+40.0,00.0,+00.0);
	Portal_Point[16]=D3DXVECTOR3(+20.0,00.0,+00.0);
	Portal_Point[17]=D3DXVECTOR3(+20.0,50.0,+00.0);
	Portal_Point[18]=D3DXVECTOR3(+40.0,50.0,+00.0);


	Sector[2].Sector_Portal_Count=2; //2 portals
	Sector[2].Sector_Portal_Start_Pos=4; //starting at sector_portal 4

	Sector_Portal[4].Sector_From=2; // from sector2 to sector1
	Sector_Portal[4].Sector_To=1;
	Sector_Portal[4].Portal_Point_Start_Pos=20; //starting at point list 20
	Sector_Portal[4].Portal_Point_Count=4; //4 points

	Portal_Point[21]=D3DXVECTOR3(+40.0,00.0,+00.0);
	Portal_Point[22]=D3DXVECTOR3(+20.0,50.0,+00.0);
	Portal_Point[23]=D3DXVECTOR3(+20.0,00.0,+00.0);
	Portal_Point[24]=D3DXVECTOR3(+40.0,50.0,+00.0);

	Sector_Portal[5].Sector_From=2; // from sector1 to sector2
	Sector_Portal[5].Sector_To=3;
	Sector_Portal[5].Portal_Point_Start_Pos=25; //starting at point list 15
	Sector_Portal[5].Portal_Point_Count=4; //4 points

	Portal_Point[25]=D3DXVECTOR3(-00.0,00.0,+40.0);
	Portal_Point[26]=D3DXVECTOR3(-00.0,00.0,+20.0);
	Portal_Point[27]=D3DXVECTOR3(-00.0,50.0,+20.0);
	Portal_Point[28]=D3DXVECTOR3(-00.0,50.0,+40.0);

	Sector[3].Sector_Portal_Count=2; //2 portals
	Sector[3].Sector_Portal_Start_Pos=6; //starting at sector_portal 6

	Sector_Portal[6].Sector_From=3; // from sector3 to sector2
	Sector_Portal[6].Sector_To=2;
	Sector_Portal[6].Portal_Point_Start_Pos=30; //starting at point list 30
	Sector_Portal[6].Portal_Point_Count=4; //4 points

	Portal_Point[30]=D3DXVECTOR3(-00.0,00.0,+40.0);
	Portal_Point[32]=D3DXVECTOR3(-00.0,50.0,+20.0);
	Portal_Point[31]=D3DXVECTOR3(-00.0,00.0,+20.0);
	Portal_Point[33]=D3DXVECTOR3(-00.0,50.0,+40.0);

	Sector_Portal[7].Sector_From=3; // from sector3 to sector0
	Sector_Portal[7].Sector_To=0;
	Sector_Portal[7].Portal_Point_Start_Pos=35; //starting at point list 35
	Sector_Portal[7].Portal_Point_Count=4; //4 points

	Portal_Point[35]=D3DXVECTOR3(-40.0,00.0,+00.0);
	Portal_Point[37]=D3DXVECTOR3(-20.0,00.0,+00.0);
	Portal_Point[36]=D3DXVECTOR3(-20.0,50.0,+00.0);
	Portal_Point[38]=D3DXVECTOR3(-40.0,50.0,+00.0);

return;

	Sector[1].Sector_Portal_Count=0; //1 portal
	Sector[1].Sector_Portal_Start_Pos=1; //starting at sector_portal 1

	Sector[2].Sector_Portal_Count=0; //1 portal
	Sector[2].Sector_Portal_Start_Pos=2; //starting at sector_portal 2

	Sector[3].Sector_Portal_Count=0; //1 portal
	Sector[3].Sector_Portal_Start_Pos=3; //starting at sector_portal 2

	Sector_Portal[2].Sector_From=2; // from sector1 to sector2
	Sector_Portal[2].Sector_To=3;
	Sector_Portal[2].Portal_Point_Start_Pos=10; //starting at point list 4
	Sector_Portal[2].Portal_Point_Count=4; //4 points

	Sector_Portal[3].Sector_From=3; // from sector1 to sector2
	Sector_Portal[3].Sector_To=4;
	Sector_Portal[3].Portal_Point_Start_Pos=15; //starting at point list 4
	Sector_Portal[3].Portal_Point_Count=4; //4 points


	Portal_Point[10]=D3DXVECTOR3(-100,-100,1900);
	Portal_Point[11]=D3DXVECTOR3(-100,+100,1900);
	Portal_Point[12]=D3DXVECTOR3(+100,+100,1900);
	Portal_Point[13]=D3DXVECTOR3(+100,-100,1900);

	Portal_Point[15]=D3DXVECTOR3(   0,-100,2200);
	Portal_Point[18]=D3DXVECTOR3(+100,   0,2200);
	Portal_Point[17]=D3DXVECTOR3(   0,+100,2200);
	Portal_Point[16]=D3DXVECTOR3(-100,   0,2200);
}

Portal::~Portal()
{
	fprintf(file,"portal shutdown\n");
}

D3DXVECTOR3 * Portal::Clip_Portal_To_Frustum_Plane(D3DXVECTOR3 *portal, const D3DXPLANE *frustum, const unsigned long frustum_count, unsigned long &portal_count)
{
	float scale;
	D3DXVECTOR3 diff;
	unsigned long clipped_portal_count=0;
	portal[portal_count]=portal[0];	// copy first to last
	for (unsigned long p=0; p!=portal_count; p++)
	{
		float curr_dot=D3DXPlaneDotCoord(frustum, &portal[p]);
		float next_dot=D3DXPlaneDotCoord(frustum, &portal[p+1]);

		if (curr_dot<0.0f) // if curr point inside
		{
			Portal_Clipped[frustum_count][clipped_portal_count]=portal[p]; // add it to the output list
			clipped_portal_count++;

			if (next_dot>=0.0f) // if the other isnt
			{
				scale=next_dot/(curr_dot-next_dot);
				diff=portal[p+1]-portal[p];
				Portal_Clipped[frustum_count][clipped_portal_count]=portal[p+1] + (diff * scale); // clip the point at the frustum
				clipped_portal_count++;
			}
		}
		else if (next_dot<0.0f) // else if the other is
		{
			scale=curr_dot/(next_dot-curr_dot);
			diff=portal[p]-portal[p+1];
			Portal_Clipped[frustum_count][clipped_portal_count]=portal[p] + (diff * scale); // clip the point at the frustum
			clipped_portal_count++;
		}
	}
	portal_count=clipped_portal_count; // set new portal point count
	return &Portal_Clipped[frustum_count][0]; // return portal clipped against this frustum
}

D3DXVECTOR3 * Portal::Clip_Portal_To_Frustum(D3DXVECTOR3 *portal, const D3DXPLANE *frustum, unsigned long &portal_count, const unsigned long frustum_count, const unsigned long clip_codes)
{
	D3DXVECTOR3 *clipped_portal=portal;
	unsigned long clip_code=1;
	for (unsigned long f=0; f!=frustum_count; f++)
	{
		unsigned long outside_clip_code=clip_codes&clip_code;
		if (outside_clip_code!=0) // if some portal points are outside this frustum
		{
			clipped_portal=Clip_Portal_To_Frustum_Plane(clipped_portal, &frustum[f], f, portal_count); // clip the portal to this frustum, return the list of clipped points and set the new point count
		}
		clip_code+=clip_code;
	}
	return clipped_portal; // return the last clipped portal
}

void Portal::Reset_Frustum(const unsigned long portal_count) // set original frustum from screen portal
{
	for (unsigned long x=0; x!=portal_count; x++)
	{
		Portal_Frustum[x]=screen.Frustum[x];
	}
}

void Portal::Create_Frustum_From_Portal(D3DXVECTOR3* portal, D3DXPLANE* frustum, const unsigned long portal_count)
{
	portal[portal_count]=portal[0]; // copy first portal point to last
	for (unsigned long x=0; x!=portal_count; x++)
	{
		D3DXVECTOR3 v1=portal[x] - engine.Location;
		D3DXVECTOR3 v2=portal[x+1] - engine.Location;
		D3DXVec3Cross(&v2, &v1, &v2);
		D3DXVec3Normalize(&v2, &v2); //????

		frustum[x].a=v2.x;
		frustum[x].b=v2.y;
		frustum[x].c=v2.z;
		frustum[x].d=-D3DXVec3Dot(&engine.Location, &v2);
	}
}

long Portal::Test_Portal_Against_Frustum(const D3DXVECTOR3 *portal, const D3DXPLANE *frustum, const unsigned long portal_count, const unsigned long frustum_count)
{
	unsigned long outside_clip_code=0, clip_code=1;
	for (unsigned long f=0; f!=frustum_count; f++)
	{
		unsigned long outside_count=0;
		for (unsigned long p=0; p!=portal_count; p++)
		{
			if (D3DXPlaneDotCoord(&frustum[f], &portal[p]) >=0.0f) // if point is outside frustum
			{
				outside_count++; // 
			}
		}
		if (outside_count==portal_count) // if all points are outside of this frustum
		{
			return -1; // return outside
		}
		if (outside_count!=0) // if some points are outside of this frustum
		{
			outside_clip_code+=clip_code; // mark frustum to be clipped against
		}
		clip_code+=clip_code;
	}
	return outside_clip_code; // return frustums to be clipped against
}

void Portal::Draw_Sector(const unsigned long to_sector, const unsigned long from_sector, const D3DXVECTOR3 *location, D3DXPLANE *frustum, const unsigned long frustum_count)
{

//	screen.DrawStaticObject(location, Sector[to_sector].Model);
//	for all objects in sector; if object in frustum; draw object
	{
		for (unsigned long p=0, sp=Sector[to_sector].Sector_Portal_Start_Pos; p!=Sector[to_sector].Sector_Portal_Count; p++, sp++)
		{
			if (Sector_Portal[sp].Sector_To!=from_sector)
			{
				unsigned long portal_start=Sector_Portal[sp].Portal_Point_Start_Pos;
				unsigned long portal_count=Sector_Portal[sp].Portal_Point_Count;

				D3DXVECTOR3 *portal=&Portal_Point[portal_start];
				long portal_clip_code=Test_Portal_Against_Frustum(portal, frustum, portal_count, frustum_count); // test each portal point against each frustum
				if (portal_clip_code!=-1) // not all are outside
				{
					if (portal_clip_code!=0) // some are outside
					{
						portal=Clip_Portal_To_Frustum(portal, frustum, portal_count, frustum_count, portal_clip_code); // clip all portals to frustums based on clip codes
					}
					screen.Draw_Portal(portal, portal_count);
					Create_Frustum_From_Portal(portal, &frustum[frustum_count], portal_count); // create a unique frustum and return it and the frustum count
					Draw_Sector(Sector_Portal[sp].Sector_To, to_sector, location, &frustum[frustum_count], portal_count); // draw sector through portal
				}
			}
		}
	}
}
