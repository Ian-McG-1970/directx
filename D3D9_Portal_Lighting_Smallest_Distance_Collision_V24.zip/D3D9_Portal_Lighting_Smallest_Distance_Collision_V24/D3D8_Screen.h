#include <d3d9.h>
#include <d3dx9.h>
//#include <d3dfont.h>

#ifndef D3D_SCREEN
#define D3D_SCREEN

#define MAX_MODELS 256
#define MAX_ACTORS 64
#define MAX_PLANES 6
#define MAX_BOUNDING_BOX 8
#define MAX_VERTICES 65535
#define MAX_MATERIALS 64

#define BACKGROUND 0

typedef struct
{
	D3DXVECTOR3 Location;
	D3DXVECTOR3 Normal;
} IM_VERTEX;
#define D3DFVF_IM_VERTEX (D3DFVF_XYZ | D3DFVF_NORMAL)

typedef struct
{
	D3DXVECTOR3											Bounding_Sphere_Centre;
	float																			Bounding_Sphere_Radius;
	D3DXVECTOR3											Bounding_Box[MAX_BOUNDING_BOX];
	LPDIRECT3DVERTEXBUFFER9	Vertex_Buffer;
	IDirect3DIndexBuffer9*					Index_Buffer;
	int													Vertices;
	int													Triangles;
	int													Material;
} MODEL;

typedef struct
{
	int Model;
	D3DXVECTOR3		Location;
	D3DXVECTOR3		Direction;
} ACTOR;
                  
class Screen
{
private:
	void ExtractFrustumPlanes(void);

	LPDIRECT3D9	g_pD3D;
	LPD3DXFONT Font;

	D3DXMATRIX Matrix_Projection;
	D3DXMATRIX Matrix_View;
	D3DXMATRIX Matrix_World;
	D3DXMATRIX Matrix_Translation;
	D3DXMATRIX Matrix_Rotation;

	int Current_Model;

public:
	D3DXPLANE Frustum[MAX_PLANES];
	char string[255];

	bool Setup(const int, const int, const D3DFORMAT, const float, const float, const D3DFORMAT, const int, const HWND);
	~Screen();
	void View_Matrix(const D3DXVECTOR3 *, const D3DXVECTOR3 *);
	bool IsPointInsideFrustum(const D3DXVECTOR3 *);
	bool IsSphereInsideFrustum(const D3DXVECTOR3 *, const float);
	void Draw_Translated_Rotated_Object(const D3DXVECTOR3 *, const D3DXVECTOR3 *, const int);
	void Draw_Translated_Object(const D3DXVECTOR3 *, const int);
	void Draw_Object(const int);
	void DrawText(int, int, D3DCOLOR, char *);
	void Draw_Portal(const D3DXVECTOR3 *, const int);
	const void CreateObject(const int, const int, const int, const int);

	LPDIRECT3DDEVICE9	g_pd3dDevice;
//	D3DFORMAT					Format;

	IM_VERTEX					Vertex[MAX_VERTICES];
	WORD									Index[MAX_VERTICES];
	MODEL								Model[MAX_MODELS]; // list of models loaded in
	ACTOR								Actor[MAX_ACTORS]; // list of models in world
	D3DMATERIAL9		Material[MAX_MATERIALS];
	int Max_Material;
};

#endif