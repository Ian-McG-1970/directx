#ifndef ENGINE
#define ENGINE

#include "d3d8_screen.h"

class Engine
{
private:
	float	Speed;
	int Frame;

	D3DXVECTOR3 Direction;
	D3DXVECTOR3 SkyDome_Direction;

	void Move(D3DXVECTOR3 &, const D3DXVECTOR3 *, const float);
public:
	D3DXVECTOR3 Location;
	void Setup();
	~Engine();
	void Update();
};

#endif
