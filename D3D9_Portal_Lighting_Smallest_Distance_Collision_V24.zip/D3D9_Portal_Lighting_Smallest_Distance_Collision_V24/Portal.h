#ifndef PORTAL
#define PORTAL

#include <stdio.h>
#include "d3d8_screen.h"

#define MAX_SECTORS 256
#define MAX_SECTOR_PORTALS 256
#define MAX_PORTAL_POINTS 65535

typedef struct
{
	int Model; // object to be drawn
	int Sector_Portal_Count; // number of portals in sector
	int Sector_Portal_Start_Pos; // pointer to first portal in sector
} SECTOR;

typedef struct
{
	int Sector_From; // sector number of where portal is looking from
	int Sector_To; // sector number of where portal is looking into
	int Portal_Point_Start_Pos; // pointer to first portal point
	int Portal_Point_Count; // number of points in this portal
} SECTOR_PORTAL;

typedef struct
{
	int Sector_Collision_Count; // number of planes in sector
	int Sector_Collision_Start_Pos; // pointer to first plane in sector
} SECTOR_COLLISION;

typedef struct
{
	D3DXPLANE Plane; // the plane
	long To_Sector; // sector through this plane (-1 = solid wall, else sector number to go through)
} SECTOR_COLLISION_PLANE;

#define SECTOR_WALL -1
#define PORTAL_POINTS_OUTSIDE_FRUSTUM -1
#define PORTAL_POINTS_INSIDE_FRUSTUM 0

class Portal
{
private:
//	SECTOR_PORTAL Sector_Portal[MAX_SECTOR_PORTALS];
	D3DXVECTOR3 Portal_Clipped[MAX_SECTOR_PORTALS][MAX_SECTOR_PORTALS]; //portal to be drawn

	const void Create_Frustum_From_Portal(D3DXVECTOR3*, D3DXPLANE*, const int);
	const long Test_Portal_Against_Frustum(const D3DXVECTOR3 *, const D3DXPLANE *, const int, const int);
	D3DXVECTOR3 * Clip_Portal_To_Frustum(D3DXVECTOR3 *, const D3DXPLANE *, int &, const int, const int);
	D3DXVECTOR3 * Clip_Portal_To_Frustum_Plane(D3DXVECTOR3 *, const D3DXPLANE *, const int, int &);
	const void Set_Clip_Planes(const D3DXPLANE*, const int);

public:
	SECTOR Sector[MAX_SECTORS];
	D3DXVECTOR3 Portal_Point[MAX_PORTAL_POINTS];
	SECTOR_PORTAL Sector_Portal[MAX_SECTOR_PORTALS];

	const void Reset_Frustum(const int);
	const void Draw_Sector(const int, const int, const D3DXVECTOR3 *, D3DXPLANE *, int);
	const long Point_Inside_Sector(const D3DXVECTOR3 *, const int);
	const void Move_Sphere_Inside_Sector(D3DXVECTOR3 &, const D3DXVECTOR3 &, const float, int &);

	D3DXPLANE Portal_Frustum[MAX_SECTOR_PORTALS];

	SECTOR_COLLISION Sector_Collision[MAX_SECTORS];
	SECTOR_COLLISION_PLANE Sector_Collision_Planes[MAX_PORTAL_POINTS];
	int Collision_Plane_Count;
	int Curr_Sector;

	const void Setup();
	~Portal();
};

#endif


