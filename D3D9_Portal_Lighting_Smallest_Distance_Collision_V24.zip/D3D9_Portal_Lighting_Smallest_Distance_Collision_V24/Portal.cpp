#include "stdlib.h"
#include "d3d8_screen.h"
#include "portal.h"
#include "engine.h"

extern Screen screen;
extern Engine engine;
extern FILE *file;

const void Portal::Setup()
{
	fprintf(file,"portal setup\n");
}

Portal::~Portal()
{
	fprintf(file,"portal shutdown\n");
}

D3DXVECTOR3 * Portal::Clip_Portal_To_Frustum_Plane(D3DXVECTOR3 *portal, const D3DXPLANE *frustum, const int frustum_count, int &portal_count)
{
	int clipped_portal_count=0;
	portal[portal_count]=portal[0];	// copy first to last
	for (int p=0; p!=portal_count; ++p)
	{
		const float curr_dot=D3DXPlaneDotCoord(frustum, &portal[p]);
		const float next_dot=D3DXPlaneDotCoord(frustum, &portal[p+1]);

		if (curr_dot<0.0f) // if curr point inside
		{
			Portal_Clipped[frustum_count][clipped_portal_count]=portal[p]; // add it to the output list
			++clipped_portal_count;

			if (next_dot>=0.0f) // if the other isnt
			{
				const float scale=next_dot/(curr_dot-next_dot);
				const D3DXVECTOR3 diff=portal[p+1]-portal[p];
				Portal_Clipped[frustum_count][clipped_portal_count]=portal[p+1] + (diff * scale); // clip the point at the frustum
				++clipped_portal_count;
			}
		}
		else if (next_dot<0.0f) // else if the other is
		{
			const float scale=curr_dot/(next_dot-curr_dot);
			const D3DXVECTOR3 diff=portal[p]-portal[p+1];
			Portal_Clipped[frustum_count][clipped_portal_count]=portal[p] + (diff * scale); // clip the point at the frustum
			++clipped_portal_count;
		}
	}
	portal_count=clipped_portal_count; // set new portal point count
	return &Portal_Clipped[frustum_count][0]; // return portal clipped against this frustum
}

D3DXVECTOR3 * Portal::Clip_Portal_To_Frustum(D3DXVECTOR3 *portal, const D3DXPLANE *frustum, int &portal_count, const int frustum_count, const int clip_codes)
{
	D3DXVECTOR3 *clipped_portal=portal;
	int clip_code=1;
	for (int f=0; f!=frustum_count; ++f)
	{
		const int outside_clip_code=clip_codes&clip_code;
		if (outside_clip_code!=0) // if some portal points are outside this frustum
		{
			clipped_portal=Clip_Portal_To_Frustum_Plane(clipped_portal, &frustum[f], f, portal_count); // clip the portal to this frustum, return the list of clipped points and set the new point count
		}
		clip_code+=clip_code;
	}
	return clipped_portal; // return the last clipped portal
}

const void Portal::Set_Clip_Planes(const D3DXPLANE* frustum, const int portal_count)
{
	DWORD clipplanes=0;
	for (int x=0; x!=portal_count; ++x)
	{
		const D3DXPLANE clipplane=-frustum[x];
		screen.g_pd3dDevice->SetClipPlane(x, (float *) &clipplane);
		clipplanes=(clipplanes<<1)+1;
	}
	screen.g_pd3dDevice->SetRenderState(D3DRS_CLIPPLANEENABLE, clipplanes);
}

const void Portal::Reset_Frustum(const int portal_count) // set original frustum from screen portal
{
	memcpy(&Portal_Frustum[0], &screen.Frustum[0], sizeof(Portal_Frustum[0])*portal_count);
	Set_Clip_Planes(&Portal_Frustum[0], portal_count);
}

const void Portal::Create_Frustum_From_Portal(D3DXVECTOR3* portal, D3DXPLANE* frustum, const int portal_count)
{
	portal[portal_count]=portal[0]; // copy first portal point to last

	for (int x=0; x!=portal_count; ++x)
	{
		D3DXPlaneFromPoints(&frustum[x], &engine.Location, &portal[x], &portal[x+1]);
	}
	Set_Clip_Planes(frustum, portal_count);
}

const long Portal::Test_Portal_Against_Frustum(const D3DXVECTOR3 *portal, const D3DXPLANE *frustum, const int portal_count, const int frustum_count)
{
	int outside_clip_code=PORTAL_POINTS_INSIDE_FRUSTUM, clip_code=1;
	for (int f=0; f!=frustum_count; ++f)
	{
		int outside_count=0;
		for (int p=0; p!=portal_count; ++p)
		{
			if (D3DXPlaneDotCoord(&frustum[f], &portal[p]) >=0.0f) // if point is outside frustum
			{
				++outside_count; // 
			}
		}
		if (outside_count==portal_count) // if all points are outside of this frustum
		{
			return PORTAL_POINTS_OUTSIDE_FRUSTUM; // return outside
		}
		if (outside_count!=0) // if some points are outside of this frustum
		{
			outside_clip_code+=clip_code; // mark frustum to be clipped against
		}
		clip_code+=clip_code;
	}
	return outside_clip_code; // return frustums to be clipped against
}

const void Portal::Draw_Sector(const int to_sector, const int from_sector, const D3DXVECTOR3 *location, D3DXPLANE *frustum, const int frustum_count)
{
//	fprintf(file,"draw sector %ld\n", to_sector);
	screen.Draw_Object(Sector[to_sector].Model);
//	screen.DrawStaticObject(location, Sector[to_sector].Model);
//	for all objects in sector; if object in frustum; draw object
	{
		for (int p=0, sp=Sector[to_sector].Sector_Portal_Start_Pos; p!=Sector[to_sector].Sector_Portal_Count; ++p, ++sp)
		{
			if (Sector_Portal[sp].Sector_To!=from_sector)
			{
				const int portal_start=Sector_Portal[sp].Portal_Point_Start_Pos;
				int portal_count=Sector_Portal[sp].Portal_Point_Count;

				D3DXVECTOR3 *portal=&Portal_Point[portal_start];
				long portal_clip_code=Test_Portal_Against_Frustum(portal, frustum, portal_count, frustum_count); // test each portal point against each frustum
				if (portal_clip_code!=PORTAL_POINTS_OUTSIDE_FRUSTUM) // not all are outside
				{
					if (portal_clip_code!=PORTAL_POINTS_INSIDE_FRUSTUM) // some are outside
					{
						portal=Clip_Portal_To_Frustum(portal, frustum, portal_count, frustum_count, portal_clip_code); // clip all portals to frustums based on clip codes
					}
					if (portal_count>=3)
					{
//						screen.Draw_Portal(portal, portal_count);
						Create_Frustum_From_Portal(portal, &frustum[frustum_count], portal_count); // create a unique frustum and return it and the frustum count
						Draw_Sector(Sector_Portal[sp].Sector_To, to_sector, location, &frustum[frustum_count], portal_count); // draw sector through portal
					}
				}
			}
		}
	}
}

const long Portal::Point_Inside_Sector(const D3DXVECTOR3 *location, const int number)
{
	int plane_pos=Sector_Collision[number].Sector_Collision_Start_Pos;
	const int plane_count=Sector_Collision[number].Sector_Collision_Count;

	for (int x=0; x!=plane_count; ++x, ++plane_pos)
	{
		if (D3DXPlaneDotCoord(&Sector_Collision_Planes[plane_pos].Plane, location) <0.0f) // point is outside sector
		{
			return Sector_Collision_Planes[plane_pos].To_Sector;
		}
	}
	return true;
}

const void Portal::Move_Sphere_Inside_Sector(D3DXVECTOR3 &location, const D3DXVECTOR3 &direction, const float bounding_sphere, int &sector)
{
	int plane_pos=Sector_Collision[sector].Sector_Collision_Start_Pos;
	const int plane_count=Sector_Collision[sector].Sector_Collision_Count;
	const D3DXVECTOR3 to_location=location+direction;

	float smallest_dest_to_plane=bounding_sphere; // the smallest distance to the plane
	int smallest_dest_to_plane_pos;

	for (int x=0; x!=plane_count; ++x, ++plane_pos)
	{	
		const float dest_to_plane=D3DXPlaneDotCoord(&Sector_Collision_Planes[plane_pos].Plane, &to_location);
		if (Sector_Collision_Planes[plane_pos].To_Sector==SECTOR_WALL)
		{
			if (dest_to_plane<bounding_sphere) // sphere is outside sector - (to_dist lt bounding_sphere)
			{
				if (dest_to_plane<smallest_dest_to_plane) //if this point is nearer than the last nearest
				{
					smallest_dest_to_plane=dest_to_plane; // make this point the nearest 
					smallest_dest_to_plane_pos=plane_pos;
				}
			}
		}
		else // this is a portal
		{
			if (dest_to_plane<0.0f) // point is outside sector
			{
				sector=Sector_Collision_Planes[plane_pos].To_Sector; //				sector=Point_Inside_Sector(&location, Sector_Collision_Planes[plane_pos].To_Sector);
				location=to_location;
				return;
			}
		}
	}
	if (smallest_dest_to_plane!=bounding_sphere)
	{
		const float source_to_plane=D3DXPlaneDotCoord(&Sector_Collision_Planes[smallest_dest_to_plane_pos].Plane, &location) -D3DX_16F_EPSILON; // distance to wall
		const float scale=( (smallest_dest_to_plane-bounding_sphere) / (source_to_plane-smallest_dest_to_plane) ) ;
		const D3DXVECTOR3	diff=to_location-location;
		location=to_location + (diff * scale); // clip the point at the collision point
//				const D3DXVECTOR3 vn = D3DXVec3Dot(&direction, (D3DXVECTOR3 *)&Sector_Collision_Planes[plane_pos].Plane) * (D3DXVECTOR3)Sector_Collision_Planes[plane_pos].Plane;
//				const D3DXVECTOR3 v2 = direction - vn;
//				Move_Sphere_Inside_Sector(location, v2, bounding_sphere, sector); // more sphere to that position
		return;
	}
	location=to_location;
}
 