#ifndef LOGFILE
#define LOGFILE

#include <stdio.h>
#include <string.h>

class LogFile
{
private:
	char file_name[256];
public:
	char file_output[256];
	const void Open(const char *);
	const void Write();
};

#endif
