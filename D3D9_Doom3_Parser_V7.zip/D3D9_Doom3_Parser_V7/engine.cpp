#include "engine.h"
#include "d3d8_screen.h"
#include "di_mouse.h"
#include "map.h"
#include "parser.h"
#include "portal.h"

extern HWND hwnd;
extern Mouse mouse;
extern Map map;
extern Screen screen;
extern Parser parser;
extern Portal portal;

extern FILE *file;

const void Engine::Setup()
{
	fprintf(file,"engine setup\n");

	Location=(parser.portals[0].point[0]+parser.portals[0].point[2])*0.5f;
	Direction=D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	Speed=0.0f;
}

Engine::~Engine()
{
	fprintf(file,"engine shutdown\n");
}

const D3DXVECTOR3 Engine::Move(const D3DXVECTOR3 &location, const D3DXVECTOR3 &direction, const float speed)
{
	D3DXMATRIX  matTmp;
	D3DXMatrixRotationYawPitchRoll(&matTmp, direction.y, direction.x, direction.z);
	D3DXVECTOR4 tmp;
	D3DXVec3Transform(&tmp, &D3DXVECTOR3(0.0f, 0.0f, 1.0f), &matTmp);
	return D3DXVECTOR3(tmp)*speed;
}

const void Engine::Input(D3DXVECTOR3 &direction, float &speed, const float dampen)
{
	mouse.Update();
	if (mouse.LB!=0 && mouse.RB!=0)
	{
		PostMessage(hwnd, WM_CLOSE, 0, 0);
		return;
	}
	if (mouse.LB==0 && mouse.RB==0)
	{
		direction.x -= mouse.Y*dampen;
		direction.y += mouse.X*dampen;
	}
	if (mouse.RB!=0)
	{
		direction.z -= mouse.X*dampen;
	}
	if (mouse.LB!=0)
	{
		speed -= mouse.Y*dampen;
	}
	speed*=0.9999f;
}

const void Engine::DrawTrack()
{
	for (int ts=0; ts!=map.TrackSections; ++ts)
	{
		const int model=map.Track[ts].Model;
		const D3DXVECTOR3 location=map.Track[ts].Location;

		if ((screen.IsSphereInsideFrustum(location, screen.Model[model].Bounding_Sphere_Centre, screen.Model[model].Bounding_Sphere_Radius) == true)
			&& (screen.BoundingBoxInFrustum(&screen.Model[model].Bounding_Box[0],location) == true))
		{
			screen.DrawObject(&location,&map.Track[ts].Direction,model,map.Track[ts].Material);
			++count;
		}


	}
}

const void Engine::DrawPortals()
{
	for (int p=0; p!=parser.portals.size(); ++p)
	{
		for(int pp=0; pp!=parser.portals[p].point.size(); ++pp)
		{
			screen.DrawPortal(&parser.portals[p].point[0], parser.portals[p].point.size());
		}
	}
}

const void Engine::Update()
{
	count=portals=clipped=inside=drawn=test=front=0;

	screen.g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, BACKGROUND, 1.0f, 0);

	Input(Direction, Speed, 0.0003f);
	const D3DXVECTOR3 location=Location;
	const D3DXVECTOR3 movement=Move(Location, Direction, Speed);
	if (map.FindArea(Location+movement)!=-1)
	{
		Location+=movement;
	}
	screen.View_Matrix(Location, &Direction);


	screen.g_pd3dDevice->BeginScene();

	portal.Reset_Frustum(4);
	portal.Curr_Sector=map.FindArea(Location);
	portal.Draw_Sector(portal.Curr_Sector,portal.Curr_Sector,&Location,&portal.Portal_Frustum[0], 4);

//	DrawTrack();
//	DrawPortals();

	sprintf(screen.string, "px %5f py %5f pz %5f cn %i ar %i pt %i cl %i in %i dr %i t %i fr %i\n", Location.x, Location.y, Location.z, count, map.FindArea(Location),portals,clipped,inside,drawn,test,front);
	screen.DrawText(5, 5, D3DCOLOR_XRGB(160, 160, 160));

	screen.g_pd3dDevice->EndScene();
	screen.g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
}
