#include "d3d8_screen.h"
#include "load.h"
#include "map.h"
#include "parser.h"
#include "portal.h"
#include "log.h"
#include <algorithm>

extern Screen screen;
extern FILE *file;
extern Parser parser;
extern Portal portal;
extern LogFile logfile;

void Map::Setup()
{
	fprintf(file,"map setup\n");
	BuildTrack();
	BuildPortals();
}

Map::~Map()
{
	fprintf(file,"map shutdown\n");
}

void Map::BuildTrack()
{
	fprintf(file,"build track models %i\n",parser.models.size());
//	sprintf(logfile.file_output,"buildtrack models start %i\n",parser.models.size()); logfile.Write();

	TrackSections=parser.models.size();
	for (int x=0; x!=TrackSections; ++x)
	{
		Track[x].Model=parser.models[x].area;//+(rand()&3);
		Track[x].Material=rand()&3;
		Track[x].Location=D3DXVECTOR3(0,0,0);// D3DXVECTOR3((((int)rand()&4095)/*+32767*/),(((int)rand()&4095)/*+32767*/),(((int)rand()&4095)/*+32767*/));
		Track[x].Direction=D3DXVECTOR3(0,0,0);//rand(),rand(),rand());
	}
//	sprintf(logfile.file_output,"buildtrack models end %i\n",parser.models.size()); logfile.Write();

}

const void Map::BuildObjects()
{
//	sprintf(logfile.file_output,"buildobjects start %i\n",parser.models.size()); logfile.Write();

	for (int o=0; o!=parser.models.size(); ++o)
	{
		BuildObject(parser.models[o].vertex, parser.models[o].index,parser.models[o].area);
	}
//	sprintf(logfile.file_output,"buildobjects end %i\n",parser.models.size()); logfile.Write();
}

const void Map::BuildObject(const std::vector<D3DXVECTOR3> &Point,const std::vector<WORD> &Triangle,const int object)
{
	const D3DCOLOR colour_areas[8]={0x0000000, 0x00000ff, 0x000ff00, 0x000ffff, 0x0ff0000, 0x0ff00ff, 0x0ffff00, 0x0777777};
	D3DCOLOR color_area=colour_areas[object &7];

	for (int p=0; p!=Point.size(); ++p)
	{
		screen.Vertex[p].Location=Point[p];
		screen.Vertex[p].Colour=(D3DCOLOR_XRGB(rand(),rand(),rand())) | color_area;

	}
	memcpy(&screen.Index[0], &Triangle[0], sizeof(screen.Index[0])*Triangle.size());

	screen.CreateObject(Point.size(),Triangle.size()/3,object);
}

const int Map::FindArea(const D3DXVECTOR3 &pos) // This returns the leaf our camera is in
{
	int i=0;
	do
	{
		const float distance = D3DXPlaneDotCoord(&parser.nodes[i].plane, &pos); // Get the current node, then find the slitter plane from that node's plane index.
		if (distance>=0) // If the camera is in front of the plane
		{
			i = parser.nodes[i].children[0]; // Assign the current node to the node in front of itself
		}
		else // Else if the camera is behind the plane
		{
			i = parser.nodes[i].children[1]; // Assign the current node to the node behind itself
		}
	} 
	while (i>0); // Continue looping until we find a negative index or 0 (solid)

	if (i==0) return -1; // 0 index is solid
	return ~i; // Return the leaf index - return -(i + 1).
}

const void Map::BuildPortals()
{
//	sprintf(logfile.file_output,"buildtrack portals start %i\n",parser.portals.size()); logfile.Write();

	const int portals=parser.portals.size();
	for (int p=0; p!=portals; ++p)
	{
		PORTAL ptal;
		ptal.from_area=parser.portals[p].to_area;
		ptal.to_area=parser.portals[p].from_area;
		for (int pp=parser.portals[p].point.size()-1; pp!=-1; --pp)
		{
			ptal.point.push_back(parser.portals[p].point[pp]);
		}
		parser.portals.push_back(ptal);
	}

//	sprintf(logfile.file_output,"buildtrack portals t1\n"); logfile.Write();

	Portals.resize(parser.portals.size()); // last change
	sprintf(logfile.file_output,"buildtrack portals t20 %i\n",Portals.size()); logfile.Write();
	for (int p=0; p!=parser.portals.size(); ++p)
	{
//		sprintf(logfile.file_output,"buildtrack portals t21 %i %i %i %i\n",p,parser.portals.size(),parser.portals[p].from_area,parser.portals[p].to_area); logfile.Write();

		MAP_PORTAL map_portal;
		map_portal.to_area=parser.portals[p].to_area;
		map_portal.point=parser.portals[p].point;
		Portals[parser.portals[p].from_area].Portal.push_back(map_portal);
	}

//	sprintf(logfile.file_output,"buildtrack portals t5\n"); logfile.Write();

	fprintf(file,"pps %i %i\n",Portals.size(),parser.portals.size());

	int portal_point_pos=0;
	int sector_portal_start_pos=0;
	int sector_portal_pos=0;

	const int sectors=parser.portals.size();

	for(int p=0; p!=Portals.size(); ++p)
	{
		int sector_portal_count=0;
		const int sector_number=p; // room number

		portal.Sector[sector_number].Model=sector_number;
		portal.Sector[sector_number].Sector_Portal_Start_Pos=sector_portal_start_pos; //starting at sector_portal

		for (int pp=0; pp!=Portals[p].Portal.size(); ++pp)
		{
			portal.Sector_Portal[sector_portal_pos].Sector_From=Portals[p].Portal[pp].from_area; // from sector
			portal.Sector_Portal[sector_portal_pos].Sector_To=Portals[p].Portal[pp].to_area; // to sector

//			sprintf(logfile.file_output,"buildportals %i %i %i\n",sector_portal_pos,p, Portals[p].Portal[pp].to_area); logfile.Write();

			portal.Sector_Portal[sector_portal_pos].Portal_Point_Start_Pos=portal_point_pos; //starting at point list 0 ??
			portal.Sector_Portal[sector_portal_pos].Portal_Point_Count=Portals[p].Portal[pp].point.size(); //4 points
			++sector_portal_pos;
			++sector_portal_count;

			for(int ppp=0; ppp!=Portals[p].Portal[pp].point.size(); ++ppp)
			{
				portal.Portal_Point[portal_point_pos]=Portals[p].Portal[pp].point[ppp];
//				sprintf(logfile.file_output,"buildportals %f %f %f\n",portal.Portal_Point[portal_point_pos].x, portal.Portal_Point[portal_point_pos].y, portal.Portal_Point[portal_point_pos].z); logfile.Write();
				++portal_point_pos;
			}
			++portal_point_pos; // create a gap at the end of each portal list
		}
		portal.Sector[sector_number].Sector_Portal_Count=sector_portal_count;
		portal.Sector[sector_number].Sector_Portal_Start_Pos=sector_portal_start_pos; //starting at sector_portal
		sector_portal_start_pos+=sector_portal_count;
	}
	sprintf(logfile.file_output,"buildtrack portals end %i\n",parser.portals.size()); logfile.Write();
}
