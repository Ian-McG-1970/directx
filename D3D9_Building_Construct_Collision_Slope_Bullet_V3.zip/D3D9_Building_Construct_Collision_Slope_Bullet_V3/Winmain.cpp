#define NAME "PORTAL"
#define TITLE "PORTAL"

#define WIN32_LEAN_AND_MEAN
#define WIN32_EXTRA_LEAN

#define D3D_OVERLOADS
#define STRICT

//#define BT_USE_DOUBLE_PRECISION

// todo - use inside / outside - to build list of multiple bounding boxes which make up shape?
// todo - create multiple objects - one object for inside and one object for outside?
// todo - add a hole in the top and the bottom and the left and the right and the back

#include <windows.h>

#include "d3d8_screen.h"
#include "di_mouse.h"
#include "load.h"
#include "engine.h"
#include "map.h"

/*
btVector3 vertex1, vertex2, vertex3, vertex4;
btTriangleMesh* triangleMeshTerrain = new btTriangleMesh();

for (int i = -250; i < 250; i = i + 10) {
for (int j = -250; j < 250; j = j + 10) {

vertex1 = btVector3(i, 0.0f, j);
vertex2 = btVector3(i + 10.0f, 0.0f, j);
vertex3 = btVector3(i + 10.0f, 0.0f, j + 10.0f);
vertex4 = btVector3(i, 0.0f, j + 10.0f);

triangleMeshTerrain->addTriangle(vertex1, vertex2, vertex3);
triangleMeshTerrain->addTriangle(vertex1, vertex3, vertex4);
}
}

btCollisionShape* collisionShapeTerrain = new btBvhTriangleMeshShape(triangleMeshTerrain, true);

btDefaultMotionState* motionState = new btDefaultMotionState(btTransform(btQuaternion(0, 0, 0, 1), btVector3(0, -15, 0)));

btRigidBody::btRigidBodyConstructionInfo rigidBodyConstructionInfo(0.0f, motionState, collisionShapeTerrain, btVector3(0, 0, 0));
btRigidBody* rigidBodyTerrain = new btRigidBody(rigidBodyConstructionInfo);
rigidBodyTerrain->setFriction(btScalar(0.9));

m_dynamicsWorld->addRigidBody(rigidBodyTerrain);
*/

Mouse		mouse;
Screen	screen;
Load		load;
Engine	engine;
Map map;

HWND	hwnd;
FILE	*file;

void ReleaseObjects()
{
	fprintf(file, "windows shutdown\n");
}

long FAR PASCAL WindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
    case	WM_DESTROY:
			ReleaseObjects();
			PostQuitMessage(0);
			break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
  WNDCLASS wc;
  wc.style = CS_HREDRAW | CS_VREDRAW;
  wc.lpfnWndProc = WindowProc;
  wc.cbClsExtra = 0;
  wc.cbWndExtra = 0;
  wc.hInstance = hInstance;
  wc.hIcon = LoadIcon(hInstance, IDI_APPLICATION);
  wc.hCursor = LoadCursor(NULL, IDC_ARROW);
  wc.hbrBackground = NULL;
  wc.lpszMenuName = NAME;
  wc.lpszClassName = NAME;
  RegisterClass(&wc);
    
  if (!(hwnd = CreateWindowEx(WS_EX_TOPMOST, NAME, TITLE, WS_POPUP, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), NULL, NULL, hInstance, NULL))) return false;

  ShowWindow(hwnd, nCmdShow);
	UpdateWindow(hwnd);

	if ((file=fopen("log.txt","w"))==NULL) return false;
	fprintf(file, "windows startup\n");

	if (!mouse.Setup(hInstance, hwnd)) return false;

	if (!screen.Setup(GetSystemMetrics(SM_CXSCREEN),GetSystemMetrics(SM_CYSCREEN), D3DFMT_X8R8G8B8, 1.0f, 32767.0f, D3DFMT_D24X8, 2, hwnd)) return false;

	engine.Setup();

	load.Setup();

	map.BuildObject(room0000, 99);
	map.BuildObject(room0001, 100);
	map.BuildObject(room0002, 101);
	map.BuildObject(room0003, 102);
	map.Setup();

	MSG msg;
	while (msg.message!=WM_QUIT)
	{
		if (PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
		{
			if (!GetMessage(&msg, NULL, 0, 0))
			{
				return msg.wParam;
			}
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
		{
			engine.Update();
		}
	}
}
