#ifndef MAP
#define MAP

#include <vector>

#define TRACK_PATCH_COUNT 32

#define TFL 0
#define TFR 1
#define TBL 2
#define TBR 3
#define BFL 4
#define BFR 5
#define BBL 6
#define BBR 7

#define TOP 1
#define BOTTOM 2
#define LEFT 4
#define RIGHT 8
#define FRONT 16
#define BACK 32
#define OUTSIDE_INSIDE 64 // draw either inside or outside sides

#define COLLIDE_TOP 0
#define COLLIDE_BOTTOM 1
#define COLLIDE_LEFT 2
#define COLLIDE_RIGHT 3
#define COLLIDE_FRONT 4
#define COLLIDE_BACK 5
#define COLLIDE_SIDES 6

typedef struct
{
	int Model;
	D3DXVECTOR3 Location;
	D3DXVECTOR3 Direction;
} TRACK_PATCH;

typedef struct
{
	bool top;
	bool bottom;
	bool left;
	bool right;
	bool front;
	bool back;
} SIDES;

typedef struct
{
	D3DXVECTOR3 start;
	D3DXVECTOR3 end;
	SIDES wall;
	bool gap;
	unsigned char slope;
	bool inside;
	bool outside; //todo use 
	bool extrude; //todo use
	bool first_slope; //todo use
	bool second_slope; //todo use
} BLOCK;

typedef struct
{
	unsigned char gaps;
	unsigned char side[9];
	D3DXVECTOR2 start[9];
	D3DXVECTOR2 end[9];
} GAP_HDR;

typedef struct
{
	unsigned char side;
	D3DXVECTOR2 start;
	D3DXVECTOR2 end;
} GAP_TYPE;

typedef struct
{
	D3DXVECTOR2 start;
	D3DXVECTOR2 end;
} GAP;

typedef struct
{
	int first;
	int second;
	int third;
	int fourth;
} PI;

typedef struct
{
	int start_index;
	int end_index;
	int side;
} COLLIDER;

typedef struct
{
	D3DXVECTOR2 max;
	D3DXVECTOR2 min;
	float pos;
} COLLISION;

typedef struct
{
	std::vector<COLLISION> Collision;
} COLLISION_LIST;

typedef struct
{
	std::vector<D3DXVECTOR3> Point;
	std::vector<WORD> Triangle;
} MESH;

/*
9 st_x (+0/+511) /8 = 0/63
9 st_y (+0/+511) /8 = 0/63
9 st_z (+0/+511) /8 = 0/63
8 si_x (0/+255) /8 = 0/31
8 si_y (0/+255) /8 = 0/31
8 si_z (0/+255) /8 = 0/31
6 wls
6 cld
1 ins
64
or
8 st_x (+0/+511) /8 = 0/31
8 st_y (+0/+511) /8 = 0/31
8 st_z (+0/+511) /8 = 0/31
8 si_x (0/+255) /8 = 0/31
8 si_y (0/+255) /8 = 0/31
8 si_z (0/+255) /8 = 0/31
6 wls
6 cld
3 slope left/right/front/back/none
1 ins
64
*/

#define YS 1
#define NO 0

#define S_X 56
#define S_Y 48
#define S_Z 40
#define E_X 32
#define E_Y 24
#define E_Z 16
#define W_TP 15
#define W_BM 14
#define W_LT 13
#define W_RT 12
#define W_FT 11
#define W_BK 10
#define W_OUT 9
#define W_EXT 8

//spare 7654

#define SLP 1 // slp none / slp hor / slp ver
#define INS 0
// spares
// 4 = top of slope type
// 5 = bottom of slope type
// 6 = whether sides of slope are all the way down (making a triangle) or just size 1 (making a square)
// 7 = inside + outside - both inside and outside inside is 1 less than outside
// 8 = if imside + outside - should gap edges be included (insides of doors and windows)

#define GP 3

#define SLP_NONE 0

#define SLP_HR 1
#define SLP_VR 2

//#define SLP_FT 1
//#define SLP_BK 2
//#define SLP_LT 3
//#define SLP_RT 4

#define B_SCL 1//0.125f

#define GH_CNT 60
#define GH_S1 57
#define GH_S2 54
#define GH_S3 51
#define GH_S4 48
#define GH_S5 45
#define GH_S6 42
#define GH_S7 38
#define GH_S8 36
#define GH_S9 33
#define GH_SX 24
#define GH_SY 16
#define GH_EX 8
#define GH_EY 0

#define GD_SX1 56
#define GD_SY1 48
#define GD_EX1 40
#define GD_EY1 32
#define GD_SX2 24
#define GD_SY2 16
#define GD_EX2 8
#define GD_EY2 0

#define GP_N 0
#define GP_LT 1
#define GP_RT 2
#define GP_TP 3
#define GP_BM 4
#define GP_FT 5
#define GP_BK 6

#define BLOCK(pos_x,pos_y,pos_z,size_x,size_y,size_z, \
 wall_top,wall_bottom,wall_left,wall_right,wall_front,wall_back, \
 outside,extrude,gap ,slope, inside) \
 ((unsigned long long)( \
  ((unsigned long long)(pos_x &255)<<S_X) | ((unsigned long long)(pos_y &255)<<S_Y) | ((unsigned long long)(pos_z &255)<<S_Z) | \
  ((unsigned long long)(size_x &255)<<E_X) | ((unsigned long long)(size_y &255)<<E_Y) | ((unsigned long long)(size_z &255)<<E_Z) | \
  ((unsigned long long)(wall_top &1)<<W_TP) | ((unsigned long long)(wall_bottom &1)<<W_BM) | \
  ((unsigned long long)(wall_left &1)<<W_LT) | ((unsigned long long)(wall_right &1)<<W_RT) | \
  ((unsigned long long)(wall_front &1)<<W_FT) | ((unsigned long long)(wall_back &1)<<W_BK) | \
  ((unsigned long long)(outside &1)<<W_OUT) | ((unsigned long long)(extrude &1)<<W_EXT) | \
  ((unsigned long long)(gap &1)<<GP) | ((unsigned long long)(slope &3)<<SLP) | ((unsigned long long)(inside &YS))) )

#define GAPTEST(gap_test) \
((unsigned long long)( \
((unsigned long long)(gap_test &15)<<S_X) | ((unsigned long long)(gap_test &7)<<S_X)))

#define GAPHDR(gap_cnt,side_1,side_2,side_3,side_4,side_5,side_6,side_7,side_8,side_9,SX,SY,EX,EY) \
 ((unsigned long long)( \
 ((unsigned long long)(gap_cnt &15) <<GH_CNT) | ((unsigned long long)(side_1 &7) <<GH_S1) | ((unsigned long long)(side_2 &7) <<GH_S2) | \
 ((unsigned long long)(side_3 &7) <<GH_S3) | ((unsigned long long)(side_4 &7) <<GH_S4) | ((unsigned long long)(side_5 &7) <<GH_S5) | \
 ((unsigned long long)(side_6 &7) <<GH_S6) | ((unsigned long long)(side_7 &7) <<GH_S7) | ((unsigned long long)(side_8 &7) <<GH_S8) | ((unsigned long long)(side_9 &7) <<GH_S9) | \
 ((unsigned long long)(SX &255) <<GH_SX) | ((unsigned long long)(SY &255) << GH_SY) | ((unsigned long long)(EX &255) << GH_EX) | ((unsigned long long)(EY &255) <<GH_EY) ))

#define GAPDTL(sx1,sy1,ex1,ey1,sx2,sy2,ex2,ey2) \
 ((unsigned long long)( \
 ((unsigned long long)(sx1 &255)<<GD_SX1) | ((unsigned long long)(sy1 &255)<<GD_SY1) | ((unsigned long long)(ex1 &255)<<GD_EX1) | ((unsigned long long)(ey1 &255)<<GD_EY1) | \
 ((unsigned long long)(sx2 &255)<<GD_SX2) | ((unsigned long long)(sy2 &255)<<GD_SY2) | ((unsigned long long)(ex2 &255)<<GD_EX2) | ((unsigned long long)(ey2 &255)<<GD_EY2) ))

typedef struct
{
	D3DXVECTOR3 location;
	int object;
} ROOM;

#define RM_X 48
#define RM_Y 32
#define RM_Z 16
#define RM_OBJ 0
#define RM_LIMIT 32767
#define RM_CENTRE 16383

#define RM(x,y,z,object) \
 ((unsigned long long)( \
 ((unsigned long long)(x &RM_LIMIT) <<RM_X) | ((unsigned long long)(y &RM_LIMIT) <<RM_Y) | \
 ((unsigned long long)(z &RM_LIMIT) <<RM_Z) | ((unsigned long long)(object &RM_LIMIT) <<RM_OBJ) ))

const std::vector<unsigned long long> room0000={
	BLOCK(0,0,1,30,13,30,YS,YS,YS,YS,YS,YS,NO,YS,YS,SLP_NONE,YS),
	GAPHDR(2,GP_FT,GP_FT,GP_N,GP_N,GP_N,GP_N,GP_N,GP_N,GP_N,3,0,7,12),
	GAPDTL(10,3,28,12,0,0,0,0),
};

const std::vector<unsigned long long> room0001={
	BLOCK(0,0,0,254,255,254,YS,YS,YS,YS,YS,YS,NO,YS,YS,SLP_NONE,YS),
	GAPHDR(7,GP_BK,GP_BK,GP_RT,GP_RT,GP_FT,GP_TP,GP_BM,GP_N,GP_N,3,0,7,12),
	GAPDTL(10,3,28,12,0,3,12,7),
	GAPDTL(3,10,12,252,32,0,160,64),
	GAPDTL(33,10,42,152,32,10,160,104),

	BLOCK(127,127,127,191,191,191,YS,YS,YS,YS,YS,NO,NO,YS,NO,SLP_NONE,NO),

	BLOCK(212,06,28,202,16,20,YS,YS,YS,YS,YS,YS,NO,NO,NO,SLP_HR,NO),
	BLOCK(112,2,48,102,0,40,YS,YS,YS,YS,YS,YS,NO,NO,NO,SLP_HR,NO)

};

const std::vector<unsigned long long> room0002={
	BLOCK(1,0,0,31,63,255,YS,YS,YS,YS,YS,YS,NO,YS,YS,SLP_NONE,YS),
	GAPHDR(2,GP_LT,GP_LT,GP_N,GP_N,GP_N,GP_N,GP_N,GP_N,GP_N,0,3,12,7),
	GAPDTL(3,10,12,252,0,0,0,0),
};

const std::vector<unsigned long long> room0003={
	BLOCK(1,1,1,254,254,254,YS,YS,YS,YS,YS,YS,NO,YS,YS,SLP_NONE,YS),
	GAPHDR(1,GP_BK,GP_N,GP_N,GP_N,GP_N,GP_N,GP_N,GP_N,GP_N,32,32,160,96),
//	BLOCK(32,32,254,160,96,255,YS,YS,YS,YS,NO,NO,NO,NO,NO,SLP_NONE,YS),
	BLOCK(64,31,200,96,32,254,YS,YS,YS,YS,YS,YS,NO,NO,NO,SLP_NONE,NO),

	BLOCK(80,40,180,90,50,190,YS,YS,YS,YS,YS,YS,YS,YS,YS,SLP_NONE,YS),
	GAPHDR(1,GP_BK,GP_N,GP_N,GP_N,GP_N,GP_N,GP_N,GP_N,GP_N,82,43,87,48),
};

const std::vector<unsigned long long> room={
	RM(RM_CENTRE+0,RM_CENTRE+0,RM_CENTRE+0,100),
	RM(RM_CENTRE+0,RM_CENTRE+0,RM_CENTRE+255,99),
	RM(RM_CENTRE+255,RM_CENTRE+0,RM_CENTRE+0,101),
	RM(RM_CENTRE+0,RM_CENTRE-32,RM_CENTRE-256,102),
};

class Map
{
private:
	std::vector<D3DXVECTOR3> Point;
	std::vector<WORD> Triangle;
	std::vector<GAP_TYPE> Gap;
	std::vector<GAP> Gaps;
	std::vector<float> GapX;
	std::vector<float> GapY;
	std::vector<GAP> Partitions;
	std::vector<GAP> UsedPartitions;
	std::vector<PI> PartitionIndex;

	const int AddPoint(const D3DXVECTOR3 &);
	const void AddFace(const int, const int, const int, const int);
	const void AddTriangle(const int, const int, const int);
	const BLOCK Block(const unsigned long long);
	const GAP_HDR GapHeader(const unsigned long long);
	const GAP_TYPE AddGapSide(const unsigned char, const D3DXVECTOR2, const D3DXVECTOR2);
	const void GapDetail(const unsigned long long, D3DXVECTOR2 *, D3DXVECTOR2 *);
	const void FindGaps(const int);
	const GAP AddGap(const float,const float,const float,const float);
	const void AddGapX(const float);
	const void AddGapY(const float);
	const void AddGaps(const float,const float,const float,const float);
	const void FindPartitions();
	const void FindUsedPartitions();
	const void LinkPartitions();
	const void BuildLeftWalls(const D3DXVECTOR3 &,const D3DXVECTOR3 &,const bool);
	const void X_2D_3D(const float, const bool);
	const void AddWallsToObject(const bool);
	const void BuildRightWalls(const D3DXVECTOR3 &,const D3DXVECTOR3 &,const bool);
	const void BuildTopWalls(const D3DXVECTOR3 &,const D3DXVECTOR3 &,const bool);
	const void Y_2D_3D(const float, const bool);
	const void BuildBottomWalls(const D3DXVECTOR3 &,const D3DXVECTOR3 &,const bool);
	const void BuildFrontWalls(const D3DXVECTOR3 &,const D3DXVECTOR3 &,const bool);
	const void BuildBackWalls(const D3DXVECTOR3 &,const D3DXVECTOR3 &,const bool);
	const void Z_2D_3D(const float,const bool);
	const PI AddPI(const int,const int,const int,const int);

	const ROOM Room(const unsigned long long);
	const void BuildHorSlope(const D3DXVECTOR3 &,const D3DXVECTOR3 &,const SIDES &, const bool, const bool);
	const void BuildVerSlope(const D3DXVECTOR3 &,const D3DXVECTOR3 &,const SIDES &);

	const void AddSillsX(const int,const float,const bool);
	const void AddSillsY(const int,const float,const bool);
	const void AddSillsZ(const int, const float, const bool);
	const void X_2D_3D_Sill(const float,const bool);
	const void Y_2D_3D_Sill(const float,const bool);
	const void Z_2D_3D_Sill(const float,const bool);

	const void AddOutsideWalls(const D3DXVECTOR3 &, const D3DXVECTOR3 &);
	const void AddExtrudedWall(const D3DXVECTOR3 &first,const D3DXVECTOR3 &second,const D3DXVECTOR3 &third,const D3DXVECTOR3 &fourth,const D3DXVECTOR3 &direction,const D3DXVECTOR3 &,const D3DXVECTOR3 &);

	const void ExtendX(D3DXVECTOR3 &first,D3DXVECTOR3 &second,D3DXVECTOR3 &third,D3DXVECTOR3 &fourth,const D3DXVECTOR3 &start,const D3DXVECTOR3 &end);
	const void ExtendY(D3DXVECTOR3 &first,D3DXVECTOR3 &second,D3DXVECTOR3 &third,D3DXVECTOR3 &fourth,const D3DXVECTOR3 &start,const D3DXVECTOR3 &end);
	const void ExtendZ(D3DXVECTOR3 &first,D3DXVECTOR3 &second,D3DXVECTOR3 &third,D3DXVECTOR3 &fourth,const D3DXVECTOR3 &start,const D3DXVECTOR3 &end);

public:
	const void Setup();
	~Map();
	ACTOR Track[TRACK_PATCH_COUNT];
	const void BuildTrack();
	int TrackSections;
	const void BuildObject(const std::vector<unsigned long long>,const int);
	MESH ModelMesh[MAX_MODELS]; // list of models loaded in
};

#endif
