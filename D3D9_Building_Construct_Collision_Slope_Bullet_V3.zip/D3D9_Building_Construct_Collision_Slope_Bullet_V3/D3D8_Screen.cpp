#include "d3d8_screen.h"
#include "map.h"
#include <d3d9.h>
#include <stdio.h>

extern FILE *file;
extern Map map;

const bool Screen::Setup(const int width, const int height, const D3DFORMAT format, const float near_clip, const float far_clip, const D3DFORMAT zbuffer, const int backbuffers, const HWND hwnd)
{
	g_pD3D	=NULL;
	g_pd3dDevice=NULL;

	fprintf(file,"d3d Direct3DCreate9\n");
	if ((g_pD3D=Direct3DCreate9(D3D_SDK_VERSION))==NULL) return false;

	D3DPRESENT_PARAMETERS d3dpp; 
	ZeroMemory (&d3dpp, sizeof(d3dpp));
	d3dpp.SwapEffect = D3DSWAPEFFECT_FLIP;
	d3dpp.BackBufferFormat = format;
	d3dpp.BackBufferWidth=width;
	d3dpp.BackBufferHeight=height;
	d3dpp.BackBufferCount=backbuffers;
	d3dpp.Windowed = false;
	d3dpp.FullScreen_RefreshRateInHz=D3DPRESENT_RATE_DEFAULT;
	d3dpp.PresentationInterval=D3DPRESENT_INTERVAL_IMMEDIATE; 
	d3dpp.EnableAutoDepthStencil = true;
	d3dpp.AutoDepthStencilFormat = zbuffer;
	fprintf(file,"d3d CreateDevice\n");
	if (FAILED(g_pD3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hwnd, D3DCREATE_HARDWARE_VERTEXPROCESSING |	D3DCREATE_PUREDEVICE, &d3dpp, &g_pd3dDevice))) return false;

  D3DXMatrixPerspectiveFovLH(&Matrix_Projection, D3DX_PI/4.0f, 1.0f, near_clip, far_clip); // For the projection matrix, we set up a perspective transform (which transforms geometry from 3D view space to 2D viewport space, with a perspective divide making objects smaller in the distance). To build a perspective transform, we need the field of view (1/4 pi is common), the aspect ratio, and the near and far clipping planes (which define at what distances geometry should be no longer be rendered).
  g_pd3dDevice->SetTransform(D3DTS_PROJECTION, &Matrix_Projection);

	fprintf(file,"d3d SetRenderState\n");
	g_pd3dDevice->SetRenderState(D3DRS_CULLMODE,D3DCULL_CCW);//D3DCULL_CCW //D3DCULL_NONE
	g_pd3dDevice->SetRenderState(D3DRS_SHADEMODE, D3DSHADE_FLAT); //D3DSHADE_FLAT //D3DSHADE_GOURAUD
	g_pd3dDevice->SetRenderState(D3DRS_FILLMODE,D3DFILL_SOLID); //D3DFILL_WIREFRAME //D3DFILL_SOLID
	g_pd3dDevice->SetRenderState(D3DRS_CLIPPING, true);
	g_pd3dDevice->SetRenderState(D3DRS_ZENABLE, true);
	g_pd3dDevice->SetRenderState(D3DRS_LIGHTING, false);

	for (int x=0; x!=MAX_MODELS; ++x)
	{
		Model[x].Vertex_Buffer=NULL;
		Model[x].Index_Buffer=NULL;
	}

	g_pd3dDevice->SetFVF(D3DFVF_IM_VERTEX);
	D3DXCreateFont(g_pd3dDevice, height/40, width/80, FW_BOLD, 0, false, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, TEXT("Arial"), &Font);

 	return true;
}

/*
D3DMCS_MATERIAL
Use the color from the current material.

D3DMCS_COLOR1
Use the diffuse vertex color.

D3DMCS_COLOR2
Use the specular vertex color.

D3DMCS_FORCE_DWORD
Forces this enumeration to compile to 32 bits in size. Without this value, some compilers would allow this enumeration to compile to a size other than 32 bits. This value is not used.

Remarks
These flags are used to set the value of the following render states in the D3DRENDERSTATETYPE enumerated type.

D3DRS_AMBIENTMATERIALSOURCE
D3DRS_DIFFUSEMATERIALSOURCE
D3DRS_EMISSIVEMATERIALSOURCE
D3DRS_SPECULARMATERIALSOURCE

D3DRS_AMBIENTMATERIALSOURCE to D3DMCS_COLOR1

*/

const void Screen::View_Matrix(const D3DXVECTOR3 &location, const D3DXVECTOR3 *direction)
{
	D3DXMATRIX matTmp;
	D3DXMatrixRotationYawPitchRoll(&matTmp, direction->y, direction->x, direction->z); // View direction

	D3DXVECTOR4 tmp;
	D3DXVec3Transform(&tmp, &D3DXVECTOR3(0.0f, 0.0f, 1.0f), &matTmp);
	D3DXVECTOR3 viewDir = (D3DXVECTOR3) tmp + location;
	
	D3DXVec3Transform(&tmp, &D3DXVECTOR3(0.0f, 1.0f, 0.0f), &matTmp); // View up orientation
	D3DXVECTOR3 viewUp = (D3DXVECTOR3) tmp;

	D3DXMatrixLookAtLH(&Matrix_View, &location, &viewDir, &viewUp);
  g_pd3dDevice->SetTransform(D3DTS_VIEW, &Matrix_View);
	ExtractFrustumPlanes();
}

Screen::~Screen()
{
	fprintf(file,"d3d screen shutdown\n");

	for (int x=0; x!=MAX_MODELS; ++x)
	{
		if (Model[x].Vertex_Buffer!=NULL)
		{
			Model[x].Vertex_Buffer->Release();
			Model[x].Vertex_Buffer=NULL;
		}
		if (Model[x].Index_Buffer!=NULL)
		{
			Model[x].Index_Buffer->Release();
			Model[x].Index_Buffer=NULL;
		}
	}

	if (g_pd3dDevice)
	{
		g_pd3dDevice->Release();
		g_pd3dDevice=NULL;
	}
	if (g_pD3D)
	{
		g_pD3D->Release();
		g_pD3D=NULL;
	}
}

const void Screen::ExtractFrustumPlanes(void)
{
	D3DXMATRIX ViewProj;
	D3DXMatrixMultiply(&ViewProj, &Matrix_View, &Matrix_Projection);

	Frustum[0].a = -(ViewProj._14 + ViewProj._11); // Left clipping plane
	Frustum[0].b = -(ViewProj._24 + ViewProj._21);
	Frustum[0].c = -(ViewProj._34 + ViewProj._31);
	Frustum[0].d = -(ViewProj._44 + ViewProj._41);
	D3DXPlaneNormalize(&Frustum[0], &Frustum[0]);

	Frustum[1].a = -(ViewProj._14 - ViewProj._11); // Right clipping plane
	Frustum[1].b = -(ViewProj._24 - ViewProj._21);
	Frustum[1].c = -(ViewProj._34 - ViewProj._31);
	Frustum[1].d = -(ViewProj._44 - ViewProj._41);
	D3DXPlaneNormalize(&Frustum[1], &Frustum[1]);

	Frustum[2].a = -(ViewProj._14 - ViewProj._12); // Top clipping plane
	Frustum[2].b = -(ViewProj._24 - ViewProj._22);
	Frustum[2].c = -(ViewProj._34 - ViewProj._32);
	Frustum[2].d = -(ViewProj._44 - ViewProj._42);
	D3DXPlaneNormalize(&Frustum[2], &Frustum[2]);

	Frustum[3].a = -(ViewProj._14 + ViewProj._12); // Bottom clipping plane
	Frustum[3].b = -(ViewProj._24 + ViewProj._22);
	Frustum[3].c = -(ViewProj._34 + ViewProj._32);
	Frustum[3].d = -(ViewProj._44 + ViewProj._42);
	D3DXPlaneNormalize(&Frustum[3], &Frustum[3]);

	Frustum[4].a = -(ViewProj._13); // Near clipping plane
	Frustum[4].b = -(ViewProj._23);
	Frustum[4].c = -(ViewProj._33);
	Frustum[4].d = -(ViewProj._43);
	D3DXPlaneNormalize(&Frustum[4], &Frustum[4]);

	Frustum[5].a = -(ViewProj._14 - ViewProj._13); // Far clipping plane
	Frustum[5].b = -(ViewProj._24 - ViewProj._23);
	Frustum[5].c = -(ViewProj._34 - ViewProj._33);
	Frustum[5].d = -(ViewProj._44 - ViewProj._43);
	D3DXPlaneNormalize(&Frustum[5], &Frustum[5]);
}

const bool Screen::IsPointInsideFrustum(const D3DXVECTOR3 *location)
{
	for (int i=0; i!=MAX_PLANES; ++i)
	{
		if (D3DXPlaneDotCoord(&Frustum[i], location)>=0.0f)
		{
			return false;
		}
	}
	return true;
}

const bool Screen::IsSphereInsideFrustum(const D3DXVECTOR3 *location, const float Bounding_Sphere)
{
	for (int i=0; i!=MAX_PLANES; ++i)
	{
		if (D3DXPlaneDotCoord(&Frustum[i], location)>=Bounding_Sphere)
		{
			return false;
		}
	}
	return true;
}

const bool Screen::BoundingBoxInFrustum(const D3DXVECTOR3 *bounding_box, const D3DXVECTOR3 &location)
{
	for (int x=0, y; x!=MAX_PLANES; ++x)
	{
		for (y=0; y!=MAX_BOUNDING_BOX; ++y)
		{
			const D3DXVECTOR3 boundingboxpoint=bounding_box[y]+location;
			if (D3DXPlaneDotCoord(&Frustum[x], &boundingboxpoint)<=0.0f)
			{
				break;
			}
		}
		if (y==MAX_BOUNDING_BOX)
		{
			return false;
		}
	}
	return true;
}

const bool Screen::BoundingBoxStaticInFrustum(const D3DXVECTOR3 *bounding_box)
{
	for (int x=0, y; x!=MAX_PLANES; ++x)
	{
		for (y=0; y!=MAX_BOUNDING_BOX; ++y)
		{
			if (D3DXPlaneDotCoord(&Frustum[x], &bounding_box[y])<=0.0f)
			{
				break;
			}
		}
		if (y==MAX_BOUNDING_BOX)
		{
			return false;
		}
	}
	return true;
}

const bool Screen::IsBoundingBoxInsideFrustum(const D3DXVECTOR3 *location)
{
	for (int x=0, y; x!=MAX_PLANES; ++x)
	{
		for (y=0; y!=MAX_BOUNDING_BOX; ++y)
		{
			if (D3DXPlaneDotCoord(&Frustum[x], &location[y])<=0.0f)
			{
				break;
			}
		}
		if (y==MAX_BOUNDING_BOX)
		{
			return false;
		}
	}
	return true;
}

const void Screen::DrawLookAtObject(const D3DXVECTOR3 &location, const D3DXVECTOR3 &eye, const int model, const int material)
{
	D3DXMATRIX Matrix_World;
	D3DXMATRIX Matrix_Rotation;

	D3DXMatrixIdentity(&Matrix_Rotation);
	D3DXMatrixLookAtLH(&Matrix_Rotation, &location, &eye, &D3DXVECTOR3(0,1,0));
	float determinant=D3DXMatrixDeterminant(&Matrix_Rotation);
	D3DXMatrixInverse(&Matrix_World, &determinant, &Matrix_Rotation);

	g_pd3dDevice->SetTransform(D3DTS_WORLD, &Matrix_World);

//	if (model!=Current_Model)
	{
		Current_Model=model;
		g_pd3dDevice->SetStreamSource(0, Model[model].Vertex_Buffer,0, sizeof(IM_VERTEX));
		g_pd3dDevice->SetIndices(Model[model].Index_Buffer);
	}
	g_pd3dDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, Model[model].Vertices, 0, Model[model].Triangles);
}

const void Screen::DrawStaticObject(const D3DXVECTOR3 *location, const int model, const int material)
{
	D3DXMATRIX Matrix_World;
	D3DXMATRIX Matrix_Translation;
	D3DXMATRIX Matrix_Rotation;

	D3DXMatrixIdentity(&Matrix_Translation);
	D3DXMatrixTranslation(&Matrix_Translation, location->x, location->y, location->z);
	g_pd3dDevice->SetTransform(D3DTS_WORLD, &Matrix_Translation);

//	if (model!=Current_Model)
	{
		Current_Model=model;
		g_pd3dDevice->SetStreamSource(0, Model[model].Vertex_Buffer,0, sizeof(IM_VERTEX));
		g_pd3dDevice->SetIndices(Model[model].Index_Buffer);
	}
	g_pd3dDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, Model[model].Vertices, 0, Model[model].Triangles);
}

const void Screen::DrawObject(const D3DXVECTOR3 *location, const D3DXVECTOR3 *direction, const int model, const int material)
{
	D3DXMatrixIdentity(&Matrix_Translation);
	D3DXMatrixTranslation(&Matrix_Translation, location->x, location->y, location->z);
	D3DXMatrixRotationYawPitchRoll(&Matrix_Rotation, direction->y, direction->x, direction->z);
	D3DXMatrixMultiply(&Matrix_World, &Matrix_Rotation, &Matrix_Translation);
	g_pd3dDevice->SetTransform(D3DTS_WORLD, &Matrix_World);

//	if (model != Current_Model)
	{
		Current_Model = model;
		g_pd3dDevice->SetStreamSource(0, Model[model].Vertex_Buffer, 0, sizeof(IM_VERTEX));
		g_pd3dDevice->SetIndices(Model[model].Index_Buffer);
	}

	g_pd3dDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, Model[model].Vertices, 0, Model[model].Triangles);
}

const void Screen::CreateObject(const int vertices, const int triangles, const int object)
{
	fprintf(file,"co-start o %ld v %ld t %ld\n", object, vertices, triangles);
//	for (int x=0; x!=vertices; ++x) fprintf(file,"%ld %ld %f %f %f %f %f %f\n", x,vertices,Vertex[x].Location.x,Vertex[x].Location.y,Vertex[x].Location.z,Vertex[x].Normal.x,Vertex[x].Normal.y,Vertex[x].Normal.z);

	Model[object].Vertices=vertices;
	Model[object].Triangles=triangles;
	Model[object].Vertex_Buffer=NULL;
	Model[object].Index_Buffer=NULL;

	LPD3DXMESH mesh;
	D3DXCreateMeshFVF(Model[object].Triangles, Model[object].Vertices, D3DXMESH_MANAGED, D3DFVF_IM_VERTEX, g_pd3dDevice, &mesh);

	IM_VERTEX* mesh_vertices;
	mesh->LockVertexBuffer(D3DLOCK_DISCARD, (void**) &mesh_vertices);
	memcpy(&mesh_vertices[0], &Vertex[0], sizeof(Vertex[0])*Model[object].Vertices);
//	mesh->UnlockVertexBuffer();

	WORD *mesh_indices;
	mesh->LockIndexBuffer(D3DLOCK_DISCARD, (void**) &mesh_indices);
	memcpy(&mesh_indices[0], &Index[0], sizeof(Index[0])*Model[object].Triangles*3);
//	mesh->UnlockIndexBuffer();
//	D3DXComputeNormals(mesh, (DWORD*)pAdjacencyBuffer->GetBufferPointer());
	LPD3DXBUFFER pAdjacencyBuffer = NULL;
	D3DXCreateBuffer(mesh->GetNumFaces() *sizeof(DWORD) *3, &pAdjacencyBuffer);
	mesh->GenerateAdjacency(0.0f, (DWORD*)pAdjacencyBuffer->GetBufferPointer());
//	D3DXComputeNormals(mesh, (DWORD*)pAdjacencyBuffer->GetBufferPointer());
	D3DXComputeNormals(mesh, NULL);
	mesh->OptimizeInplace(D3DXMESHOPT_COMPACT, (DWORD*)pAdjacencyBuffer->GetBufferPointer(), NULL, NULL, NULL);

	Model[object].Triangles=mesh->GetNumFaces();
	Model[object].Vertices=mesh->GetNumVertices();

//	mesh->LockIndexBuffer(D3DLOCK_READONLY, (void**) &mesh_indices);
//	mesh->LockVertexBuffer(D3DLOCK_READONLY, (void**) &mesh_vertices);

	g_pd3dDevice->CreateVertexBuffer(sizeof(IM_VERTEX)*Model[object].Vertices, D3DUSAGE_WRITEONLY, D3DFVF_IM_VERTEX, D3DPOOL_DEFAULT, &Model[object].Vertex_Buffer, NULL);
  IM_VERTEX* pVertices;
	Model[object].Vertex_Buffer->Lock(0, sizeof(IM_VERTEX)*Model[object].Vertices, (void**) &pVertices, 0);
	memcpy(&pVertices[0], &mesh_vertices[0], sizeof(mesh_vertices[0])*Model[object].Vertices);

	g_pd3dDevice->CreateIndexBuffer(sizeof(WORD)*Model[object].Triangles*3, D3DUSAGE_WRITEONLY, D3DFMT_INDEX16, D3DPOOL_DEFAULT, &Model[object].Index_Buffer, NULL);
	WORD *pIndices;
	Model[object].Index_Buffer->Lock(0, sizeof(WORD)*Model[object].Triangles*3, (void**) &pIndices, 0);
	memcpy(&pIndices[0], &mesh_indices[0], sizeof(mesh_indices[0])*Model[object].Triangles*3);

	Model[object].Index_Buffer->Unlock();
	mesh->UnlockIndexBuffer();

	D3DXVECTOR3 min, max;
	D3DXComputeBoundingBox(&mesh_vertices[0].Location, Model[object].Vertices, sizeof(mesh_vertices[0]), &min, &max);
	D3DXComputeBoundingSphere(&mesh_vertices[0].Location, Model[object].Vertices, sizeof(IM_VERTEX), &Model[object].Bounding_Sphere_Centre, &Model[object].Bounding_Sphere_Radius);

	Model[object].Vertex_Buffer->Unlock();
	mesh->UnlockVertexBuffer();
	mesh->Release();
	mesh=NULL;

	Model[object].Bounding_Box[0]=D3DXVECTOR3(min.x, min.y, min.z);
	Model[object].Bounding_Box[1]=D3DXVECTOR3(min.x, min.y, max.z);
	Model[object].Bounding_Box[2]=D3DXVECTOR3(min.x, max.y, min.z);
	Model[object].Bounding_Box[3]=D3DXVECTOR3(min.x, max.y, max.z);
	Model[object].Bounding_Box[4]=D3DXVECTOR3(max.x, min.y, min.z);
	Model[object].Bounding_Box[5]=D3DXVECTOR3(max.x, min.y, max.z);
	Model[object].Bounding_Box[6]=D3DXVECTOR3(max.x, max.y, min.z);
	Model[object].Bounding_Box[7]=D3DXVECTOR3(max.x, max.y, max.z);

	fprintf(file,"co-end o %ld v %ld t %ld\n", object, Model[object].Vertices, Model[object].Triangles);
}

const void Screen::DrawText(const int  x, const int y, const D3DCOLOR color)
{
	RECT rect;
	SetRect(&rect, x, y, 0, 0);
	Font->DrawText(NULL, string, -1, &rect, DT_NOCLIP, color);
}

const void Screen::DrawBoundingBox(const int model)
{
return;
	static const WORD index[]={0,1,1,3,3,2,2,0,4,5,5,7,7,6,6,4,0,4,1,5,3,7,2,6};
	g_pd3dDevice->DrawIndexedPrimitiveUP(D3DPT_LINELIST, 0, 8, 12, (void*) index, D3DFMT_INDEX16, (void*) Model[model].Bounding_Box[0], sizeof(D3DXVECTOR3));     

}
