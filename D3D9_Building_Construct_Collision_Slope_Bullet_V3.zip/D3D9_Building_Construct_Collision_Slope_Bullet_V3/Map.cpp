#include "d3d8_screen.h"
#include "load.h"
#include "map.h"
#include "engine.h"
#include <algorithm>

extern Screen screen;
extern Load load;
extern FILE *file;
extern Engine engine;

//todo
//routine to identify if inside object or not using model bounding box - done
//routine to return object number and model number - done
//collision list structure - done
// sort collision lists into order - done
//mesh type which stores indices/vertices/collision lists/bounding box - done
// pass inside/outside to add collision - and if inside store in opposite wall - not needed

const void Map::Setup()
{
	fprintf(file,"map setup\n");
	BuildTrack();
}

Map::~Map()
{
	fprintf(file,"map shutdown\n");
}

const void Map::BuildTrack()
{
	TrackSections=room.size();

	for (int r=0; r!=room.size(); ++r)
	{
		const ROOM rm=Room(room[r]);
		Track[r].Model=rm.object;
		Track[r].Material=rand()&3;
		Track[r].Location=rm.location;
		Track[r].Direction=D3DXVECTOR3(0,0,0);

		engine.AddPhysicsMesh(ModelMesh[Track[r].Model].Point, ModelMesh[Track[r].Model].Triangle, Track[r].Location, r);
	}
	engine.Camera=TrackSections;

//	engine.AddPhysicsActor(1,D3DXVECTOR3(0,2,0),D3DXVECTOR3(50.0f,50.0f,50.0f),D3DXVECTOR3(0.0f,0.0f,0.0f),1.0f,50);


//	engine.AddPhysicsCapsule(1.4f*2.0f,1.4f,D3DXVECTOR3(RM_CENTRE+50.0f,RM_CENTRE+50.0f,RM_CENTRE+50.0f),1.5f,engine.Camera);
//	engine.AddPhysicsSphere(1.4f, D3DXVECTOR3(RM_CENTRE+50.0f,RM_CENTRE+50.0f,RM_CENTRE+50.0f),1.0f,engine.Camera);
	engine.AddPhysicsBox(EXTENT_STAND,D3DXVECTOR3(RM_CENTRE+50.0f,RM_CENTRE+150.0f,RM_CENTRE+150.0f),1.0f,engine.Camera);
}

const GAP_TYPE Map::AddGapSide(const unsigned char side, const D3DXVECTOR2 start, const D3DXVECTOR2 end)
{
	GAP_TYPE gap;
	gap.side=side;
	gap.start=start;
	gap.end=end;
	return gap;
}

const int Map::AddPoint(const D3DXVECTOR3 &point)
{
	for (int p=0; p!=Point.size(); ++p)
	{
		if ((Point[p].x==point.x) && (Point[p].y==point.y) && (Point[p].z==point.z))
		{
			return p;
		}
	}
	Point.push_back(point);
	return Point.size()-1;
}

const void Map::AddTriangle(const int p0,const int p1,const int p2)
{
	Triangle.push_back(p0);
	Triangle.push_back(p1);
	Triangle.push_back(p2);
}

const void Map::AddFace(const int p0,const int p1,const int p2,const int p3)
{
	AddTriangle(p0,p1,p2);
	AddTriangle(p0,p2,p3);
}

const void Map::BuildLeftWalls(const D3DXVECTOR3 &start,const D3DXVECTOR3 &end, const bool inside)
{
	FindGaps(GP_LT);
	AddGaps(start.y,end.y,start.z,end.z);
	FindPartitions();
	FindUsedPartitions();
	LinkPartitions();
	X_2D_3D(start.x, false);
	AddWallsToObject(inside);
}

const void Map::BuildRightWalls(const D3DXVECTOR3 &start,const D3DXVECTOR3 &end,const bool inside)
{
	FindGaps(GP_RT);
	AddGaps(start.y,end.y,start.z,end.z);
	FindPartitions();
	FindUsedPartitions();
	LinkPartitions();
	X_2D_3D(end.x, true);
	AddWallsToObject(inside);
}

const void Map::BuildTopWalls(const D3DXVECTOR3 &start,const D3DXVECTOR3 &end,const bool inside)
{
	FindGaps(GP_TP);
	AddGaps(start.x,end.x,start.z,end.z);
	FindPartitions();
	FindUsedPartitions();
	LinkPartitions();
	Y_2D_3D(end.y,false);
	AddWallsToObject(inside);
}

const void Map::BuildBottomWalls(const D3DXVECTOR3 &start,const D3DXVECTOR3 &end,const bool inside)
{
	FindGaps(GP_BM);
	AddGaps(start.x,end.x,start.z,end.z);
	FindPartitions();
	FindUsedPartitions();
	LinkPartitions();
	Y_2D_3D(start.y,true);
	AddWallsToObject(inside);
}

const void Map::BuildFrontWalls(const D3DXVECTOR3 &start,const D3DXVECTOR3 &end,const bool inside)
{
	FindGaps(GP_FT);
	AddGaps(start.x,end.x,start.y,end.y);
	FindPartitions();
	FindUsedPartitions();
	LinkPartitions();
	Z_2D_3D(start.z,false);
	AddWallsToObject(inside);
}

const void Map::BuildBackWalls(const D3DXVECTOR3 &start,const D3DXVECTOR3 &end,const bool inside)
{
	FindGaps(GP_BK);
	AddGaps(start.x,end.x,start.y,end.y);
	FindPartitions();
	FindUsedPartitions();
	LinkPartitions();
	Z_2D_3D(end.z,true);
	AddWallsToObject(inside);
}

const PI Map::AddPI(const int p0, const int p1, const int p2, const int p3)
{
	PI pi;
	pi.first=p0;
	pi.second=p1;
	pi.third=p2;
	pi.fourth=p3;
	return pi;
}

const void Map::X_2D_3D(const float x, const bool reverse)
{
	PartitionIndex.clear();

	for (int p=0; p!=UsedPartitions.size(); ++p)
	{
		const D3DXVECTOR3 point_first=D3DXVECTOR3(x,UsedPartitions[p].start.x,UsedPartitions[p].start.y);
		const D3DXVECTOR3 point_second=D3DXVECTOR3(x,UsedPartitions[p].start.x,UsedPartitions[p].end.y);
		const D3DXVECTOR3 point_third=D3DXVECTOR3(x,UsedPartitions[p].end.x,UsedPartitions[p].end.y);
		const D3DXVECTOR3 point_fourth=D3DXVECTOR3(x,UsedPartitions[p].end.x,UsedPartitions[p].start.y);
		if (reverse==false)
		{
			PartitionIndex.push_back(AddPI(AddPoint(point_first),AddPoint(point_second),AddPoint(point_third),AddPoint(point_fourth)));
		}
		else
		{
			PartitionIndex.push_back(AddPI(AddPoint(point_fourth),AddPoint(point_third),AddPoint(point_second),AddPoint(point_first)));
		}
	}
}

const void Map::Y_2D_3D(const float y,const bool reverse)
{
	PartitionIndex.clear();

	for (int p=0; p!=UsedPartitions.size(); ++p)
	{
		const D3DXVECTOR3 point_first=D3DXVECTOR3(UsedPartitions[p].start.x,y,UsedPartitions[p].start.y);
		const D3DXVECTOR3 point_second=D3DXVECTOR3(UsedPartitions[p].start.x,y,UsedPartitions[p].end.y);
		const D3DXVECTOR3 point_third=D3DXVECTOR3(UsedPartitions[p].end.x,y,UsedPartitions[p].end.y);
		const D3DXVECTOR3 point_fourth=D3DXVECTOR3(UsedPartitions[p].end.x,y,UsedPartitions[p].start.y);
		if (reverse==false)
		{
			PartitionIndex.push_back(AddPI(AddPoint(point_first),AddPoint(point_second),AddPoint(point_third),AddPoint(point_fourth)));
		}
		else
		{
			PartitionIndex.push_back(AddPI(AddPoint(point_fourth),AddPoint(point_third),AddPoint(point_second),AddPoint(point_first)));
		}
	}
}

const void Map::Z_2D_3D(const float z,const bool reverse)
{
	PartitionIndex.clear();

	for (int p=0; p!=UsedPartitions.size(); ++p)
	{
		const D3DXVECTOR3 point_first=D3DXVECTOR3(UsedPartitions[p].start.x,UsedPartitions[p].start.y,z);
		const D3DXVECTOR3 point_second=D3DXVECTOR3(UsedPartitions[p].start.x,UsedPartitions[p].end.y,z);
		const D3DXVECTOR3 point_third=D3DXVECTOR3(UsedPartitions[p].end.x,UsedPartitions[p].end.y,z);
		const D3DXVECTOR3 point_fourth=D3DXVECTOR3(UsedPartitions[p].end.x,UsedPartitions[p].start.y,z);
		if (reverse==false)
		{
			PartitionIndex.push_back(AddPI(AddPoint(point_first),AddPoint(point_second),AddPoint(point_third),AddPoint(point_fourth)));
		}
		else
		{
			PartitionIndex.push_back(AddPI(AddPoint(point_fourth),AddPoint(point_third),AddPoint(point_second),AddPoint(point_first)));
		}
	}
}

const void Map::AddWallsToObject(const bool inside)
{
	for (int p=0; p!=PartitionIndex.size(); ++p)
	{
		if (inside==false)
		{
			AddFace(PartitionIndex[p].first,PartitionIndex[p].second,PartitionIndex[p].third,PartitionIndex[p].fourth);
		}
		else
		{
			AddFace(PartitionIndex[p].fourth,PartitionIndex[p].third,PartitionIndex[p].second,PartitionIndex[p].first);
		}
	}
}

const void Map::BuildHorSlope(const D3DXVECTOR3 &start,const D3DXVECTOR3 &end, const SIDES &side, const bool left_edge_up, const bool right_edge_up)
{
	D3DXVECTOR3 btl=D3DXVECTOR3(end.x,end.y,start.z);
	D3DXVECTOR3 btr=D3DXVECTOR3(start.x,start.y,start.z);
	D3DXVECTOR3 ftl=D3DXVECTOR3(end.x,end.y,end.z);
	D3DXVECTOR3 ftr=D3DXVECTOR3(start.x,start.y,end.z);
	D3DXVECTOR3 bbl=D3DXVECTOR3(end.x,end.y-1,start.z);
	D3DXVECTOR3 bbr=D3DXVECTOR3(start.x,start.y-1,start.z);
	D3DXVECTOR3 fbl=D3DXVECTOR3(end.x,end.y-1,end.z);
	D3DXVECTOR3 fbr=D3DXVECTOR3(start.x,start.y-1,end.z);

	if (left_edge_up==false)
	{
		if (start.y >= end.y)
		{
			fbr=ftr+D3DXVECTOR3(+1,0,0);
			bbr=btr+D3DXVECTOR3(+1,0,0);
		}
		else
		{
			ftr=fbr+D3DXVECTOR3(+1,0,0);
			btr=bbr+D3DXVECTOR3(+1,0,0);
		}
	}

	if (right_edge_up==false)
	{
		if (start.y >= end.y)
		{
			ftl=fbl+D3DXVECTOR3(-1,0,0);
			btl=bbl+D3DXVECTOR3(-1,0,0);
		}
		else
		{
			fbl=ftl+D3DXVECTOR3(-1,0,0);
			bbl=btl+D3DXVECTOR3(-1,0,0);
		}
	}

	const int btlp=AddPoint(btl);
	const int btrp=AddPoint(btr);
	const int ftrp=AddPoint(ftr);
	const int ftlp=AddPoint(ftl);

	const int bblp=AddPoint(bbl);
	const int bbrp=AddPoint(bbr);
	const int fbrp=AddPoint(fbr);
	const int fblp=AddPoint(fbl);

	if (side.bottom==true) AddFace(btlp, btrp,ftrp, ftlp);
	if (side.top==true) AddFace(bbrp,bblp,fblp,fbrp);

	if (side.left==true) AddFace(ftrp,btrp,bbrp,fbrp);
	if (side.right==true) AddFace(btlp,ftlp,fblp,bblp);

	if (side.front==true) AddFace(btrp,btlp,bblp,bbrp);
	if (side.back==true) AddFace(ftlp,ftrp,fbrp,fblp);
}

const void Map::BuildVerSlope(const D3DXVECTOR3 &start,const D3DXVECTOR3 &end,const SIDES &sides)
{

}

const void Map::X_2D_3D_Sill(const float x, const bool direction)
{
	const D3DXVECTOR3 extrude_dir = (direction==true) ? D3DXVECTOR3(1,0,0) : D3DXVECTOR3(-1,0,0);

	for (int g=0; g!=Gaps.size(); ++g)
	{
		const D3DXVECTOR3 tl=D3DXVECTOR3(x,Gaps[g].start.x, Gaps[g].start.y);
		const D3DXVECTOR3 tr=D3DXVECTOR3(x,Gaps[g].start.x, Gaps[g].end.y);
		const D3DXVECTOR3 br=D3DXVECTOR3(x,Gaps[g].end.x, Gaps[g].end.y);
		const D3DXVECTOR3 bl=D3DXVECTOR3(x,Gaps[g].end.x, Gaps[g].start.y);

		const D3DXVECTOR3 etl=tl+extrude_dir;
		const D3DXVECTOR3 etr=tr+extrude_dir;
		const D3DXVECTOR3 ebr=br+extrude_dir;
		const D3DXVECTOR3 ebl=bl+extrude_dir;
		
		const int tlp=AddPoint(tl);
		const int trp=AddPoint(tr);
		const int brp=AddPoint(br);
		const int blp=AddPoint(bl);

		const int etlp=AddPoint(etl);
		const int etrp=AddPoint(etr);
		const int ebrp=AddPoint(ebr);
		const int eblp=AddPoint(ebl);

		if (direction==false)
		{
			AddFace(tlp,etlp,etrp,trp);
			AddFace(trp,etrp,ebrp,brp);
			AddFace(brp,ebrp,eblp,blp);
			AddFace(blp,eblp,etlp,tlp);
		}
		else
		{
			AddFace(etlp,tlp,trp,etrp);
			AddFace(etrp,trp,brp,ebrp);
			AddFace(ebrp,brp,blp,eblp);
			AddFace(eblp,blp,tlp,etlp);
		}
	}
}

const void Map::Y_2D_3D_Sill(const float y,const bool direction)
{
	const D3DXVECTOR3 extrude_dir = (direction==true) ? D3DXVECTOR3(0,1,0) : D3DXVECTOR3(0,-1,0);

	for (int g=0; g!=Gaps.size(); ++g)
	{
		const D3DXVECTOR3 tl=D3DXVECTOR3(Gaps[g].start.x,y,Gaps[g].start.y);
		const D3DXVECTOR3 tr=D3DXVECTOR3(Gaps[g].start.x,y,Gaps[g].end.y);
		const D3DXVECTOR3 br=D3DXVECTOR3(Gaps[g].end.x,y,Gaps[g].end.y);
		const D3DXVECTOR3 bl=D3DXVECTOR3(Gaps[g].end.x,y,Gaps[g].start.y);

		const D3DXVECTOR3 etl=tl+extrude_dir;
		const D3DXVECTOR3 etr=tr+extrude_dir;
		const D3DXVECTOR3 ebr=br+extrude_dir;
		const D3DXVECTOR3 ebl=bl+extrude_dir;

		const int tlp=AddPoint(tl);
		const int trp=AddPoint(tr);
		const int brp=AddPoint(br);
		const int blp=AddPoint(bl);

		const int etlp=AddPoint(etl);
		const int etrp=AddPoint(etr);
		const int ebrp=AddPoint(ebr);
		const int eblp=AddPoint(ebl);

		if(direction==true)
		{
			AddFace(tlp,etlp,etrp,trp);
			AddFace(trp,etrp,ebrp,brp);
			AddFace(brp,ebrp,eblp,blp);
			AddFace(blp,eblp,etlp,tlp);
		}
		else
		{
			AddFace(etlp,tlp,trp,etrp);
			AddFace(etrp,trp,brp,ebrp);
			AddFace(ebrp,brp,blp,eblp);
			AddFace(eblp,blp,tlp,etlp);
		}
	}
}

const void Map::Z_2D_3D_Sill(const float z,const bool direction)
{

	const D3DXVECTOR3 extrude_dir = (direction==true) ? D3DXVECTOR3(0,0,1) : D3DXVECTOR3(0,0,-1);

	for (int g=0; g!=Gaps.size(); ++g)
	{
		const D3DXVECTOR3 tl=D3DXVECTOR3(Gaps[g].start.x,Gaps[g].start.y,z);
		const D3DXVECTOR3 tr=D3DXVECTOR3(Gaps[g].start.x,Gaps[g].end.y,z);
		const D3DXVECTOR3 br=D3DXVECTOR3(Gaps[g].end.x,Gaps[g].end.y,z);
		const D3DXVECTOR3 bl=D3DXVECTOR3(Gaps[g].end.x,Gaps[g].start.y,z);

		const D3DXVECTOR3 etl=tl+extrude_dir;
		const D3DXVECTOR3 etr=tr+extrude_dir;
		const D3DXVECTOR3 ebr=br+extrude_dir;
		const D3DXVECTOR3 ebl=bl+extrude_dir;

		const int tlp=AddPoint(tl);
		const int trp=AddPoint(tr);
		const int brp=AddPoint(br);
		const int blp=AddPoint(bl);

		const int etlp=AddPoint(etl);
		const int etrp=AddPoint(etr);
		const int ebrp=AddPoint(ebr);
		const int eblp=AddPoint(ebl);

		if(direction==false)
		{
			AddFace(tlp,etlp,etrp,trp);
			AddFace(trp,etrp,ebrp,brp);
			AddFace(brp,ebrp,eblp,blp);
			AddFace(blp,eblp,etlp,tlp);
		}
		else
		{
			AddFace(etlp,tlp,trp,etrp);
			AddFace(etrp,trp,brp,ebrp);
			AddFace(ebrp,brp,blp,eblp);
			AddFace(eblp,blp,tlp,etlp);
		}
	}

}

const void Map::AddSillsX(const int gap, const float pos, const bool direction)
{
	FindGaps(gap);
	X_2D_3D_Sill(pos, direction);
}

const void Map::AddSillsY(const int gap,const float pos,const bool direction)
{
	FindGaps(gap);
	Y_2D_3D_Sill(pos,direction);
}

const void Map::AddSillsZ(const int gap,const float pos,const bool direction)
{
	FindGaps(gap);
	Z_2D_3D_Sill(pos,direction);
}


const void Map::ExtendX(D3DXVECTOR3 &first, D3DXVECTOR3 &second, D3DXVECTOR3 &third, D3DXVECTOR3 &fourth, const D3DXVECTOR3 &start, const D3DXVECTOR3 &end)
{
	if (first.x==start.x) first.x-=1.0f;
	if (second.x==start.x) second.x-=1.0f;
	if (third.x==start.x) third.x-=1.0f;
	if (fourth.x==start.x) fourth.x-=1.0f;

	if (first.x==end.x) first.x+=1.0f;
	if (second.x==end.x) second.x+=1.0f;
	if (third.x==end.x) third.x+=1.0f;
	if (fourth.x==end.x) fourth.x+=1.0f;
}

const void Map::ExtendY(D3DXVECTOR3 &first,D3DXVECTOR3 &second,D3DXVECTOR3 &third,D3DXVECTOR3 &fourth,const D3DXVECTOR3 &start,const D3DXVECTOR3 &end)
{
	if (first.y==start.y) first.y-=1.0f;
	if (second.y==start.y) second.y-=1.0f;
	if (third.y==start.y) third.y-=1.0f;
	if (fourth.y==start.y) fourth.y-=1.0f;

	if (first.y==end.y) first.y+=1.0f;
	if (second.y==end.y) second.y+=1.0f;
	if (third.y==end.y) third.y+=1.0f;
	if (fourth.y==end.y) fourth.y+=1.0f;
}

const void Map::ExtendZ(D3DXVECTOR3 &first,D3DXVECTOR3 &second,D3DXVECTOR3 &third,D3DXVECTOR3 &fourth,const D3DXVECTOR3 &start,const D3DXVECTOR3 &end)
{
	if (first.z==start.z) first.z-=1.0f;
	if (second.z==start.z) second.z-=1.0f;
	if (third.z==start.z) third.z-=1.0f;
	if (fourth.z==start.z) fourth.z-=1.0f;

	if (first.z==end.z) first.z+=1.0f;
	if (second.z==end.z) second.z+=1.0f;
	if (third.z==end.z) third.z+=1.0f;
	if (fourth.z==end.z) fourth.z+=1.0f;
}

const void Map::AddExtrudedWall(const D3DXVECTOR3 &first, const D3DXVECTOR3 &second, const D3DXVECTOR3 &third, const D3DXVECTOR3 &fourth, const D3DXVECTOR3 &direction,const D3DXVECTOR3 &start,const D3DXVECTOR3 &end)
{
	D3DXVECTOR3 firstex=first+direction;
	D3DXVECTOR3 secondex=second+direction;
	D3DXVECTOR3 thirdex=third+direction;
	D3DXVECTOR3 fourthex=fourth+direction;

	if ((firstex.x==secondex.x) && (firstex.x==thirdex.x) && (firstex.x==fourthex.x))
	{
		ExtendY(firstex,secondex,thirdex,fourthex,start,end);
		ExtendZ(firstex,secondex,thirdex,fourthex,start,end);
	}
	else if ((firstex.y==secondex.y) && (firstex.y==thirdex.y) && (firstex.y==fourthex.y))
	{
		ExtendX(firstex,secondex,thirdex,fourthex,start,end);
		ExtendZ(firstex,secondex,thirdex,fourthex,start,end);
	}
	else if ((firstex.z==secondex.z) && (firstex.z==thirdex.z) && (firstex.z==fourthex.z))
	{
		ExtendX(firstex,secondex,thirdex,fourthex,start,end);
		ExtendY(firstex,secondex,thirdex,fourthex,start,end);
	}
	const int firstp=AddPoint(firstex);
	const int secondp=AddPoint(secondex);
	const int thirdp=AddPoint(thirdex);
	const int fourthp=AddPoint(fourthex);
	AddFace(firstp,secondp,thirdp,fourthp);
}

const void Map::AddOutsideWalls(const D3DXVECTOR3 &start, const D3DXVECTOR3 &end)
{
	const int PartitionIndexSize=PartitionIndex.size();
	for (int p=0; p!=PartitionIndexSize; ++p)
	{
		const D3DXVECTOR3 first=Point[PartitionIndex[p].first];
		const D3DXVECTOR3 second=Point[PartitionIndex[p].second];
		const D3DXVECTOR3 third=Point[PartitionIndex[p].third];
		const D3DXVECTOR3 fourth=Point[PartitionIndex[p].fourth];

		if ((first.x==second.x) && (first.x==third.x) && (first.x==fourth.x))
		{
			if (first.x==start.x)
			{
				AddExtrudedWall(first, second, third, fourth,D3DXVECTOR3(-1,0,0),start,end);
			}
			else
			{
				AddExtrudedWall(first,second,third,fourth,D3DXVECTOR3(+1,0,0),start,end);
			}
		}
		else if ((first.y==second.y) && (first.y==third.y) && (first.y==fourth.y))
		{
			if (first.y==start.y)
			{
				AddExtrudedWall(first,second,third,fourth,D3DXVECTOR3(0,-1,0),start,end);
			}
			else
			{
				AddExtrudedWall(first,second,third,fourth,D3DXVECTOR3(0,+1,0),start,end);
			}

		}
		else if ((first.z==second.z) && (first.z==third.z) && (first.z==fourth.z))
		{
			if (first.z==start.z)
			{
				AddExtrudedWall(first,second,third,fourth,D3DXVECTOR3(0,0,-1),start,end);
			}
			else
			{
				AddExtrudedWall(first,second,third,fourth,D3DXVECTOR3(0,0,+1),start,end);
			}
		}
	}
}

const void Map::BuildObject(const std::vector<unsigned long long> shape,const int object)
{
	fprintf(file,"shapes %i\n",shape.size());

	Point.clear();
	Triangle.clear();

	for(int s=0; s!=shape.size(); ++s)
	{
		const BLOCK block=Block(shape[s]);

		if(block.slope!=SLP_NONE)
		{
			if(block.slope==SLP_HR)
			{
				BuildHorSlope(block.start,block.end,block.wall,false,false);
			}
			else // SLP_VR
			{
				//				BuildVerSlope(block.start,block.end,block.wall);
			}
			continue;
		}

		Gap.clear();
		if(block.gap==true)
		{
			++s;
			GAP_HDR gap_header=GapHeader(shape[s]);

			for(int g=0; g!=gap_header.gaps/2; ++g)
			{
				++s;
				GapDetail(shape[s],&gap_header.start[(g*2)+1],&gap_header.end[(g*2)+1]);
			}
			for(int g=0; g!=gap_header.gaps; ++g)
			{
				Gap.push_back(AddGapSide(gap_header.side[g],gap_header.start[g],gap_header.end[g]));
			}
		}

		if (block.wall.left==true)
		{
			BuildLeftWalls(block.start,block.end,block.inside);
			if ( (block.inside==true) && (block.outside==true) ) AddOutsideWalls(block.start,block.end);
		}
		if (block.wall.right==true) 
		{
			BuildRightWalls(block.start,block.end,block.inside);
			if ( (block.inside==true) && (block.outside==true) ) AddOutsideWalls(block.start,block.end);
		}
		if (block.wall.top==true) 
		{
			BuildTopWalls(block.start,block.end,block.inside);
			if ( (block.inside==true) && (block.outside==true) ) AddOutsideWalls(block.start,block.end);
		}
		if (block.wall.bottom==true) 
		{	
			BuildBottomWalls(block.start,block.end,block.inside);
			if ( (block.inside==true) && (block.outside==true) ) AddOutsideWalls(block.start,block.end);
		}
		if (block.wall.front==true) 
		{
			BuildFrontWalls(block.start,block.end,block.inside);
			if ( (block.inside==true) && (block.outside==true) ) AddOutsideWalls(block.start,block.end);
		}
		if (block.wall.back==true) 
		{	
			BuildBackWalls(block.start,block.end,block.inside);
			if ( (block.inside==true) && (block.outside==true) ) AddOutsideWalls(block.start,block.end);
		}

		if (block.extrude==true)
		{
			AddSillsX(GP_LT, block.start.x-1, true);
			AddSillsX(GP_RT, block.end.x+1, false);
			AddSillsY(GP_TP,block.end.y+1,false);
			AddSillsY(GP_BM,block.start.y-1,true);
			AddSillsZ(GP_FT,block.start.z-1,true);
			AddSillsZ(GP_BK,block.end.z+1,false);
		}
	}

	for (int p=0; p!=Point.size(); ++p)
	{
		screen.Vertex[p].Location=Point[p];
		screen.Vertex[p].Colour=D3DCOLOR_XRGB(rand(),rand(),rand());
	}
	memcpy(&screen.Index[0],&Triangle[0],sizeof(screen.Index[0])*Triangle.size());
	screen.CreateObject(Point.size(),Triangle.size()/3,object);

	ModelMesh[object].Point=Point;
	ModelMesh[object].Triangle=Triangle;

//	fprintf(file,"ts %i cs %i\n",Triangle.size()/3,Colliders.size());
}

const BLOCK Map::Block(const unsigned long long Block)
{
	BLOCK block;
//	fprintf(file,"blk %i %i %i\n",(Block >>S_X) &255,(Block >>S_Y) &255,(Block >>S_Z) &255);
	block.start=D3DXVECTOR3( (((Block >>S_X) &255) *B_SCL), (((Block >>S_Y) &255) *B_SCL), (((Block >>S_Z) &255) *B_SCL) );
	block.end=D3DXVECTOR3( (((Block >>E_X) &255) *B_SCL), (((Block >>E_Y) &255) *B_SCL), (((Block >>E_Z) &255) *B_SCL) );
	block.wall.top=(Block >>W_TP) &YS;
	block.wall.bottom=(Block >>W_BM) &YS;
	block.wall.left=(Block >>W_LT) &YS;
	block.wall.right=(Block >>W_RT) &YS;
	block.wall.front=(Block >>W_FT) &YS;
	block.wall.back=(Block >>W_BK) &YS;
	block.gap=(Block >>GP) &YS;
	block.slope=(Block >>SLP) &3;
	block.inside=Block &YS;
	block.outside=(Block >>W_OUT) &YS;
	block.extrude=(Block >>W_EXT) &YS;
	block.first_slope=block.outside;
	block.second_slope=block.extrude;
//	fprintf(file,"block gap %i\n",block.gap);
	return block;
}

const GAP_HDR Map::GapHeader(const unsigned long long GapHeader)
{
	GAP_HDR gap_header;
	gap_header.gaps=(GapHeader >>GH_CNT) &15;
	gap_header.side[0]=(GapHeader >>GH_S1) &7;
	gap_header.side[1]=(GapHeader >>GH_S2) &7;
	gap_header.side[2]=(GapHeader >>GH_S3) &7;
	gap_header.side[3]=(GapHeader >>GH_S4) &7;
	gap_header.side[4]=(GapHeader >>GH_S5) &7;
	gap_header.side[5]=(GapHeader >>GH_S6) &7;
	gap_header.side[6]=(GapHeader >>GH_S7) &7;
	gap_header.side[7]=(GapHeader >>GH_S8) &7;
	gap_header.side[8]=(GapHeader >>GH_S9) &7;
	gap_header.start[0]=D3DXVECTOR2((((GapHeader >>GH_SX) &255) *B_SCL),(((GapHeader >>GH_SY) &255) *B_SCL));
	gap_header.end[0]=D3DXVECTOR2((((GapHeader >>GH_EX) &255) *B_SCL),(((GapHeader >>GH_EY) &255) *B_SCL));
	return gap_header;
}

const void Map::GapDetail(const unsigned long long GapDetail, D3DXVECTOR2 *start, D3DXVECTOR2 *end)
{
	start[0]=D3DXVECTOR2((((GapDetail >>GD_SX1) &255) *B_SCL),(((GapDetail >>GD_SY1) &255) *B_SCL));
	end[0]=D3DXVECTOR2((((GapDetail >>GD_EX1) &255) *B_SCL),(((GapDetail >>GD_EY1) &255) *B_SCL));
	start[1]=D3DXVECTOR2((((GapDetail >>GD_SX2) &255) *B_SCL),(((GapDetail >>GD_SY2) &255) *B_SCL));
	end[1]=D3DXVECTOR2((((GapDetail >>GD_EX2) &255) *B_SCL),(((GapDetail >>GD_EY2) &255) *B_SCL));
}

const GAP Map::AddGap(const float sx,const float sy,const float ex,const float ey)
{
	GAP gap;
	gap.start.x=sx;
	gap.start.y=sy;
	gap.end.x=ex;
	gap.end.y=ey;
	return gap;
}

const void Map::FindGaps(const int side)
{
	Gaps.clear();

	for (int g=0; g!=Gap.size(); ++g)
	{
		if (Gap[g].side==side)
		{
			Gaps.push_back(AddGap(Gap[g].start.x,Gap[g].start.y,Gap[g].end.x,Gap[g].end.y));
		}
	}
}

const void Map::AddGapX(const float x)
{
	for (int g=0; g!=GapX.size(); ++g)
	{
		if (GapX[g]==x)
		{
			return;
		}
	}
	GapX.push_back(x);
}

const void Map::AddGapY(const float y)
{
	for (int g=0; g!=GapY.size(); ++g)
	{
		if (GapY[g]==y)
		{
			return;
		}
	}
	GapY.push_back(y);
}

const void Map::AddGaps(const float sx,const float ex,const float sy,const float ey)
{
	GapX.clear();
	GapY.clear();

	AddGapX(sx);
	AddGapX(ex);
	AddGapY(sy);
	AddGapY(ey);

	for (int g=0; g!=Gaps.size(); ++g)
	{
		AddGapX(Gaps[g].start.x);
		AddGapX(Gaps[g].end.x);
		AddGapY(Gaps[g].start.y);
		AddGapY(Gaps[g].end.y);
	}
	std::sort(GapX.begin(),GapX.end());
	std::sort(GapY.begin(),GapY.end());
}

const void Map::FindPartitions()
{
	Partitions.clear();
	for(int x=0; x!=GapX.size()-1; ++x)
	{
		const float sx=GapX[x];
		const float ex=GapX[x+1];
		for(int y=0; y!=GapY.size()-1; ++y)
		{
			const float sy=GapY[y];
			const float ey=GapY[y+1];
			Partitions.push_back(AddGap(sx,sy,ex,ey));
		}
	}
}

const void Map::FindUsedPartitions()
{
	UsedPartitions.clear();
	for(int p=0; p!=Partitions.size(); ++p)
	{
		bool found=false;
		for(int g=0; g!=Gaps.size(); ++g)
		{
			if((Gaps[g].start.x <= Partitions[p].start.x) && (Gaps[g].end.x >= Partitions[p].end.x) && (Gaps[g].start.y <= Partitions[p].start.y) && (Gaps[g].end.y >= Partitions[p].end.y))
			{
				found=true;
				break;
			}
		}
		if(found==false)
		{
			UsedPartitions.push_back(Partitions[p]);
		}
	}
}

const void Map::LinkPartitions()
{
	for(bool removed=true; removed==true; )
	{
		removed=false;
		for(int p=0; (p!=UsedPartitions.size()) && (removed==false); ++p)
		{
			for(int q=0; (q!=UsedPartitions.size()) && (removed==false); ++q)
			{
				if(p!=q)
				{
					if((UsedPartitions[p].end.x==UsedPartitions[q].start.x) && (UsedPartitions[p].start.y==UsedPartitions[q].start.y) && (UsedPartitions[p].end.y==UsedPartitions[q].end.y))
					{
						UsedPartitions[p].end.x=UsedPartitions[q].end.x;
						UsedPartitions.erase(UsedPartitions.begin() + q);
						removed=true;
					}
					else if((UsedPartitions[p].end.y==UsedPartitions[q].start.y) && (UsedPartitions[p].start.x==UsedPartitions[q].start.x) && (UsedPartitions[p].end.x==UsedPartitions[q].end.x))
					{
						UsedPartitions[p].end.y=UsedPartitions[q].end.y;
						UsedPartitions.erase(UsedPartitions.begin() + q);
						removed=true;
					}
				}
			}
		}
	}
}

const ROOM Map::Room(const unsigned long long Room)
{
	ROOM room;
	room.location.x=(Room >>RM_X) &RM_LIMIT;
	room.location.y=(Room >>RM_Y) &RM_LIMIT;
	room.location.z=(Room >>RM_Z) &RM_LIMIT;
	room.location*=B_SCL;
	room.object=(Room >>RM_OBJ) &RM_LIMIT;
	return room;
}
