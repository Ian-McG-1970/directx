#include "load.h"
#include "d3d8_screen.h"
#include "map.h"

extern FILE *file;
extern Screen screen;
extern Map map;

void Load::Setup()
{
	fprintf(file, "Load setup\n");
}

Load::~Load()
{
	fprintf(file, "Load shutdown\n");
}

const void Load::Model(const char *name, const int object)
{
	if ((fileopen=fopen(name, "r"))==NULL) return;

	fscanf(fileopen, "%s", rec);
	const int vertices=atol(rec);
	fscanf(fileopen, "%s", rec);
	const int triangles=atol(rec);

	for (int x=0; x!=vertices; ++x)
	{
		fscanf(fileopen, "%s", rec);
		screen.Vertex[x].Location.x=atof(rec);
		fscanf(fileopen, "%s", rec);
		screen.Vertex[x].Location.y=atof(rec);
		fscanf(fileopen, "%s", rec);
		screen.Vertex[x].Location.z=atof(rec);

		screen.Vertex[x].Colour=D3DCOLOR_XRGB(rand(),rand(),rand());
	}

	for (int y=0, z=0; y!=triangles; ++y, z+=3)
	{
		fscanf(fileopen, "%s", rec);
		screen.Index[z] =atol(rec);
		fscanf(fileopen, "%s", rec);
		screen.Index[z+1] =atol(rec);
		fscanf(fileopen, "%s", rec);
		screen.Index[z+2] =atol(rec);
	}

	fclose(fileopen);
	screen.CreateObject(vertices, triangles, object);
}
